#include "stdafx.h"

extern "C" 
{
	MYINDICATOR_API int init(const PIN_INDICATORINFO in, POUT_INDICATORINFO out)
	{
		return RLT_OK;
	}

	MYINDICATOR_API void deinit()
	{
		;
	}

	MYINDICATOR_API int	calc(PCALCINDICATORINFO in)
	{
		return 0;
	}
}