// Platform.cpp : main source file for Platform.exe
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Platform.h"
#include "PlatformModule.h"
#include "../Base/Holiday.h"

//////////////////////////////////////////////////////////////////////////

Platform::Platform()
{
	
}

Platform::~Platform()
{

}

long Platform::Init()
{
	long rlt = UXModule::Init();
	SetAppName(_Module.GetName());
	SetAppPath(_Module.GetAppPath());
	SetAppData(_Module.GetAppData());

	Base::Init();

	TCHAR szTemp[MAX_PATH];
	TCHAR szPath[MAX_PATH];

	CurrentDirectory curdir;

	//THEME
	memset(szTemp, 0, sizeof(szTemp));
	memset(szPath, 0, sizeof(szPath));
	if(RLT_OK == ReadValue(_T("name"), szTemp, MAX_PATH, _T("root/theme"), APPFILE)) {
		_stprintf(szPath, _T("%s\\theme\\%s"), _Module.GetAppData(), szTemp);
	}
	if (!PathFileExists(szPath)) {
		_stprintf(szPath, _T("%s\\default"), _Module.GetAppPath());
	}
	curdir.SetCurrentDirectory(szPath);
	Markup* xml = new Markup(_T("theme.xml"));
	m_Name2pMarkup[THEMEFILE] = xml;
	xml->Find(UIX_SKIN_ROOT);
	xml->IntoElem();
	LoadSkin((LPCTSTR)xml, XML_FLAG_MARKUP);
	xml->OutofElem();
	//UxModule::LoadSkin(_T("theme.xml"));
	curdir.RestoreCurrentDirectory();

	//����ģ��
	m_pDataManager = new XDataManager();

	//��¼ģ��
	TCHAR szLoginPath[MAX_PATH] = {0};
	_tmakepath(szLoginPath, NULL, _Module.GetAppPath(), _T("Login.dll"), NULL);
	m_hLogin = _Module.LoadLibrary(szLoginPath);

	//����ָ��ģ��
	TCHAR szIndicatorPath[MAX_PATH] = {0};
	_tmakepath(szIndicatorPath, NULL, _Module.GetAppPath(), _T("Indicator.dll"), NULL);
	m_hIndicator = _Module.LoadLibrary(szIndicatorPath);
	
	return rlt;
}

void Platform::Term()
{
	Base::Term();

	UXModule::Term();
}

void Platform::Login(HWND hParent)
{
	Objecter* pLogin = GetLoginPtr();
	if (pLogin) {
		CString strXmlFile;
		strXmlFile.Format(_T("%s\\AboutDlg.xml"), _pUISkinManager->GetSkinPath());

		DoLoginPtr objPtr = new DoLogin;
		objPtr->modal = 0;
		objPtr->hParent = hParent;
		objPtr->strParam = strXmlFile;
		SendEvent(pLogin, EVT_PLAT_CALL, MAKEVALUE(MCALL_PLAT_LOGIN,CCALL_LOGIN_LOGIN), objPtr);
	}
}

long Platform::OnCreateThread(CreateThreadInfoPtr& objPtr)
{
#if USES_MULTITHREAD
	UIMultiEvtMessageLoop* pMsgLoop = dynamic_cast<UIMultiEvtMessageLoop*>(_Module.GetMessageLoop());
	if(pMsgLoop) {
		pMsgLoop->AddThread(
			_MultiThreadMgr.AddThread(objPtr->Name,(LPTSTR)objPtr->cmdline.c_str(),objPtr->show));
	}
#endif//
	return RLT_UNKNOWN;
}

long Platform::OnDestroyThread(DestroyThreadInfoPtr& objPtr)
{
	return RLT_UNKNOWN;
}
