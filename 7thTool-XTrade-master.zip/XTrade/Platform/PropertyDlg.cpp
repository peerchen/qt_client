// aboutdlg.cpp : implementation of the CPrppertyDlg class
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "resource.h"

#include "PropertyDlg.h"


// LRESULT CPrppertyDlg::OnInitDialog(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& bHandled)
// {
// 	bHandled = FALSE;
// 	CenterWindow(GetParent());
// 	return TRUE;
// }
// 
// LRESULT CPrppertyDlg::OnCloseCmd(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
// {
// 	EndDialog(wID);
// 	return 0;
// }
