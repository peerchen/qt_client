//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Platform.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDS_OPEN_ERROR                  129
#define IDR_TABTOOLBAR                  203
#define IDB_PAGEIMAGE                   204
#define IDR_MAINFRAME_BIG               205
#define IDR_GO                          207
#define IDB_DEFAULT                     211
#define IDB_BITMAP_BKGND                212
#define IDI_ICON1                       213
#define IDR_MENU_EDIT_PANE              216
#define IDR_MENU_EDIT                   216
#define IDC_CURSOR_DRAW                 218
#define ID_LINKS_FIRST                  31000
#define ID_LINKS_MICROSOFT              31000
#define ID_LINKS_MSDN                   31001
#define ID_LINKS_LIVE                   31002
#define ID_LINKS_UPDATE                 31003
#define ID_LINKS_WTL                    31004
#define ID_LINKS_LAST                   31099
#define ID_LINKS_URL_FIRST              31100
#define ID_LINKS_URL_MICROSOFT          31100
#define ID_LINKS_URL_MSDN               31101
#define ID_LINKS_URL_LIVE               31102
#define ID_LINKS_URL_UPDATE             31103
#define ID_LINKS_URL_WTL                31104
#define ID_LINKS_URL_LAST               31199
#define ID_WINDOW_CLOSE                 32773
#define ID_WINDOW_CLOSE_ALL             32776
#define ID_BROWSER_BACK                 32777
#define ID_BROWSER_FORWARD              32778
#define ID_BROWSER_REFRESH              32779
#define ID_BROWSER_STOP                 32782
#define ID_WINDOW_SHOW_VIEWS            32783
#define ID_BROWSER_HOME                 32791
#define ID_BROWSER_SEARCH               32795
#define ID_VIEW_ADDRESS_BAR             32796
#define ID_GO                           32797
#define IDS_LOADING                     32798
#define IDS_ADDRESS                     32799
#define IDS_LINKS                       32800
#define IDS_BLANK_URL                   32801
#define IDS_BLANK_TITLE                 32802
#define ID_VIEW_LOCK_TOOLBARS           32807
#define ID_VIEW_LINKS_BAR               32808
#define ID_EDIT_PANE_START_STOP         32812
#define ID_EDIT_PANE_INSERTLR_2         32814
#define ID_EDIT_PANE_INSERTLR_3         32815
#define ID_EDIT_PANE_INSERTLR_4         32816
#define ID_EDIT_PANE_INSERTTB_2         32817
#define ID_EDIT_PANE_INSERTTB_3         32818
#define ID_EDIT_PANE_INSERTTB_4         32819
#define ID_EDIT_PANE_DELETE             32820
#define ID_EDIT_PANE_LR_SCALE           32821
#define ID_EDIT_PANE_TB_SCALE           32823
#define ID_EDIT_PANE_L_SIZED            32824
#define ID_EDIT_PANE_R_SIZED            32825
#define ID_EDIT_PANE_T_SIZED            32826
#define ID_EDIT_PANE_B_SIZED            32827
#define ID_EDIT_VIEW_DEBUG              32829
#define ID_EDIT_VIEW_GROUP1             32831
#define ID_EDIT_VIEW_GROUP2             32832
#define ID_EDIT_VIEW_GROUP3             32833
#define ID_EDIT_VIEW_GROUP4             32834
#define ID_EDIT_VIEW_GROUP              32835

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        219
#define _APS_NEXT_COMMAND_VALUE         32836
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
