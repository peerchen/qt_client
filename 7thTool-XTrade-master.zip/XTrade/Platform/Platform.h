// Platform.h
//
/////////////////////////////////////////////////////////////////////////////

#pragma once

#include <Platform/XPlatform.h>
#include "resource.h"
#include <XLib/UIXModule.h>
#include "MainFrm.h"

class Platform 
	: public XPlatform
	, public UIXModuleT<Platform>
{
	typedef XPlatform Base;
	typedef UIXModuleT<Platform> UXModule;
public:
	Platform();
	~Platform();

	long Init();
	void Term();

public:
	void Login(HWND hParent);

protected:
	virtual long OnCreateThread(CreateThreadInfoPtr& objPtr);
	virtual long OnDestroyThread(DestroyThreadInfoPtr& objPtr);
};

#define _PlatformPtr ((Platform*)_Platform)
