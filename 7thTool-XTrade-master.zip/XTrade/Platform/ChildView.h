// PlatformView.h : interface of the CPlatformView class
//
/////////////////////////////////////////////////////////////////////////////

#pragma once

#ifndef _H_CHILDVIEW_H_
#define _H_CHILDVIEW_H_

#include <XLib/UIXCtrl.h>

class QTabCtrl 
	: public UIWndImpl<QTabCtrl,UITabCtrl>
	, public UITabCtrlOwnerDraw<QTabCtrl>
{
	typedef QTabCtrl This;
	typedef UIWndImpl<QTabCtrl,UITabCtrl> Base;
public:

protected:
	void _GetTrapezoid(const RECT& rc, POINT* pts) const
	{
		pts[0].x = rc.left;
		pts[0].y = rc.top;
		pts[1].x = rc.left + 4;
		pts[1].y = rc.bottom;
		pts[2].x = rc.right - 4;
		pts[2].y = rc.bottom;
		pts[3].x = rc.right, rc.top;
		pts[3].y = rc.top;
	}

	BEGIN_MSG_MAP(This)
		CHAIN_MSG_MAP(UITabCtrlOwnerDraw<QTabCtrl>)
		CHAIN_MSG_MAP(Base)
		//DEFAULT_REFLECTION_HANDLER()
	END_MSG_MAP()

	void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
};

class CChildView 
	: public CTabViewImpl<CChildView>
	, public UIEraseBkgnd<CChildView>
{
	typedef CChildView This;
	typedef CTabViewImpl<CChildView> Base;
public:
	DECLARE_WND_CLASS_EX(_T("Platform_ChildView"), 0, COLOR_APPWORKSPACE)

	CToolBarCtrl m_wndTB;
	int m_cxTB;

	CString m_strTooltip;

	QTabCtrl m_wndTab;

	CChildView();

	BOOL PreTranslateMessage(MSG* pMsg);

	BEGIN_MSG_MAP(This)
		CHAIN_MSG_MAP(UIEraseBkgnd<CChildView>)
		CHAIN_MSG_MAP(Base)
		ALT_MSG_MAP(1)
		CHAIN_MSG_MAP_ALT(Base,1)
	END_MSG_MAP()

	BOOL OnEraseBkgnd(HDC hdc);

	int CalcTabHeight();
	bool CreateTabControl();
	void UpdateLayout();
	void ShowTabControl(bool bShow);
	void UpdateTooltipText(LPNMTTDISPINFO pTTDI);
};

#endif//_H_CHILDVIEW_H_
