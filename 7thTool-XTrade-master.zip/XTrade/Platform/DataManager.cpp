#include "stdafx.h"
#include "DataManager.h"

//////////////////////////////////////////////////////////////////////////
///MyDataEngine

DataManager::DataManager():m_AccountListPtr(new AccountListInfo()),m_ServerListPtr(new ServerListInfo())
{
	
}

DataManager::~DataManager()
{
	//SectionLocker Lock(&m_Section);
	ASSERT(m_Requests.left.empty()&&m_Requests.right.empty());
}

long DataManager::Instance()
{
	long rlt = RLT_OK;

	LoadFromFile();

	EvtDispatcher* pDispatcher = EvtDispatcher::GetEvtDispatcher();
	ASSERT(pDispatcher);
	pDispatcher->RegisterEvtIdler(this);

	return rlt;
}

void DataManager::Release()
{
	EvtDispatcher* pDispatcher = EvtDispatcher::GetEvtDispatcher();
	ASSERT(pDispatcher);
	pDispatcher->UnRegisterEvtIdler(this);

	EvtRequest::Clear(false);

	DeInit();

	SaveToFile();
}

void DataManager::LoadFromFile()
{
	
}

void DataManager::SaveToFile()
{
	
}

void DataManager::Init()
{

}

void DataManager::DeInit()
{

}

void DataManager::OnIdle()
{
	SectionLocker Lock(&m_Section);
	HisDataInfos::iterator it = m_HisDataInfos.begin();
	for (; it != m_HisDataInfos.end(); )
	{
		HisDataInfoPtr& tempPtr = (*it);
		if (tempPtr->DWDataPtr && tempPtr->DWDataPtr->__getRef() == 1) {
			it = m_HisDataInfos.erase(it);
			continue;
		}
		if (tempPtr->DataPtr->__getRef() == 1) {
			it = m_HisDataInfos.erase(it);
			continue;
		}
		++it;
	}
	Lock.Detach();
}

bool DataManager::AddAccount(const AccountInfoPtr & objPtr)
{
	return FindAccount(const_cast<AccountInfoPtr &>(objPtr),FIND_FLAG_ADD_IFNOTEXIST|FIND_FLAG_UPDATE_IFEXIST);
}

bool DataManager::RemoveAccount(const AccountInfoPtr & objPtr)
{
	return FindAccount(const_cast<AccountInfoPtr &>(objPtr),FIND_FLAG_REMOVE_IFEXIST);
}

bool DataManager::UpdateAccount(const AccountInfoPtr & objPtr)
{
	return FindAccount(const_cast<AccountInfoPtr &>(objPtr),FIND_FLAG_UPDATE_IFEXIST);
}

bool DataManager::FindAccount(AccountInfoPtr & objPtr, UINT nFlags)
{
	SectionLocker Lock(&m_Section);
	bool ret = false;
	std::vector<AccountInfoPtr>::iterator it = m_AccountListPtr->AccountList.begin();
	for (; it!=m_AccountListPtr->AccountList.end(); ++it)
	{
		const AccountInfoPtr & tempPtr = *it;
		if (stricmp(objPtr->strName.c_str(),tempPtr->strName.c_str())==0) {
			if (stricmp(objPtr->strUser.c_str(),tempPtr->strUser.c_str())==0) {
				if (nFlags&FIND_FLAG_UPDATE_IFEXIST) {
					*it = objPtr;
				} else if (nFlags&FIND_FLAG_GET_IFEXIST) {
					objPtr = *it;
				}
				ret = true;
				break;
			}
		}
	}
	if (it==m_AccountListPtr->AccountList.end()) {
		if (nFlags&FIND_FLAG_ADD_IFNOTEXIST) {
			m_AccountListPtr->AccountList.push_back(objPtr);
			ret = true;
		} 
	} else {
		if (nFlags&FIND_FLAG_REMOVE_IFEXIST) {
			m_AccountListPtr->AccountList.erase(it);
			ret = true;
		} 
	}
	return ret;
}

bool DataManager::AddServer(const ServerInfoPtr & objPtr)
{
	return FindServer(const_cast<ServerInfoPtr &>(objPtr),FIND_FLAG_ADD_IFNOTEXIST|FIND_FLAG_UPDATE_IFEXIST);
}

bool DataManager::RemoveServer(const ServerInfoPtr & objPtr)
{
	return FindServer(const_cast<ServerInfoPtr &>(objPtr),FIND_FLAG_REMOVE_IFEXIST);
}

bool DataManager::UpdateServer(const ServerInfoPtr & objPtr)
{
	return FindServer(const_cast<ServerInfoPtr &>(objPtr),FIND_FLAG_UPDATE_IFEXIST);
}

bool DataManager::FindServer(ServerInfoPtr & objPtr, UINT nFlags)
{
	SectionLocker Lock(&m_Section);
	bool ret = false;
	std::vector<ServerInfoPtr>::iterator it = m_ServerListPtr->ServerList.begin();
	for (; it!=m_ServerListPtr->ServerList.end(); ++it)
	{
		const ServerInfoPtr & tempPtr = *it;
		if (stricmp(objPtr->strName.c_str(),tempPtr->strName.c_str())==0) {
			if (stricmp(objPtr->strUser.c_str(),tempPtr->strUser.c_str())==0) {
				if (nFlags&FIND_FLAG_UPDATE_IFEXIST) {
					*it = objPtr;
				} else if (nFlags&FIND_FLAG_GET_IFEXIST) {
					objPtr = *it;
				}
				ret = true;
				break;
			}
		}
	}
	if (it==m_ServerListPtr->ServerList.end()) {
		if (nFlags&FIND_FLAG_ADD_IFNOTEXIST) {
			m_ServerListPtr->ServerList.push_back(objPtr);
			ret = true;
		} 
	} else {
		if (nFlags&FIND_FLAG_REMOVE_IFEXIST) {
			m_ServerListPtr->ServerList.erase(it);
			ret = true;
		} 
	}
	return ret;
}

DataHandler* DataManager::OpenHandler(LPCSTR lpszName, LPCSTR lpszUser)
{
	DataHandler* pHandler = Listener::OpenHandler(lpszName,lpszUser);
	if (pHandler) {
		AddHandler(pHandler);

		SectionLocker Lock(&m_Section);
		if (IsRegister(lpszName)) {
			pHandlers::iterator it = std::find(m_pRegisters.begin(),m_pRegisters.end(),pHandler);
			if (it==m_pRegisters.end()) {
				m_pRegisters.push_back(pHandler);
			}
		}
		if (IsExchange(lpszName)) {
			pHandlers::iterator it = std::find(m_pExchanges.begin(),m_pExchanges.end(),pHandler);
			if (it==m_pExchanges.end()) {
				m_pExchanges.push_back(pHandler);
			}
		}
		if (IsTrader(lpszName)) {
			pHandlers::iterator it = std::find(m_pTraders.begin(),m_pTraders.end(),pHandler);
			if (it==m_pTraders.end()) {
				m_pTraders.push_back(pHandler);
			}
		}
		Lock.Detach();
	}
	return pHandler;
}

void DataManager::CloseHandler(DataHandler* pHandler)
{
	SectionLocker Lock(&m_Section);
	pHandlers::iterator it;
	it = std::find(m_pRegisters.begin(),m_pRegisters.end(),pHandler);
	if (it!=m_pRegisters.end()) {
		m_pRegisters.erase(it);
	}
	it = std::find(m_pExchanges.begin(),m_pExchanges.end(),pHandler);
	if (it!=m_pExchanges.end()) {
		m_pExchanges.erase(it);
	}
	it = std::find(m_pTraders.begin(),m_pTraders.end(),pHandler);
	if (it!=m_pTraders.end()) {
		m_pTraders.erase(it);
	}
	Lock.Detach();

	Listener::RemoveHandler(pHandler);
	Listener::CloseHandler(pHandler);
}

DataHandler* DataManager::FindHandler(LPCSTR lpszName, LPCSTR lpszUser)
{
#ifdef _DEBUG
	DataHandler* pHandler = Listener::FindHandler(lpszName,lpszUser);
	ASSERT(pHandler);
	return pHandler;
#else
	return Listener::FindHandler(lpszName,lpszUser);
#endif//
}

BOOL DataManager::IsRegister(LPCSTR lpszName)
{
	char* src = (char*)lpszName;
	int srclen = strlen(lpszName);
	char* dst = "Register";
	int dstlen = strlen(dst);
	if (srclen>dstlen && strrnicmp(src+srclen,dst+dstlen,dstlen)==0) {
		return TRUE;
	}
	return FALSE;
}

BOOL DataManager::IsExchange(LPCSTR lpszName)
{
	unsigned char Id = Exchange2IdA(lpszName);
	if (Id!=0) {
		return TRUE;
	}
	return FALSE;
}

BOOL DataManager::IsTrader(LPCSTR lpszName)
{
	char* src = (char*)lpszName;
	int srclen = strlen(lpszName);
	char* dst = "Trader";
	int dstlen = strlen(dst);
	if (srclen>dstlen && strrnicmp(src+srclen,dst+dstlen,dstlen)==0) {
		return TRUE;
	}
	return FALSE;
}

BOOL DataManager::IsRegister(DataHandler* pHandler)
{
	SectionLocker Lock(&m_Section);
	if(std::find(m_pRegisters.begin(),m_pRegisters.end(),pHandler)!=m_pRegisters.end()) {
		return TRUE;
	}
	return FALSE;
}

BOOL DataManager::IsExchange(DataHandler* pHandler)
{
	SectionLocker Lock(&m_Section);
	if(std::find(m_pExchanges.begin(),m_pExchanges.end(),pHandler)!=m_pExchanges.end()) {
		return TRUE;
	}
	return FALSE;
}

BOOL DataManager::IsTrader(DataHandler* pHandler)
{
	SectionLocker Lock(&m_Section);
	if(std::find(m_pTraders.begin(),m_pTraders.end(),pHandler)!=m_pTraders.end()) {
		return TRUE;
	}
	return FALSE;
}

unsigned char DataManager::Exchange2IdA(const char* szExchange)
{
	unsigned char Id = 0;
	if (stricmp(szExchange,XEN_SHANGHAIA)==0) {
		Id = XSE_SH;
	} else if(stricmp(szExchange,XEN_SHENZHENA)==0) {
		Id = XSE_SZ;
	} else  if(stricmp(szExchange,XEN_CFA)==0) {
		Id = XFE_CF;
	}  else  if(stricmp(szExchange,XEN_ZX3XA)==0) {
		Id = XZX_XX;
	}
	return Id;
}

unsigned char DataManager::Exchange2IdW(const wchar_t* szExchange)
{
	unsigned char Id = 0;
	if (wcsicmp(szExchange,XEN_SHANGHAIW)==0) {
		Id = XSE_SH;
	} else if(wcsicmp(szExchange,XEN_SHENZHENW)==0) {
		Id = XSE_SZ;
	} else  if(wcsicmp(szExchange,XEN_CFW)==0) {
		Id = XFE_CF;
	}  else  if(wcsicmp(szExchange,XEN_ZX3XW)==0) {
		Id = XZX_XX;
	}
	return Id;
}

const char* DataManager::Id2ExchangeA(const unsigned char Id)
{
	const char* str = NULL;
	switch(Id)
	{
	case XSE_SH:
		str = XEN_SHANGHAIA;
		break;
	case XSE_SZ:
		str = XEN_SHENZHENA;
		break;
	case XFE_CF:
		str = XEN_CFA;
		break;
	case XZX_XX:
		str = XEN_ZX3XA;
		break;
	}
	return str;
}

const wchar_t* DataManager::Id2ExchangeW(const unsigned char Id)
{
	const wchar_t* str = NULL;
	switch(Id)
	{
	case XSE_SH:
		str = XEN_SHANGHAIW;
		break;
	case XSE_SZ:
		str = XEN_SHENZHENW;
		break;
	case XFE_CF:
		str = XEN_CFW;
		break;
	case XZX_XX:
		str = XEN_ZX3XW;
		break;
	}
	return str;
}

DataHandler* DataManager::FindExchangeBy(const int Pos)
{
	if (Pos>=0 && Pos<m_pExchanges.size()) {
		//ASSERT(m_pExchanges[Pos].IsOK());
		return m_pExchanges[Pos];
	}
	return NULL;
}

DataHandler* DataManager::FindExchangeBy(const char* szExchange)
{
	return FindHandler(szExchange);
}

DataHandler* DataManager::FindExchangeBy(const wchar_t* szExchange)
{
	char buf[MAX_EXCH_LENGTH+1] = {0};
	wc2mb(szExchange, MAX_EXCH_LENGTH, buf, MAX_EXCH_LENGTH, CP_OEMCP);
	return FindExchangeBy(buf);
}

DataHandler* DataManager::FindExchangeBy(unsigned char Exchange)
{
	return FindHandler(Id2ExchangeA(Exchange));
}

DataHandler* DataManager::FindExchangeBy(const COMREF & Commodity)
{
	switch (Commodity.Type)
	{
	case COMREF_TYPE_STRUCT:
		return FindExchangeBy(Commodity.Exchange);
		break;
	case COMREF_TYPE_SZEXCH:
		return FindExchangeBy(Commodity.Exch);
		break;
	case COMREF_TYPE_STRING:
		return FindExchangeBy(Commodity.String);
		break;
	default:
		return NULL;
	}
	return NULL;
}

void DataManager::OnRemoveRequest(const Event& Req,const Event& SubReq)
{ 
	DataHandler* pHandler = dynamic_cast<DataHandler*>(SubReq.dst);
	if (pHandler) {
		SendToHandler(pHandler, EVT_DE_REQUEST, REQUEST_DE_CANCEL, SubReq.objPtr);
	}
}

void DataManager::OnAddRequest(const Event& Req, const Event& SubReq)
{
	
}

void DataManager::OnUpdateRequest(const Event& Req, const Event& SubReq, long SubReqCount)
{
	RequestInfoPtr ReqPtr = RequestInfoPtr::dynamicCast(Req.objPtr);
	if (ReqPtr) {
		if (SubReqCount==0) {
			ReqPtr->SetFinishRate(100);
		} else {
			ReqPtr->SetFinishRate(1/SubReqCount);
		}
		switch(SubReq.value)
		{
		case NOTIFY_DE_RESPONSE_REGPUSH:
			{
			}
			break;
		case NOTIFY_DE_RESPONSE_FIELD_DATA:
			{
			}
			break;
		case NOTIFY_DE_RESPONSE_HISDATA:
			{
				if (ReqPtr->IsFinished()) {
					if(ReqPtr->IsChanged()) {
						REQ_HISDATAInfoPtr ReqHisDataPtr = REQ_HISDATAInfoPtr::dynamicCast(ReqPtr);
						if (ReqHisDataPtr) {
							CleanHisData(ReqHisDataPtr->Commodity, ReqHisDataPtr->Period);
						}
					} else {
						PRINTFL("NOTIFY_DE_RESPONSE_HISDATA:NoChange.");
					}
				}
			}
			break;
		default:
			break;
		}
		PostEvent(_PlatPtr,EVT_PLAT_NOTIFY,EvtRequest2ResponseValue(Req.value),Req.objPtr);
	}
}

void DataManager::OnOffline(OnlineInfoPtr& objPtr)
{//���ﲻ����������pHandler Online, pHandler���Զ������ģ������Ͽ����ӵ���������ղ���Offline��

}

void DataManager::OnInitData(OnlineInfoPtr& objPtr)
{//�����п��ܻ᲻ͣ���յ�pHandler�ĳ�ʼ������֪ͨ

}

void DataManager::OnOnline(OnlineInfoPtr& objPtr)
{//��¼���֪ͨ
	/*SectionLocker Lock(&m_Section);
	int i;
	if (IsRegister(objPtr->strName.c_str())) {
		//������ط��񣬱������������
		Init();

		i = 0;
		DataHandler* pExchange = NULL;
		while(pExchange = FindExchangeBy(i++))
		{
			objPtr->strName = pExchange->c_strof(STR_NAMEA);
			SendToHandler(pExchange, EVT_DE_SET, SET_DE_ONLINE, objPtr);
		}
	}*/
}

unsigned char DataManager::IsOnlineRegister(LPCSTR lpszName, LPCSTR lpszUser)
{
	if (lpszName && lpszName[0]) {
		OnlineInfoPtr objPtr = new OnlineInfo(lpszName,lpszUser,DE_OFFLINE);
		SendToHandler(_DataEngine,EVT_DE_GET,GET_DE_ONLINE,objPtr);
		return objPtr->bOnline;
	} else {
		OnlineInfoPtr objPtr = new OnlineInfo(lpszName,lpszUser,DE_OFFLINE);
		pHandlers::iterator it = m_pRegisters.begin();
		for (;it!=m_pRegisters.end();++it)
		{
			DataHandler* pHandler = *it;
			SendToHandler(pHandler,EVT_DE_GET,GET_DE_ONLINE,objPtr);
			if (objPtr->bOnline==DE_INITDATA) {
				return DE_INITDATA;
			}
		}
		return true;
	}
	return 0;
}

unsigned char DataManager::IsOnline(LPCSTR lpszName, LPCSTR lpszUser)
{
	if (lpszName && lpszName[0]) {
		OnlineInfoPtr objPtr = new OnlineInfo(lpszName,lpszUser,DE_OFFLINE);
		SendToHandler(_DataEngine,EVT_DE_GET,GET_DE_ONLINE,objPtr);
		return objPtr->bOnline;
	} else {
		OnlineInfoPtr objPtr = new OnlineInfo(lpszName,lpszUser,DE_OFFLINE);
		pHandlers::iterator it = m_pExchanges.begin();
		for (;it!=m_pExchanges.end();++it)
		{
			DataHandler* pHandler = *it;
			SendToHandler(pHandler,EVT_DE_GET,GET_DE_ONLINE,objPtr);
			if (objPtr->bOnline==DE_INITDATA) {
				return DE_INITDATA;
			}
		}
		return true;
	}
	return 0;
}

unsigned char DataManager::IsOnlineTrader(LPCSTR lpszName, LPCSTR lpszUser)
{
	if (lpszName && lpszName[0]) {
		OnlineInfoPtr objPtr = new OnlineInfo(lpszName,lpszUser,DE_OFFLINE);
		SendToHandler(_DataEngine,EVT_DE_GET,GET_DE_ONLINE,objPtr);
		return objPtr->bOnline;
	} else {
		OnlineInfoPtr objPtr = new OnlineInfo(lpszName,lpszUser,DE_OFFLINE);
		pHandlers::iterator it = m_pTraders.begin();
		for (;it!=m_pTraders.end();++it)
		{
			DataHandler* pHandler = *it;
			SendToHandler(pHandler,EVT_DE_GET,GET_DE_ONLINE,objPtr);
			if (objPtr->bOnline==DE_INITDATA) {
				return DE_INITDATA;
			}
		}
		return true;
	}
	return 0;
}

void DataManager::LoadSelfCommodity(LPCTSTR lpszFileName)
{
	int i,j;
	TCHAR szName[MAX_PATH],szAttr[MAX_PATH],szValue[1024];
	Markup xml;
	if (xml.Open(lpszFileName)) {
		for (i=0; i<KIND_INDEX_SELFMAX; i++)
		{
			_stprintf(szName, _T("Kind%d"), i);
			if(!xml.Find(szName)) {
				continue;
			}
			xml.IntoElem();
			if (i>=KIND_INDEX_SELFCOUNT) {
				KIND Kind = {0};
				Kind.Type = KIND_TYPE_USER;
				Kind.Exchange = 0;
				Kind.Index = i;
				xml.GetAttributeString(_T(""), _T("name"), Kind.Name, MAX_NAME_LENGTH);
				m_SelfKind[i] = KindInfo(Kind);
			} else {
				//
			}
			m_SelfCommoditys[i].resize(xml.GetAttributeT<COMREFLIST::size_type>(_T(""), _T("count"), 0));
			for (j=0;j<m_SelfCommoditys[i].size(); j++)
			{
				_stprintf(szName, _T("Commodity%d"), i);
				if(!xml.Find(szName)) {
					continue;
				}
				xml.IntoElem();
				//m_SelfCommoditys[i][j].Type = COMREF_TYPE_STRING;
				xml.GetAttributeString(_T(""), _T("name"), m_SelfCommoditys[i][j].Name, MAX_NAME_LENGTH);
				xml.GetAttributeString(_T(""), _T("code"), szValue, 1024);
				wc2mb(szValue, _tcslen(szValue), m_SelfCommoditys[i][j].String, 63);
				//DataHandler* pExchange = FindExchangeBy(m_SelfCommoditys[i][j].Exch);
				//ASSERT(pExchange);
				m_SelfCommoditys[i][j].Exchange = Exchange2IdA(m_SelfCommoditys[i][j].Exch);
				xml.OutofElem();
			}
			xml.OutofElem();
		}

		xml.Close();
	}
}

void DataManager::SaveSelfCommodity(LPCTSTR lpszFileName)
{
	int i,j;
	TCHAR szName[MAX_PATH],szAttr[MAX_PATH],szValue[1024];
	File::RemoveFile(lpszFileName);
	Markup xml;
	if (xml.Open(lpszFileName, TRUE)) {
		for (i=0; i<KIND_INDEX_SELFMAX; i++)
		{
			if (m_SelfKind[i].IsInvalid()) {
				continue;
			}
			_stprintf(szName, _T("Kind%d"), i);
			xml.New(szName);
			xml.IntoElem();
			if (i>=KIND_INDEX_SELFCOUNT) {
				xml.SetAttributeString(_T(""), _T("name"), (TCHAR*)m_SelfKind[i].GetName());
			}
			xml.SetAttributeT<COMREFLIST::size_type>(_T(""), _T("count"), m_SelfCommoditys[i].size());
			for (j=0;j<m_SelfCommoditys[i].size(); j++)
			{
				_stprintf(szName, _T("Commodity%d"), i);
				xml.New(szName);
				xml.IntoElem();
				xml.SetAttributeString(_T(""), _T("name"), m_SelfCommoditys[i][j].Name);
				_stprintf(szValue, _T("%s,%S"), Id2ExchangeW(m_SelfCommoditys[i][j].Exchange), m_SelfCommoditys[i][j].Code);
				xml.SetAttributeString(_T(""), _T("code"), szValue);
				xml.OutofElem();
			}
			xml.OutofElem();
		}

		xml.Close();
	}
}

long DataManager::RefHisData(HisDataInfoPtr& objPtr)
{
	if (!objPtr) {
		return RLT_UNKNOWN;
	}

	SectionLocker Lock(&m_Section);

	int find = 0;
	HisDataInfos::iterator it = m_HisDataInfos.begin();
	for (; it != m_HisDataInfos.end(); ++it)
	{
		HisDataInfoPtr& tempPtr = (*it);
		if (tempPtr->Commodity == objPtr->Commodity) {
			if (tempPtr->Period == objPtr->Period && tempPtr->PeriodEx == objPtr->PeriodEx) {
				find = 1;
				objPtr->DataPtr = tempPtr->DataPtr;
				objPtr->WeightPtr = tempPtr->WeightPtr;
				if (((tempPtr->DWType==objPtr->DWType) || (tempPtr->DWType==DW_NONE && objPtr->DWType==DW_FORWARD) || (tempPtr->DWType==DW_FORWARD && objPtr->DWType==DW_NONE)) 
					&& tempPtr->DWDate == objPtr->DWDate) {
						objPtr->DWDataPtr = tempPtr->DWDataPtr;
						find = 2;
						break;
				}
			}
		}
	}
	Lock.Detach();
	if (find == 2) {
		return RLT_OK;
	}

	if (find == 1) {
		HisDataInfoPtr newPtr = new HisDataInfo();
		newPtr->Commodity = objPtr->Commodity;
		newPtr->Period = objPtr->Period;
		newPtr->PeriodEx = objPtr->PeriodEx;
		newPtr->DWType = objPtr->DWType;
		newPtr->DWDate = objPtr->DWDate;
		newPtr->DataPtr = objPtr->DataPtr;
		newPtr->WeightPtr = objPtr->WeightPtr;
		newPtr->DWDataPtr = new HisData();
		newPtr->DWDataPtr->HisDataList = newPtr->DataPtr->HisDataList;
		//
		//�����Ȩ
		//
		if (!newPtr->DWDataPtr->HisDataList.empty() && !newPtr->WeightPtr->WeightList.empty()) {
			switch (newPtr->DWType)
			{
			case DW_FORWARD:
				DisrightForward(&newPtr->DWDataPtr->HisDataList[0], newPtr->DWDataPtr->HisDataList.size()
					, &newPtr->WeightPtr->WeightList[0], newPtr->WeightPtr->WeightList.size());
				break;
			case DW_BACKWARD:
				DisrightBackward(&newPtr->DWDataPtr->HisDataList[0], newPtr->DWDataPtr->HisDataList.size()
					, &newPtr->WeightPtr->WeightList[0], newPtr->WeightPtr->WeightList.size());
				break;
			case DW_DAY:
				DisrightByDate(&newPtr->DWDataPtr->HisDataList[0], newPtr->DWDataPtr->HisDataList.size()
					, &newPtr->WeightPtr->WeightList[0], newPtr->WeightPtr->WeightList.size(), newPtr->DWDate);
				break;
			case DW_ALL:
				DisrightByDate(&newPtr->DWDataPtr->HisDataList[0], newPtr->DWDataPtr->HisDataList.size()
					, &newPtr->WeightPtr->WeightList[0], newPtr->WeightPtr->WeightList.size(), newPtr->WeightPtr->WeightList[0].Date);
				break;
			default:
				break;
			}
		}
		objPtr->DWDataPtr = newPtr->DWDataPtr;
		Lock.Attach(&m_Section);
		m_HisDataInfos.push_back(newPtr);
		Lock.Detach();
		return RLT_OK;
	} else {
		HisDataInfoPtr newPtr = new HisDataInfo();
		newPtr->Commodity = objPtr->Commodity;
		newPtr->Period = objPtr->Period;
		newPtr->PeriodEx = objPtr->PeriodEx;
		newPtr->DWType = objPtr->DWType;
		newPtr->DWDate = objPtr->DWDate;
		newPtr->DataPtr = new HisData();
		newPtr->WeightPtr = new WeightInfo();
		newPtr->DWDataPtr = new HisData();
		DataHandler* pExchange = FindExchangeBy(objPtr->Commodity.Exchange);
		if(pExchange) {
			SendToHandler(pExchange, EVT_DE_GET, GET_DE_HISDATA, newPtr);
		}
		objPtr->DataPtr = newPtr->DataPtr;
		objPtr->WeightPtr = newPtr->WeightPtr;
		objPtr->DWDataPtr = newPtr->DWDataPtr;
		Lock.Attach(&m_Section);
		m_HisDataInfos.push_back(newPtr);
		Lock.Detach();
		return RLT_OK;
	}

	return RLT_UNKNOWN;
}

void DataManager::CleanHisData(const COMREF & Commodity, ENUM_TIMEFRAMES Period)
{
	SectionLocker Lock(&m_Section);
	HisDataInfos::iterator it = m_HisDataInfos.begin();
	for (; it != m_HisDataInfos.end();)
	{
		HisDataInfoPtr& tempPtr = (*it);
		if (tempPtr->Commodity == Commodity && tempPtr->Period == Period) {
			it = m_HisDataInfos.erase(it);
		} else {
			++it;
		}
	}
}

void DataManager::CleanHisData(const unsigned char Exchange)
{
	SectionLocker Lock(&m_Section);
	HisDataInfos::iterator it = m_HisDataInfos.begin();
	for (; it != m_HisDataInfos.end();)
	{
		HisDataInfoPtr& tempPtr = (*it);
		if (tempPtr->Commodity.Exchange == Exchange) {
			it = m_HisDataInfos.erase(it);
		} else {
			++it;
		}
	}
}

void DataManager::UpdateHisData(const COMREF & Commodity, ENUM_TIMEFRAMES Period)
{
	SectionLocker Lock(&m_Section);
	HisDataInfos::iterator it = m_HisDataInfos.begin();
	for (; it != m_HisDataInfos.end();)
	{
		HisDataInfoPtr& tempPtr = (*it);
		if (tempPtr->Commodity == Commodity) {
			if (tempPtr->Period >= Period) {
				it = m_HisDataInfos.erase(it);
			} else {
				++it;
				PRINTFL("CleanHisData[%s][%d-%d]:NoClean.", Commodity.Code, tempPtr->Period, tempPtr->PeriodEx);
			}
		} else {
			++it;
		}
	}
}

long DataManager::OnCall(Event& evt)
{
	long rlt = RLT_UNKNOWN;
	long i=0,j=0;
	switch(evt.value)
	{
	//////////////////////////////////////////////////////////////////////////
	//GET
	case MAKEVALUE(MGET_PLAT_DE,CGET_DE_ACCOUNTINFO):
		{
			OBJPARAMObjPtr objPtr = OBJPARAMObjPtr::dynamicCast(evt.objPtr);
			if (objPtr) {
				objPtr->objPtr = m_AccountListPtr;
			}
			rlt = RLT_OK;
		}
		break;
	case MAKEVALUE(MGET_PLAT_DE,CGET_DE_SERVERINFO):
		{
			OBJPARAMObjPtr objPtr = OBJPARAMObjPtr::dynamicCast(evt.objPtr);
			if (objPtr) {
				objPtr->objPtr = m_ServerListPtr;
			}
			rlt = RLT_OK;
		}
		break;
	case MAKEVALUE(MGET_PLAT_DE,CGET_DE_ONLINE):
		{

		}
		break;
	case MAKEVALUE(MGET_PLAT_DE,CGET_DE_KIND):
		{
			KINDInfoPtr ptr = KINDInfoPtr::dynamicCast(evt.objPtr);
			if (ptr) {
				SectionLocker Lock(&m_Section);
				DataHandler* pExchange = FindExchangeBy(ptr->Kind.Exchange);
				Lock.Detach();
				if(pExchange) {
					SendToHandler(pExchange, EVT_DE_GET, GET_DE_KIND, evt.objPtr);
				}
			}
		}
		break;
	case MAKEVALUE(MGET_PLAT_DE,CGET_DE_KINDLIST):
		{
			AllKindListInfoPtr objPtr = AllKindListInfoPtr::dynamicCast(evt.objPtr);
			if (objPtr) {
				//��ѡ��
				objPtr->AllKindList.push_back(KindListInfo());
				KindListInfo& selfInfo = objPtr->AllKindList.back();
				for (j=0; j<m_SelfKindIdxs.size(); j++)
				{
					selfInfo.KindList.push_back(m_SelfKind[m_SelfKindIdxs[j]]);
				}
				//ϵͳ���
				KINDListInfoPtr getptr = new KINDListInfo();
				SectionLocker Lock(&m_Section);
				DataHandler* pExchange = NULL;
				while(pExchange = FindExchangeBy(i++))
				{
					getptr->KindList.clear();
					SendToHandler(pExchange, EVT_DE_GET, GET_DE_KIND_LIST, getptr);
					if (!getptr->KindList.empty()) {
						objPtr->AllKindList.push_back(KindListInfo());
						KindListInfo& info = objPtr->AllKindList.back();
						for (j=0; j<getptr->KindList.size(); j++)
						{
							KindInfo kind;
							kind.KindList.push_back(getptr->KindList[j]);
							info.KindList.push_back(kind);
						}
					}
				}
			}
		}
		break;
	case MAKEVALUE(MGET_PLAT_DE,CGET_DE_COMMODITY):
		{
			COMREFInfoPtr commptr = COMREFInfoPtr::dynamicCast(evt.objPtr);
			if (commptr) {
				SectionLocker Lock(&m_Section);
				DataHandler* pExchange = FindExchangeBy(commptr->Commodity);
				Lock.Detach();
				if(pExchange) {
					commptr->Commodity.Type = COMREF_TYPE_STRUCT;
					commptr->Commodity.Exchange = Exchange2IdA(pExchange->c_strof(STR_NAMEA));
					return SendToHandler(pExchange, EVT_DE_GET, GET_DE_COMMODITY, evt.objPtr);
				}
			}
		}
		break;
	case MAKEVALUE(MGET_PLAT_DE,CGET_DE_COMMODITYLIST):
		{
			CommodityListInfoPtr commlistptr = CommodityListInfoPtr::dynamicCast(evt.objPtr);
			if (commlistptr) {
				COMREFListInfoPtr getptr = new COMREFListInfo();
				for (int i=0,j=commlistptr->Kind.KindList.size(); i<j; i++)
				{
					getptr->Kind = commlistptr->Kind.KindList[i];
					switch(getptr->Kind.Type)
					{
					case KIND_TYPE_SYSTEM:
						{
							SectionLocker Lock(&m_Section);
							DataHandler* pExchange = FindExchangeBy(getptr->Kind.Exchange);
							Lock.Detach();
							if(pExchange) {
								SendToHandler(pExchange, EVT_DE_GET, GET_DE_COMMODITY_LIST, getptr);
							}
						}
						break;
					case KIND_TYPE_USER:
						{
							getptr->CommodityList.insert(getptr->CommodityList.end()
								, m_SelfCommoditys[getptr->Kind.Index].begin(), m_SelfCommoditys[getptr->Kind.Index].end());
						}
						break;
					default:
						ASSERT(0);
						break;
					}
				}
				commlistptr->CommodityList = getptr->CommodityList;
			}
		}
		break;
	case MAKEVALUE(MGET_PLAT_DE,CGET_DE_FIELD_NAME):
		{
			FIELDNAMEListInfoPtr fieldnameptr = FIELDNAMEListInfoPtr::dynamicCast(evt.objPtr);
			if (fieldnameptr) {
				SectionLocker Lock(&m_Section);
				DataHandler* pExchange = FindExchangeBy(fieldnameptr->Commodity);
				Lock.Detach();
				if(pExchange) {
					return SendToHandler(pExchange, EVT_DE_GET, GET_DE_FIELD_NAME, evt.objPtr);
				}
			}
		}
		break;
	case MAKEVALUE(MGET_PLAT_DE,CGET_DE_FIELD_VALUE):
		{
			FIELDVALUEListInfoPtr fieldvalueptr = FIELDVALUEListInfoPtr::dynamicCast(evt.objPtr);
			if (fieldvalueptr) {
				SectionLocker Lock(&m_Section);
				DataHandler* pExchange = FindExchangeBy(fieldvalueptr->Commodity);
				Lock.Detach();
				if(pExchange) {
					return SendToHandler(pExchange, EVT_DE_GET, GET_DE_FIELD_VALUE, evt.objPtr);
				}
			}
		}
		break;
	case MAKEVALUE(MGET_PLAT_DE,CGET_DE_FIELD_VALUETEXT):
		{
			FIELDVALUEListInfoPtr fieldvalueptr = FIELDVALUEListInfoPtr::dynamicCast(evt.objPtr);
			if (fieldvalueptr) {
				SectionLocker Lock(&m_Section);
				DataHandler* pExchange = FindExchangeBy(fieldvalueptr->Commodity);
				Lock.Detach();
				if(pExchange) {
					for (i=0,j=fieldvalueptr->FieldValueList.size(); i<j; i++)
					{
						switch(fieldvalueptr->FieldValueList[i].cTextType)
						{
						case FIELD_VALUE_STRINGA:
						case FIELD_VALUE_STRINGW:
							break;
						default:
							fieldvalueptr->FieldValueList[i].cTextType = FIELD_VALUE_STRING;
							break;
						}
					}
					return SendToHandler(pExchange, EVT_DE_GET, GET_DE_FIELD_VALUETEXT, evt.objPtr);
				}
			}
		}
		break;
	case MAKEVALUE(MGET_PLAT_DE,CGET_DE_HISDATA):
		{
			HisDataInfoPtr hisdataptr = HisDataInfoPtr::dynamicCast(evt.objPtr);
			if (hisdataptr) {
				return RefHisData(hisdataptr);
			}
		}
		break;
	case MAKEVALUE(MGET_PLAT_DE,CGET_DE_ORDER):
		{
			/*OrderListInfoPtr orderlistinfoptr = OrderListInfoPtr::dynamicCast(evt.objPtr);
			if (orderlistinfoptr) {
				//ȡ�����б�
				int i = 0;
				QTrader* pTrader = NULL;
				while(pTrader = FindTraderBy(i++))
				{
					pTrader->Get(GET_DE_ORDER,evt.objPtr);
				}
			}*/
		}
		break;
	//////////////////////////////////////////////////////////////////////////
	//SET
	case MAKEVALUE(MSET_PLAT_DE,CSET_DE_ADD_ACCOUNTINFO):
		{
			AccountInfoPtr objPtr = AccountInfoPtr::dynamicCast(evt.objPtr);
			if (objPtr) {
				AddAccount(objPtr);
				DataHandler* pHandler = OpenHandler(objPtr->strName.c_str(),objPtr->strUser.c_str());
				if (pHandler) {
					return SendToHandler(pHandler, EVT_DE_SET, SET_DE_ACCOUNTINFO, evt.objPtr);
				}
			}
			return RLT_UNKNOWN;
		}
		break;
	case MAKEVALUE(MSET_PLAT_DE,CSET_DE_REMOVE_ACCOUNTINFO):
		{
			AccountInfoPtr objPtr = AccountInfoPtr::dynamicCast(evt.objPtr);
			if (objPtr) {
				RemoveAccount(objPtr);
				DataHandler* pHandler = FindHandler(objPtr->strName.c_str(),objPtr->strUser.c_str());
				if (pHandler) {
					CloseHandler(pHandler);
				}
				return RLT_OK;
			}
			return RLT_UNKNOWN;
		}
		break;
	case MAKEVALUE(MSET_PLAT_DE,CSET_DE_SERVERINFO):
		{
			ServerInfoPtr objPtr = ServerInfoPtr::dynamicCast(evt.objPtr);
			if (objPtr) {
				FindServer(objPtr,FIND_FLAG_ADD_IFNOTEXIST|FIND_FLAG_UPDATE_IFEXIST);
				DataHandler* pHandler = FindHandler(objPtr->strName.c_str(),objPtr->strUser.c_str());
				if (pHandler) {
					return SendToHandler(pHandler,EVT_DE_SET,SET_DE_SERVERINFO,evt.objPtr);
				}
			}
			return RLT_UNKNOWN;
		}
		break;
	case MAKEVALUE(MSET_PLAT_DE,CSET_DE_ONLINE):
		{
			OnlineInfoPtr objPtr = OnlineInfoPtr::dynamicCast(evt.objPtr);
			if (objPtr) {
				DataHandler* pHandler = FindHandler(objPtr->strName.c_str(),objPtr->strUser.c_str());
				if (pHandler) {
					return SendToHandler(pHandler,EVT_DE_SET,SET_DE_ONLINE,evt.objPtr);
				}
			} else {
				BroadcastSendToHandler(EVT_DE_SET,SET_DE_ONLINE,evt.objPtr);
			}
			return RLT_UNKNOWN;
		}
		break;
	case MAKEVALUE(MSET_PLAT_DE,CSET_DE_OFFLINE):
		{
			OnlineInfoPtr objPtr = OnlineInfoPtr::dynamicCast(evt.objPtr);
			if (objPtr) {
				DataHandler* pHandler = FindHandler(objPtr->strName.c_str(),objPtr->strUser.c_str());
				if (pHandler) {
					return SendToHandler(pHandler,EVT_DE_SET,SET_DE_OFFLINE,evt.objPtr);
				}
			} else {
				BroadcastSendToHandler(EVT_DE_SET,SET_DE_OFFLINE,evt.objPtr);
			}
			return RLT_UNKNOWN;
		}
		break;
	//////////////////////////////////////////////////////////////////////////
	//CALL
	case MAKEVALUE(MCALL_PLAT_DE,CCALL_DE_ADDSELFKIND):
		{
			AddSelfKindPtr objPtr = AddSelfKindPtr::dynamicCast(evt.objPtr);
			if (objPtr) {
				SectionLocker Lock(&m_Section);
				for (i=KIND_INDEX_SELFCOUNT; i<KIND_INDEX_SELFMAX; i++)
				{
					if (m_SelfKind[i].KindList.empty()) {
						m_SelfKind[i].KindList.resize(1);
						m_SelfKind[i].KindList[0].Type = KIND_TYPE_USER;
						m_SelfKind[i].KindList[0].Exchange = 0;
						m_SelfKind[i].KindList[0].Index = i;
						_tcscpy(m_SelfKind[i].KindList[0].Name, objPtr->Name);
						m_SelfKindIdxs.push_back(i);
						m_bSelfChanged = true;
						break;
					}
				}
				return RLT_OK;
			}
		}
		break;
	case MAKEVALUE(MCALL_PLAT_DE,CCALL_DE_REMOVESELFKIND):
		{
			RemoveSelfKindPtr objPtr = RemoveSelfKindPtr::dynamicCast(evt.objPtr);
			if (objPtr) {
				SectionLocker Lock(&m_Section);
				for (i=KIND_INDEX_SELFCOUNT; i<KIND_INDEX_SELFMAX; i++)
				{
					if (m_SelfKind[i] == objPtr->Kind) {
						m_SelfKind[i].KindList.clear();
						m_SelfKindIdxs.erase(std::find(m_SelfKindIdxs.begin(),m_SelfKindIdxs.end(),i));
						m_bSelfChanged = true;
						break;
					}
				}
				return RLT_OK;
			}
		}
	case MAKEVALUE(MCALL_PLAT_DE,CCALL_DE_ADDSELFCOMMODITY):
		{
			AddSelfCommodityPtr objPtr = AddSelfCommodityPtr::dynamicCast(evt.objPtr);
			if (objPtr) {
				SectionLocker Lock(&m_Section);
				for (i=0; i<KIND_INDEX_SELFMAX; i++)
				{
					if (m_SelfKind[i] == objPtr->Kind) {
						for (j=0; j<objPtr->CommodityList.size(); j++)
						{
							COMREFLIST::iterator it = std::find(m_SelfCommoditys[i].begin(), m_SelfCommoditys[i].end(), objPtr->CommodityList[j]);
							if (it == m_SelfCommoditys->end()) {
								m_SelfCommoditys[i].push_back(objPtr->CommodityList[j]);
								m_bSelfChanged = true;
							}
						}

						break;
					}
				}
				return RLT_OK;
			}
		}
		break;
	case MAKEVALUE(MCALL_PLAT_DE,CCALL_DE_REMOVESELFCOMMODITY):
		{
			RemoveSelfCommodityPtr objPtr = RemoveSelfCommodityPtr::dynamicCast(evt.objPtr);
			if (objPtr) {
				SectionLocker Lock(&m_Section);
				for (i=0; i<KIND_INDEX_SELFMAX; i++)
				{
					if (m_SelfKind[i] == objPtr->Kind) {
						for (j=0; j<objPtr->CommodityList.size(); j++)
						{
							COMREFLIST::iterator it = std::find(m_SelfCommoditys[i].begin(), m_SelfCommoditys[i].end(), objPtr->CommodityList[j]);
							if (it != m_SelfCommoditys->end()) {
								m_SelfCommoditys[i].erase(it);
								m_bSelfChanged = true;
							}
						}
						break;
					}
				}
				return RLT_OK;
			}
		}
		break;
	default:
		evt.handled = false;
		break;
	}
	return rlt;
}

long DataManager::OnRequest(Event& evt)
{
	long Res = RLT_UNKNOWN;

	switch(evt.value)
	{
	case MAKEVALUE(MREQUEST_PLAT_DE,CREQUEST_DE_CANCEL):
		RemoveRequest(evt);
		return RLT_OK;
		break;
	case MAKEVALUE(MREQUEST_PLAT_DE,CREQUEST_DE_REGPUSH):
		{
			SectionLocker Lock(&m_Section);
			if (!IsOnline(NULL)) {
				return RLT_UNKNOWN;
			}

			long i,j;
			REQ_PushInfoPtr reqpushptr = REQ_PushInfoPtr::dynamicCast(evt.objPtr);
			if (reqpushptr) {
				std::map<DataHandler*,REQ_PushInfoPtr> pExchange2reqPtr;
				for (i=0; i<reqpushptr->Commoditys.size(); i++)
				{
					DataHandler* pExchange = FindExchangeBy(reqpushptr->Commoditys[i]);
					if(pExchange) {
						REQ_PushInfoPtr & treqpushptr = pExchange2reqPtr[pExchange];
						if (!treqpushptr) {
							treqpushptr = new REQ_PushInfo();
						}
						treqpushptr->Commoditys.push_back(reqpushptr->Commoditys[i]);
					}
				}
				std::map<DataHandler*,REQ_PushInfoPtr>::iterator it = pExchange2reqPtr.begin();
				for ( ; it!=pExchange2reqPtr.end(); ++it)
				{
					AddRequest(evt,Event(this,it->first,EVT_DE_REQUEST,REQUEST_DE_REGPUSH,it->second));
				}
				it = pExchange2reqPtr.begin();
				for ( ; it!=pExchange2reqPtr.end(); ++it)
				{
					Event SubReq(this,it->first,EVT_DE_REQUEST,REQUEST_DE_REGPUSH,it->second);
					Res = SendToHandler(SubReq);
					if (Res<=0 || it->second->IsFinished()) {
						UpdateRequest(SubReq);
					}
				}
				return RLT_OK;
			}
		}
		break;
	case MAKEVALUE(MREQUEST_PLAT_DE,CREQUEST_DE_FIELD_VALUE):
		{
			SectionLocker Lock(&m_Section);
			if (!IsOnline(NULL)) {
				return RLT_UNKNOWN;
			}

			long i,j;
			REQ_FIELDDATAInfoPtr reqfieldptr = REQ_FIELDDATAInfoPtr::dynamicCast(evt.objPtr);
			if (reqfieldptr) {
				std::map<DataHandler*,REQ_FIELDDATAInfoPtr> pExchange2reqPtr;
				for (i=0; i<reqfieldptr->Commoditys.size(); i++)
				{
					DataHandler* pExchange = FindExchangeBy(reqfieldptr->Commoditys[i]);
					if(pExchange) {
						REQ_FIELDDATAInfoPtr & treqfieldptr = pExchange2reqPtr[pExchange];
						if (!treqfieldptr) {
							treqfieldptr = new REQ_FIELDDATAInfo();
						}
						treqfieldptr->uFlags = reqfieldptr->uFlags;
						if (reqfieldptr->uFlags!=REQ_FIELD_FLAG_ALL) {
							treqfieldptr->Commoditys.push_back(reqfieldptr->Commoditys[i]);
						}
						treqfieldptr->Fields.assign(reqfieldptr->Fields.begin(),reqfieldptr->Fields.end());
					}
				}
				std::map<DataHandler*,REQ_FIELDDATAInfoPtr>::iterator it = pExchange2reqPtr.begin();
				for ( ; it!=pExchange2reqPtr.end(); ++it)
				{
					AddRequest(evt,Event(this,it->first,EVT_DE_REQUEST,REQUEST_DE_FIELD_DATA,it->second));
				}
				it = pExchange2reqPtr.begin();
				for ( ; it!=pExchange2reqPtr.end(); ++it)
				{
					Event SubReq(this,it->first,EVT_DE_REQUEST,REQUEST_DE_FIELD_DATA,it->second);
					Res = SendToHandler(SubReq);
					if (Res<=0 || it->second->IsFinished()) {
						UpdateRequest(SubReq);
					}
				}
				return RLT_OK;
			}
		}
		break;
	case MAKEVALUE(MREQUEST_PLAT_DE,CREQUEST_DE_HISDATA):
		{
			SectionLocker Lock(&m_Section);
			if (!IsOnline(NULL)) {
				return RLT_UNKNOWN;
			}

			REQ_HISDATAInfoPtr reqhisdataptr = REQ_HISDATAInfoPtr::dynamicCast(evt.objPtr);
			if (reqhisdataptr) {
				DataHandler* pExchange = FindExchangeBy(reqhisdataptr->Commodity);
				if(pExchange) {
					Event SubReq(this,pExchange,EVT_DE_REQUEST,REQUEST_DE_HISDATA,reqhisdataptr);
					AddRequest(evt,SubReq);
					Res = SendToHandler(SubReq);
					if (Res<=0 || reqhisdataptr->IsFinished()) {
						UpdateRequest(SubReq);
					}
				}
			}
			return RLT_OK;
		}
		break;
	case MAKEVALUE(MCALL_PLAT_DE,CREQUEST_DE_ORDERSEND):
		{
			SectionLocker Lock(&m_Section);
			REQ_OrderSendPtr objPtr = REQ_OrderSendPtr::dynamicCast(evt.objPtr);
			if (objPtr) {
				//���û����name��user����Ҫѡ����ʵ�DataHandler����?
				DataHandler* pHandler = FindHandler(objPtr->strName.c_str(),objPtr->strUser.c_str());
				if (pHandler) {
					return SendToHandler(pHandler,EVT_DE_REQUEST,REQUEST_DE_ORDERSEND,evt.objPtr);
				}
			}
		}
		break;
	default:
		evt.handled = false;
		break;
	}
	return RLT_UNKNOWN;
}

long DataManager::OnNotify(Event& evt)
{
	switch(evt.value)
	{
	case NOTIFY_DE_ONLINE:
		{
			///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			//��¼����(���Զ��ʹ�õ�¼����֧�ֶ��ʺ�) _PlatPtr/_DataPtr/_LoginPtr�����߳� _FramePtr/_IndicatorPtr�ڿ���߳�
			//		  |��֤��¼
			//       _LoginPtr-------------->_DataPtr->DataEngine->Register---��¼
			//		  |                       |                               |����
			//        |-<-------------------<_DataPtr-<---------------------<-|
			//        |
			//		  |//������ط���
			//       _LoginPtr-------------->_DataPtr->DataEngine->DataHandler-���ط���
			//		  |                       |                               |����
			//        |-<-------------------<_DataPtr-<---------------------<-|
			//                                |           ^        ^
			//                              _PlatPtr->_FramePtr->_IndicatorPtr
			//        |_FramePtr/_IndicatorPtr�Ϳ���ʹ��_DataPtr�ṩ�ķ�����
			////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			DataHandler* pHandler = dynamic_cast<DataHandler*>(evt.src);
			OnlineInfoPtr objPtr = OnlineInfoPtr::dynamicCast(evt.objPtr);
			if (pHandler && objPtr) {
				//�ȷ��͸���¼ģ�飬֪ͨ��¼״̬
				SendEvent(Event(pHandler, _LoginPtr, EVT_PLAT_NOTIFY, MAKEVALUE(MNOTIFY_PLAT_DE,CNOTIFY_DE_ONLINE), evt.objPtr));
				//������¼
				SectionLocker Lock(&m_Section);
				switch (objPtr->bOnline) 
				{
				case DE_OFFLINE:
					OnOffline(objPtr);
					break;
				case DE_INITDATA:
					OnInitData(objPtr);
					break;
				case DE_ONLINE:
					OnOnline(objPtr);
					break;
				}
				Lock.Detach();
				//֪ͨƽ̨��¼״̬��ƽ̨�ַ���ص�¼״̬����ܣ�����ٷַ�������ҵ��ģ�飬ҵ��ģ������Ӧ����
				if (!IsRegister(pHandler)) {
					SendEvent(Event(pHandler, _PlatPtr, EVT_PLAT_NOTIFY, MAKEVALUE(MNOTIFY_PLAT_DE,CNOTIFY_DE_ONLINE), evt.objPtr));
				}
			}
		}
		break;
	default:
		{
			RequestInfoPtr SubReqPtr = RequestInfoPtr::dynamicCast(evt.objPtr);
			if (SubReqPtr) {
				SectionLocker Lock(&m_Section);
				Event SubReq(this,evt.src,evt.evt,evt.value,evt.objPtr);
				Event Req;
				if(!FindRequest(SubReq,Req)) {
					break;
				}
				RequestInfoPtr ReqPtr = RequestInfoPtr::dynamicCast(Req.objPtr);
				if (!ReqPtr) {
					break;
				}

				//��������������ݴ���

				if (!SubReqPtr->IsFinished()) {
					break;
				}
				UpdateRequest(SubReq);
				Lock.Detach();
				//����������������Ĵ���
				switch(evt.value)
				{
				case NOTIFY_DE_RESPONSE_REGPUSH:
					{
						//REQ_PushInfoPtr ReqPushPtr = REQ_PushInfoPtr::dynamicCast(ReqPtr);
						//SendEvent(_PlatPtr, EVT_PLAT_NOTIFY, MAKEVALUE(MNOTIFY_PLAT_DE,CNOTIFY_DE_RESPONSE_REGPUSH), ReqPushPtr);
					}
					break;
				case NOTIFY_DE_RESPONSE_FIELD_DATA:
					{
						//REQ_FIELDDATAInfoPtr ReqFieldPtr = REQ_FIELDDATAInfoPtr::dynamicCast(ReqPtr);
						//SendEvent(_PlatPtr, EVT_PLAT_NOTIFY, MAKEVALUE(MNOTIFY_PLAT_DE,CNOTIFY_DE_RESPONSE_FIELD_VALUE), ReqFieldPtr);
					}
					break;
				case NOTIFY_DE_RESPONSE_HISDATA:
					{
						//if (ReqPtr->IsFinished()) {
						//	REQ_HISDATAInfoPtr ReqHisDataPtr = REQ_HISDATAInfoPtr::dynamicCast(ReqPtr);
						//	if (ReqHisDataPtr) {
						//		CleanHisData(ReqHisDataPtr->Commodity, ReqHisDataPtr->Period);
						//		//N_HISDATAInfoPtr notifyPtr = new N_HISDATAInfo(ReqHisDataPtr->Commodity
						//		//	, iPeriod2Period(Period2iPeriod(ReqHisDataPtr->Period,ReqHisDataPtr->PeriodEx)));
						//		//SendEvent(_PlatPtr, EVT_PLAT_NOTIFY, MAKEVALUE(MNOTIFY_PLAT_DE,CNOTIFY_DE_PUSH_HISDATA), notifyPtr);
						//	}
						//}
					}
					break;
				default:
					break;
				}
			} else {
				switch(evt.value)
				{
				case NOTIFY_DE_PUSH_FIELD_DATA:
					{
						N_FIELDDATAInfoPtr notifyPtr = N_FIELDDATAInfoPtr::dynamicCast(evt.objPtr);
						SendEvent(_PlatPtr, EVT_PLAT_NOTIFY, MAKEVALUE(MNOTIFY_PLAT_DE,CNOTIFY_DE_PUSH_FIELD_VALUE), notifyPtr);
					}
					break;
				case NOTIFY_DE_PUSH_HISDATA:
					{
						N_HISDATAInfoPtr notifyPtr = N_HISDATAInfoPtr::dynamicCast(evt.objPtr);
						if (notifyPtr) {
							UpdateHisData(notifyPtr->Commodity, notifyPtr->Period);
						}
						SendEvent(_PlatPtr, EVT_PLAT_NOTIFY, MAKEVALUE(MNOTIFY_PLAT_DE,CNOTIFY_DE_PUSH_HISDATA), notifyPtr);
					}
					break;
				default:
					break;
				}
			}
		}
		break;
	}
	return RLT_OK;
}

//////////////////////////////////////////////////////////////////////////
///QDataManager

QDataManager::QDataManager()
{
	m_bSelfChanged = false;
}

QDataManager::~QDataManager()
{
	
}

void QDataManager::Init()
{//���������֤��������������ί�г�ʼ��
	long i,j;
	TCHAR szBuf[1024];

	//׼��
	m_pExchanges.reserve(3);
	m_SelfKindIdxs.reserve(KIND_INDEX_SELFMAX);

	//��ʼ���г�
	//OpenHandler("SH");
	//OpenHandler("SZ");
	//OpenHandler("CF");

	//��ʼ����ѡ��
	KindInfo Kind;
	Kind.KindList.resize(1);
	Kind.KindList[0].Type = KIND_TYPE_USER;
	Kind.KindList[0].Exchange = 0;
	for (i=0; i<KIND_INDEX_SELFCOUNT; i++)
	{
		Kind.KindList[0].Index = i;
		if (i==0) {
			_stprintf(Kind.KindList[0].Name, _T("��ѡ��"));
		} else {
			_stprintf(Kind.KindList[0].Name, _T("��ѡ��%s"), Number2String(szBuf,i));
		}
		m_SelfKind[i] = Kind;
		m_SelfKindIdxs.push_back(i); 
	}
	//������ѡ��

	LoadFromFile();
}

void QDataManager::DeInit()
{//��Init�෴
	long i,j;

	SaveToFile();

	m_SelfKindIdxs.clear();
	for (i=0; i<KIND_INDEX_SELFCOUNT; i++)
	{
		m_SelfCommoditys[i].clear();
		m_SelfKind[i].KindList.clear();
	}
	
	while(!m_pRegisters.empty())
	{
		CloseHandler(m_pRegisters.front());
	}
	//m_pRegisters.clear();
	while(!m_pExchanges.empty())
	{
		CloseHandler(m_pExchanges.front());
	}
	//m_pExchanges.clear();
	while(!m_pTraders.empty())
	{
		CloseHandler(m_pTraders.front());
	}
	//m_pTraders.clear();
}

long QDataManager::OnCall(Event& evt)
{
	switch(evt.value)
	{
	//////////////////////////////////////////////////////////////////////////
	//GET
	//////////////////////////////////////////////////////////////////////////
	//SET
	//////////////////////////////////////////////////////////////////////////
	//CALL
	default:
		evt.handled = false;
		break;
	}
	return RLT_UNKNOWN;
}

long QDataManager::OnRequest(Event& evt)
{
	switch(evt.value)
	{
	default:
		evt.handled = false;
		break;
	}
	return RLT_UNKNOWN;
}

long QDataManager::OnNotify(Event& evt)
{
	switch(evt.value)
	{
	default:
		{
			evt.handled = false;
		}
		break;
	}
	return RLT_OK;
}

