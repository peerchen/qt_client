// MainFrm.cpp : implmentation of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "resource.h"

#include "Platform.h"
#include "MainFrm.h"

#include "ChildView.h"
#include "AboutDlg.h"
#include "SmartKBDlg.h"

#include <FaceDef.h>
#include <Indicator/Indicator.h>
#include <Indicator/XIndicatorEx.h>

//////////////////////////////////////////////////////////////////////////

extern "C"
{

typedef long (*pfnStart)(char*);
typedef void (*pfnStop)();

}

//////////////////////////////////////////////////////////////////////////

#define ID_TIMER			100
#define ID_REQPUSHTIMER		101

//////////////////////////////////////////////////////////////////////////

BOOL QReBarCtrl::OnEraseBkgnd(HDC hdc)
{
	CRect rcClient;
	GetClientRect(&rcClient);

	//::FillRect(hdc, &rcClient, GetStockBrush(DKGRAY_BRUSH));
	//UIgdi::FillSolidRect(hdc, &rcClient, GetSysColor(COLOR_WINDOW));
	UIgdi::FillSolidRect(hdc, &rcClient, RGB(20,20,20));
	//::DrawCaption(*this, hdc, &rcClient, (::GetActiveWindow()==*this?DC_ACTIVE:0) | DC_ICON | DC_TEXT);
	return TRUE;
}

//////////////////////////////////////////////////////////////////////////

LRESULT QCommandBarCtrl::OnParentCustomDraw(int /*idCtrl*/, LPNMHDR pnmh, BOOL& bHandled)
{
	LRESULT lRet = CDRF_DODEFAULT;
	bHandled = FALSE;
	if(pnmh->hwndFrom == m_hWnd)
	{
		LPNMTBCUSTOMDRAW lpTBCustomDraw = (LPNMTBCUSTOMDRAW)pnmh;
		if(lpTBCustomDraw->nmcd.dwDrawStage == CDDS_PREPAINT)
		{
			CRect rcClient;
			GetClientRect(&rcClient);

			//::FillRect(hdc, &rcClient, GetStockBrush(DKGRAY_BRUSH));
			UIgdi::FillSolidRect(lpTBCustomDraw->nmcd.hdc, &rcClient, RGB(34,34,34));

			lRet = CDRF_NOTIFYITEMDRAW;
			bHandled = TRUE;
		}
		else if(lpTBCustomDraw->nmcd.dwDrawStage == CDDS_ITEMPREPAINT)
		{
			if(m_bFlatMenus)
			{
#ifndef COLOR_MENUHILIGHT
				const int COLOR_MENUHILIGHT = 29;
#endif // !COLOR_MENUHILIGHT
				bool bDisabled = ((lpTBCustomDraw->nmcd.uItemState & CDIS_DISABLED) == CDIS_DISABLED);
				if(!bDisabled && ((lpTBCustomDraw->nmcd.uItemState & CDIS_HOT) == CDIS_HOT || 
					(lpTBCustomDraw->nmcd.uItemState & CDIS_SELECTED) == CDIS_SELECTED))
				{
					//::FillRect(lpTBCustomDraw->nmcd.hdc, &lpTBCustomDraw->nmcd.rc, ::GetSysColorBrush(COLOR_MENUHILIGHT));
					//::FrameRect(lpTBCustomDraw->nmcd.hdc, &lpTBCustomDraw->nmcd.rc, ::GetSysColorBrush(COLOR_HIGHLIGHT));
					//UIgdi::FillSolidRect(lpTBCustomDraw->nmcd.hdc, &lpTBCustomDraw->nmcd.rc,RGB(37,37,37));
					lpTBCustomDraw->clrText = RGB(255,200,50);//::GetSysColor(m_bParentActive ? COLOR_HIGHLIGHTTEXT : COLOR_GRAYTEXT);
				}
				else if(bDisabled || !m_bParentActive)
				{
					lpTBCustomDraw->clrText = ::GetSysColor(COLOR_GRAYTEXT);
				}
				else
				{
					lpTBCustomDraw->clrText = RGB(250,250,250);
				}
				CDCHandle dc = lpTBCustomDraw->nmcd.hdc;
				dc.SetTextColor(lpTBCustomDraw->clrText);
				dc.SetBkMode(lpTBCustomDraw->nStringBkMode);
				HFONT hFont = GetFont();
				HFONT hFontOld = NULL;
				if(hFont != NULL)
					hFontOld = dc.SelectFont(hFont);
				const int cchText = 200;
				TCHAR szText[cchText] = { 0 };
				TBBUTTONINFO tbbi = { 0 };
				tbbi.cbSize = sizeof(TBBUTTONINFO);
				tbbi.dwMask = TBIF_TEXT;
				tbbi.pszText = szText;
				tbbi.cchText = cchText;
				GetButtonInfo((int)lpTBCustomDraw->nmcd.dwItemSpec, &tbbi);
				dc.DrawText(szText, -1, &lpTBCustomDraw->nmcd.rc, DT_SINGLELINE | DT_CENTER | DT_VCENTER | (m_bShowKeyboardCues ? 0 : DT_HIDEPREFIX));
				if(hFont != NULL)
					dc.SelectFont(hFontOld);
				lRet = CDRF_SKIPDEFAULT;
				bHandled = TRUE;
			}
			else if(!m_bParentActive)
			{
				lpTBCustomDraw->clrText = ::GetSysColor(COLOR_GRAYTEXT);
				bHandled = TRUE;
			}
		}
	}
	return lRet;
}

//////////////////////////////////////////////////////////////////////////

LRESULT QToolBarCtrl::OnPaint(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	CPaintDC dc(m_hWnd);

	DWORD  nHotItem = GetHotItem();
	int nItemCount = GetButtonCount();

	for (int i=0;i<nItemCount;++i)
	{
		TBBUTTONINFO pbtnifo;
		ZeroMemory(&pbtnifo,sizeof(TBBUTTONINFO));
		pbtnifo.cbSize = sizeof(TBBUTTONINFO);
		pbtnifo.dwMask = TBIF_BYINDEX|TBIF_STATE|TBIF_COMMAND;
		GetButtonInfo(i,&pbtnifo);

		CRect rect;           
		GetRect(pbtnifo.idCommand,&rect);

		TCHAR szText[256]={0};
		GetButtonText(pbtnifo.idCommand,szText);
		CString strText=szText;

		if (pbtnifo.fsState & TBSTATE_PRESSED)
		{
		}
		else if(i == nHotItem)
		{

		}
		
		dc.SetTextColor(RGB(255,0,0));
		dc.TextOut(rect.left,rect.top,szText);
		//::FillRect(lpNMCustomDraw->hdc, &lpNMCustomDraw->rc, GetStockBrush(DKGRAY_BRUSH));
	}

	bHandled = TRUE;
	return 0;
}

DWORD QToolBarCtrl::OnPrePaint(int /*idCtrl*/, LPNMCUSTOMDRAW lpNMCustomDraw)
{
	::SetTextColor(lpNMCustomDraw->hdc, RGB(250,0,0));
	return CDRF_NOTIFYITEMDRAW;
	return CDRF_DODEFAULT;
}

DWORD QToolBarCtrl::OnPostPaint(int /*idCtrl*/, LPNMCUSTOMDRAW /*lpNMCustomDraw*/)
{
	return CDRF_SKIPDEFAULT;
}

DWORD QToolBarCtrl::OnPreErase(int /*idCtrl*/, LPNMCUSTOMDRAW /*lpNMCustomDraw*/)
{
	return CDRF_SKIPDEFAULT;
}

DWORD QToolBarCtrl::OnPostErase(int /*idCtrl*/, LPNMCUSTOMDRAW /*lpNMCustomDraw*/)
{
	return CDRF_SKIPDEFAULT;
}

DWORD QToolBarCtrl::OnItemPrePaint(int idCtrl, LPNMCUSTOMDRAW lpNMCustomDraw)
{
	//::SetTextColor(lpNMCustomDraw->hdc, RGB(250,250,250));
	//::FillRect(lpNMCustomDraw->hdc, &lpNMCustomDraw->rc, GetStockBrush(DKGRAY_BRUSH));

	return CDRF_DODEFAULT;
}

DWORD QToolBarCtrl::OnItemPostPaint(int /*idCtrl*/, LPNMCUSTOMDRAW /*lpNMCustomDraw*/)
{
	return CDRF_SKIPDEFAULT;
}

DWORD QToolBarCtrl::OnItemPreErase(int /*idCtrl*/, LPNMCUSTOMDRAW /*lpNMCustomDraw*/)
{
	return CDRF_SKIPDEFAULT;
}

DWORD QToolBarCtrl::OnItemPostErase(int /*idCtrl*/, LPNMCUSTOMDRAW /*lpNMCustomDraw*/)
{
	return CDRF_SKIPDEFAULT;
}

#if (_WIN32_IE >= 0x0400)
DWORD QToolBarCtrl::OnSubItemPrePaint(int /*idCtrl*/, LPNMCUSTOMDRAW /*lpNMCustomDraw*/)
{
	return CDRF_DODEFAULT;
}
#endif // (_WIN32_IE >= 0x0400)

//////////////////////////////////////////////////////////////////////////

LRESULT QAddressBar::OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& /*bHandled*/)
{
	// let the combo box initialize itself
	LRESULT lRet = DefWindowProc(uMsg, wParam, lParam);

	if(lRet != -1)
	{
		// adjust the drop-down width
		m_cb = GetComboCtrl();
		m_cb.SetDroppedWidth(m_cxMinDropWidth);

		// create a toolbar for the GO button
		m_tb = CFrameWindowImplBase<>::CreateSimpleToolBarCtrl(m_hWnd, IDR_MAINFRAME, FALSE, ATL_SIMPLE_TOOLBAR_PANE_STYLE | TBSTYLE_LIST);

		RECT rect;
		m_tb.GetItemRect(0, &rect);
		m_sizeTB.cx = rect.right;
		m_sizeTB.cy = rect.bottom;
	}

	return lRet;
}

LRESULT QAddressBar::OnEraseBkgnd(UINT /*uMsg*/, WPARAM wParam, LPARAM /*lParam*/, BOOL& bHandled)
{
	CDCHandle dc = (HDC)wParam;
	CWindow wndParent = GetParent();

	// Forward this to the parent window, rebar bands are transparent
	POINT pt = { 0, 0 };
	MapWindowPoints(wndParent, &pt, 1);
	dc.OffsetWindowOrg(pt.x, pt.y, &pt);
	LRESULT lRet = wndParent.SendMessage(WM_ERASEBKGND, (WPARAM)dc.m_hDC);
	dc.SetWindowOrg(pt.x, pt.y);

	bHandled = (lRet != 0);
	return lRet;
}

LRESULT QAddressBar::OnWindowPosChanging(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	if(m_tb.m_hWnd == NULL)
	{
		bHandled = FALSE;
		return 1;
	}

	// copy the WINDOWPOS struct and adjust for the GO button
	WINDOWPOS wp = *(LPWINDOWPOS)lParam;
	wp.cx -= m_sizeTB.cx + m_cxGap;
	LRESULT lRet = DefWindowProc(uMsg, wParam, (LPARAM)&wp);

	// paint below the GO button
	RECT rcGo = { wp.cx, 0, wp.cx + m_sizeTB.cx + m_cxGap, wp.cy };
	InvalidateRect(&rcGo);

	// center the GO button relative to the combo box
	RECT rcCombo;
	m_cb.GetWindowRect(&rcCombo);
	int y = (rcCombo.bottom - rcCombo.top - m_sizeTB.cy) / 2;

	// position the GO button on the right
	m_tb.SetWindowPos(NULL, wp.cx + m_cxGap, y, m_sizeTB.cx, m_sizeTB.cy, SWP_SHOWWINDOW | SWP_NOACTIVATE | SWP_NOOWNERZORDER);

	return lRet;
}

LRESULT QAddressBar::OnToolTipText(int idCtrl, LPNMHDR pnmh, BOOL& bHandled)
{
	if(idCtrl == ID_GO)
		SendMessage(GetParent(), WM_NOTIFY, idCtrl, (LPARAM)pnmh);
	else
		bHandled = FALSE;

	return 0;
}

LRESULT QAddressBar::OnMouseActivate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& /*bHandled*/)
{
	LRESULT lRet = DefWindowProc(uMsg, wParam, lParam);
	//SendMessage(GetTopLevelParent(), WM_COMBOMOUSEACTIVATE, 0, 0L);

	return lRet;
}

//////////////////////////////////////////////////////////////////////////

UIEdit MyAddressBar::GetEditCtrl()
{
	return m_cb.GetEditCtrl();
}

CToolBarCtrl MyAddressBar::GetToolBarCtrl()
{
	return m_tb;
}

LRESULT MyAddressBar::OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& /*bHandled*/)
{
	// let the combo box initialize itself
	LRESULT lRet = DefWindowProc(uMsg, wParam, lParam);

	if(lRet != -1)
	{
		CRect rcClient;
		GetClientRect(&rcClient);

		// adjust the drop-down width
		m_cb.Create(m_hWnd, rcClient, NULL, WS_CHILD|WS_VISIBLE|CBS_DROPDOWN);
		//m_cb.SetDroppedWidth(m_cxMinDropWidth);

		// create a toolbar for the GO button
		m_tb = CFrameWindowImplBase<>::CreateSimpleToolBarCtrl(m_hWnd, IDR_MAINFRAME, FALSE, ATL_SIMPLE_TOOLBAR_PANE_STYLE | TBSTYLE_LIST);

		RECT rect;
		m_tb.GetItemRect(0, &rect);
		m_sizeTB.cx = rect.right;
		m_sizeTB.cy = rect.bottom;
	}

	return lRet;
}

LRESULT MyAddressBar::OnSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	if (wParam != SIZE_MINIMIZED && lParam != 0) {
	}
	return bHandled;
}

LRESULT MyAddressBar::OnEraseBkgnd(UINT /*uMsg*/, WPARAM wParam, LPARAM /*lParam*/, BOOL& bHandled)
{
	CDCHandle dc = (HDC)wParam;
	CWindow wndParent = GetParent();

	// Forward this to the parent window, rebar bands are transparent
	POINT pt = { 0, 0 };
	MapWindowPoints(wndParent, &pt, 1);
	dc.OffsetWindowOrg(pt.x, pt.y, &pt);
	LRESULT lRet = wndParent.SendMessage(WM_ERASEBKGND, (WPARAM)dc.m_hDC);
	dc.SetWindowOrg(pt.x, pt.y);

	bHandled = (lRet != 0);
	return lRet;
}

LRESULT MyAddressBar::OnWindowPosChanging(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	if(m_tb.m_hWnd == NULL)
	{
		bHandled = FALSE;
		return 1;
	}

	// copy the WINDOWPOS struct and adjust for the GO button
	WINDOWPOS wp = *(LPWINDOWPOS)lParam;
	wp.cx -= m_sizeTB.cx + m_cxGap;
	LRESULT lRet = DefWindowProc(uMsg, wParam, (LPARAM)&wp);

	m_cb.MoveWindow(0, 0, wp.cx, wp.cy-m_cxGap);

	// paint below the GO button
	RECT rcGo = { wp.cx, 0, wp.cx + m_sizeTB.cx + m_cxGap, wp.cy };
	InvalidateRect(&rcGo);

	// center the GO button relative to the combo box
	RECT rcCombo;
	m_cb.GetWindowRect(&rcCombo);
	int y = (rcCombo.bottom - rcCombo.top - m_sizeTB.cy) / 2;

	// position the GO button on the right
	m_tb.SetWindowPos(NULL, wp.cx + m_cxGap, y, m_sizeTB.cx, m_sizeTB.cy, SWP_SHOWWINDOW | SWP_NOACTIVATE | SWP_NOOWNERZORDER);

	return lRet;
}

LRESULT MyAddressBar::OnToolTipText(int idCtrl, LPNMHDR pnmh, BOOL& bHandled)
{
	if(idCtrl == ID_GO)
		SendMessage(GetParent(), WM_NOTIFY, idCtrl, (LPARAM)pnmh);
	else
		bHandled = FALSE;

	return 0;
}

LRESULT MyAddressBar::OnMouseActivate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& /*bHandled*/)
{
	LRESULT lRet = DefWindowProc(uMsg, wParam, lParam);
	//SendMessage(GetTopLevelParent(), WM_COMBOMOUSEACTIVATE, 0, 0L);

	return lRet;
}

//////////////////////////////////////////////////////////////////////////

BOOL QStatusBarCtrl::OnEraseBkgnd(HDC hdc)
{
	CRect rcClient;
	GetClientRect(&rcClient);

	UIgdi::FillSolidRect(hdc, &rcClient, RGB(7,7,7));
	return TRUE;
}

//////////////////////////////////////////////////////////////////////////

CMainFrame::CMainFrame(LPCTSTR lpstrName, LPCTSTR lpstrCmdLine):m_strName(lpstrName),m_strCmdLine(lpstrCmdLine)
{
	m_hStrategy = NULL;

	m_pContainer = NULL;

	m_pSmartKBDlg = NULL;
	memset(&m_xySmartKBOffset, 0, sizeof(m_xySmartKBOffset));

	m_nTimer = 0;
	m_nReqPushTimer = 0;

	m_pRptContainer = NULL;
	m_pScdtContainer = NULL;

	m_nCurRecord = -1;
	m_bEnableRecord = TRUE;
}

BOOL CMainFrame::IsStrategy()
{
	return !m_strName.IsEmpty();
}

Markup* CMainFrame::OpenMarkup(LPCTSTR lpszFile)
{
	if(!lpszFile || !lpszFile[0]) {
		return m_Name2pMarkup[_T("")];
	}
	Name2pMarkup::iterator iter = m_Name2pMarkup.find(lpszFile);
	if (iter != m_Name2pMarkup.end()) {
		return iter->second;
	} else {
		//
	}
	return NULL;
}

void CMainFrame::CloseMarkup(LPCTSTR lpszFile)
{
	Name2pMarkup::iterator it = m_Name2pMarkup.find(lpszFile);
	if(it != m_Name2pMarkup.end()) {
		it->second->Close();
		delete it->second;
		m_Name2pMarkup.erase(it);
	}
}

long CMainFrame::WriteValue(LPCSTR lpszName, LPCSTR lpszValue, int nValueCount, LPCSTR lpszSpec, LPCSTR lpszFile)
{
	long rlt = RLT_UNKNOWN;
#ifdef UNICODE
	std::string name(lpszName), val(lpszValue);
	std::wstring wname, wval;
	mb2wc(name, wname, CP_OEMCP);
	mb2wc(val, wval, CP_OEMCP);
	if (!lpszFile || !lpszFile[0]) {
		if (lpszSpec == NULL || lpszSpec[0]==0) {
			rlt = WriteValue(wname.c_str(), wval.c_str(), wval.length());
		} else {
			std::string spec(lpszSpec);
			std::wstring wspec;
			mb2wc(spec, wspec, CP_OEMCP);
			rlt = WriteValue(wname.c_str(), wval.c_str(), wval.length(), wspec.c_str());
		}
	} else {
		std::string config(lpszFile);
		std::wstring wconfig;
		mb2wc(config, wconfig, CP_OEMCP);
		if (lpszSpec == NULL || lpszSpec[0]==0) {
			rlt = WriteValue(wname.c_str(), wval.c_str(), wval.length(), NULL, wconfig.c_str());
		} else {
			std::string spec(lpszSpec);
			std::wstring wspec;
			mb2wc(spec, wspec, CP_OEMCP);
			rlt = WriteValue(wname.c_str(), wval.c_str(), wval.length(), wspec.c_str(), wconfig.c_str());
		}
	}
#else
#endif
	return rlt;
	return RLT_UNKNOWN;
}

long CMainFrame::ReadValue(LPCSTR lpszName, LPSTR lpszValue, int nValueCount, LPCSTR lpszSpec, LPCSTR lpszFile)
{
	long rlt = RLT_UNKNOWN;
#ifdef UNICODE
	std::string name(lpszName), val(lpszValue, nValueCount);
	std::wstring wname, wval(nValueCount, 0), wspec, wconfig;
	mb2wc(name, wname, CP_OEMCP);
	if (lpszSpec) {
		mb2wc(std::string(lpszSpec), wspec, CP_OEMCP);
	}
	if (lpszFile) {
		mb2wc(std::string(lpszFile), wconfig, CP_OEMCP);
	}
	rlt = ReadValue((LPCWSTR)wname.c_str(), (LPWSTR)wval.c_str(), nValueCount,
		lpszSpec ? (LPCWSTR)wspec.c_str() : NULL, lpszFile ? (LPCWSTR)wconfig.c_str() : NULL);
	if(rlt >= 0) {
		rlt = wc2mb((wchar_t*)wval.c_str(), rlt, lpszValue, nValueCount, CP_OEMCP);
	}
#else

#endif//
	return rlt;
	return RLT_UNKNOWN;
}

long CMainFrame::WriteValue(LPCWSTR lpszName, LPCWSTR lpszValue, int nValueCount, LPCWSTR lpszSpec, LPCWSTR lpszFile)
{
	return RLT_UNKNOWN;
}

long CMainFrame::ReadValue(LPCWSTR lpszName, LPWSTR lpszValue, int nValueCount, LPCWSTR lpszSpec, LPCWSTR lpszFile)
{
	long rlt = RLT_UNKNOWN;
#ifdef UNICODE
	bool bOk = false;
	if ((!lpszSpec || !lpszSpec[0]) && (!lpszFile || !lpszFile[0])) {
		/*if (wcsicmp(lpszName, USERDIRW) == 0) {
			bOk = true;
			_sntprintf(lpszValue, nValueCount, _T("%s\\user\\"), _Module.GetAppData());
			if (!File::IsFileExistW(lpszValue)) {
				File::CreateDirectoryW(lpszValue);
			}
			wcscat(lpszValue, (LPCWSTR)m_strUserName);
			if (!File::IsFileExistW(lpszValue)) {
				File::CreateDirectoryW(lpszValue);
			}
		}
		if (bOk) {
			return rlt;
		}*/
	}
	Markup* pConfig = OpenMarkup(lpszFile);
	if(pConfig) {
		pConfig->ResetPos();
		if (!lpszSpec || !lpszSpec[0]) {
			wcsref strrefname((wchar_t*)lpszName), strrefval;
			if (pConfig->Find(strrefname)) {
				bOk = true;
				if(pConfig->Get(strrefname, strrefval)) {
					rlt = MIN(strrefval.second, nValueCount);
					wcsncpy(lpszValue, strrefval.first, rlt);
				}
			}
		} else {
			wcsref strrefname((wchar_t*)lpszName), strrefattr((wchar_t*)lpszSpec), strrefval;
			if(pConfig->Find(strrefname)) {
				if(pConfig->Get(strrefname, strrefattr, strrefval)) {
					bOk = true;
					rlt = MIN(strrefval.second, nValueCount - 1);
					wcsncpy(lpszValue, strrefval.first, rlt);
				}
			}
		}
	}
	if(!bOk) {
		Objecter* pPlat = GetPlatPtr();
		if (pPlat) {
			return pPlat->ReadValue(lpszName, lpszValue, nValueCount, lpszSpec, lpszFile);
		}
	} 
#else

#endif//
	return RLT_UNKNOWN;
}

UINT CMainFrame::MapCmdId(UINT nCmdId, LPCTSTR lpszName)
{
	if(lpszName && lpszName[0]) {
		m_strName2CmdId[lpszName] = nCmdId;
		return nCmdId;
	}
	return 0;
}

UINT CMainFrame::MapCmdId(LPCTSTR lpszName, UINT nCmdId)
{
	if(lpszName && lpszName[0]) {
		m_strName2CmdId[lpszName] = nCmdId;
		return nCmdId;
	}
	return 0;
}

UINT CMainFrame::MapCmdId(LPCTSTR lpszName)
{
	if (!lpszName || !lpszName[0]) {
		return 0;
	}
	UINT nCmdId = 0;
	Str2CmdId::iterator it = m_strName2CmdId.find(lpszName);
	if (it != m_strName2CmdId.end()) {
		nCmdId = it->second;
	} else {
		nCmdId = tcsto<UINT>((LPCTSTR)lpszName);
	}
	return nCmdId;
}

LPCTSTR CMainFrame::MapCmdline(LPCTSTR lpszCmdline, UINT nCmdId)
{
	if(nCmdId) {
		m_nId2Cmdline[nCmdId] = lpszCmdline;
		return m_nId2Cmdline[nCmdId];
	}
	return NULL;
}

LPCTSTR CMainFrame::MapCmdline(UINT nCmdId, LPCTSTR lpszCmdline)
{
	if(nCmdId) {
		m_nId2Cmdline[nCmdId] = lpszCmdline;
		return m_nId2Cmdline[nCmdId];
	}
	return NULL;
}

LPCTSTR CMainFrame::MapCmdline(UINT nCmdId)
{
	CmdId2Cmdline::iterator it = m_nId2Cmdline.find(nCmdId);
	if (it != m_nId2Cmdline.end()) {
		return it->second;
	}
	return NULL;
}

void CMainFrame::DoCmdMap()
{
	//MapCmdId();
	//MapCmdline();
}

void CMainFrame::DoXmlMenu(HMENU hMenu, Markup* xml)
{
	TCHAR szBuf[1024];
	CMenuHandle menu = hMenu;
	long cookie = 0;
	for (cookie = xml->First(); cookie != 0; cookie = xml->Next(cookie))
	{
		xml->IntoElem();
		CString strName = xml->GetAttributeString(_T(""), _T("name"), szBuf, 1024);
		UINT nFlags = xml->GetAttributeT<UINT>(_T(""), _T("style"), MF_STRING);
		if (strName.IsEmpty()) {
			menu.AppendMenu(MF_SEPARATOR);
		} else {
			if (nFlags & MF_POPUP) {
				CMenuHandle submenu;
				submenu.CreatePopupMenu();
				DoXmlMenu(submenu, xml);
				menu.AppendMenu(MF_POPUP, submenu, (LPCTSTR)strName);
			} else {
				CString strCmd = xml->GetAttributeString(_T(""), _T("cmd"), szBuf, 1024);
				menu.AppendMenu(nFlags, MapCmdId(strCmd), (LPCTSTR)strName);
			}
		}
		xml->OutofElem();
	}
}

BOOL CMainFrame::Execute(LPCTSTR lpszCmdline)
{
	return FALSE;
}

BOOL CMainFrame::PreTranslateMessage(MSG* pMsg)
{
	if (MsgFilter::PreTranslateMessage(pMsg)) {
		return TRUE;
	}
	
	if (!IsStrategy()) {
		//���ﲻҪ����SendMessage����PostMessage��ת����Ϣ����Ҫ��ǰ��������Ϣ����ȷ���ö�Ӧ�ĺ�����������ȷ����������TRUE�����򷵻�FALSE
		BOOL bHandled = FALSE;
		switch(pMsg->message)
		{
		case WM_KEYDOWN:
			if (m_AddressBar.GetEditCtrl() == GetFocus()) {
				break;
			} else if (m_pSmartKBDlg && m_pSmartKBDlg->IsWindowVisible()) {
				break;
			}
			bHandled = TRUE;
			OnKeyDown(pMsg->message, pMsg->wParam, pMsg->lParam, bHandled);
			break;
		case WM_CHAR:
			bHandled = TRUE;
			OnChar(pMsg->message, pMsg->wParam, pMsg->lParam, bHandled);
			break;
		}
		if(bHandled) {
			return TRUE;
		}
	}

	return Base::PreTranslateMessage(pMsg);
}

BOOL CMainFrame::OnIdle()
{
	BOOL bContinue = FALSE;

	int i,j;

	WndObjecter* pContainer = m_pContainer;
	UIWnd2 wndContainer(pContainer?pContainer->GetThisHwnd():NULL);
	
	if (m_ChildView) {
		int nItem = m_ChildView.GetActivePage();
		if (nItem>=0 && nItem<m_PageInfoPtrs.size()) {
			//USES_CONVERSION;
			//A2T(m_PageInfoPtrs[nItem]->InfoPtr->CommodityListPtr->CommodityList[m_PageInfoPtrs[nItem]->InfoPtr->CurCommodityPos].Code);
			CString strNew ;
			wndContainer.GetWindowText(strNew);
			CString strNow = m_ChildView.GetPageTitle(nItem);
			if (strNow != strNew) {
				m_ChildView.SetPageTitle(nItem, strNew);
			}
		}
	}

	UIUpdateToolBar();
	
	return bContinue;
}

HWND CMainFrame::Create(HWND hWndParent, ATL::_U_RECT rect, LPCTSTR szWindowName,
			DWORD dwStyle, DWORD dwExStyle,
			HMENU hMenu, LPVOID lpCreateParam)
{
	return Base::Create(hWndParent, rect, szWindowName, dwStyle, dwExStyle, hMenu, lpCreateParam);
}

HWND CMainFrame::Create(HWND hWndParent, LPCTSTR lpszXml, UINT XmlFlag)
{ 
	ASSERT(0);
	return NULL;
}

void CMainFrame::Destroy()
{
	if (m_hWnd) {
		DestroyWindow();
	}
}

LRESULT CMainFrame::OnCreate(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
{
	long i,j;
	TCHAR szBuf[1024];

	//�����������
	LoadDispInfo(); 

	//��ʼ���ڴ���
	CreateSimpleReBar(ATL_SIMPLE_REBAR_NOBORDER_STYLE);
	m_Rebar.SubclassWindow(m_hWndToolBar);

	//���������
	//������->�ȸ���ǰ����->�ȸ���ǰ��ͼ---|
	//	������<-����ǰ����<-��ǰ��ͼ������<-
	//
	//��ʼ����������ӳ��
	MapCmdId(ID_COMMAND_OPTION, _T("Option"));
	MapCmdId(ID_COMMAND_BACK, _T("Back"));
	MapCmdId(ID_COMMAND_FORWARD, _T("Forward"));
	MapCmdId(ID_COMMAND_ESCAPE, _T("Esc"));
	MapCmdId(ID_COMMAND_HOME, _T("Home"));
	MapCmdId(ID_COMMAND_REPORT, _T("Reort"));
	MapCmdId(ID_COMMAND_TECH, _T("Tech"));
	MapCmdId(ID_COMMAND_SEARCH, _T("Search"));
	MapCmdId(ID_COMMAND_SELECT_KIND, _T("SelectKind"));
	MapCmdId(ID_COMMAND_SELECT_COMMODITY, _T("SelectCommodity"));
	MapCmdId(ID_TECHVIEW_TEST, _T("Order"));
	MapCmdId(ID_COMMAND_ROBOT, _T("Robot"));

	
	MapCmdId(ID_CONTAINER_HOME, _T("Begin"));
	MapCmdId(ID_CONTAINER_END, _T("End"));
	MapCmdId(ID_CONTAINER_LEFT, _T("Left"));
	MapCmdId(ID_CONTAINER_RIGHT, _T("Right"));
	MapCmdId(ID_CONTAINER_UP, _T("Up"));
	MapCmdId(ID_CONTAINER_DOWN, _T("Down"));
	MapCmdId(ID_CONTAINER_PAGEUP, _T("PageUp"));
	MapCmdId(ID_CONTAINER_PAGEDOWN, _T("PageDown"));
		
	MapCmdId(ID_CONTAINER_ORDER_BUY, _T("OrderBuy"));
	MapCmdId(ID_CONTAINER_ORDER_SELL, _T("OrderSell"));
	MapCmdId(ID_CONTAINER_ORDER_SEND_LIMIT, _T("OrderSendLimit"));
	MapCmdId(ID_CONTAINER_ORDER_SEND_STOP, _T("OrderSendStop"));
	MapCmdId(ID_CONTAINER_ORDER_CLOSE, _T("OrderClose"));

	MapCmdId(ID_CONTAINER_F10, _T("F10"));
	MapCmdId(ID_CONTAINER_PERIOD, _T("Period"));
	for (i=0; i<CYC_MAX; i++)
	{
		Period2String(szBuf, 1024, (ENUM_TIMEFRAMES)i, 0);
		MapCmdId(ID_CONTAINER_PERIOD + i, szBuf);
	}
	MapCmdId(ID_CONTAINER_DW, _T("Disright"));
	for (i=0; i<DW_MAX; i++)
	{
		DWType2String(szBuf, (ENUM_DWTYPE)i);
		MapCmdId(ID_CONTAINER_PERIOD + i, szBuf);
	}

	MapCmdId(ID_REPORT_NEWCONTAINER, _T("goto"));
	MapCmdId(ID_REPORT_NEWCONTAINER, _T("new"));

	MapCmdId(ID_TECHVIEW_SHOWCROSSCURSOR, _T("showcrosscursor"));
	MapCmdId(ID_TECHVIEW_SHOWMINITRADER, _T("showminitrader"));
	MapCmdId(ID_TECHVIEW_LARGER, _T("larger"));
	MapCmdId(ID_TECHVIEW_SMALLER, _T("smaller"));
	MapCmdId(ID_TECHVIEW_AUTO, _T("auto"));
	MapCmdId(ID_TECHVIEW_SHIFT, _T("shift"));
	MapCmdId(ID_TECHVIEW_TEMPLATE, _T("template"));
	MapCmdId(ID_TECHVIEW_TEMPLATE_SAVE, _T("template_save"));
	MapCmdId(ID_TECHVIEW_KLINE, _T("kline"));
	MapCmdId(ID_TECHVIEW_KLINE+KLINE_BAR, _T("barline"));
	MapCmdId(ID_TECHVIEW_KLINE+KLINE_TREND, _T("trendline"));
	MapCmdId(ID_TECHVIEW_VOLUME, _T("volume"));
	MapCmdId(ID_TECHVIEW_ADD, _T("add"));
	MapCmdId(ID_TECHVIEW_REMOVE, _T("remove"));

	for (i=0; i<TVLT_MAX; i++)
	{
		if (i==0) {
			MapCmdId(ID_TECHVIEW_INDICATOR_ADDOBJECT + i, _T("NOLINE"));
		} else {
			MapCmdId(ID_TECHVIEW_INDICATOR_ADDOBJECT + i, iDrawline2String(szBuf, 1024, i));
		}
	}

	CString strXmlFile;
	strXmlFile.Format(_T("%s\\mainfrm.xml"), _Module.GetAppPath());
	Markup xml;
	if(xml.Open(strXmlFile)) {
		if(xml.Find(_T("mainfrm"))) {
			xml.IntoElem();
			//
			if(xml.Find(_T("cmdlist"))) {
				xml.IntoElem();
				UINT nUserCmdId = ID_COMMAND_MAX;
				long cookie = 0;
				for (cookie = xml.First(); cookie != 0; cookie = xml.Next(cookie))
				{
					xml.IntoElem();
					CString strName = xml.GetAttributeString(_T(""), _T("name"), szBuf, 1024);
					if (!strName.IsEmpty()) {
						UINT nCmdId = _HEXVALUE(xml.GetAttributeString(_T(""), _T("cmdid"), szBuf, 1024));
						if (!nCmdId) {
							nCmdId = nUserCmdId++;
						}
						MapCmdline(MapCmdId(strName, nCmdId), (LPCTSTR)xml.GetAttributeString(_T(""), _T("cmdline"), szBuf, 1024));
					}
					xml.OutofElem();
				}
				xml.OutofElem();
			}
			DoCmdMap();
			//
			if(xml.Find(_T("toolbar"))) {
				xml.IntoElem();
				long cookie = 0;
				for (cookie = xml.First(); cookie != 0; cookie = xml.Next(cookie))
				{
					xml.IntoElem();
					std::tstring tagName;
					xml.GetName(tagName);
					if(_tcsicmp(tagName.c_str(), _T("menu")) == 0) {
						if (m_CmdBar.m_hWnd) {
							continue;
						}
						CMenuHandle menu = GetMenu();
						for (i=menu.GetMenuItemCount(); i>0; i--)
						{
							menu.DeleteMenu(i-1, MF_BYPOSITION);
						}
						long menu_cookie = 0;
						for (menu_cookie = xml.First(); menu_cookie != 0; menu_cookie = xml.Next(menu_cookie))
						{
							xml.IntoElem();
							CString strName = xml.GetAttributeString(_T(""), _T("name"), szBuf, 1024);
							CMenuHandle submenu;
							submenu.CreatePopupMenu();
							DoXmlMenu(submenu, &xml);
							menu.AppendMenu(MF_POPUP, submenu, (LPCTSTR)strName);
							xml.OutofElem();
						}

						// create command bar window
						HWND hWndCmdBar = m_CmdBar.Create(m_hWnd, rcDefault, NULL, ATL_SIMPLE_CMDBAR_PANE_STYLE);
						// attach menu
						m_CmdBar.AttachMenu(GetMenu());
						// load command bar images
						//m_CmdBar.LoadImages(IDR_MAINFRAME);
						// remove old menu
						SetMenu(NULL);

						AddSimpleReBarBand(hWndCmdBar, NULL, TRUE);
					} else {
						CString strName = xml.GetAttributeString(_T(""), _T("name"), szBuf, 1024);
						const DWORD sStyle = ATL_SIMPLE_TOOLBAR_PANE_STYLE;
						DWORD dwStyle = xml.GetAttributeT<DWORD>(_T(""), _T("style"), ATL_SIMPLE_TOOLBAR_PANE_STYLE | TBSTYLE_LIST | TBSTYLE_REGISTERDROP);
						DWORD dwExStyle = xml.GetAttributeT<DWORD>(_T(""), _T("exstyle"), 
							TBSTYLE_EX_DRAWDDARROWS //֧��������ť
							);
						BOOL bBreak = xml.GetAttributeT<BOOL>(_T(""), _T("break"));
						UINT nWidth = xml.GetAttributeT<UINT>(_T(""), _T("width"), 0);
						CString strImageList = xml.GetAttributeString(_T(""), _T("imagelist"), szBuf, 1024);
						m_ToolBars.push_back(QToolBarCtrl());
						QToolBarCtrl & toolbar = m_ToolBars.back();
						if(strName.CompareNoCase(_T("Address")) == 0) {
							RECT rcAddressBar = {0, 0, 1, 22};
							m_AddressBar.Create(m_hWnd, rcAddressBar, NULL
								, WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | WS_CLIPCHILDREN
								| CBS_DROPDOWN | CBS_AUTOHSCROLL
								, 0, (HMENU)NULL, &xml);
							AddSimpleReBarBand(m_AddressBar, NULL, bBreak, nWidth);
							//UIAddToolBar(m_AddressBar);
							SendEvent(&m_AddressBar.m_cb, EVT_PLAT_CALL, MAKEVALUE(MSET_PLAT_OBJECT,CSET_OBJECT_DISPINFO), GetDispInfoPtr());
						} else if(strName.CompareNoCase(_T("Period")) == 0) {
							toolbar.SubclassWindow(CreateSimpleToolBarCtrl(m_hWnd, IDR_MAINFRAME, FALSE, dwStyle));
							ASSERT(toolbar.m_hWnd);
							CToolTipCtrl tooltip = toolbar.GetToolTips();
							toolbar.SetExtendedStyle(dwExStyle);
							toolbar.SetImageList(NULL);
							toolbar.DeleteButton(0);
							for (i = 0; i<CYC_MAX; i++)
							{
								Period2String(szBuf, 1024, (ENUM_TIMEFRAMES)i, 0);
								UINT nCmdId = MapCmdId(szBuf);
								toolbar.AddButton(nCmdId, BTNS_CHECK | BTNS_AUTOSIZE | BTNS_CHECKGROUP, TBSTATE_ENABLED, -1, szBuf, (DWORD_PTR)0);
								if (nCmdId != 0) {
									//�趨��������ť����ʾ����
									if (tooltip) {
										CRect rect;
										toolbar.GetItemRect(i, &rect);
										tooltip.AddTool(toolbar, (LPCTSTR)szBuf, &rect, nCmdId);
									}
								}
								UIAddUpdateElement(nCmdId, UPDUI_TOOLBAR|UPDUI_MENUPOPUP);
							}
							AddSimpleReBarBand(toolbar, NULL, bBreak, nWidth);
							UIAddToolBar(toolbar);
						} else {
							toolbar.SubclassWindow(CreateSimpleToolBarCtrl(m_hWnd, IDR_MAINFRAME, FALSE, dwStyle));
							ASSERT(toolbar.m_hWnd);
							toolbar.SetExtendedStyle(dwExStyle);
							//toolbar.SetBitmapSize(20,20);
							//toolbar.SetButtonWidth(20,100);
							if(!strImageList.IsEmpty()) {
								toolbar.SetImageList(_PlatformPtr->GetImageList(strImageList));
							}
							toolbar.DeleteButton(0);
							long tbcookie = 0;
							for (i = 0,tbcookie = xml.First(); tbcookie != 0; i++,tbcookie = xml.Next(tbcookie))
							{
								xml.IntoElem();
								CString strName = xml.GetAttributeString(_T(""), _T("name"), szBuf, 1024);
								CString strTip = xml.GetAttributeString(_T(""), _T("tip"), szBuf, 1024);
								const long sepstyle = BTNS_SEP;
								const long btnstyle = BTNS_BUTTON | BTNS_AUTOSIZE; //16
								const long btndrapstyle = BTNS_BUTTON | BTNS_AUTOSIZE | BTNS_WHOLEDROPDOWN; //144
								const long btnsplitstyle = BTNS_BUTTON | BTNS_AUTOSIZE | BTNS_DROPDOWN; //24
								const long btncheckstyle = BTNS_CHECK | BTNS_AUTOSIZE; //18
								const long btncheckgroupstyle = BTNS_CHECK | BTNS_AUTOSIZE | BTNS_CHECKGROUP; //22
								long Style = xml.GetAttributeT<long>(_T(""), _T("style"), BTNS_BUTTON | BTNS_AUTOSIZE);
								CString strCmd = xml.GetAttributeString(_T(""), _T("cmd"), szBuf, 1024);
								int image = xml.GetAttributeT<int>(_T(""), _T("image"), 0);
								UINT nCmdId = MapCmdId(strCmd);
								toolbar.AddButton(nCmdId, Style, TBSTATE_ENABLED, image, strName, (DWORD_PTR)0);
								if (nCmdId != 0) {
									//�趨��������ť����ʾ����
									CToolTipCtrl tooltip = toolbar.GetToolTips();
									if (tooltip) {
										CRect rect;
										toolbar.GetItemRect(i, &rect);
										tooltip.AddTool(toolbar, (LPCTSTR)strTip, &rect, nCmdId);
									}
									UIAddUpdateElement(nCmdId, UPDUI_TOOLBAR|UPDUI_MENUPOPUP);
								}
								xml.OutofElem();
							}
							AddSimpleReBarBand(toolbar, NULL, bBreak, nWidth);
							UIAddToolBar(toolbar);
						}
					}
					xml.OutofElem();
				}
				xml.OutofElem();
			}
			xml.OutofElem();

			SizeSimpleReBarBands();

			m_Rebar.LockBands(true);

			CreateSimpleStatusBar();
			m_StatusBar.SubclassWindow(m_hWndStatusBar);


			//UISetCheck(IDR_MAINFRAME, 1);
			//UISetCheck(ATL_IDW_STATUS_BAR, 1);
			UISetBlockAccelerators(true);
		}
	} else {
		/*// create command bar window
		HWND hWndCmdBar = m_CmdBar.Create(m_hWnd, rcDefault, NULL, ATL_SIMPLE_CMDBAR_PANE_STYLE);
		// attach menu
		m_CmdBar.AttachMenu(GetMenu());
		// load command bar images
		m_CmdBar.LoadImages(IDR_MAINFRAME);
		// remove old menu
		SetMenu(NULL);

		HWND hWndToolBar = CreateSimpleToolBarCtrl(m_hWnd, IDR_MAINFRAME, FALSE, ATL_SIMPLE_TOOLBAR_PANE_STYLE);

		AddSimpleReBarBand(hWndCmdBar);
		AddSimpleReBarBand(hWndToolBar, NULL, TRUE);

		SizeSimpleReBarBands();

		m_Rebar.LockBands(false);

		CreateSimpleStatusBar();
		m_StatusBar.SubclassWindow(m_hWndStatusBar);

		UIAddToolBar(hWndToolBar);
		UISetCheck(ID_VIEW_TOOLBAR, 1);
		UISetCheck(ID_VIEW_STATUS_BAR, 1);*/
	}

	//m_Rebar.EnableWindow(FALSE);
	//m_StatusBar.ShowWindow(SW_HIDE);

	if (!m_AddressBar) {
		m_pSmartKBDlg = new CSmartKBDlg();
		strXmlFile.Format(_T("%s\\SmartKBDlg.xml"), _pUISkinManager->GetSkinPath());
		m_pSmartKBDlg->Create(m_hWnd,strXmlFile);
		SendEvent(&m_pSmartKBDlg->m_smartkb, EVT_PLAT_CALL, MAKEVALUE(MSET_PLAT_OBJECT,CSET_OBJECT_DISPINFO), GetDispInfoPtr());
	}

	m_hWndClient = m_ChildView.Create(m_hWnd, rcDefault, NULL, WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | WS_CLIPCHILDREN, 0);
	
	// register object for message filtering and idle updates
	CMessageLoop* pLoop = _Module.GetMessageLoop();
	ATLASSERT(pLoop != NULL);
	pLoop->AddMessageFilter(this);
	pLoop->AddIdleHandler(this);

	XFrame::Create(m_hWnd,NULL,XML_FLAG_STREAM);
	
	if (IsStrategy()) {
		SetWindowText(m_strName+_T("|")+m_strCmdLine);
		m_hStrategy = iRefPool(m_strName,m_strCmdLine,XML_FLAG_STREAM);

	} else {
		//
	}

	//TCHAR szPath[MAX_PATH] = {0};
	//_stprintf(szPath, _T("%s\\%s"), _Module.GetAppPath(), _T("rptcontainer.xml"));
	//SetCurContainer(CreateContainer(_T("RptContainer"), szPath));

	if (IsStrategy()) {
		/*int nBandCount = m_Rebar.GetBandCount();
		for (i=nBandCount-2; i>=0; i--)
		{
			m_Rebar.ShowBand(i,FALSE);
		}*/
		m_Rebar.ShowWindow(SW_HIDE);
		m_StatusBar.ShowWindow(SW_HIDE);
	} else {
		//
	}

	//��¼
	PostMessage(WM_CREATED);

	//m_nTimer = SetTimer(ID_TIMER, 200); //200���붨ʱ��

	return 0;
}

LRESULT CMainFrame::OnCreated(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	//Login();

	int i;

	if (m_SmartKBCommkodityInfoPtr) {
		if(!m_SmartKBCommkodityInfoPtr->SmartKBPtrList.empty()) {
			//DoSmartKB(m_SmartKBCommkodityInfoPtr->SmartKBPtrList.front());
			for (i=0; i<m_SmartKBCommkodityInfoPtr->SmartKBPtrList.size(); i++)
			{
				if (_tcsicmp(m_SmartKBCommkodityInfoPtr->SmartKBPtrList[i]->GetKey(), _T("600000"))==0) {
					DoSmartKB(m_SmartKBCommkodityInfoPtr->SmartKBPtrList[i]);
				}
			}
		}
	}

	//m_nReqPushTimer = SetTimer(ID_REQPUSHTIMER, 200); //����ע�����Ͷ�ʱ��

	return bHandled;
}

HWND CMainFrame::CreateControl(HWND hWndParent, LPCTSTR lpszWndClass, LPCTSTR lpszCtrlName, UINT nID, LPCTSTR lpszXml, UINT XmlFlag)
{
	if (_tcsicmp(lpszWndClass, Pane::GetXmlPaneName()) != 0) {
		HWND hWndCtrl = CreateObjecter(lpszWndClass, hWndParent, lpszXml, XmlFlag);
		OnCreateControl(hWndParent, hWndCtrl, lpszWndClass, lpszCtrlName, nID);
		return hWndCtrl;
	}
	return PaneSplitter::CreateControl(hWndParent, lpszWndClass, lpszCtrlName, nID, lpszXml, XmlFlag);
}

/*
void CMainFrame::UpdateTabControl()
{
	if (!m_ChildView) {
		return;
	}

	ASSERT(m_pRptContainer);

	int i,j,k;
	int nActivePage = m_ChildView.GetActivePage();
	PageInfoPtr ActivePagePtr;
	if (nActivePage>=0 && nActivePage<m_PageInfoPtrs.size()) {
		ActivePagePtr = m_PageInfoPtrs[nActivePage];
	}

	m_ChildView.RemoveAllPages();
	m_PageInfoPtrs.clear();

	for (i=0; i<m_AllKindInfoPtr->KindList.size(); i++)
	{
		const KindInfo& Kind = m_AllKindInfoPtr->KindList[i].KindList[m_AllKindInfoPtr->KindList[i].CurKindPos];
		m_ChildView.AddPage(*m_pRptContainer, Kind.KindList.size()>1?Kind.Name.c_str():Kind.KindList[0].Name);
		PageInfoPtr PagePtr = new PageInfo();
		PagePtr->KindList = m_AllKindInfoPtr->KindList[i];
		PagePtr->InfoPtr->pContainer = m_pRptContainer;
		m_PageInfoPtrs.push_back(PagePtr);
	}

	if (ActivePagePtr) {
		for (i=0; i<m_AllKindInfoPtr->KindList.size(); i++)
		{
			const std::vector<KindInfo>& KindList = m_AllKindInfoPtr->KindList[i].KindList;
			for (j=0; j<KindList.size(); j++)
			{	
				const KindInfo & ActiveKind = ActivePagePtr->KindList.KindList[ActivePagePtr->KindList.CurKindPos];
				if (KindList[j].KindList.size() == ActiveKind.KindList.size()) {
					for (k=0; k<KindList[j].KindList.size(); k++)
					{
						if (KindList[j].KindList[k].Id != ActiveKind.KindList[k].Id) {
							break;
						}
					}
					if (k<KindList[j].KindList.size()) {
						break;
					}
				}
			}
			if (j<KindList.size()) {
				m_AllKindInfoPtr->KindList[i].CurKindPos = j;
				break;
			}
		}
	} 
	if (i<m_AllKindInfoPtr->KindList.size()) {
		const KindInfo& Kind = m_AllKindInfoPtr->KindList[i].KindList[m_AllKindInfoPtr->KindList[i].CurKindPos];
		m_ChildView.SetPageTitle(i, Kind.KindList.size()>1?Kind.Name.c_str():Kind.KindList[0].Name);
		m_ChildView.SetActivePage(i);
	} else {
		m_ChildView.SetActivePage(0);
	}
}
*/

void CMainFrame::GetPushInfo()
{
	XFrame::GetPushInfo();

	BroadcastSend(EVT_PLAT_CALL, MAKEVALUE(MGET_PLAT_OBJECT,CGET_OBJECT_PUSHINFO), m_PushInfoPtr);
}

WndObjecter* CMainFrame::CreateContainer(LPCTSTR lpszName, LPCTSTR lpszXml, UINT XmlFlag)
{
	WndObjecter* pContainer = NULL;
	HWND hWndContainer = NULL;
	if (m_ChildView) {
		hWndContainer = CreateObjecter(lpszName, m_ChildView, lpszXml, XmlFlag);
	} else {
		hWndContainer = CreateObjecter(lpszName, m_hWnd, lpszXml, XmlFlag);
	}
	if (hWndContainer) {
		pContainer = GetObjecterBy(hWndContainer);
		ASSERT(pContainer);
		
		if (_tcsicmp(pContainer->GetThisClassName(),_T("scdtcontainer")) == 0) {
			m_pScdtContainer = pContainer;
		} else if (_tcsicmp(pContainer->GetThisClassName(),_T("RptContainer")) == 0) {
			m_pRptContainer = pContainer;
		}
	}
	return pContainer;
}

void CMainFrame::DestroyContainer(WndObjecter* pContainer)
{
	UINT i,j;
	if(pContainer) {
		DestroyObjecter(pContainer);
		if (pContainer == m_pRptContainer) {
			for (i=0,j=GetObjecterCount(); i<j; i++)
			{
				m_pRptContainer = GetObjecterBy(i);
				if (_tcsicmp(_T("RptContainer"),m_pRptContainer->GetThisClassName()) == 0) {
					break;
				}
			}
			if (i >= j) {
				m_pRptContainer = NULL;
			}
		}
		if (pContainer == m_pScdtContainer) {
			for (i=0,j=GetObjecterCount(); i<j; i++)
			{
				m_pScdtContainer = GetObjecterBy(i);
				if (_tcsicmp(_T("ScdtContainer"),m_pScdtContainer->GetThisClassName()) == 0) {
					break;
				}
			}
			if (i >= j) {
				m_pScdtContainer = NULL;
			}
		}
		if (pContainer == m_pContainer) {
			m_pContainer = NULL;
		}
	}
}

WndObjecter* CMainFrame::FindContainer(LPCTSTR lpszName)
{
	int i;
	for (i=(int)GetObjecterCount()-1; i>=0; i--)
	{
		WndObjecter* pContainer = GetObjecterBy((UINT)i);
		if (_tcsicmp(lpszName,pContainer->GetThisClassName()) == 0) {
			return pContainer;
		}
	}
	return NULL;
}

WndObjecter* CMainFrame::SetCurContainer(WndObjecter* pContainer)
{
	if (pContainer) {
		UIWnd2 wndContainer(pContainer->GetThisHwnd());

		if (m_pScdtContainer != pContainer && _tcsicmp(pContainer->GetThisClassName(),_T("scdtcontainer")) == 0) {
			m_pScdtContainer = pContainer;
		} else if (m_pRptContainer != pContainer && _tcsicmp(pContainer->GetThisClassName(),_T("RptContainer")) == 0) {
			m_pRptContainer = pContainer;
		}
		
		m_pContainer = pContainer;
	}
	return m_pContainer;
}

//CMainFrame::PageInfoPtr CMainFrame::GetCurPage()
//{
//	return m_CurPagePtr;
//}

void CMainFrame::SetCurPage(int nItem, UINT uFlags)
{
	m_CurPagePtr = m_PageInfoPtrs[nItem];
	if (uFlags != PAGE_NONE || IsRptPage(m_CurPagePtr)) {
		SendEvent(m_CurPagePtr->InfoPtr->pContainer, EVT_PLAT_CALL, MAKEVALUE(MSET_PLAT_OBJECT,CSET_CONTAINER_INFO), m_CurPagePtr->InfoPtr);
	}
	SetCurContainer(m_CurPagePtr->InfoPtr->pContainer);

	AddHisRecord(m_CurPagePtr);
}

void CMainFrame::GotoPage(int nItem, UINT uFlags)
{
	if (nItem<0 || nItem>=m_PageInfoPtrs.size()) {
		return;
	}

	WndObjecter* pCurContainer = m_pContainer;
	UIWnd2 wndCurContainer(pCurContainer?m_pContainer->GetThisHwnd():NULL);

	WndObjecter* pContainer = m_PageInfoPtrs[nItem]->InfoPtr->pContainer;
	UIWnd2 wndContainer(pContainer?pContainer->GetThisHwnd():NULL);

	if (m_ChildView) {
	} else {
		if (pCurContainer != pContainer) {
			if (pCurContainer) {
				wndCurContainer.ShowWindow(SW_HIDE);
			}
		}
	}

	SetCurPage(nItem, uFlags);

	if (m_ChildView) {
		if (!(uFlags & PAGE_NEW_PAGE)) {
			int nActivePage = m_ChildView.GetActivePage();
			if (nActivePage != nItem) {
				m_ChildView.SetActivePage(nItem);
			}
			CString strTitle;
			wndContainer.GetWindowText(strTitle);
			m_ChildView.SetPageTitle(nItem, strTitle);
		} else {
			CString strTitle;
			wndContainer.GetWindowText(strTitle);
			m_ChildView.InsertPage(nItem, wndContainer, strTitle);
		}
		wndContainer.SetFocus();
	} else {
		m_hWndClient = wndContainer;
		UpdateLayout();
		wndContainer.ShowWindow(SW_SHOW);
		wndContainer.SetFocus();
	}
}

bool CMainFrame::IsRptPage(const PageInfoPtr& PagePtr)
{
	if (PagePtr
		&& !PagePtr->InfoPtr->KindList.KindList.empty()) {
		return true;
	}
	return false;
}

bool CMainFrame::IsScdtPage(const PageInfoPtr& PagePtr)
{
	if (PagePtr
		&& PagePtr->InfoPtr->KindList.KindList.empty()) {
		return true;
	}
	return false;
}

void CMainFrame::Goto(const KindInfo& Kind)
{
	int i,j;
	if (Kind.IsInvalid()) {
		return;
	}

	PageInfoPtr CurPagePtr = m_CurPagePtr;
	if (IsRptPage(CurPagePtr)) {
		if (CurPagePtr->InfoPtr->CommodityListPtr->Kind == Kind) {
			return;
		}
	}

	for (i=0; i<m_PageInfoPtrs.size(); i++)
	{
		for(j=0; j<m_PageInfoPtrs[i]->InfoPtr->KindList.KindList.size(); j++)
		{
			if (IsRptPage(m_PageInfoPtrs[i])) {
				if (Kind == m_PageInfoPtrs[i]->InfoPtr->KindList.KindList[j]) {
					break;
				}
			}
		}
		if (j < m_PageInfoPtrs[i]->InfoPtr->KindList.KindList.size()) {
			break;
		}
	}
	if (i < m_PageInfoPtrs.size()) {
		//���µ�ǰPageInfoPtr
		if (j != m_PageInfoPtrs[i]->InfoPtr->KindList.CurKindPos) {
			m_PageInfoPtrs[i]->InfoPtr->KindList.CurKindPos = j;
		}
		m_PageInfoPtrs[i]->InfoPtr->CommodityListPtr->Kind = m_PageInfoPtrs[i]->InfoPtr->KindList.KindList[m_PageInfoPtrs[i]->InfoPtr->KindList.CurKindPos];
		m_PageInfoPtrs[i]->InfoPtr->CommodityListPtr->CommodityList.clear();
		m_PageInfoPtrs[i]->InfoPtr->CurCommodityPos = -1;
		SendEvent(_DataPtr, EVT_PLAT_CALL, MAKEVALUE(MGET_PLAT_DE,CGET_DE_COMMODITYLIST), m_PageInfoPtrs[i]->InfoPtr->CommodityListPtr);

		GotoPage(i, PAGE_KIND_CHANGED);
	
		return;
	}

	for (i=0; i<m_AllKindInfoPtr->AllKindList.size(); i++)
	{
		const std::vector<KindInfo>& KindList = m_AllKindInfoPtr->AllKindList[i].KindList;
		for (j=0; j<KindList.size(); j++)
		{	
			if (Kind == KindList[j]) {
				break;
			}
		}
		if (j<KindList.size()) {
			break;
		}
	}

	if (i < m_AllKindInfoPtr->AllKindList.size()) {
		PageInfoPtr PagePtr = new PageInfo(new ContainerInfo());
		PagePtr->InfoPtr->KindList = m_AllKindInfoPtr->AllKindList[i];
		PagePtr->InfoPtr->KindList.CurKindPos = j;
		PagePtr->InfoPtr->pContainer = m_pRptContainer;

		for (i=0; i<m_PageInfoPtrs.size(); i++)
		{
			if (!IsRptPage(m_PageInfoPtrs[i])) {
				break;
			}
		}
		m_PageInfoPtrs.insert(m_PageInfoPtrs.begin()+i, PagePtr);

		m_PageInfoPtrs[i]->InfoPtr->CommodityListPtr->Kind = m_PageInfoPtrs[i]->InfoPtr->KindList.KindList[m_PageInfoPtrs[i]->InfoPtr->KindList.CurKindPos];
		m_PageInfoPtrs[i]->InfoPtr->CommodityListPtr->CommodityList.clear();
		m_PageInfoPtrs[i]->InfoPtr->CurCommodityPos = -1;
		SendEvent(_DataPtr, EVT_PLAT_CALL, MAKEVALUE(MGET_PLAT_DE,CGET_DE_COMMODITYLIST), m_PageInfoPtrs[i]->InfoPtr->CommodityListPtr);
		
		GotoPage(i, PAGE_NEW_PAGE);
	}
}

void CMainFrame::Goto(const ContainerInfoPtr& InfoPtr, BOOL bNew)
{
	int i,j;

	if (!bNew) {
		COMREF Commodity;
		InfoPtr->GetCurCommodity(&Commodity);
		const KindInfo& Kind = InfoPtr->GetCurKind();

		PageInfoPtr CurPagePtr = m_CurPagePtr;
		if (IsScdtPage(CurPagePtr)) {
			COMREF tCommodity;
			CurPagePtr->InfoPtr->GetCurCommodity(&tCommodity);
			if (Commodity == tCommodity && Kind == CurPagePtr->InfoPtr->GetCurKind()) {
				return;
			}
		}

		for (i=m_PageInfoPtrs.size()-1; i>=0; i--)
		{
			if (IsScdtPage(m_PageInfoPtrs[i])) {
				if (m_PageInfoPtrs[i]->InfoPtr->pContainer == m_pScdtContainer) {
					break;
				}
			}
		}
		if (i >= 0) {
			UINT uFlags = PAGE_NONE;
			COMREF tCommodity;
			m_PageInfoPtrs[i]->InfoPtr->GetCurCommodity(&tCommodity);
			if (Commodity == tCommodity && Kind == m_PageInfoPtrs[i]->InfoPtr->GetCurKind()) {
				
			} else {
				ASSERT(!InfoPtr->pContainer);
				InfoPtr->pContainer = m_PageInfoPtrs[i]->InfoPtr->pContainer;
				m_PageInfoPtrs[i]->InfoPtr = InfoPtr;
				uFlags = PAGE_KIND_CHANGED|PAGE_COMMODITY_CHANGED;
			}

			GotoPage(i, uFlags);

			return;
		}
	}

	PageInfoPtr PagePtr = new PageInfo(InfoPtr);
	PagePtr->InfoPtr->pContainer = m_pScdtContainer;
	i = m_PageInfoPtrs.size();
	m_PageInfoPtrs.push_back(PagePtr);

	GotoPage(i, PAGE_NEW_PAGE);
}

void CMainFrame::Goto(const ContainerInfoPtr& InfoPtr, const COMREF& Commodity)
{
	int i,j;

	PageInfoPtr CurPagePtr = m_CurPagePtr;
	if (InfoPtr == CurPagePtr->InfoPtr && IsScdtPage(CurPagePtr)) {
		COMREF tCommodity;
		CurPagePtr->InfoPtr->GetCurCommodity(&tCommodity);
		if (Commodity == tCommodity) {
			return;
		}
	}

	for (i=m_PageInfoPtrs.size()-1; i>=0; i--)
	{
		if (InfoPtr == m_PageInfoPtrs[i]->InfoPtr && IsScdtPage(m_PageInfoPtrs[i])) {
			COMREFLIST& CommodityList = m_PageInfoPtrs[i]->InfoPtr->GetCommodityList();
			for (j=0; j<CommodityList.size(); j++)
			{
				if (Commodity == CommodityList[j]) {
					break;
				}
			}
			if (j < CommodityList.size()) {
				break;
			}
		}
	}
	if (i >= 0) {
		UINT uFlags = PAGE_NONE;
		if (m_PageInfoPtrs[i]->InfoPtr->GetCurCommodityPos() != j) {
			m_PageInfoPtrs[i]->InfoPtr->SetCurCommodity(j);
			uFlags |= PAGE_COMMODITY_CHANGED;
		}

		GotoPage(i, PAGE_COMMODITY_CHANGED);

		return;
	}

	ASSERT(TRUE);
}

void CMainFrame::Goto(int nOffset)
{
	if (m_nCurRecord<0) {
		return;
	}
	if (nOffset > 0) {
		if ((m_nCurRecord+nOffset) >= m_HisRecordList.size()) {
			return;
		}

		m_nCurRecord += nOffset;
	} else {
		if (nOffset == 0) {
			nOffset = -1;
		}
		if ((m_nCurRecord+nOffset) < 0) {
			return;
		}

		m_nCurRecord += nOffset;
	}

	m_bEnableRecord = FALSE;
	HisRecordInfoPtr recordPtr = m_HisRecordList[m_nCurRecord];
	if (recordPtr->IsRptPage()) {
		Goto(recordPtr->GetKind());
	} else if(recordPtr->IsScdtPage()) {
		Goto(recordPtr->GetInfoPtr(), recordPtr->GetCommodity());
	}
	m_bEnableRecord = TRUE;
}

void CMainFrame::AddHisRecord(PageInfoPtr PagePtr, int nKind, int nCommodity)
{
	if (!m_bEnableRecord) {
		return;
	}

	WndObjecter* pContainer = PagePtr->InfoPtr->pContainer;
	UIWnd2 wndContainer(pContainer?pContainer->GetThisHwnd():NULL);
	
	m_nCurRecord++;
	if (m_nCurRecord < m_HisRecordList.size()) {
		HisRecordPtrList::iterator it = m_HisRecordList.begin() + m_nCurRecord;
		HisRecordInfoPtr recordptr = *it;
		m_HisRecordList.erase(it);
		m_HisRecordList.push_back(recordptr);
	}
	if (m_HisRecordList.size()) {
		if (m_HisRecordList.back()->PagePtr == PagePtr)
		{
		}
	}
	HisRecordInfoPtr recordptr = new HisRecordInfo();
	wndContainer.GetWindowText(recordptr->strName);
	recordptr->PagePtr = PagePtr;
	recordptr->nKind = nKind<0 ? PagePtr->InfoPtr->GetCurKindPos() : nKind;
	recordptr->nCommodity = nCommodity<0 ? PagePtr->InfoPtr->GetCurCommodityPos() : nCommodity;
	m_HisRecordList.push_back(recordptr);

	if (m_HisRecordList.size() > 32) {
		m_HisRecordList.erase(m_HisRecordList.begin());
		m_nCurRecord--;
	}
}

void CMainFrame::RemoveRecord(PageInfoPtr PagePtr)
{
	HisRecordInfoPtr recordPtr = m_HisRecordList[m_nCurRecord];

	HisRecordPtrList::iterator it = m_HisRecordList.begin();
	for (; it!=m_HisRecordList.end(); )
	{
		if ((*it)->PagePtr == PagePtr) {
			it = m_HisRecordList.erase(it);
		} else {
			it++;
		}
	}

	it = std::find(m_HisRecordList.begin(), m_HisRecordList.end(), recordPtr);
	if (it != m_HisRecordList.end()) {
		m_nCurRecord = it - m_HisRecordList.begin();
	} else {
		m_nCurRecord = m_HisRecordList.size() - 1;
	}
}

void CMainFrame::ShowSmartKBDlg(BOOL bShow)
{
	if (!m_pSmartKBDlg) {
		return;
	}

	if (bShow) {
		if(!m_pSmartKBDlg->IsWindowVisible()) {
			CRect rcClient;
			if (m_pContainer) {
				UIWnd2 wndContainer(m_pContainer->GetThisHwnd());
				wndContainer.GetWindowRect(&rcClient);
				ScreenToClient(&rcClient);
			} else {
				if (m_ChildView) {
					m_ChildView.GetWindowRect(&rcClient);
					ScreenToClient(&rcClient);
				} else {
					CRect rcRebar;
					m_Rebar.GetWindowRect(&rcRebar);
					if (m_StatusBar) {
						rcClient = rcRebar;
						rcClient.top = rcRebar.bottom;
						CRect rcStatusBar;
						m_StatusBar.GetWindowRect(&rcStatusBar);
						rcClient.bottom = rcStatusBar.top;
					} else {
						ScreenToClient(&rcRebar);
						GetClientRect(&rcClient);
						rcClient.top = rcRebar.bottom;
					}
				}
			}
			CRect rcSmartKB;
			m_pSmartKBDlg->GetWindowRect(&rcSmartKB);
			ScreenToClient(&rcSmartKB);
			/*rcSmartKB.left = rcClient.right-rcSmartKB.Width();
			rcSmartKB.right = rcClient.right;
			rcSmartKB.top = rcClient.bottom-rcSmartKB.Height();
			rcSmartKB.bottom = rcClient.bottom;*/
			rcSmartKB.OffsetRect(rcClient.right-rcSmartKB.right-m_xySmartKBOffset.cx, rcClient.bottom-rcSmartKB.bottom-m_xySmartKBOffset.cy);
			ClientToScreen(&rcSmartKB);
			m_pSmartKBDlg->MoveWindow(&rcSmartKB);
			m_pSmartKBDlg->ShowWindow(SW_SHOW);
		}
	} else {
		if(m_pSmartKBDlg->IsWindowVisible()) {
			CRect rcClient;
			GetClientRect(&rcClient);
			CRect rcSmartKB;
			m_pSmartKBDlg->GetWindowRect(&rcSmartKB);
			ScreenToClient(&rcSmartKB);
			m_xySmartKBOffset.cx = rcClient.right-rcSmartKB.right;
			m_xySmartKBOffset.cy = rcClient.bottom-rcSmartKB.bottom;
			m_pSmartKBDlg->ShowWindow(SW_HIDE);
		}
	}
}

void CMainFrame::UpdateLayout(BOOL bResizeBars)
{
	RECT rect = { 0 };
	GetClientRect(&rect);

	// position bars and offset their dimensions
	UpdateBarsPosition(rect, bResizeBars);

	PaneSplitter::Relayout(&rect);

	// resize client window
	if(m_hWndClient != NULL)
		::SetWindowPos(m_hWndClient, NULL, rect.left, rect.top,
		rect.right - rect.left, rect.bottom - rect.top,
		SWP_NOZORDER | SWP_NOACTIVATE);
}

BOOL CMainFrame::OnEraseBkgnd(HDC hdc)
{
	CRect rcClient;
	GetClientRect(&rcClient);

	UIgdi::FillSolidRect(hdc, &rcClient, RGB(7,7,7));

	return TRUE;
}

DWORD CMainFrame::OnPrePaint(int /*idCtrl*/, LPNMCUSTOMDRAW lpNMCustomDraw)
{
	return CDRF_NOTIFYITEMDRAW;
}

DWORD CMainFrame::OnPostPaint(int /*idCtrl*/, LPNMCUSTOMDRAW /*lpNMCustomDraw*/)
{
	return CDRF_SKIPDEFAULT;
}

DWORD CMainFrame::OnPreErase(int /*idCtrl*/, LPNMCUSTOMDRAW /*lpNMCustomDraw*/)
{
	return CDRF_SKIPDEFAULT;
}

DWORD CMainFrame::OnPostErase(int /*idCtrl*/, LPNMCUSTOMDRAW /*lpNMCustomDraw*/)
{
	return CDRF_SKIPDEFAULT;
}

DWORD CMainFrame::OnItemPrePaint(int idCtrl, LPNMCUSTOMDRAW lpNMCustomDraw)
{
	NMTBCUSTOMDRAW* pTBCD = reinterpret_cast<NMTBCUSTOMDRAW*>( lpNMCustomDraw );

	if (lpNMCustomDraw->hdr.hwndFrom!=m_Rebar)
	{
		TCHAR szBuf[1024] = {0};
		UIToolBarCtrl toolbar = lpNMCustomDraw->hdr.hwndFrom;
		int nTextLen = toolbar.GetButtonText(lpNMCustomDraw->dwItemSpec,szBuf);
		if (szBuf[0])
		{
			CDCHandle dc(lpNMCustomDraw->hdc);
			//pTBCD->clrText = RGB(250,250,250);
			//::SetBkMode(lpNMCustomDraw->hdc,TRANSPARENT);
			::SetTextColor(lpNMCustomDraw->hdc, RGB(255,200,50));
			//::FillRect(lpNMCustomDraw->hdc, &lpNMCustomDraw->rc, GetStockBrush(DKGRAY_BRUSH));
			//::TextOut(lpNMCustomDraw->hdc, lpNMCustomDraw->rc.left, lpNMCustomDraw->rc.top, szBuf, nTextLen);

			HFONT hFont = toolbar.GetFont();
			HFONT hFontOld = NULL;
			if(hFont != NULL)
				hFontOld = dc.SelectFont(hFont);
			dc.DrawText(szBuf, -1, &lpNMCustomDraw->rc, DT_SINGLELINE | DT_CENTER | DT_VCENTER);
			if(hFont != NULL)
				dc.SelectFont(hFontOld);

			return CDRF_SKIPDEFAULT;
		}
	}

	return CDRF_DODEFAULT;
}

DWORD CMainFrame::OnItemPostPaint(int /*idCtrl*/, LPNMCUSTOMDRAW /*lpNMCustomDraw*/)
{
	return CDRF_SKIPDEFAULT;
}

DWORD CMainFrame::OnItemPreErase(int /*idCtrl*/, LPNMCUSTOMDRAW /*lpNMCustomDraw*/)
{
	return CDRF_SKIPDEFAULT;
}

DWORD CMainFrame::OnItemPostErase(int /*idCtrl*/, LPNMCUSTOMDRAW /*lpNMCustomDraw*/)
{
	return CDRF_SKIPDEFAULT;
}

#if (_WIN32_IE >= 0x0400)
DWORD CMainFrame::OnSubItemPrePaint(int /*idCtrl*/, LPNMCUSTOMDRAW /*lpNMCustomDraw*/)
{
	return CDRF_DODEFAULT;
}
#endif // (_WIN32_IE >= 0x0400)

LRESULT CMainFrame::OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	Base::OnDestroy(uMsg, wParam, lParam, bHandled);

	if (m_nTimer) {
		KillTimer(m_nTimer);
	}
	if (m_nReqPushTimer) {
		KillTimer(m_nReqPushTimer);
	}

	if (m_CmdBar.m_hWnd) {
		m_CmdBar.AttachMenu(NULL);
	}
	//m_ToolBar.UnsubclassWindow();
	//m_StatusBar.UnsubclassWindow();
	//m_Rebar.UnsubclassWindow();

	PaneSplitter::OnDestroy(uMsg, wParam, lParam, bHandled);

	MultiWndObjectMap::OnDestroy(uMsg, wParam, lParam, bHandled);
	m_pContainer = NULL;
	m_pRptContainer = NULL;
	m_pScdtContainer = NULL;

	if (m_pSmartKBDlg) {
		m_pSmartKBDlg->DestroyWindow();
		delete m_pSmartKBDlg;
		m_pSmartKBDlg = NULL;
	}

	Name2pMarkup::iterator iter = m_Name2pMarkup.begin();
	for (;iter != m_Name2pMarkup.end(); ++iter)
	{
		if (iter->second) {
			delete iter->second;
		}
	}
	m_Name2pMarkup.clear();

	WndObjectMap::Clear();

	if (m_hStrategy) {
		iRelease(m_hStrategy);
		m_hStrategy = NULL;
	}

	XFrame::Destroy();

	// unregister message filtering and idle updates
	CMessageLoop* pLoop = _Module.GetMessageLoop();
	ATLASSERT(pLoop != NULL);
	pLoop->RemoveMessageFilter(this);
	pLoop->RemoveIdleHandler(this);

	bHandled = TRUE;
	return 1;
}

LRESULT CMainFrame::OnSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	Base::OnSize(uMsg, wParam, lParam, bHandled);
	bHandled = TRUE;
	return bHandled;
}

LRESULT CMainFrame::OnGetMinMaxInfo(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	DefWindowProc();
	MINMAXINFO* pMMInfo = (MINMAXINFO*)lParam;
	if (pMMInfo) {
		pMMInfo->ptMinTrackSize.x = 860;
		pMMInfo->ptMinTrackSize.y = 640;
	}
	return 0;
}

LRESULT CMainFrame::OnFileExit(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	PostMessage(WM_CLOSE);
	return 0;
}

LRESULT CMainFrame::OnFileNew(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	return 0;
}

LRESULT CMainFrame::OnViewToolBar(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	static BOOL bVisible = TRUE;	// initially visible
	bVisible = !bVisible;
	CReBarCtrl rebar = m_hWndToolBar;
	int nBandIndex = rebar.IdToIndex(ATL_IDW_BAND_FIRST + 1);	// toolbar is 2nd added band
	rebar.ShowBand(nBandIndex, bVisible);
	UISetCheck(ID_VIEW_TOOLBAR, bVisible);
	UpdateLayout();
	return 0;
}

LRESULT CMainFrame::OnViewStatusBar(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	BOOL bVisible = !::IsWindowVisible(m_hWndStatusBar);
	::ShowWindow(m_hWndStatusBar, bVisible ? SW_SHOWNOACTIVATE : SW_HIDE);
	UISetCheck(ID_VIEW_STATUS_BAR, bVisible);
	UpdateLayout();
	return 0;
}

LRESULT CMainFrame::OnAppAbout(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	//CAboutDlg dlg;
	//CString strXmlFile;
	//strXmlFile.Format(_T("%s\\AboutDlg.xml"), _pUISkinManager->GetSkinPath());
	//dlg.DoModal(m_hWnd,strXmlFile);
	return 0;
}

LRESULT CMainFrame::OnWindowCascade(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	//MDICascade();
	return 0;
}

LRESULT CMainFrame::OnWindowTile(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	//MDITile();
	return 0;
}

LRESULT CMainFrame::OnWindowArrangeIcons(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	//MDIIconArrange();
	return 0;
}

LRESULT CMainFrame::OnWindowClose(WORD wNotifyCode, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	int nItem = wNotifyCode;
	if (nItem<0 || nItem>=m_PageInfoPtrs.size()) {
		return 0;
	}

	PageInfoPtr PagePtr = m_PageInfoPtrs[nItem];
	m_PageInfoPtrs.erase(m_PageInfoPtrs.begin() + nItem);
	if (m_CurPagePtr == PagePtr) {
		m_CurPagePtr = 0;
	}
	RemoveRecord(PagePtr);

	if (IsRptPage(PagePtr)) {
	} else {
		DestroyContainer(PagePtr->InfoPtr->pContainer);
	}
	if (m_ChildView) {
		m_ChildView.RemovePage(nItem);
	}

	if (m_ChildView.GetActivePage()<0) {
		SetFocus();
	}

	return 0;
}

LRESULT CMainFrame::OnWindowActivate(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	int nPage = wID - ID_WINDOW_TABFIRST;
	if (m_ChildView) {
		m_ChildView.SetActivePage(nPage);
	}

	return 0;
}

LRESULT CMainFrame::OnKeyDown(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	int nVirtKey = (int)wParam; 
	LPARAM lKeyData = lParam;
	switch(nVirtKey)
	{
	case VK_ESCAPE:
		PostMessage(WM_COMMAND,MAKEWPARAM(ID_COMMAND_ESCAPE,0), 0L);
		break;
	case VK_BACK:
		PostMessage(WM_COMMAND,MAKEWPARAM(ID_COMMAND_BACK,0), 0L);
		break;
	case VK_HOME:
		PostMessage(WM_COMMAND,MAKEWPARAM(ID_COMMAND_HOME,0), 0L);
		break;
	case VK_TAB:
		if (m_ChildView) {
			int nItem = m_ChildView.GetActivePage() + 1;
			if (nItem >= m_ChildView.GetPageCount()) {
				nItem = 0;
			}
			GotoPage(nItem);
		} else {
			std::vector<PageInfoPtr>::iterator it = std::find(m_PageInfoPtrs.begin(), m_PageInfoPtrs.end(), m_CurPagePtr);
			if (it != m_PageInfoPtrs.end()) {
				int nItem = (it-m_PageInfoPtrs.begin()) + 1;
				if (nItem >= m_PageInfoPtrs.size()) {
					nItem = 0;
				}
				GotoPage(nItem);
			}
		}
		break;
	default:
		/*if ()
		{
			UINT nFlags = HIWORD(lParam);
			BOOL bShift = GetKeyState(VK_SHIFT)&0x0100;
			BOOL bCtrl = GetKeyState(VK_CONTROL)&0x0100;
			BOOL bAlt = ((nFlags&0x2000L)!=0);
		}*/
		bHandled = FALSE;
		break;
	}
	return 0;
}

LRESULT CMainFrame::OnChar(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	bHandled = FALSE;
	TCHAR ch = (TCHAR)wParam;
	if (_istprint(ch)) {
		UIEdit2 wndInput;
		if (m_AddressBar) {
			wndInput = m_AddressBar.GetEditCtrl();
		} else if(m_pSmartKBDlg) {
			ShowSmartKBDlg();
			wndInput = m_pSmartKBDlg->m_smartkb.GetEditCtrl();
		}
		if (wndInput) {
			if (wndInput != GetFocus()) {
				bHandled = TRUE;
				wndInput.SetFocus();
				wndInput.SetSel(wndInput.GetWindowTextLength());
				wndInput.SendMessage(uMsg, wParam, lParam);
			}
		}
	}
	return FALSE;
}

LRESULT CMainFrame::OnCommand(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	WORD wNotifyCode = HIWORD(wParam); 
	WORD wID = LOWORD(wParam); 
	HWND hwndCtrl = (HWND)lParam;

	if (m_CurPagePtr) {
		UIWnd2 wndContainer(m_CurPagePtr->InfoPtr->pContainer->GetThisHwnd());
		bHandled = wndContainer.SendMessage(uMsg, wParam, lParam);
	}

	switch(wID)
	{
	case ID_COMMAND_BACK:
		Goto(-1);
		break;
	case ID_COMMAND_FORWARD:
		Goto(1);
		break;
	case ID_COMMAND_ESCAPE:
		Goto(-1);
		break;
	case ID_COMMAND_HOME:
		break;
	case ID_COMMAND_REPORT:
		break;
	case ID_COMMAND_TECH:
		break;
	case ID_COMMAND_SEARCH:
		break;
	case ID_COMMAND_SELECT_KIND:
		break;
	case ID_COMMAND_SELECT_COMMODITY:
		break;
	case ID_COMMAND_ORDER:
		break;
	case ID_COMMAND_ROBOT:
		break;
	default:
		bHandled = Execute(MapCmdline(wID));
		break;
	}

	return bHandled;
}

LRESULT CMainFrame::OnTimer(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	if (wParam == m_nTimer) {
		
	} else if (wParam == m_nReqPushTimer) {
		KillTimer(m_nReqPushTimer);
		m_nReqPushTimer = 0;
	} else {
		bHandled = FALSE;
	}
	return bHandled;
}

LRESULT CMainFrame::OnTBDropDown(int idFrom, LPNMHDR lpNMHdr, BOOL& bHandled)
{
	LPNMTOOLBAR lpTB = (LPNMTOOLBAR)lpNMHdr;
	switch(lpTB->iItem)
	{
	case ID_COMMAND_FORWARD:
		break;
	case ID_COMMAND_HOME:
		break;
	case ID_COMMAND_REPORT:
		break;
	case ID_COMMAND_TECH:
		break;
	default:
		bHandled = FALSE;
		return 0;
		break;
	}

	CToolBarCtrl wndToolBar = lpTB->hdr.hwndFrom;
	int nIndex = wndToolBar.CommandToIndex(lpTB->iItem);
	RECT rect;
	wndToolBar.GetItemRect(nIndex, &rect);
	wndToolBar.ClientToScreen(&rect);

	switch(lpTB->iItem)
	{
	case ID_COMMAND_FORWARD:
		{
			CMenu menu;
			menu.CreatePopupMenu();

			//if (m_ChildView) {
			//	m_ChildView.BuildWindowMenu(menu,65535,true,false);
			//} else {
				for (int i=0; i<m_HisRecordList.size(); i++) 
				{
					menu.AppendMenu(MF_STRING
						//|(i%16==0?MF_MENUBREAK:0)
						, ID_WINDOW_TABFIRST+i, m_HisRecordList[i]->strName);
					if (i == m_nCurRecord) {
						menu.CheckMenuItem(ID_WINDOW_TABFIRST+i, MF_CHECKED);
					}
				}
			//}
			
			int nRet = (int)m_CmdBar.TrackPopupMenu(menu, TPM_RETURNCMD | TPM_LEFTALIGN | TPM_LEFTBUTTON | TPM_VERTICAL, rect.left, rect.bottom);
			int nRecord = nRet-ID_WINDOW_TABFIRST;
			if(nRecord>=0 && nRecord<m_HisRecordList.size()) {
				if (nRecord != m_nCurRecord) {
					Goto(nRecord-m_nCurRecord);
				}
			} else {
				SendMessage(WM_COMMAND, MAKEWPARAM(nRet, 0));
			}
		}
		break;
	case ID_COMMAND_HOME:
		break;
	case ID_COMMAND_REPORT:
		{
			int i,j,k;

			CMenu menu;
			menu.CreatePopupMenu();
			
			i = 0;
			j = 0;
			k = 0;
			for (i=0; i<m_AllKindInfoPtr->AllKindList.size(); i++) 
			{
				UINT uFlags = 0;
				if (i != 0 && !m_AllKindInfoPtr->AllKindList[i].KindList.empty()) {
					menu.AppendMenu(MF_SEPARATOR);
				}
				if (!m_AllKindInfoPtr->AllKindList[i].Name[0]) {
					for (j=0; j<m_AllKindInfoPtr->AllKindList[i].KindList.size(); j++) {
						uFlags = MF_STRING;
						//if (j==0) {
						//	uFlags |= MF_MENUBREAK;
						//}
						menu.AppendMenu(uFlags, ID_WINDOW_TABFIRST+k
							, m_AllKindInfoPtr->AllKindList[i].KindList[j].GetName());
						k++;
					}
				} else {
					CMenu submenu;
					submenu.CreatePopupMenu();
					for (j=0; j<m_AllKindInfoPtr->AllKindList[i].KindList.size(); j++) {
						submenu.AppendMenu(MF_STRING, ID_WINDOW_TABFIRST+k
							, m_AllKindInfoPtr->AllKindList[i].KindList[j].GetName());
						k++;
					}
					menu.AppendMenu(MF_POPUP, submenu, m_AllKindInfoPtr->AllKindList[i].Name);
				}
			}

			int nRet = (int)m_CmdBar.TrackPopupMenu(menu, TPM_RETURNCMD | TPM_LEFTALIGN | TPM_LEFTBUTTON | TPM_VERTICAL, rect.left, rect.bottom);
			int nKind = (nRet-ID_WINDOW_TABFIRST);
			if(nKind>=0 && nKind<k) {
				for (i=0; i<m_AllKindInfoPtr->AllKindList.size(); i++) 
				{
					if (nKind<m_AllKindInfoPtr->AllKindList[i].KindList.size()) {
						break;
					}
					nKind -= m_AllKindInfoPtr->AllKindList[i].KindList.size();
				}
				Goto(m_AllKindInfoPtr->AllKindList[i].KindList[nKind]);
			}//else
			//	SendMessage(WM_COMMAND, MAKEWPARAM(nRet, 0));
		}
		break;
	case ID_COMMAND_TECH:
		{
			CMenu menu;
			menu.CreatePopupMenu();

			for (int i=0; i<m_PageInfoPtrs.size(); i++) 
			{
				if (IsScdtPage(m_PageInfoPtrs[i])) {
					UIWnd2 wndContainer(m_PageInfoPtrs[i]->InfoPtr->pContainer->GetThisHwnd());
					CString strPageTitle;
					wndContainer.GetWindowText(strPageTitle);
					menu.AppendMenu(MF_STRING, ID_WINDOW_TABFIRST+i, strPageTitle);
				}
			}

			int nRet = (int)m_CmdBar.TrackPopupMenu(menu, TPM_RETURNCMD | TPM_LEFTALIGN | TPM_LEFTBUTTON | TPM_VERTICAL, rect.left, rect.bottom);
			int nPage = (nRet-ID_WINDOW_TABFIRST);
			if(nPage>=0 && nPage<m_PageInfoPtrs.size()) {
				//COMREF Commodity = {0};
				//m_PageInfoPtrs[nPage]->InfoPtr->GetCurCommodity(&Commodity);
				//Goto(m_PageInfoPtrs[nPage]->InfoPtr, Commodity);
				GotoPage(nPage);
			}//else
			//	SendMessage(WM_COMMAND, MAKEWPARAM(nRet, 0));
		}
		break;
	default:
		bHandled = FALSE;
		break;
	}

	return TBDDRET_DEFAULT;
}

LRESULT CMainFrame::OnPageActivated(int idFrom, LPNMHDR lpNMHdr, BOOL& bHandled)
{
	int nItem = m_ChildView.GetActivePage();
	
	if(nItem>=0 && nItem<m_PageInfoPtrs.size()) {
		if (m_CurPagePtr != m_PageInfoPtrs[nItem]) {
			SetCurPage(nItem);
		}
	}
	return bHandled;
}

LRESULT CMainFrame::OnPageContextMenu(int idFrom, LPNMHDR lpNMHdr, BOOL& bHandled)
{
	TBVCONTEXTMENUINFO* pCM = (TBVCONTEXTMENUINFO*)lpNMHdr;
	CMenu menu;
	menu.CreatePopupMenu();

	menu.AppendMenu(MF_STRING, MAKEWPARAM(ID_WINDOW_CLOSE,pCM->hdr.idFrom), _T("�ر�"));

	POINT pt = pCM->pt;
	menu.TrackPopupMenu(TPM_LEFTALIGN | TPM_LEFTBUTTON | TPM_VERTICAL, pt.x, pt.y, m_hWnd);

	return bHandled;
}

void CMainFrame::LoadDispInfo()
{
	CWindowDC dc(NULL);

	m_DispInfoPtr = new ObjectDispInfo();

	m_DispInfoPtr->hCurDraw = LoadCursor(UIHelper::GetResourceInstance(), MAKEINTRESOURCE(IDC_CURSOR_DRAW));
	ASSERT(m_DispInfoPtr->hCurDraw);

	m_DispInfoPtr->crBackgnd = RGB(7,7,7);		//����
	m_DispInfoPtr->crTabSelBackgnd = RGB(64, 0, 0);	//��ǩѡ�б���
	m_DispInfoPtr->crRptTitleBakcgnd = QCOLOR_DEF_RPT_TITLEBG;//�������ⱳ��
	m_DispInfoPtr->crRptSelBackgnd = RGB(0,0,128);	//����ѡ�б���

	m_DispInfoPtr->crTitle = RGB(192,192,192);			//����
	m_DispInfoPtr->crName = RGB(192,192,192);			//����
	m_DispInfoPtr->crText = QCOLOR_SYS_PLAIN_WHITE;			//����
	m_DispInfoPtr->crRising = RGB(255,62,62);			//����
	m_DispInfoPtr->crFalling = QCOLOR_SYS_GREEN;		//�µ�
	m_DispInfoPtr->crCommodityCode = QCOLOR_SYS_CAMBRIDGE_BLUE;	//����
	m_DispInfoPtr->crCommodityName = QCOLOR_SYS_YELLOW;	//����
	m_DispInfoPtr->crAmount = QCOLOR_SYS_YELLOW;			//��
	m_DispInfoPtr->crVolume = QCOLOR_SYS_YELLOW;			//��
	m_DispInfoPtr->crTabSel = QCOLOR_SYS_CYAN;			//��ǩѡ��

	m_DispInfoPtr->crLine = QCOLOR_SYS_PLAIN_WHITE;			//��
	m_DispInfoPtr->crAverageLine = QCOLOR_SYS_YELLOW;	//����
	m_DispInfoPtr->crDrawLine = RGB(255, 0, 255);		//����
	m_DispInfoPtr->crXYLine = RGB(60,60,60);			//X��Y�ָ���
	m_DispInfoPtr->crXText = RGB(125,125,125);			//X��������
	m_DispInfoPtr->crYText = RGB(125,125,125);//QCOLOR_DEF_YAXIS_VALUE;			//Y��������
	m_DispInfoPtr->crCrossCursor = RGB(122,122,122);	//ʮ���α�	
	m_DispInfoPtr->crRptLine = QCOLOR_DEF_RPT_TITLESPLITLINE;		//������
	m_DispInfoPtr->crRisingLine = RGB(255,52,52);		//������
	m_DispInfoPtr->crFallingLine = QCOLOR_SYS_CYAN;	//�µ���
	m_DispInfoPtr->crILine[0] = QCOLOR_DEF_LINE_INDEX1;
	m_DispInfoPtr->crILine[1] = QCOLOR_DEF_LINE_INDEX2;
	m_DispInfoPtr->crILine[2] = QCOLOR_DEF_LINE_INDEX3;
	m_DispInfoPtr->crILine[3] = QCOLOR_DEF_LINE_INDEX4;
	m_DispInfoPtr->crILine[4] = QCOLOR_DEF_LINE_INDEX5;
	m_DispInfoPtr->crILine[5] = QCOLOR_DEF_LINE_INDEX6;
	m_DispInfoPtr->crILine[6] = QCOLOR_DEF_LINE_INDEX7;
	m_DispInfoPtr->crILine[7] = QCOLOR_DEF_LINE_INDEX8;
	m_DispInfoPtr->crRefline = RGB(60,60,60);
	m_DispInfoPtr->crOrderLine = RGB(60,60,60);
	
	m_DispInfoPtr->hPen = CreatePen(PS_SOLID, 1, m_DispInfoPtr->crLine);
	m_DispInfoPtr->hRisingPen = CreatePen(PS_SOLID, 1, m_DispInfoPtr->crRisingLine);
	m_DispInfoPtr->hFallingPen = CreatePen(PS_SOLID, 1, m_DispInfoPtr->crFallingLine);
	m_DispInfoPtr->hDrawLinePen = CreatePen(PS_SOLID, 1, m_DispInfoPtr->crDrawLine);
	m_DispInfoPtr->hCrossCursorPen = CreatePen(PS_SOLID, 1, RGB(80,80,80));
	m_DispInfoPtr->hYCrossCursorPen = CreatePen(PS_SOLID, 1, RGB(60,60,60));
	m_DispInfoPtr->hNowPen = CreatePen(PS_SOLID, 1, QCOLOR_SYS_GRAY);
	m_DispInfoPtr->hOrderPen = CreatePen(PS_DASHDOTDOT, 1, m_DispInfoPtr->crOrderLine);
	m_DispInfoPtr->pen = new Pen(Color(m_DispInfoPtr->crLine), 1.0);
	m_DispInfoPtr->penRising = new Pen(Color(m_DispInfoPtr->crRisingLine), 1.0);
	m_DispInfoPtr->penFalling = new Pen(Color(m_DispInfoPtr->crFallingLine), 1.0);
	m_DispInfoPtr->penDrawLine = new Pen(Color(m_DispInfoPtr->crDrawLine), 1.0);
	m_DispInfoPtr->penCrossCursor = new Pen(Color(80,80,80), 0.5);
	m_DispInfoPtr->penNow = new Pen(Color(QCOLOR_SYS_GRAY), 1.0);
	m_DispInfoPtr->penOrder = new Pen(Color(m_DispInfoPtr->crOrderLine), 1.0);

	m_DispInfoPtr->hBrush = CreateSolidBrush(m_DispInfoPtr->crLine);
	m_DispInfoPtr->hRisingBrush = CreateSolidBrush(m_DispInfoPtr->crRisingLine);
	m_DispInfoPtr->hFallingBrush = CreateSolidBrush(m_DispInfoPtr->crFallingLine);
	m_DispInfoPtr->hDrawLineBrush = CreateSolidBrush(m_DispInfoPtr->crDrawLine);
	m_DispInfoPtr->hNullBrush = GetStockBrush(HOLLOW_BRUSH);
	m_DispInfoPtr->brush = new SolidBrush(Color(m_DispInfoPtr->crLine));
	m_DispInfoPtr->brushRising = new SolidBrush(Color(m_DispInfoPtr->crRisingLine));
	m_DispInfoPtr->brushFalling = new SolidBrush(Color(m_DispInfoPtr->crFallingLine));
	m_DispInfoPtr->brushDrawLine = new SolidBrush(Color(m_DispInfoPtr->crDrawLine));
	m_DispInfoPtr->brushNull = new SolidBrush(Color(0));

	LOGFONT lgFont = {0};
	CFontHandle font = UIgdi::GetDefaultGuiFont();
	font.GetLogFont(lgFont);
	lgFont.lfWeight = FW_DONTCARE;
	font.Detach();
	lgFont.lfHeight = 14;
	_tcscpy(lgFont.lfFaceName, _T("����"));
	m_DispInfoPtr->hName = font.CreateFontIndirect(&lgFont);
	font.Detach();
	lgFont.lfHeight = 14;
	_tcscpy(lgFont.lfFaceName, _T("system"));
	m_DispInfoPtr->hText = font.CreateFontIndirect(&lgFont);
	font.Detach();
	lgFont.lfHeight = 13;
	_tcscpy(lgFont.lfFaceName, _T("����"));
	m_DispInfoPtr->hTabTitle = font.CreateFontIndirect(&lgFont);
	font.Detach();
	lgFont.lfHeight = 13;
	_tcscpy(lgFont.lfFaceName, _T("����"));
	m_DispInfoPtr->hRptTitle = font.CreateFontIndirect(&lgFont);
	font.Detach();
	m_DispInfoPtr->hRptText = font.CreateFontIndirect(&lgFont);
	font.Detach();
	lgFont.lfHeight = 12;
	_tcscpy(lgFont.lfFaceName, _T("����"));
	m_DispInfoPtr->hTechTitle = font.CreateFontIndirect(&lgFont);
	font.Detach();
	lgFont.lfHeight = 13;
	lgFont.lfCharSet = 1;
	_tcscpy(lgFont.lfFaceName, _T("����"));
	m_DispInfoPtr->hXText =  font.CreateFontIndirect(&lgFont);
	font.Detach();
	m_DispInfoPtr->hYText =  font.CreateFontIndirect(&lgFont);
	font.Detach();
	m_DispInfoPtr->hOrder =  font.CreateFontIndirect(&lgFont);
	font.Detach();

	TCHAR* strText = _T("�������齻��ϵͳ");
	int nTextLen = _tcslen(strText);
	HFONT hOldFont = NULL;
	hOldFont = dc.GetCurrentFont();
	dc.SelectFont(m_DispInfoPtr->hName);
	dc.GetTextExtent(strText, nTextLen, &m_DispInfoPtr->xyName);
	m_DispInfoPtr->xyName.cx /= nTextLen;
	dc.SelectFont(m_DispInfoPtr->hText);
	dc.GetTextExtent(strText, nTextLen, &m_DispInfoPtr->xyText);
	m_DispInfoPtr->xyText.cx /= nTextLen;
	dc.SelectFont(m_DispInfoPtr->hTabTitle);
	dc.GetTextExtent(strText, nTextLen, &m_DispInfoPtr->xyTabTitle);
	m_DispInfoPtr->xyTabTitle.cx /= nTextLen;
	dc.SelectFont(m_DispInfoPtr->hRptTitle);
	dc.GetTextExtent(strText, nTextLen, &m_DispInfoPtr->xyRptTitle);
	m_DispInfoPtr->xyRptTitle.cx /= nTextLen;
	dc.SelectFont(m_DispInfoPtr->hRptText);
	dc.GetTextExtent(strText, nTextLen, &m_DispInfoPtr->xyRptText);
	m_DispInfoPtr->xyRptText.cx /= nTextLen;
	dc.SelectFont(m_DispInfoPtr->hTechTitle);
	dc.GetTextExtent(strText, nTextLen, &m_DispInfoPtr->xyTechTitle);
	m_DispInfoPtr->xyTechTitle.cx /= nTextLen;
	dc.SelectFont(m_DispInfoPtr->hXText);
	dc.GetTextExtent(strText, nTextLen, &m_DispInfoPtr->xyXText);
	m_DispInfoPtr->xyXText.cx /= nTextLen;
	dc.SelectFont(m_DispInfoPtr->hYText);
	dc.GetTextExtent(strText, nTextLen, &m_DispInfoPtr->xyYText);
	m_DispInfoPtr->xyYText.cx /= nTextLen;
	dc.SelectFont(m_DispInfoPtr->hOrder);
	dc.GetTextExtent(strText, nTextLen, &m_DispInfoPtr->xyOrder);
	m_DispInfoPtr->xyOrder.cx /= nTextLen;
	m_DispInfoPtr->xySpace.cx = 2;
	m_DispInfoPtr->xySpace.cy = 3;
	dc.SelectFont(hOldFont);

	m_DispInfoPtr->xyTabCtrl.cx = 18;
	m_DispInfoPtr->xyTabCtrl.cy = 18;
	m_DispInfoPtr->xyScrollBar.cx = 18;
	m_DispInfoPtr->xyScrollBar.cy = 18;
	m_DispInfoPtr->xyWndIndicator.cx = 100;
	m_DispInfoPtr->xyWndIndicator.cy = 100;
	m_DispInfoPtr->xyInfoIndicator.cx = m_DispInfoPtr->xyXText.cx * 5;
	m_DispInfoPtr->xyInfoIndicator.cy = 24;
	m_DispInfoPtr->xyCoordinate.cx = 18;
	m_DispInfoPtr->xyCoordinate.cy = 18;


	m_DispInfoPtr->nBarWidth[0] = 1;
	m_DispInfoPtr->nBarWidth[1] = 1;
	m_DispInfoPtr->nBarWidth[2] = 1;
	m_DispInfoPtr->nBarWidth[3] = 1;
	m_DispInfoPtr->nBarWidth[4] = 3;
	m_DispInfoPtr->nBarWidth[5] = 5;
	m_DispInfoPtr->nBarWidth[6] = 7;
	m_DispInfoPtr->nBarWidth[7] = 9;
	m_DispInfoPtr->nBarWidth[8] = 12;
	m_DispInfoPtr->nBarSpace[0] = 0;
	m_DispInfoPtr->nBarSpace[1] = 1;
	m_DispInfoPtr->nBarSpace[2] = 2;
	m_DispInfoPtr->nBarSpace[3] = 3;
	m_DispInfoPtr->nBarSpace[4] = 3;
	m_DispInfoPtr->nBarSpace[5] = 3;
	m_DispInfoPtr->nBarSpace[6] = 3;
	m_DispInfoPtr->nBarSpace[7] = 3;
	m_DispInfoPtr->nBarSpace[8] = 3;
	m_DispInfoPtr->nBarScale = 5;
	m_DispInfoPtr->nBarShift = 100;
}

long CMainFrame::DoSmartKB(SmartKBObjectPtr& objPtr, BOOL bNew)
{
	if (objPtr) {
		SmartKBKindObject* pKind = dynamic_cast<SmartKBKindObject*>((SmartKBObject*)objPtr);
		if (pKind) {
			Goto(pKind->GetKind());
			return RLT_OK;
		}
		SmartKBCommodityObject* pCommodity = dynamic_cast<SmartKBCommodityObject*>((SmartKBObject*)objPtr);
		if (pCommodity) {
			ContainerInfoPtr InfoPtr = new ContainerInfo();
			InfoPtr->bInteractive = !IsStrategy();
			InfoPtr->KindList;
			InfoPtr->CommodityListPtr->Kind = pCommodity->GetKind();
			AllCommodityListInfo::iterator it = m_AllCommodityList.find(InfoPtr->CommodityListPtr);
			if (it != m_AllCommodityList.end()) {
				InfoPtr->CommodityListPtr->CommodityList = (*it)->CommodityList;
				COMREFLIST::iterator it_comm = std::find(InfoPtr->CommodityListPtr->CommodityList.begin(),InfoPtr->CommodityListPtr->CommodityList.end(),pCommodity->GetCommodity());
				if (it_comm != InfoPtr->CommodityListPtr->CommodityList.end()) {
					InfoPtr->CurCommodityPos = it_comm - InfoPtr->CommodityListPtr->CommodityList.begin();
					TCHAR szPath[MAX_PATH] = {0};
					_stprintf(szPath, _T("%s\\%s"), _Module.GetAppPath(), _T("scdtcontainer.xml"));
					WndObjecter* pContainer = NULL;
					if (!bNew) {
						pContainer = FindContainer(_T("ScdtContainer"));
					}
					if (!pContainer) {
						pContainer = CreateContainer(_T("ScdtContainer"), szPath, XML_FLAG_FILE);
					}
					Goto(InfoPtr,bNew);
					return RLT_OK;
				}
			}
			return RLT_UNKNOWN;
		}
		return Execute(objPtr->GetKey());
	}
	return RLT_UNKNOWN;
}

void CMainFrame::OnDispInfoChanged()
{
	BroadcastSend(EVT_PLAT_CALL, MAKEVALUE(MSET_PLAT_OBJECT,CSET_OBJECT_DISPINFO), m_DispInfoPtr);
}

long CMainFrame::OnCall(Event& evt)
{
	switch(evt.value)
	{
	case MAKEVALUE(MCALL_PLAT_FRAME,CCALL_FRAME_SMARTKB):
		{
			SmartKBObjectPtr objPtr = SmartKBObjectPtr::dynamicCast(evt.objPtr);
			if (objPtr) {
				return DoSmartKB(objPtr);
			}
		}
		break;
	case MAKEVALUE(MCALL_PLAT_FRAME,CCALL_FRAME_GOTOCONTAINER):
		{
			DoGotoContainerPtr gotoPtr = DoGotoContainerPtr::dynamicCast(evt.objPtr);
			if (gotoPtr) {
				WndObjecter* pContainer = NULL;
				if (!gotoPtr->bNew) {
					pContainer = FindContainer(gotoPtr->lpszName);
				}
				if (!pContainer) {
					pContainer = CreateContainer(gotoPtr->lpszName, gotoPtr->lpszXml, gotoPtr->XmlFlag);
				}
				Goto(gotoPtr->InfoPtr, gotoPtr->bNew);
				return RLT_OK;
			}
		}
		break;
	//case MAKEVALUE(MCALL_PLAT_FRAME,CCALL_FRAME_REQPUSH):
	//	{
	//		m_nReqPushTimer = SetTimer(ID_REQPUSHTIMER, 200); //����ע�����Ͷ�ʱ��
	//	}
	//	break;
	default:
		evt.handled = false;
		break;
	}
	return RLT_UNKNOWN;
}

long CMainFrame::OnNotify(Event& evt)
{
	XFrame::OnEvent(evt);
	switch(evt.value)
	{
	case MAKEVALUE(MNOTIFY_PLAT_DE,CNOTIFY_DE_ONLINE):
		{
			int i,j;
			OnlineInfoPtr objPtr = OnlineInfoPtr::dynamicCast(evt.objPtr);
			if (!IsStrategy()) {
				if(objPtr->nStatus==DE_ONLINE) {
					if (m_SmartKBCommkodityInfoPtr) {
						if(!m_SmartKBCommkodityInfoPtr->SmartKBPtrList.empty()) {
							//DoSmartKB(m_SmartKBCommkodityInfoPtr->SmartKBPtrList.front());
							for (i=0; i<m_SmartKBCommkodityInfoPtr->SmartKBPtrList.size(); i++)
							{
								if (_tcsicmp(m_SmartKBCommkodityInfoPtr->SmartKBPtrList[i]->GetKey(), _T("600000"))==0) {
									DoSmartKB(m_SmartKBCommkodityInfoPtr->SmartKBPtrList[i]);
								}
							}
						}
					}
				}
			} else {
				std::vector<COMREF> Commoditys;
				int nPoolsTotal = iPoolsTotal(m_hStrategy);
				if (nPoolsTotal>0) {
					Commoditys.resize(nPoolsTotal);
					nPoolsTotal = iPoolSelect(0,&Commoditys[0],nPoolsTotal,m_hStrategy);
					if (nPoolsTotal>0) {
						Commoditys.resize(nPoolsTotal);
						for (i=0;i<nPoolsTotal;i++)
						{
							if (m_CommoditysOfStrategy.find(Commoditys[i])==m_CommoditysOfStrategy.end()) {
								m_CommoditysOfStrategy[Commoditys[i]] = FALSE;
							}
						}
					}
				}
				for (i=0;i<nPoolsTotal;i++)
				{
					if (!m_CommoditysOfStrategy[Commoditys[i]]) {
						if (m_SmartKBCommkodityInfoPtr) {
							if(!m_SmartKBCommkodityInfoPtr->SmartKBPtrList.empty()) {
								for (j=0; j<m_SmartKBCommkodityInfoPtr->SmartKBPtrList.size(); j++)
								{
									SmartKBObjectPtr & kbPtr = m_SmartKBCommkodityInfoPtr->SmartKBPtrList[j];
									SmartKBCommodityObject* pCommodity = dynamic_cast<SmartKBCommodityObject*>((SmartKBObject*)kbPtr);
									ASSERT(pCommodity);
									if (pCommodity->GetCommodity()==Commoditys[i]) {
										m_CommoditysOfStrategy[Commoditys[i]] = TRUE;
										DoSmartKB(kbPtr,TRUE);
									}
								}
							}
						}
					}
				}
			}
		}
		break;
	default:
		break;
	}
	BroadcastSend(evt);
	return RLT_OK;
}

