#ifndef _H_QRIGHTVIEW_H_
#define _H_QRIGHTVIEW_H_

#include <Util/CommodityView.h>
#include <Util/CommodityMap.h>
#include <Util/ViewSplitter.h>
#include "CommCtrl.h"

class CommodityTitleView 
	: public CommodityViewImpl<CommodityTitleView>
{
	typedef CommodityTitleView This;
	typedef CommodityViewImpl<CommodityTitleView> Base;
	DECLARE_XMLWND_CLASS(_T("TitleView"))
	DECLARE_DYNCREATE_WND_OBJECTER(CommodityTitleView,Objecter)

public:
	CommodityTitleView();
	virtual ~CommodityTitleView();

	BOOL IsDirectUI() { return TRUE; }

	void GetMinMaxInfo(MINMAXINFO* pMMInfo);

	BEGIN_MSG_MAP(This)
		CHAIN_MSG_MAP(Base)
	END_MSG_MAP()

	void OnPaint(HDC hdc);

protected:
	//
	FIELDVALUEListInfoPtr m_FieldValueListPtr;

public:
	void OnDispInfoChanged();
	void OnViewInfoChanged();
	//
	void OnRefresh(ObjectPtr objPtr);

	BEGIN_EVT_MAP(This)
		CHAIN_EVT_MAP(Base)
	END_EVT_MAP()
};

class CommodityMmpView 
	: public CommodityViewImpl<CommodityMmpView>
	, public FieldDataMap<CommodityMmpView>
{
	typedef CommodityMmpView This;
	typedef CommodityViewImpl<CommodityMmpView> Base;
	DECLARE_XMLWND_CLASS(_T("MmpView"))
	DECLARE_DYNCREATE_WND_OBJECTER(CommodityMmpView,Objecter)

public:
	CommodityMmpView();
	virtual ~CommodityMmpView();

	BOOL IsDirectUI() { return TRUE; }

	void GetMinMaxInfo(MINMAXINFO* pMMInfo);

	BEGIN_MSG_MAP(This)
		CHAIN_MSG_MAP(Base)
	END_MSG_MAP()

	void OnPaint(HDC hdc);

protected:
	//
	FIELDNAMEListInfoPtr m_FieldNameListPtr;
	FIELDVALUEListInfoPtr m_FieldValueListPtr;
	REQ_FIELDDATAInfoPtr m_ReqFieldDataPtr;

public:
	void OnDispInfoChanged();
	void OnViewInfoChanged();
	//
	void OnRefresh(ObjectPtr objPtr);

	void OnFieldDataChanged(Event& evt);

	BEGIN_EVT_MAP(This)
		CHAIN_EVT_MAP(FieldDataMap<CommodityMmpView>)
		CHAIN_EVT_MAP(Base)
	END_EVT_MAP()
};

class CommodityInfoView 
	: public CommodityViewImpl<CommodityInfoView>
	, public FieldDataMap<CommodityInfoView>
{
	typedef CommodityInfoView This;
	typedef CommodityViewImpl<CommodityInfoView> Base;
	DECLARE_XMLWND_CLASS(_T("InfoView"))
	DECLARE_DYNCREATE_WND_OBJECTER(CommodityInfoView,Objecter)
protected:
	CMemDC m_dc;

public:
	CommodityInfoView();
	virtual ~CommodityInfoView();

	BOOL IsDirectUI() { return TRUE; }

	HWND CreateControl(HWND hWndParent, LPCTSTR lpszWndClass, LPCTSTR lpszCtrlName, UINT nID, LPCTSTR lpszXml, UINT XmlFlag);

	void GetMinMaxInfo(MINMAXINFO* pMMInfo);

	BEGIN_MSG_MAP(This)
		MESSAGE_HANDLER(WM_CREATE, OnCreate)
		MESSAGE_HANDLER(WM_DESTROY, OnDestroy)
		MESSAGE_HANDLER(WM_SIZE, OnSize)
		MESSAGE_RANGE_HANDLER(WM_MOUSEFIRST, WM_MOUSELAST, OnMouse)
		MESSAGE_HANDLER(WM_MOUSEHOVER, OnMouse)
		MESSAGE_HANDLER(WM_MOUSELEAVE, OnMouse)
		CHAIN_MSG_MAP(Base)
	END_MSG_MAP()

	LRESULT OnCreate(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/);
	LRESULT OnDestroy(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& bHandled);
	LRESULT OnSize(UINT /*uMsg*/, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnMouse(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	void OnPaint(HDC hdc);

protected:
	//
	enum
	{
		FIELD_FLAG_NONE = 0,
		FIELD_FLAG_BREAK,
		FIELD_FLAG_BREAKLINE,
	};
	std::vector<UINT> m_FieldFlag;
	int m_MaxFieldPerLine;
	FIELDNAMEListInfoPtr m_FieldNameListPtr;
	FIELDVALUEListInfoPtr m_FieldValueListPtr;
	REQ_FIELDDATAInfoPtr m_ReqFieldDataPtr;

protected:
	void Draw();

public:
	void OnDispInfoChanged();
	void OnViewInfoChanged();
	//
	void OnRefresh(ObjectPtr objPtr);

	void OnFieldDataChanged(Event& evt);

	BEGIN_EVT_MAP(This)
		CHAIN_EVT_MAP(FieldDataMap<CommodityInfoView>)
		CHAIN_EVT_MAP(Base)
	END_EVT_MAP()

};

class CommodityTickView 
	: public ViewObjecterImpl<CommodityTickView,UIListCtrl2>
	, public MyListCtrlMap<CommodityTickView>
	, public CalcDataMap<CommodityTickView>
	, public UIPaint<CommodityTickView>
{
	typedef CommodityTickView This;
	typedef ViewObjecterImpl<CommodityTickView,UIListCtrl2> Base;
	typedef MyListCtrlMap<CommodityTickView> ListCtrlMap;
	typedef UIPaint<CommodityTickView> PaintMap;
	DECLARE_XMLWND_CLASS(_T("TickView"))
	DECLARE_DYNCREATE_WND_OBJECTER(CommodityTickView,Objecter)
public:
	CommodityTickView();
	virtual ~CommodityTickView();

	//BOOL IsDirectUI() { return TRUE; }

	HWND Create(HWND hWndParent, RECT& rcPos
		, LPCTSTR szWindowName = NULL, DWORD dwStyle = 0, DWORD dwExStyle = 0, UINT nID = 0, LPVOID lpCreateParam = NULL);
	HWND Create(HWND hWndParent, LPCTSTR lpszXml = NULL, UINT XmlFlag = XML_FLAG_FILE);

	void Relayout(LPCRECT lpRect = NULL);

	void GetMinMaxInfo(MINMAXINFO* pMMInfo);

	void OnCacheHint(NMLVCACHEHINT* lpCacheHint);
	void OnGetDispInfo(NMLVDISPINFO* lpDispInfo);
	//void OnMeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct);
	void OnDrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	void OnPaint(HDC hdc);
	
	BEGIN_MSG_MAP(This)
		MESSAGE_HANDLER(WM_CREATE, OnCreate)
		MESSAGE_HANDLER(WM_DESTROY, OnDestroy)
		MESSAGE_HANDLER(WM_SIZE, OnSize)
		MESSAGE_HANDLER(WM_TIMER, OnTimer)
		CHAIN_MSG_MAP(ListCtrlMap)
		//CHAIN_MSG_MAP(PaintMap)
		CHAIN_MSG_MAP(Base)
		DEFAULT_REFLECTION_HANDLER()
	END_MSG_MAP()

	LRESULT OnCreate(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/);
	LRESULT OnDestroy(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& bHandled);
	LRESULT OnSize(UINT /*uMsg*/, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnTimer(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

protected:
	void InitColList();

protected:
	UINT m_uTimer;
	BAR m_LastBar;
	UINT m_nMaxTickData;

	void LoadData(bool bRequest = false);
public:
	void OnDispInfoChanged();
	void OnViewInfoChanged();
	//
	void OnRefresh(ObjectPtr objPtr);

	void OnHisDataChanged(Event& evt);

	BEGIN_EVT_MAP(This)
		CHAIN_EVT_MAP(CalcDataMap<CommodityTickView>)
		CHAIN_EVT_MAP(Base)
	END_EVT_MAP()
};

class QRightView 
	: public CommodityViewImpl<QRightView>
	, public ViewSplitterImpl<QRightView>
	, public FieldDataMap<QRightView>
{
	typedef QRightView This;
	typedef CommodityViewImpl<QRightView> Base;
	typedef ViewSplitterImpl<QRightView> ViewSplitter;
	DECLARE_XMLWND_CLASS(_T("RightView"))
	DECLARE_DYNCREATE_WND_OBJECTER(QRightView,Objecter)
protected:
	TechTabCtrl m_wndTabCtrl;
public:
	QRightView();
	virtual ~QRightView();

	BOOL IsDirectUI() { return TRUE; }

	HWND CreateControl(HWND hWndParent, LPCTSTR lpszWndClass, LPCTSTR lpszCtrlName, UINT nID, LPCTSTR lpszXml, UINT XmlFlag);

	BOOL GetLayoutRect(LPRECT lpRect);

	void Relayout(LPCRECT lpRect = NULL);

	BOOL OnEraseBkgnd(HDC hdc)
	{
		return TRUE;
	}
	void OnPaint(HDC hdc)
	{
		if (!m_DispInfoPtr) {
			return;
		}

		CDCHandle dc(hdc);

		CRect rcClient;
		GetClientRect(&rcClient);

		dc.SetBkMode(TRANSPARENT);
		dc.FillSolidRect(&rcClient, m_DispInfoPtr->crXYLine);
	}

	BEGIN_MSG_MAP(This)
		MESSAGE_HANDLER(WM_CREATE, OnCreate)
		MESSAGE_HANDLER(WM_DESTROY, OnDestroy)
		MESSAGE_HANDLER(WM_SIZE, OnSize)
		MESSAGE_RANGE_HANDLER(WM_MOUSEFIRST, WM_MOUSELAST, OnMouse)
		MESSAGE_HANDLER(WM_MOUSEHOVER, OnMouse)
		MESSAGE_HANDLER(WM_MOUSELEAVE, OnMouse)
		NOTIFY_CODE_HANDLER(TCN_SELCHANGE,OnTabSelChange)
		CHAIN_MSG_MAP(ViewSplitter)
		CHAIN_MSG_MAP(Base)
		REFLECT_NOTIFICATIONS()
	END_MSG_MAP()

	LRESULT OnCreate(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/);
	LRESULT OnDestroy(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& bHandled);
	LRESULT OnSize(UINT /*uMsg*/, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnMouse(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnTabSelChanging(int nCode, LPNMHDR lpNMHdr, BOOL& bHandled);
	LRESULT OnTabSelChange(int nCode, LPNMHDR lpNMHdr, BOOL& bHandled);

protected:
	void ReInitLayout(BOOL bInfoChanged = FALSE);

public:
	void OnDispInfoChanged();
	void OnViewInfoChanged();
	void OnViewDispInfoChanged();
	void OnRefresh(ObjectPtr objPtr);

	BEGIN_EVT_MAP(This)
		ON_EVT(EVT_PLAT_CALL,OnCall)
		CHAIN_EVT_MAP(FieldDataMap<QRightView>)
		CHAIN_EVT_MAP(ViewSplitter)
		CHAIN_EVT_MAP(Base)
	END_EVT_MAP()

	long OnCall(Event& evt);
};

#endif//_H_QRIGHTVIEW_H_