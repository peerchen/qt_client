// Platform.cpp : main source file for Platform.exe
//

#include "stdafx.h"
#include "resource.h"
#include "Module.h"
#include "PlatformModule.h"
#include "Platform.h"
#include "MainFrm.h"

#include <XLib/XSocket.h>

#if !defined(_LIB) && !defined(_USRDLL)

int Run(LPTSTR lpstrCmdLine, int nCmdShow)
{
	MSG msg;
	// force message queue to be created
	::PeekMessage(&msg, NULL, WM_USER, WM_USER, PM_NOREMOVE);

#if USES_MULTITHREAD
	UIMultiEvtMessageLoop theLoop(FALSE);
#else
	UIEvtMessageLoop theLoop;
#endif//
	_Module.AddMessageLoop(&theLoop);

	USES_CONVERSION;

	CurrentDirectory curdir(_Module.GetAppPath());

	Platform Plat;

	_Platform->Init();

	char szNetXml[1024] = {0};
	sprintf((char*)szNetXml, "<root workdir=\"%s\" datadir=\"%s\"><module name=\"QNetModule.dll\"></module></root>", T2A(_Module.GetAppPath()), T2A(_Module.GetAppData()));
	_NetIOEngine->Start((char*)szNetXml);

	char szDEXml[1024] = {0};
	sprintf((char*)szDEXml, "<root workdir=\"%s\" datadir=\"%s\"><module name=\"QDataModule.dll\"></module><module name=\"CTPTrader.dll\"></module></root>", T2A(_Module.GetAppPath()), T2A(_Module.GetAppData()));
	_DataEngine->Start(szDEXml);

	_Platform->Instance();

	_PlatformPtr->Login(NULL);

	CMainFrame wndMain;
	if(wndMain.CreateEx() == NULL)
	{
		ATLTRACE(_T("Main window creation failed!\n"));
		return 0;
	}

	//_PlatformPtr->Login(wndMain);
#if USES_MULTITHREAD
	/*theLoop.AddThread(_MultiThreadMgr.AddThread(_T(""), _T(""), SW_SHOWNORMAL));
	Sleep(100);
	theLoop.AddThread(_MultiThreadMgr.AddThread(_T(""), SW_SHOWNORMAL));*/
#else
	//
#endif//

	wndMain.ShowWindow(nCmdShow);

	int nRet = theLoop.Run();

	//UnRegisterAll();

	_Platform->Release();

	_DataEngine->Stop();

	_NetIOEngine->Stop();

	_Platform->Term();

	_Module.RemoveMessageLoop();
	return nRet;
}

//////////////////////////////////////////////////////////////////////////

int WINAPI _tWinMain(HINSTANCE hInstance, HINSTANCE /*hPrevInstance*/, LPTSTR lpstrCmdLine, int nCmdShow)
{
	HRESULT hRes = ::CoInitialize(NULL);
// If you are running on NT 4.0 or higher you can use the following call instead to 
// make the EXE free threaded. This means that calls come in on a random RPC thread.
//	HRESULT hRes = ::CoInitializeEx(NULL, COINIT_MULTITHREADED);
	ATLASSERT(SUCCEEDED(hRes));

	// this resolves ATL window thunking problem when Microsoft Layer for Unicode (MSLU) is used
	::DefWindowProc(NULL, 0, 0, 0L);

	AtlInitCommonControls(ICC_COOL_CLASSES | ICC_BAR_CLASSES);	// add flags to support other controls

	hRes = _Module.Init(NULL, hInstance);
	ATLASSERT(SUCCEEDED(hRes));

	AtlAxWinInit();

	int nRet = Run(lpstrCmdLine, nCmdShow);

	_Module.Term();

	::CoUninitialize();

	return nRet;
}

#endif//
