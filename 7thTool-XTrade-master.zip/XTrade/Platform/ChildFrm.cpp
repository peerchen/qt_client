// ChildFrm.cpp : implementation of the CChildFrame class
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "resource.h"

#include "ChildFrm.h"

void CChildFrame::OnFinalMessage(HWND /*hWnd*/)
{
	delete this;
}

LRESULT CChildFrame::OnCreate(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& bHandled)
{
	RECT rcPos = rcDefault;
	//m_hWndClient = m_view.Create(m_hWnd,_T(""),XML_FLAG_STREAM);
	m_hWndClient = m_Container.Create(m_hWnd,_T("<Container><pane rect=\"0,0,100,100\" style=\"0X0000000d\"></pane></Container>"),XML_FLAG_STREAM);

	//m_view.Connect("192.168.3.145", 9004);

	bHandled = FALSE;
	return 1;
}

LRESULT CChildFrame::OnForwardMsg(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM lParam, BOOL& /*bHandled*/)
{
	LPMSG pMsg = (LPMSG)lParam;

	if(UIMDIChildFrameImpl<CChildFrame>::PreTranslateMessage(pMsg))
		return TRUE;

	//return m_view.PreTranslateMessage(pMsg);
	return m_Container.PreTranslateMessage(pMsg);
}

LRESULT CChildFrame::OnCommand(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	return (BOOL)m_Container.SendMessage(uMsg, wParam, lParam);
}
