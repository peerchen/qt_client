// XXPlatform.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <Platform/XPlatform.h>
#include <Login/XLoginManager.h>
#include <Platform/XFrame.h>
#include <Indicator/XIndicator.h>


unsigned int __stdcall ThreadFunc(void* pParam)
{
	HMODULE hModule = GetModuleHandleW(NULL);
	ASSERT(hModule);
	wchar_t szPath[_MAX_PATH] = { 0 };
	::GetModuleFileNameW(hModule, szPath, _MAX_PATH);

	wchar_t szAppDrive[_MAX_DRIVE] = { 0 };
	wchar_t szAppDir[_MAX_DIR] = { 0 };
	wchar_t szAppName[_MAX_FNAME] = { 0 };
	wchar_t szAppExt[_MAX_EXT] = { 0 };
	_wsplitpath(szPath, szAppDrive, szAppDir, szAppName, szAppExt);

	wchar_t szAppPath[_MAX_PATH] = { 0 };
	_snwprintf(szAppPath, _MAX_PATH, _T("%s%s"), szAppDrive, szAppDir);
	::PathRemoveBackslashW(szAppPath);

	wchar_t szAppData[MAX_PATH] = { 0 };
	::SHGetSpecialFolderPathW(NULL, szPath, CSIDL_APPDATA, TRUE);
	_sntprintf(szAppData, _MAX_PATH, _T("%s\\%s"), szPath, szAppName);
	::SHCreateDirectoryExW(NULL, szAppData, NULL);

	char szAppNameA[_MAX_FNAME] = { 0 };
	char szAppPathA[_MAX_PATH] = { 0 };
	char szAppDataA[_MAX_PATH] = { 0 };
	wc2mb(szAppName, wcslen(szAppName), szAppNameA, _MAX_FNAME);
	wc2mb(szAppPath, wcslen(szAppPath), szAppPathA, _MAX_PATH);
	wc2mb(szAppData, wcslen(szAppData), szAppDataA, _MAX_PATH);
	printf(
		"\
/******************************************************************************\\\n\
 %s\n\
 %s\n\
 %s\n\
\\******************************************************************************/\n\
"
, szAppNameA, szAppPathA, szAppDataA);

	//��ʼ��XLib
	XLibInit::Init();

	//�����¼�loop
	EvtDispatcher theLoop;

	//����ƽ̨
	XPlatform Plat;

	//��ʼ��ƽ̨

	_Platform->SetAppName(szAppName);
	_Platform->SetAppPath(szAppPath);
	_Platform->SetAppData(szAppData);

	_Platform->Init();

	//��ʼ�������
	char szNetXml[1024] = { 0 };
	sprintf((char*)szNetXml, "<root workdir=\"%s\" datadir=\"%s\"><module name=\"QNetModule.dll\"></module></root>", szAppPathA, szAppDataA);
	printf("Start NetIOEngine:\n%s\n", szNetXml);
	_NetIOEngine->Start((char*)szNetXml);
	printf("Start NetIOEngine OK.\n");

	//��ʼ�����ݲ�
	char szDEXml[1024] = { 0 };
	sprintf((char*)szDEXml, "<root workdir=\"%s\" datadir=\"%s\"><module name=\"QDataModule.dll\"></module><module name=\"CTPTrader.dll\"></module></root>", szAppPathA, szAppDataA);
	printf("Start DataEngine:\n%s\n", szDEXml);
	_DataEngine->Start(szDEXml);
	printf("Start DataEngine OK.\n");

	_Platform->SetDataManager(new XDataManager);

	//��ʼ��ָ��ϵͳ
	TCHAR szIndicatorPath[MAX_PATH] = { 0 };
	_tmakepath(szIndicatorPath, NULL, szAppPath, _T("XIndicator.dll"), NULL);
	//iLogW(LOGLEVEL_INFO,szIndicatorPath);
	_Platform->SetIndicatorModule(LoadLibrary(szIndicatorPath));

	//ƽ̨����
	_Platform->Instance();

	//�����¼ģ��
	XLoginManager Login;

	//��¼����
	_LoginMgr->Instance();

	_LoginMgr->PostEvent(EVT_PLAT_CALL, MAKEVALUE(MCALL_PLAT_LOGIN, CCALL_LOGIN_LOGIN), 0);

	//������ģ��
	XFrame Frame;

	//�������
	Frame.Create(NULL);

	//�¼�ѭ��
#if 0
	system("pause");
#else
	theLoop.Run();
#endif//

	//���ٿ��
	Frame.Destroy();

	//�ͷŵ�¼ģ��
	_LoginMgr->Release();

	//ֹͣƽ̨
	_Platform->Release();

	//ֹͣ���ݲ�
	_DataEngine->Stop();

	//ֹͣ�����
	_NetIOEngine->Stop();

	//����ƽ̨
	_Platform->Term();

	//�ͷ�XLib
	XLibInit::Release();

	return 0;
}

int Run(void)
{
	Thread thrd;
	thrd.CreateThread(ThreadFunc, NULL);
	//thrd.Join();
	//system("pause");
	getchar();
	EvtDispatcher* pThrdDispatcher = EvtDispatcher::GetEvtDispatcher(thrd.GetThreadId());
	if (pThrdDispatcher) {
		pThrdDispatcher->PostQuitEvent();
	}
	thrd.StopThread();

	return 0;
}

int _tmain(int argc, _TCHAR* argv[])
{
	return Run();
	return 0;
}

