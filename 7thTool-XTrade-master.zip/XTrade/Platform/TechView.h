#ifndef _H_QTECHVIEW_H_
#define _H_QTECHVIEW_H_

#include <Util/CommodityView.h>
#include <Util/CommodityMap.h>
#include <Util/ViewSplitter.h>
#include <Util/IndicatorMap.h>
#include <Util/OrderTicketMap.h>

class QWndIndicator 
	: public CommodityViewImpl<QWndIndicator>
	, public MultiObjecterMap<QWndIndicator>
	, public IndicatorMap<QWndIndicator>
	, public HisDataMap<QWndIndicator>
{
	typedef QWndIndicator This;
	typedef CommodityViewImpl<QWndIndicator> Base;
	typedef MultiObjecterMap<QWndIndicator> MultiIndicatorMap;
	typedef IndicatorMap<QWndIndicator> MyIndicatorMap;
	DECLARE_XMLWND_CLASS(_T("WndIndicator"))
	DECLARE_DYNCREATE_WND_OBJECTER(QWndIndicator,Objecter)
protected:
	CMemDC m_dc;
	CMemDC m_dcInfo;
	CMemDC m_dcCrossCursor;

	BOOL m_bMainIndicator:1;
public:
	QWndIndicator();
	virtual ~QWndIndicator();

	BOOL IsDirectUI() { return TRUE; }

	HWND CreateControl(HWND hWndParent, LPCTSTR lpszWndClass, LPCTSTR lpszCtrlName, UINT nID, LPCTSTR lpszXml, UINT XmlFlag);

	HWND AddIndicator(LPCTSTR lpszClass, LPCTSTR lpszXml, UINT XmlFlag);
	void RemoveIndicator(UINT Pos);
	void RemoveAllIndicator();

	void OnCreateObjecter(Objecter* pObjecter);

	BEGIN_MSG_MAP(This)
		MESSAGE_HANDLER(WM_CREATE, OnCreate)
		MESSAGE_HANDLER(WM_DESTROY, OnDestroy)
		MESSAGE_HANDLER(WM_SIZE, OnSize)
		MESSAGE_RANGE_HANDLER(WM_MOUSEFIRST, WM_MOUSELAST, OnMouse)
		MESSAGE_HANDLER(WM_MOUSEHOVER, OnMouse)
		MESSAGE_HANDLER(WM_MOUSELEAVE, OnMouse)
		MESSAGE_RANGE_HANDLER(WM_KEYFIRST, WM_KEYLAST, OnKey)
		UPDATE_COMMAND_UI_HANDLER(OnUpdateCommandUI)
		MESSAGE_HANDLER(WM_COMMAND, OnCommand)
		CHAIN_MSG_MAP(Base)
	END_MSG_MAP()

	LRESULT OnCreate(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/);
	LRESULT OnDestroy(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& bHandled);
	LRESULT OnSize(UINT /*uMsg*/, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnMouse(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnKey(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnUpdateCommandUI(CUpdateUIBase* pUpdateUI, BOOL& bHandled);
	LRESULT OnCommand(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	void OnPaint(HDC hdc);

public:
	void GetRect(LPRECT lpRect) { GetClientRect(lpRect); }

	bool IsDispOk();

	//����ӿ�
	virtual void Draw(HDC hdc);
	virtual void DrawInfo(HDC hdc);

	virtual void DrawCrossCursor(HDC hdc);

protected:
	//
	MsgEventPtr m_msgPtr;
	//
	std::vector<IndicatorInfoPtr> m_iInfoPtrs;
	void UpdateInfos();
	std::vector<std::vector<IndicatorIndexInfoPtr>> m_iIndexInfoPtrs; //ָ����Ϣ��ָ��λ����Ϣ��ֵ�����꣩
	void UpdateIndexInfos();
	void UpdateIndexInfosByPos(unsigned long pos);
	IndicatorPointInfoExPtr m_iPointInfoPtr; //������Ϣ��λ�ã�ֵ��
	void UpdateIndexInfosByPoint(POINT pt);
	std::vector<CRect> m_iInfoRects;
	
	bool UpdateMmxValue(); //������ʾ�����Сֵ

public:
	void OnDispInfoChanged();
	void OnViewInfoChanged();
	void OnViewDispInfoChanged();
	void OnIndicatorCalcInfoChanged();
	void OnIndicatorDispInfoChanged();
	void OnRefresh(ObjectPtr objPtr);
	void OnInvalidate(ObjectPtr objPtr);

	void OnHisDataChanged(Event& evt);

	BEGIN_EVT_MAP(This)
		ON_EVT(EVT_PLAT_CALL,OnCall)
		ON_EVT(EVT_PLAT_NOTIFY,OnNotify)
		CHAIN_EVT_MAP(HisDataMap<QWndIndicator>)
		CHAIN_EVT_MAP(MyIndicatorMap)
		CHAIN_EVT_MAP(MultiIndicatorMap)
		CHAIN_EVT_MAP(Base)
	END_EVT_MAP()

	long OnCall(Event& evt);
	long OnNotify(Event& evt);
};

class QMainWndIndicator 
	: public QWndIndicator
{
	typedef QMainWndIndicator This;
	typedef QWndIndicator Base;
	DECLARE_XMLWND_CLASS(_T("MainIndicator"))
	DECLARE_DYNCREATE_WND_OBJECTER(QMainWndIndicator,Objecter)
public:
	QMainWndIndicator();
	virtual ~QMainWndIndicator();

	BEGIN_MSG_MAP(This)
		MESSAGE_HANDLER(WM_DESTROY, OnDestroy)
		CHAIN_MSG_MAP(Base)
	END_MSG_MAP()

	LRESULT OnDestroy(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& bHandled);

protected:
	WndObjecter* m_pWndTrader;
	double m_MinValue;
	double m_MaxValue;

	void ShowMiniTrader();
	void HideMiniTrader();

public:
	
	BEGIN_EVT_MAP(This)
		ON_EVT(EVT_PLAT_CALL,OnCall)
		CHAIN_EVT_MAP(Base)
	END_EVT_MAP()

	long OnCall(Event& evt);
};

class QTechView 
	: public CommodityViewImpl<QTechView>
	, public ViewSplitterImpl<QTechView>
	, public HisDataMap<QTechView>
{
	typedef QTechView This;
	typedef CommodityViewImpl<QTechView> Base;
	typedef ViewSplitterImpl<QTechView> ViewSplitter;
	DECLARE_XMLWND_CLASS(_T("TechView"))
	DECLARE_DYNCREATE_WND_OBJECTER(QTechView,Objecter)
public:
	QTechView();

	BOOL m_bCrossCursor;
	CMemDC m_dcCrossCursor;

	POINT m_ptCoordinate;
	CMemDC m_dcCoordinate;
	BOOL m_bMoveCoordinate;

	BOOL IsDirectUI() { return TRUE; }

	HWND CreateControl(HWND hWndParent, LPCTSTR lpszWndClass, LPCTSTR lpszCtrlName, UINT nID, LPCTSTR lpszXml, UINT XmlFlag);

	//void OnCreateControl(HWND hWndParent, HWND hWndCtrl, LPCTSTR lpszWndClass, LPCTSTR lpszCtrlName, UINT nID);
	//void OnCloseControl(HWND hWndCtrl, LPCTSTR lpszWndClass, LPCTSTR lpszCtrlName);

	BOOL GetLayoutRect(LPRECT lpRect);

	void AddWndIndicator(HWND hWnd);
	void RemoveWndIndicator(HWND hWnd);

	BOOL PreTranslateMessage(MSG* pMsg);

	BEGIN_MSG_MAP(This)
		MESSAGE_HANDLER(WM_CREATE, OnCreate)
		MESSAGE_HANDLER(WM_DESTROY, OnDestroy)
		MESSAGE_HANDLER(WM_SIZE, OnSize)
		MESSAGE_RANGE_HANDLER(WM_MOUSEFIRST, WM_MOUSELAST, OnMouse)
		MESSAGE_HANDLER(WM_MOUSEHOVER, OnMouse)
		MESSAGE_HANDLER(WM_MOUSELEAVE, OnMouse)
		MESSAGE_RANGE_HANDLER(WM_KEYFIRST, WM_KEYLAST, OnKey)
		MESSAGE_HANDLER(WM_PAINTEFFECTMSG, OnPaintEffect)
		MESSAGE_HANDLER(WM_BACKWARDMSG, OnBackwardMsg)
		UPDATE_COMMAND_UI_HANDLER(OnUpdateCommandUI)
		MESSAGE_HANDLER(WM_COMMAND, OnCommand)
		CHAIN_MSG_MAP(ViewSplitter)
		CHAIN_MSG_MAP(Base)
	END_MSG_MAP()

	LRESULT OnCreate(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/);
	LRESULT OnDestroy(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& bHandled);
	LRESULT OnSize(UINT /*uMsg*/, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnMouse(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnKey(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnPaintEffect(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnBackwardMsg(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnUpdateCommandUI(CUpdateUIBase* pUpdateUI, BOOL& bHandled);
	LRESULT OnCommand(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	void OnPaint(HDC hdc);

protected:
	//
	IndicatorCalcInfoPtr m_iCalcInfoPtr;
	IndicatorDispInfoPtr m_iPreDispInfoPtr;
	IndicatorDispInfoPtr m_iDispInfoPtr;
	IndicatorPointInfoPtr m_iPointInfoPtr;		//������Ϣ��λ�ã�ֵ��
	IndicatorIndexInfoPtr m_iBufferInfoPtr;	//K����Ϣ��ֵ�����꣩

	void GetTechRect(LPRECT lpRect);
	void GetInfoBarRect(PRECT lpRect);
	void GetCoordinateRect(LPRECT lpRect);

	bool IsDispOk();

	void DrawCoordinate(HDC hdc);
	void DrawTick(HDC hdc, LPRECT lprc, LPCTSTR lpszText = NULL, int nTextLen = 0);

	int GetBarPosBy(POINT pt);
	//POINT GetBarPointBy(int nPos);

	void UpdateIndicatorCalcInfo();

	void SwapIndicatorDispInfo();
	enum { UD_NONE = 0, UD_BARSCHANGE, UD_SIZECHANGE, UD_DISPCHANGE, };
	void UpdateIndicatorDispInfo(int udType = UD_NONE);

	//void ShowCrossCursor(POINT pt);
	//void ShowCrossCursor(int nPos);
	void HideCrossCursor();
	void DrawCrossCursor(HDC hdc);

	void Scale(int nOffset);
	void Move(int nOffset);

	void MoveCurrent(int nOffset);
	void ShowCurrent(int nPos);
	void ShowCurrent(POINT pt, BOOL bShowOrHide = FALSE);
	void ShowCurrent(int nPos, BOOL bCrossCursor);
	
public:
	void UpdateCalcInfo();
	void UpdateDispInfo();

	void OnDispInfoChanged();
	void OnViewInfoChanged();
	void OnViewDispInfoChanged();
	void OnRefresh(ObjectPtr objPtr);
	
	void OnHisDataChanged(Event& evt);

	BEGIN_EVT_MAP(This)
		ON_EVT(EVT_PLAT_CALL, OnCall)
		ON_EVT(EVT_PLAT_NOTIFY, OnNotify)
		CHAIN_EVT_MAP(HisDataMap<QTechView>)
		CHAIN_EVT_MAP(ViewSplitter)
		CHAIN_EVT_MAP(Base)
	END_EVT_MAP()

	long OnCall(Event& evt);
	long OnNotify(Event& evt);
};

#endif//_H_QTECHVIEW_H_