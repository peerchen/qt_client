// MainFrm.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#pragma once

#include <Platform/XFrame.h>
#include <Util/WndObjecterMap.h>
#include <Util/ViewSplitter.h>
#include "ChildView.h"
#include "SmartKB.h"
class CSmartKBDlg;

//////////////////////////////////////////////////////////////////////////

class QReBarCtrl : public UIWndImpl<QReBarCtrl, UIReBarCtrl>
	,public UIEraseBkgnd<QReBarCtrl>
	//,public UIOwnerDraw<QReBarCtrl>
{
	typedef QReBarCtrl This;
	typedef UIWndImpl<QReBarCtrl, UIReBarCtrl> Base;
public:
	BEGIN_MSG_MAP_EX(This)
		CHAIN_MSG_MAP(UIEraseBkgnd<QReBarCtrl>)
		//CHAIN_MSG_MAP(UIOwnerDraw<UIReBarCtrlEx>)
		CHAIN_MSG_MAP(Base)
	END_MSG_MAP()

	BOOL OnEraseBkgnd(HDC hdc);

	// 	DWORD OnPrePaint(int /*idCtrl*/, LPNMCUSTOMDRAW /*lpNMCustomDraw*/)
	// 	{
	// 		return CDRF_NOTIFYITEMDRAW;
	// 	}
};

//////////////////////////////////////////////////////////////////////////

class QCommandBarCtrl : public  UICommandBarCtrlImpl<QCommandBarCtrl>
{
	typedef QCommandBarCtrl This;
	typedef UICommandBarCtrlImpl<QCommandBarCtrl> Base;
public:
	DECLARE_WND_SUPERCLASS(_T("Q_CommandBar"), GetWndClassName())
	
public:

	BEGIN_MSG_MAP(This)
		CHAIN_MSG_MAP(Base)
		ALT_MSG_MAP(1)   // Parent window messages
		NOTIFY_CODE_HANDLER(NM_CUSTOMDRAW, OnParentCustomDraw)
		CHAIN_MSG_MAP_ALT(Base,1)
		ALT_MSG_MAP(2)   // MDI client window messages
		CHAIN_MSG_MAP_ALT(Base,2)
		ALT_MSG_MAP(3)   // Message hook messages
		CHAIN_MSG_MAP_ALT(Base,3)
	END_MSG_MAP()

	LRESULT OnEraseBackground(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnParentCustomDraw(int /*idCtrl*/, LPNMHDR pnmh, BOOL& bHandled);
};

//////////////////////////////////////////////////////////////////////////

class QToolBarCtrl : public UIWndImpl<QToolBarCtrl, UIToolBarCtrl>
	,public UIOwnerDraw<QToolBarCtrl>
	,public UICustomDraw<QToolBarCtrl>
	//,public UIPaintBkgnd<QToolBarCtrl>
{
	typedef QToolBarCtrl This;
	typedef UIWndImpl<QToolBarCtrl, UIToolBarCtrl> Base;
public:

	BEGIN_MSG_MAP_EX(This)
		//MESSAGE_HANDLER(WM_PAINT,OnPaint)
		CHAIN_MSG_MAP(UIOwnerDraw<QToolBarCtrl>)
		CHAIN_MSG_MAP(UICustomDraw<QToolBarCtrl>)
		//CHAIN_MSG_MAP(UIPaintBkgnd<QToolBarCtrl>)
		CHAIN_MSG_MAP(Base)
	END_MSG_MAP()

	LRESULT OnPaint(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	DWORD OnPrePaint(int /*idCtrl*/, LPNMCUSTOMDRAW lpNMCustomDraw);
	DWORD OnPostPaint(int /*idCtrl*/, LPNMCUSTOMDRAW /*lpNMCustomDraw*/);
	DWORD OnPreErase(int /*idCtrl*/, LPNMCUSTOMDRAW /*lpNMCustomDraw*/);
	DWORD OnPostErase(int /*idCtrl*/, LPNMCUSTOMDRAW /*lpNMCustomDraw*/);
	DWORD OnItemPrePaint(int idCtrl, LPNMCUSTOMDRAW lpNMCustomDraw);
	DWORD OnItemPostPaint(int /*idCtrl*/, LPNMCUSTOMDRAW /*lpNMCustomDraw*/);
	DWORD OnItemPreErase(int /*idCtrl*/, LPNMCUSTOMDRAW /*lpNMCustomDraw*/);
	DWORD OnItemPostErase(int /*idCtrl*/, LPNMCUSTOMDRAW /*lpNMCustomDraw*/);
#if (_WIN32_IE >= 0x0400)
	DWORD OnSubItemPrePaint(int /*idCtrl*/, LPNMCUSTOMDRAW /*lpNMCustomDraw*/);
#endif // (_WIN32_IE >= 0x0400)
};

//////////////////////////////////////////////////////////////////////////

class QAddressBar : public UIWndImpl<QAddressBar,UIComboBoxEx>
{
	typedef QAddressBar This;
public:
	DECLARE_WND_SUPERCLASS(_T("AddressBar"), UIComboBoxEx::GetWndClassName())

	enum
	{
		m_cxGap = 2,
		m_cxMinDropWidth = 200
	};

	CComboBox m_cb;
	CToolBarCtrl m_tb;
	SIZE m_sizeTB;

	BEGIN_MSG_MAP(This)
		MESSAGE_HANDLER(WM_CREATE, OnCreate)
		MESSAGE_HANDLER(WM_ERASEBKGND, OnEraseBkgnd)
		MESSAGE_HANDLER(WM_WINDOWPOSCHANGING, OnWindowPosChanging)
		NOTIFY_CODE_HANDLER(TTN_GETDISPINFO, OnToolTipText)
		MESSAGE_HANDLER(WM_MOUSEACTIVATE, OnMouseActivate)
	END_MSG_MAP()

	LRESULT OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& /*bHandled*/);
	LRESULT OnEraseBkgnd(UINT /*uMsg*/, WPARAM wParam, LPARAM /*lParam*/, BOOL& bHandled);
	LRESULT OnWindowPosChanging(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnToolTipText(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);
	LRESULT OnMouseActivate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& /*bHandled*/);
};

class MyAddressBar 
	: public UIWndImpl<MyAddressBar>
{
	typedef MyAddressBar This;
public:
	DECLARE_WND_CLASS(_T("MyAddressBar"))

	enum
	{
		m_cxGap = 2,
		m_cxMinDropWidth = 200
	};

	UIEdit GetEditCtrl();
	CToolBarCtrl GetToolBarCtrl();

	SmartKBComboBox m_cb;
	CToolBarCtrl m_tb;
	SIZE m_sizeTB;

	BEGIN_MSG_MAP(This)
		MESSAGE_HANDLER(WM_CREATE, OnCreate)
		MESSAGE_HANDLER(WM_CREATE, OnSize)
		MESSAGE_HANDLER(WM_ERASEBKGND, OnEraseBkgnd)
		MESSAGE_HANDLER(WM_WINDOWPOSCHANGING, OnWindowPosChanging)
		NOTIFY_CODE_HANDLER(TTN_GETDISPINFO, OnToolTipText)
		MESSAGE_HANDLER(WM_MOUSEACTIVATE, OnMouseActivate)
	END_MSG_MAP()

	LRESULT OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& /*bHandled*/);
	LRESULT OnSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& /*bHandled*/);
	LRESULT OnEraseBkgnd(UINT /*uMsg*/, WPARAM wParam, LPARAM /*lParam*/, BOOL& bHandled);
	LRESULT OnWindowPosChanging(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnToolTipText(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);
	LRESULT OnMouseActivate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& /*bHandled*/);
};

//////////////////////////////////////////////////////////////////////////

class QStatusBarCtrl : public UIWndImpl<QStatusBarCtrl, UIStatusBarCtrl>
	,public UIEraseBkgnd<QStatusBarCtrl>
{
	typedef QStatusBarCtrl This;
	typedef UIWndImpl<QStatusBarCtrl, UIStatusBarCtrl> Base;
public:
	BEGIN_MSG_MAP_EX(This)
		CHAIN_MSG_MAP(UIEraseBkgnd<QStatusBarCtrl>)
		CHAIN_MSG_MAP(Base)
	END_MSG_MAP()

	BOOL OnEraseBkgnd(HDC hdc);
};

//////////////////////////////////////////////////////////////////////////

class CMainFrame 
	: public UISDIFrameImpl<CMainFrame>
	, public UIOwnerDraw<CMainFrame>
	, public UICustomDraw<CMainFrame>
	, public CDynamicUpdateUI<CMainFrame>
	, public UIMessageFilter<CMainFrame>
	, public CIdleHandler
	, public UIXPaneSplitterImpl<CMainFrame,UIXPane2>
	, public UIEraseBkgnd<CMainFrame>
	, public WndObjecter
	, public WndObjecterMap<CMainFrame>
	, public MultiWndObjecterMap<CMainFrame>
	, public XFrameManager
{
	typedef CMainFrame This;
	typedef UISDIFrameImpl<CMainFrame> Base;
	typedef UIMessageFilter<CMainFrame> MsgFilter;
	typedef UIXPaneSplitterImpl<CMainFrame,UIXPane2> PaneSplitter;
	typedef WndObjecterMap<CMainFrame> WndObjectMap;
	typedef MultiWndObjecterMap<CMainFrame> MultiWndObjectMap;
	typedef XFrameManager XFrame;
public:
	DECLARE_FRAME_WND_CLASS(_T("Platform_MainFrame"), IDR_MAINFRAME)
	DECLARE_DYNCCREATE_WND_CLASS(CMainFrame)
	DECLARE_OBJECTER(CMainFrame)
	DECLARE_WND_OBJECTER(CMainFrame)

	CString m_strName;
	CString m_strCmdLine;

	typedef std::map<CString,UINT,CStringLess> Str2CmdId;
	Str2CmdId m_strName2CmdId;
	typedef std::map<UINT,CString> CmdId2Cmdline;
	CmdId2Cmdline m_nId2Cmdline;
	std::list<QToolBarCtrl> m_ToolBars;
	//QAddressBar m_AddressBar;
	MyAddressBar m_AddressBar;
	QCommandBarCtrl m_CmdBar;
	//QToolBarCtrl m_ToolBar;
	QReBarCtrl m_Rebar;
	CChildView m_ChildView;
	WndObjecter* m_pContainer;
	QStatusBarCtrl m_StatusBar;

	iHandle m_hStrategy;
	std::map<COMREF,BOOL> m_CommoditysOfStrategy;

	CSmartKBDlg* m_pSmartKBDlg;
	SIZE m_xySmartKBOffset;

	UINT m_nTimer;
	UINT m_nReqPushTimer;

	WndObjecter* m_pRptContainer;
	WndObjecter* m_pScdtContainer;

	//PageInfo��ChildView��Tab����˳��λ����ȫһ��
	class PageInfo : public Object
	{
	public:
		PageInfo(const ContainerInfoPtr& infoPtr):
		  InfoPtr(infoPtr)
		{
			
		}

		ContainerInfoPtr InfoPtr;
	};
	typedef Handle<PageInfo> PageInfoPtr;
	std::vector<PageInfoPtr> m_PageInfoPtrs;
	PageInfoPtr m_CurPagePtr;

	//��¼�û�������¼
	class HisRecordInfo : public Object
	{
	public:
		HisRecordInfo()
		{
			//PagePtr;
			nKind = -1;
			nCommodity = -1;
		}

		bool IsRptPage()
		{
			return nCommodity < 0;
		}

		bool IsScdtPage() 
		{
			return nCommodity >= 0;
		}

		const ContainerInfoPtr & GetInfoPtr()
		{
			return PagePtr->InfoPtr;
		}

		const KindInfo& GetKind()
		{
			return PagePtr->InfoPtr->GetKindList()[nKind];
		}

		const COMREF& GetCommodity()
		{
			return PagePtr->InfoPtr->GetCommodityList()[nCommodity];
		}

		CString strName;
		PageInfoPtr PagePtr;
		int nKind;
		int nCommodity;
	};
	typedef Handle<HisRecordInfo> HisRecordInfoPtr;
	typedef std::vector<HisRecordInfoPtr> HisRecordPtrList;
	HisRecordPtrList  m_HisRecordList; //
	int m_nCurRecord;
	BOOL m_bEnableRecord;

protected:
	typedef std::map<std::tstring, Markup*, std::tstringiless> Name2pMarkup;
	Name2pMarkup m_Name2pMarkup;
	Markup* OpenMarkup(LPCTSTR lpszFile);
	void CloseMarkup(LPCTSTR lpszFile);
//public:
	virtual long WriteValue(LPCSTR lpszName, LPCSTR lpszValue, int nValueCount = 0, LPCSTR lpszSpec = NULL, LPCSTR lpszFile = NULL);
	virtual long ReadValue(LPCSTR lpszName, LPSTR lpszValue, int nValueCount, LPCSTR lpszSpec = NULL, LPCSTR lpszFile = NULL);
	virtual long WriteValue(LPCWSTR lpszName, LPCWSTR lpszValue, int nValueCount = 0, LPCWSTR lpszSpec = NULL, LPCWSTR lpszFile = NULL);
	virtual long ReadValue(LPCWSTR lpszName, LPWSTR lpszValue, int nValueCount, LPCWSTR lpszSpec = NULL, LPCWSTR lpszFile = NULL);

public:
	CMainFrame(LPCTSTR lpstrName = NULL, LPCTSTR lpstrCmdLine = NULL);

	BOOL IsStrategy();

	UINT MapCmdId(UINT nCmdId, LPCTSTR lpszName);
	UINT MapCmdId(LPCTSTR lpszName, UINT nCmdId);
	UINT MapCmdId(LPCTSTR lpszName);
	LPCTSTR MapCmdline(LPCTSTR lpszCmdline, UINT nCmdId);
	LPCTSTR MapCmdline(UINT nCmdId, LPCTSTR lpszCmdline);
	LPCTSTR MapCmdline(UINT nCmdId);
protected:
	void DoCmdMap();
	void DoXmlMenu(HMENU hMenu, Markup* xml);

	BOOL Execute(LPCTSTR lpszCmdline);
public:

	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual BOOL OnIdle();

	HWND Create(HWND hWndParent = NULL, ATL::_U_RECT rect = NULL, LPCTSTR szWindowName = NULL,
		DWORD dwStyle = 0, DWORD dwExStyle = 0,
		HMENU hMenu = NULL, LPVOID lpCreateParam = NULL);
	virtual HWND Create(HWND hWndParent, LPCTSTR lpszXml = NULL, UINT XmlFlag = XML_FLAG_FILE);
	virtual void Destroy();

	HWND CreateControl(HWND hWndParent, LPCTSTR lpszWndClass, LPCTSTR lpszCtrlName, UINT nID, LPCTSTR lpszXml, UINT XmlFlag);

	virtual void GetPushInfo();

	WndObjecter* CreateContainer(LPCTSTR lpszName, LPCTSTR lpszXml, UINT XmlFlag = XML_FLAG_FILE);
	void DestroyContainer(WndObjecter* pContainer);
	WndObjecter* FindContainer(LPCTSTR lpszName);

	WndObjecter* SetCurContainer(WndObjecter* pContainer);
	
	enum
	{
		PAGE_NONE = 0,
		PAGE_NEW_PAGE = 0x01,
		PAGE_KIND_CHANGED = 0x02,
		PAGE_COMMODITY_CHANGED = 0x04,
	};
	//PageInfoPtr GetCurPage();
	void SetCurPage(int nItem, UINT uFlags = PAGE_NONE);

	void GotoPage(int nItem, UINT uFlags = PAGE_NONE);

	bool IsRptPage(const PageInfoPtr& PagePtr);
	bool IsScdtPage(const PageInfoPtr& PagePtr);
	void Goto(const KindInfo& Kind);
	void Goto(const ContainerInfoPtr& InfoPtr, BOOL bNew = FALSE);
	void Goto(const ContainerInfoPtr& InfoPtr, const COMREF& Commodity);
	void Goto(int nOffset);

	void AddHisRecord(PageInfoPtr PagePtr, int nKind = -1, int nCommodity = -1);
	void RemoveRecord(PageInfoPtr PagePtr);

	void ShowSmartKBDlg(BOOL bShow = TRUE);

	void UpdateLayout(BOOL bResizeBars = TRUE);
	
	BOOL OnEraseBkgnd(HDC hdc);

	DWORD OnPrePaint(int /*idCtrl*/, LPNMCUSTOMDRAW lpNMCustomDraw);
	DWORD OnPostPaint(int /*idCtrl*/, LPNMCUSTOMDRAW /*lpNMCustomDraw*/);
	DWORD OnPreErase(int /*idCtrl*/, LPNMCUSTOMDRAW /*lpNMCustomDraw*/);
	DWORD OnPostErase(int /*idCtrl*/, LPNMCUSTOMDRAW /*lpNMCustomDraw*/);
	DWORD OnItemPrePaint(int idCtrl, LPNMCUSTOMDRAW lpNMCustomDraw);
	DWORD OnItemPostPaint(int /*idCtrl*/, LPNMCUSTOMDRAW /*lpNMCustomDraw*/);
	DWORD OnItemPreErase(int /*idCtrl*/, LPNMCUSTOMDRAW /*lpNMCustomDraw*/);
	DWORD OnItemPostErase(int /*idCtrl*/, LPNMCUSTOMDRAW /*lpNMCustomDraw*/);
#if (_WIN32_IE >= 0x0400)
	DWORD OnSubItemPrePaint(int /*idCtrl*/, LPNMCUSTOMDRAW /*lpNMCustomDraw*/);
#endif // (_WIN32_IE >= 0x0400)

	BEGIN_UPDATE_UI_MAP(This)
		UPDATE_ELEMENT(IDR_MAINFRAME, UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ATL_IDW_STATUS_BAR, UPDUI_MENUPOPUP)
		//
		/*UPDATE_ELEMENT(ID_TECHVIEW_KLINE, UPDUI_TOOLBAR|UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_TECHVIEW_KLINE+KLINE_BAR, UPDUI_TOOLBAR|UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_TECHVIEW_KLINE+KLINE_TREND, UPDUI_TOOLBAR|UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_TECHVIEW_INDICATOR_ADDOBJECT, UPDUI_TOOLBAR|UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_TECHVIEW_INDICATOR_ADDOBJECT+1, UPDUI_TOOLBAR|UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_TECHVIEW_INDICATOR_ADDOBJECT+2, UPDUI_TOOLBAR|UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_TECHVIEW_INDICATOR_ADDOBJECT+3, UPDUI_TOOLBAR|UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_TECHVIEW_INDICATOR_ADDOBJECT+4, UPDUI_TOOLBAR|UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_TECHVIEW_INDICATOR_ADDOBJECT+5, UPDUI_TOOLBAR|UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_TECHVIEW_INDICATOR_ADDOBJECT+6, UPDUI_TOOLBAR|UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_TECHVIEW_INDICATOR_ADDOBJECT+7, UPDUI_TOOLBAR|UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_TECHVIEW_INDICATOR_ADDOBJECT+8, UPDUI_TOOLBAR|UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_TECHVIEW_INDICATOR_ADDOBJECT+9, UPDUI_TOOLBAR|UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_TECHVIEW_INDICATOR_ADDOBJECT+10, UPDUI_TOOLBAR|UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_TECHVIEW_INDICATOR_ADDOBJECT+11, UPDUI_TOOLBAR|UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_TECHVIEW_INDICATOR_ADDOBJECT+12, UPDUI_TOOLBAR|UPDUI_MENUPOPUP)*/
	END_UPDATE_UI_MAP()

	BEGIN_MSG_MAP_EX(This)
		MESSAGE_HANDLER(WM_CREATE, OnCreate)
		MESSAGE_HANDLER(WM_CREATED, OnCreated)
		MESSAGE_HANDLER(WM_DESTROY, OnDestroy)
		MESSAGE_HANDLER(WM_SIZE, OnSize)
		MESSAGE_HANDLER(WM_GETMINMAXINFO, OnGetMinMaxInfo)
		COMMAND_ID_HANDLER(ID_APP_EXIT, OnFileExit)
		COMMAND_ID_HANDLER(ID_FILE_NEW, OnFileNew)
		COMMAND_ID_HANDLER(ID_VIEW_TOOLBAR, OnViewToolBar)
		COMMAND_ID_HANDLER(ID_VIEW_STATUS_BAR, OnViewStatusBar)
		COMMAND_ID_HANDLER(ID_APP_ABOUT, OnAppAbout)
		COMMAND_ID_HANDLER(ID_WINDOW_CASCADE, OnWindowCascade)
		COMMAND_ID_HANDLER(ID_WINDOW_TILE_HORZ, OnWindowTile)
		COMMAND_ID_HANDLER(ID_WINDOW_ARRANGE, OnWindowArrangeIcons)
		COMMAND_ID_HANDLER(ID_WINDOW_CLOSE, OnWindowClose)
		COMMAND_RANGE_HANDLER(ID_WINDOW_TABFIRST, ID_WINDOW_TABLAST, OnWindowActivate)
		MESSAGE_HANDLER(WM_KEYDOWN, OnKeyDown)
		MESSAGE_HANDLER(WM_CHAR, OnChar)
		MESSAGE_HANDLER(WM_COMMAND, OnCommand)
		MESSAGE_HANDLER(WM_TIMER, OnTimer)
		NOTIFY_CODE_HANDLER(TBN_DROPDOWN,OnTBDropDown)
		NOTIFY_CODE_HANDLER(TBVN_PAGEACTIVATED, OnPageActivated)
		NOTIFY_CODE_HANDLER(TBVN_CONTEXTMENU, OnPageContextMenu)
		CHAIN_MSG_MAP(UIOwnerDraw<CMainFrame>)
		CHAIN_MSG_MAP(UICustomDraw<CMainFrame>)
		CHAIN_MSG_MAP(CDynamicUpdateUI<CMainFrame>)
		CHAIN_MSG_MAP(UIEraseBkgnd<CMainFrame>)
		//CHAIN_MSG_MAP(WndObjectMap)
		CHAIN_MSG_MAP(MultiWndObjectMap)
		CHAIN_MSG_MAP(PaneSplitter)
		CHAIN_MSG_MAP(Base)
	END_MSG_MAP()

// Handler prototypes (uncomment arguments if needed):
//	LRESULT MessageHandler(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
//	LRESULT CommandHandler(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
//	LRESULT NotifyHandler(int /*idCtrl*/, LPNMHDR /*pnmh*/, BOOL& /*bHandled*/)

	LRESULT OnCreate(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/);
	LRESULT OnCreated(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/);
	LRESULT OnDestroy(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& bHandled);
	LRESULT OnSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnGetMinMaxInfo(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnFileExit(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnFileNew(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnViewToolBar(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnViewStatusBar(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnAppAbout(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnWindowCascade(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnWindowTile(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnWindowArrangeIcons(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnWindowClose(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnWindowActivate(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnKeyDown(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnChar(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnCommand(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnTimer(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnTBDropDown(int idFrom, LPNMHDR lpNMHdr, BOOL& bHandled);

	LRESULT OnPageActivated(int idFrom, LPNMHDR lpNMHdr, BOOL& bHandled);
	LRESULT OnPageContextMenu(int idFrom, LPNMHDR lpNMHdr, BOOL& bHandled);

protected:
	void LoadDispInfo();

	long DoSmartKB(SmartKBObjectPtr& objPtr, BOOL bNew = FALSE);

public:
	void OnDispInfoChanged();

	BEGIN_EVT_MAP(CMainFrame)
		ON_EVT(EVT_PLAT_CALL,OnCall)
		ON_EVT(EVT_PLAT_NOTIFY,OnNotify)
		CHAIN_EVT_MAP(WndObjectMap)
		CHAIN_EVT_MAP(MultiWndObjectMap)
		CHAIN_EVT_MAP(XFrame)
	END_EVT_MAP()

	long OnCall(Event& evt);
	long OnNotify(Event& evt);
};
