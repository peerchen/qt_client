#include "stdafx.h"
#include "TradeView.h"

//////////////////////////////////////////////////////////////////////////
///QTradeView

IMPLEMENT_DYNCREATE_WND_OBJECTER(QTradeView,Objecter)

void QTradeView::OnPaint(HDC hdc)
{
	CDCHandle dc(hdc);

	CRect rcClient;
	GetClientRect(&rcClient);

	dc.FillSolidRect(&rcClient, m_DispInfoPtr->crBackgnd);

	dc.SetTextColor(m_DispInfoPtr->crText);
	dc.TextOut(rcClient.left,rcClient.top, GetThisClassName());
}

void QTradeView::OnDispInfoChanged()
{
	Invalidate();
}

void QTradeView::OnViewInfoChanged()
{
	Invalidate();
}


//////////////////////////////////////////////////////////////////////////
///QMiniTradeView

IMPLEMENT_DYNCREATE_WND_OBJECTER(QMiniTradeView,Objecter)

void QMiniTradeView::OnPaint(HDC hdc)
{
	CDCHandle dc(hdc);

	CRect rcClient;
	GetClientRect(&rcClient);

	dc.FillSolidRect(&rcClient, m_DispInfoPtr->crBackgnd);

	dc.SetTextColor(m_DispInfoPtr->crText);
	dc.TextOut(rcClient.left,rcClient.top, GetThisClassName());
}

LRESULT QMiniTradeView::OnCreate(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& bHandled)
{
	LRESULT lRes = DefWindowProc();

	/*m_btnBuy.Create(m_hWnd, rcDefault);
	m_btnSell.Create(m_hWnd, rcDefault);
	m_btnPlus.Create(m_hWnd, rcDefault);
	m_btnMinus.Create(m_hWnd, rcDefault);
	m_edVolume.Create(m_hWnd, rcDefault);*/

	return lRes;
}

LRESULT QMiniTradeView::OnSize(UINT /*uMsg*/, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	/*if (wParam != SIZE_MINIMIZED && lParam != 0) {
		if (m_edVolume) {
			CRect rcClient;
			GetClientRect(&rcClient);
			m_btnSell.MoveWindow(rcClient.left, rcClient.top, rcClient.Width()/2, rcClient.Height());
			m_btnBuy.MoveWindow(rcClient.right-rcClient.Width()/2, rcClient.top, rcClient.Width()/2, rcClient.Height());
			m_btnPlus.MoveWindow(rcClient.left+50, rcClient.top, 25, 25);
			m_btnMinus.MoveWindow(rcClient.right-50-25, rcClient.top, 25, 25);
			m_edVolume.MoveWindow(rcClient.left+50+25, rcClient.top, rcClient.Width()-(50+25)-(50+25), 25);
		}
	}*/
	return bHandled;
}

void QMiniTradeView::OnDispInfoChanged()
{
	Invalidate();
}

void QMiniTradeView::OnViewInfoChanged()
{
	Invalidate();
}

