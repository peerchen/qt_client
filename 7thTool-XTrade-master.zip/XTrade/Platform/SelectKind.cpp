#include "stdafx.h"
#include "SelectKind.h"

