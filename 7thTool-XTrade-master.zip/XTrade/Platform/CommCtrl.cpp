#include "stdafx.h"
#include "CommCtrl.h"

TradeButton::TradeButton()
{
	m_strValue;
	m_crText = 0;
	m_crBackgnd = 0;
	m_hValue = NULL;
}

void TradeButton::SetWindowText(LPCTSTR lpszTitle, LPCTSTR lpszValue)
{
	Base::SetWindowText(lpszTitle);
	m_strValue = lpszValue;
}

void TradeButton::SetColor(COLORREF crText, COLORREF crBackgnd)
{
	m_crText = crText;
	m_crBackgnd = crBackgnd;
}

void TradeButton::SetFont(HFONT hFont, HFONT hValue, BOOL bRedraw)
{
	Base::SetFont(hFont,bRedraw);
	m_hValue = hValue;
}

BOOL TradeButton::OnEraseBkgnd(HDC hdc)
{
	return TRUE;
}

void TradeButton::OnPaint(HDC hdc)
{
	CDCHandle dc(hdc);
	
	RECT rcClient;
	GetClientRect(&rcClient);

	CRect rcUp = rcClient;
	rcUp.bottom = rcUp.top + rcUp.Height()/3;
	CRect rcDown = rcClient;
	rcDown.top = rcUp.bottom;
	UIgdi::FillGradient(dc, &rcUp, m_crBackgnd-10, m_crBackgnd);
	UIgdi::FillGradient(dc, &rcDown, m_crBackgnd, m_crBackgnd-20);

	UIgdi::DrawText(dc, m_strValue, m_strValue.GetLength(), rcUp, DT_CENTER|DT_VCENTER|DT_SINGLELINE, m_crText, m_hValue);

	UIgdi::DrawLine(dc, rcDown.TopLeft(), rcUp.BottomRight(), PS_SOLID, 2, m_crBackgnd, R2_COPYPEN);

	CString strText;
	GetWindowText(strText);
	UIgdi::DrawText(dc, strText, strText.GetLength(), rcDown, DT_CENTER|DT_VCENTER|DT_SINGLELINE, m_crText);
}

//////////////////////////////////////////////////////////////////////////
///MyTabCtrl

void MyTabCtrl::Draw(HDC hdc)
{
	if (!m_DispInfoPtr) {
		return;
	}

	CDCHandle dc(hdc);

	DWORD dwStyle = GetStyle();
	DWORD dwExStyle = GetExStyle();
	DWORD dwTextFlags = GetTextFlags();

	HIMAGELIST hImageList = GetImageList();
	int nCount	= GetItemCount();
	int nFocus	= GetCurFocus();
	int nCurSel = GetCurSel();

	//SIZE szItem = {0};
	//SIZE szPadding = {0};
	//GetItemSize(&szItem);
	//GetPadding(&szPadding);

	RECT rcClient = {0};
	GetClientRect(&rcClient);
	UIgdi::FillSolidRect(hdc, &rcClient, m_DispInfoPtr->crBackgnd);

	/*if(dwStyle & TCS_VERTICAL) {

	} else {
		if (dwStyle & TCS_BOTTOM) {
			UIgdi::DrawLine(hdc, rcClient.left, rcClient.top, rcClient.right, rcClient.top, 1, m_DispInfoPtr->crXYLine);
		}
	}*/
	while (nCount--) {
		TCHAR szText[MAX_PATH] = {0};
		int nText = 0;
		TCITEM tcItem = {0};
		tcItem.mask = TCIF_IMAGE|TCIF_STATE|TCIF_TEXT;
		tcItem.pszText = szText;
		tcItem.cchTextMax = MAX_PATH;
		GetItem(nCount, &tcItem);
		nText = _tcslen(szText);
		RECT rcItem;
		GetItemRect(nCount, &rcItem);
		if (RectVisible(hdc, &rcItem)) {
			CRect rc = rcItem;
			COLORREF crText = nCount==nCurSel?m_DispInfoPtr->crTabSel:m_DispInfoPtr->crTitle;
			HFONT hText = m_DispInfoPtr->hTabTitle;
			if (nCount == nCurSel) {
				UIgdi::FillSolidRect(hdc, &rc, m_DispInfoPtr->crTabSelBackgnd);
			}
			if(dwStyle & TCS_VERTICAL) {
				rc.DeflateRect(0, m_szPadding.cx, 0, m_szPadding.cx);
				UIgdi::DrawText(dc, szText, nText, &rc, dwTextFlags, crText, hText, m_szPadding.cy);
				UIgdi::DrawLine(hdc, rcItem.left, rcItem.bottom, rcItem.right, rcItem.bottom, PS_SOLID, 1, m_DispInfoPtr->crXYLine, R2_COPYPEN);
			} else {
				rc.DeflateRect(m_szPadding.cy, 0, m_szPadding.cy, 0);
				if (dwStyle&TCS_FORCELABELLEFT) {
					rc.right = rc.left + nText*m_szItem.cx;
					UIgdi::DrawText(dc, szText, nText, &rc, dwTextFlags, crText, hText);
					if (hImageList && tcItem.iImage>=0) {
						rc.left = rc.right + m_szPadding.cx;
						rc.right = rcItem.right - m_szPadding.cy;
						//
					} 
				} else {
					if (hImageList && tcItem.iImage>=0) {
						rc.right = rc.right - nText*m_szItem.cx;
						//

						rc.left = rc.right + m_szPadding.cx;
						rc.right = rcItem.right - m_szPadding.cy;
					} 
					UIgdi::DrawText(dc, szText, nText, &rc, dwTextFlags, crText, hText);
				}
				UIgdi::DrawLine(hdc, rcItem.right, rcItem.top, rcItem.right, rcItem.bottom, PS_SOLID, 1, m_DispInfoPtr->crXYLine, R2_COPYPEN);
			}
		}
	}

	//UIgdi::DrawText(hdc, GetWndClassName(), _tcslen(GetWndClassName()), &rcClient, DT_LEFT|DT_VCENTER|DT_SINGLELINE, RGB(255,255,255));
}

////////////////////////////////////////////////////////////////////////////
/////MyHeaderCtrl
//
//void MyHeaderCtrl::Draw(HDC hdc)
//{
//	if (!m_DispInfoPtr) {
//		return;
//	}
//
//	CDCHandle dc(hdc);
//
//	DWORD dwStyle = GetStyle();
//	DWORD dwExStyle = GetExStyle();
//	//DWORD dwTextFlags = GetTextFlags();
//
//	HIMAGELIST hImageList = GetImageList();
//
//	RECT rcClient = {0};
//	GetClientRect(&rcClient);
//	UIgdi::FillSolidRect(hdc, &rcClient, m_DispInfoPtr->crBackgnd);
//}
//
////////////////////////////////////////////////////////////////////////////
/////MyScrollBar
//
//void MyScrollBar::Draw(HDC hdc)
//{
//	if (!m_DispInfoPtr) {
//		return;
//	}
//
//	CDCHandle dc(hdc);
//
//	DWORD dwStyle = GetStyle();
//}
//
////////////////////////////////////////////////////////////////////////////
/////MyListCtrl
//
//BOOL  MyListCtrl::PreCreateWindow(CREATESTRUCT& cs)
//{
//	RECT rcWnd = {cs.x, cs.y, cs.x+cs.cx, cs.y+cs.cy};
//	m_wndHeader.Create(m_hWnd, rcWnd, NULL, WS_CHILD|WS_VISIBLE);
//
//	return Base::PreCreateWindow(cs);
//}

//////////////////////////////////////////////////////////////////////////
///MyHeaderCtrl

MyHeaderCtrl::MyHeaderCtrl()
{
	
}

MyHeaderCtrl::~MyHeaderCtrl()
{

}

void MyHeaderCtrl::DrawItem( LPDRAWITEMSTRUCT lpDrawItemStruct )
{
	/*// attath to the device context.
	CDC dc;
	VERIFY( dc.Attach( lpDrawItemStruct->hDC ) );

	// save the device context.
	const int iSavedDC = dc.SaveDC();

	// get the column rect.
	CRect rc( lpDrawItemStruct->rcItem );

	// set the clipping region to limit drawing within the column.
	CRgn rgn;
	VERIFY( rgn.CreateRectRgnIndirect( &rc ) );
	(void)dc.SelectObject( &rgn );
	VERIFY( rgn.DeleteObject() );

	// draw the background,
	CBrush brush( GetSysColor( COLOR_3DFACE ) );
	dc.FillRect( rc, &brush );

	// get the column text and format.
	TCHAR szText[ 256 ]={0};
	HD_ITEM hditem;

	hditem.mask = HDI_TEXT | HDI_FORMAT;
	hditem.pszText = szText;
	hditem.cchTextMax = 255;

	VERIFY( GetItem( lpDrawItemStruct->itemID, &hditem ) );

	// determine the format for drawing the column label.
	UINT uFormat = DT_SINGLELINE | DT_NOPREFIX | DT_NOCLIP | DT_VCENTER | DT_END_ELLIPSIS ;

	if( hditem.fmt & HDF_CENTER)
		uFormat |= DT_CENTER;
	else if( hditem.fmt & HDF_RIGHT)
		uFormat |= DT_RIGHT;
	else
		uFormat |= DT_LEFT;

	// adjust the rect if the mouse button is pressed on it.
	if( lpDrawItemStruct->itemState == ODS_SELECTED )
	{
		rc.left++;
		rc.top += 2;
		rc.right++;
	}

	CRect rcIcon( lpDrawItemStruct->rcItem );
	const int iOffset = ( rcIcon.bottom - rcIcon.top ) / 4;

	// adjust the rect further if the sort arrow is to be displayed.
	if( lpDrawItemStruct->itemID == (UINT)m_iSortCol )
		rc.right -= 3 * iOffset;

	rc.left += iOffset;
	rc.right -= iOffset;

	// draw the column label.
	if( rc.left < rc.right )
		(void)dc.DrawText( szText, lstrlen(szText), rc, uFormat );

	// draw the sort arrow.
	if( lpDrawItemStruct->itemID == (UINT)m_iSortCol )
	{
		CSize sizeTxt = dc.GetTextExtent(szText, lstrlen(szText));

		if( hditem.fmt & HDF_RIGHT)
		{
			rcIcon.left = rc.right+4;
			rcIcon.right =rcIcon.left+iOffset;
		}
		else
		{
			rcIcon.left = rc.left + sizeTxt.cx + iOffset;
			rcIcon.right= rcIcon.left + iOffset;
		}


		CPoint ptCenter = rcIcon.CenterPoint();
		CPen  penLine(PS_SOLID,1, RGB(153,153,153));
		CPen * pOldPen = dc.SelectObject(&penLine);
		CBrush brLine(RGB(153,153,153));
		CBrush* pOldBr = dc.SelectObject(&brLine);
		if (m_bSortAsc)
		{
			POINT pt[4]=
			{
				{ptCenter.x, ptCenter.y},
				{ptCenter.x-4, ptCenter.y+4},
				{ptCenter.x+4, ptCenter.y+4},
				{ptCenter.x, ptCenter.y}
			};
			dc.Polygon(pt,4);
		}
		else
		{
			POINT pt[4]=
			{
				{ptCenter.x-4, ptCenter.y},
				{ptCenter.x, ptCenter.y+4},
				{ptCenter.x+4,ptCenter.y},
				{ptCenter.x-4, ptCenter.y}
			};
			dc.Polygon(pt,4);
		}

		dc.SelectObject(pOldPen);
		dc.SelectObject(pOldBr);
		penLine.DeleteObject();
		brLine.DeleteObject();
	}

	// restore the previous device context.
	VERIFY( dc.RestoreDC( iSavedDC ) );

	// detach the device context before returning.
	dc.Detach();*/
}
/*
void MyHeaderCtrl::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	CRect rcClient;
	GetClientRect( &rcClient );

	CDC memDC;
	CBitmap bitmap;
	memDC.CreateCompatibleDC(&dc);
	bitmap.CreateCompatibleBitmap(&dc, rcClient.Width(), rcClient.Height());
	CBitmap* pOldBitmap = memDC.SelectObject(&bitmap);
	memDC.FillSolidRect(rcClient, GetSysColor( COLOR_BTNFACE ));

	// First let the control do its default drawing.
	CWnd::DefWindowProc( WM_PAINT, (WPARAM)memDC.m_hDC, 0 );

	DrawFlatBorder(&memDC);

	dc.BitBlt( rcClient.left, rcClient.top, rcClient.Width(), rcClient.Height(), &memDC, 
		rcClient.left, rcClient.top, SRCCOPY );

	memDC.SelectObject(pOldBitmap);
	memDC.DeleteDC();
	bitmap.DeleteObject();
}

BOOL MyHeaderCtrl::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;
}

void MyHeaderCtrl::DrawFlatBorder(CDC* pDC)
{
	CRect rci;
	GetWindowRect(&rci);
	ScreenToClient(&rci);

	// Cover up thick 3D border.
	pDC->Draw3dRect(rci, GetSysColor( COLOR_BTNFACE ), GetSysColor( COLOR_BTNFACE ));
	rci.DeflateRect(1,1);
	pDC->Draw3dRect(rci, GetSysColor( COLOR_BTNFACE ), GetSysColor( COLOR_BTNFACE ));

	// Draw flat style border around entire header.
	rci.InflateRect(1,1);
	pDC->Draw3dRect(rci, GetSysColor( COLOR_BTNHILIGHT ), GetSysColor( COLOR_BTNSHADOW ));

	// Create the pens for further cover-up.
	CPen penLite(PS_SOLID, 1, GetSysColor( COLOR_BTNHILIGHT ));
	CPen penShad(PS_SOLID, 1, GetSysColor( COLOR_BTNSHADOW ));
	CPen penFace(PS_SOLID, 1, GetSysColor( COLOR_BTNFACE ));
	CPen *pOldPen = pDC->SelectObject( &penLite );

	// Set up the header item struct.
	HD_ITEM hdi;
	memset (&hdi, 0, sizeof(HD_ITEM));
	hdi.fmt  = HDF_STRING | HDF_LEFT | HDF_OWNERDRAW;
	hdi.mask = HDI_WIDTH | HDI_TEXT | HDI_FORMAT | HDI_ORDER; 
	int cx = 0;

	long j = GetItemCount();    
	long i = 0;                 

	long * ItemOrders = new long[j];    
	for( i=0; i<j; i++ ) 
	{			
		GetItem(i, &hdi);				
		ItemOrders[hdi.iOrder] = i;    
	}

	hdi.fmt  = HDF_STRING | HDF_LEFT | HDF_OWNERDRAW;   
	hdi.mask = HDI_WIDTH | HDI_TEXT | HDI_FORMAT;      

	// For each header item found, do further cover up.
	for (i = 0; i < j; ++i)
	{
		GetItem( ItemOrders[i], &hdi);
		cx += hdi.cxy;

		pDC->SelectObject(&penShad);
		pDC->MoveTo(cx, 2);
		pDC->LineTo(cx, rci.bottom-2);

		pDC->SelectObject(&penLite);
		pDC->MoveTo(cx+1, 2);
		pDC->LineTo(cx+1, rci.bottom-2);

		pDC->SelectObject(&penFace);
		pDC->MoveTo(cx-1, 2);
		pDC->LineTo(cx-1, rci.bottom-2);

		pDC->SelectObject(&penFace);
		pDC->MoveTo(cx-2, 2);
		pDC->LineTo(cx-2, rci.bottom-2);
	}

	delete [] ItemOrders; 

	pDC->SelectObject( pOldPen );

	penLite.DeleteObject();
	penShad.DeleteObject();
	penFace.DeleteObject();
}*/

//////////////////////////////////////////////////////////////////////////
///MyListCtrl

void MyListCtrl::MeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct)
{

}

void MyListCtrl::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct)
{

}

