#include "stdafx.h"
#include "Platform.h"
#include "Container.h"

//////////////////////////////////////////////////////////////////////////
//���ﶨһ�´����߼���
//1������ʱ����������ʾ��Ϣ���������ض�������Ϣ��������Refresh�¼�������ˢ�����ݣ�
//2�����ú�����ˢ���߼������������Ӷ������������Ϳ������Ӷ�������֮����ȫ�ִ����������ռ��Ӷ�����ʾ������Ҫ���ٸ���Ʒ��
//3���������ػ��ˡ�

#define ID_TIMER_LOADDATA	100

//////////////////////////////////////////////////////////////////////////
///QContainer

IMPLEMENT_DYNCREATE_WND_OBJECTER(QContainer,Objecter)

QContainer::QContainer()
{
	m_bEdit = TRUE;
	m_bLoading = FALSE;

	m_ViewInfoPtr = new ViewInfo();
	m_ViewDispInfoPtr = new ViewDispInfo();
}

QContainer::~QContainer()
{

}
/*
HWND QContainer::Create(HWND hWndParent, RECT& rcPos
			, LPCTSTR szWindowName, DWORD dwStyle, DWORD dwExStyle, UINT nID, LPVOID lpCreateParam)
{
	return Base::Create(hWndParent, rcPos, szWindowName, dwStyle | WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | WS_CLIPCHILDREN, dwExStyle, nID, lpCreateParam);
}

HWND QContainer::Create(HWND hWndParent, LPCTSTR lpszXml, UINT XmlFlag)
{
	return Base::Create(hWndParent, lpszXml, XmlFlag);
}

BOOL QContainer::PreCreateWindow(CREATESTRUCT& cs)
{
	SetWindowLong(GWL_USERDATA, (LONG)dynamic_cast<WndObjecter*>(this));

	return Base::PreCreateWindow(cs);
}
*/
/*HWND QContainer::CreateControl(HWND hWndParent, LPCTSTR lpszWndClass, LPCTSTR lpszCtrlName, UINT nID, LPCTSTR lpszXml, UINT XmlFlag)
{
	if (_tcsicmp(lpszWndClass, Pane::GetXmlPaneName()) != 0) {
		HWND hWndCtrl = MultiViewerMap::CreateObjecter(lpszWndClass, lpszCtrlName, hWndParent, lpszXml, XmlFlag);
		OnCreateControl(hWndParent, hWndCtrl, lpszWndClass, lpszCtrlName, nID);
		return hWndCtrl;
	}
	return ViewSplitter::CreateControl(hWndParent, lpszWndClass, lpszCtrlName, nID, lpszXml, XmlFlag);
}*/

/*void QContainer::OnCreateControl(HWND hWndParent, HWND hWndCtrl, LPCTSTR lpszWndClass, LPCTSTR lpszCtrlName, UINT nID)
{
	PaneSplitter::OnCreateControl(hWndParent, hWndCtrl, lpszWndClass, lpszCtrlName, nID);
}

void QContainer::OnCloseControl(HWND hWndCtrl, LPCTSTR lpszWndClass, LPCTSTR lpszCtrlName)
{
	PaneSplitter::OnCloseControl(hWndCtrl, lpszWndClass, lpszCtrlName);
}*/

void QContainer::SaveLayout()
{
	TCHAR szPath[MAX_PATH] = {0};
	_tmakepath(szPath, NULL, _Module.GetAppData(), GetWndClassName(), _T(".xml"));
	File::RemoveFile(szPath);
	Format(szPath);
}

BOOL QContainer::GetLayoutRect(LPRECT lpRect)
{
	return ViewSplitter::GetLayoutRect(lpRect);
}

void QContainer::Relayout(LPCRECT lpRect)
{
	return ViewSplitter::Relayout(lpRect);
}

BOOL QContainer::PreTranslateMessage(MSG* pMsg)
{//���ﲻҪ����SendMessage����PostMessage��ת����Ϣ����Ҫ��ǰ��������Ϣ����ȷ���ö�Ӧ�ĺ�����������ȷ����������TRUE�����򷵻�FALSE
	return FALSE;
	BOOL bHandled = FALSE;
	switch(pMsg->message)
	{
	case WM_KEYDOWN:
		{
			//OnKeyDown(pMsg->message, pMsg->wParam, pMsg->lParam, bHandled);
		}
		break;
	default:
		break;
	}
	return bHandled;
}

LRESULT QContainer::OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	bHandled = FALSE;

	return bHandled;
}

LRESULT QContainer::OnContextMenu(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	bHandled = m_bEdit;
	POINT pt = {GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam)};
	if (m_bEdit) {
		POINT ptClient = pt;
		ScreenToClient(&ptClient);

		m_pP1 = PaneFromPoint(ptClient);
		if (m_pP1) {
			m_pP2 = m_pP1->Next();
		} else {
			m_pP2 = NULL;
		}

		CMenu menu;
		menu.LoadMenu(IDR_MENU_EDIT);
		CMenuHandle subMenu = menu.GetSubMenu(0);
		if (subMenu)
		{
			unsigned long Style = m_pP1->GetStyle();
			subMenu.CheckMenuItem(ID_EDIT_PANE_LR_SCALE, Style&PANEL_STYLE_LR_SCALE?MF_CHECKED:MF_UNCHECKED);
			subMenu.CheckMenuItem(ID_EDIT_PANE_TB_SCALE, Style&PANEL_STYLE_TB_SCALE?MF_CHECKED:MF_UNCHECKED);
			subMenu.CheckMenuItem(ID_EDIT_PANE_L_SIZED, Style&PANEL_STYLE_L_SIZED?MF_CHECKED:MF_UNCHECKED);
			subMenu.CheckMenuItem(ID_EDIT_PANE_R_SIZED, Style&PANEL_STYLE_R_SIZED?MF_CHECKED:MF_UNCHECKED);
			subMenu.CheckMenuItem(ID_EDIT_PANE_T_SIZED, Style&PANEL_STYLE_T_SIZED?MF_CHECKED:MF_UNCHECKED);
			subMenu.CheckMenuItem(ID_EDIT_PANE_B_SIZED, Style&PANEL_STYLE_B_SIZED?MF_CHECKED:MF_UNCHECKED);
			return subMenu.TrackPopupMenu(0, pt.x, pt.y, m_hWnd, NULL);
		}
	} else {
		HWND hChild = ChildWindowFromPointEx(pt, CWP_SKIPINVISIBLE);

		WndObjecter* pWndObjecter = GetObjecterBy(hChild);
		if (pWndObjecter) {
			//pWndObjecter->
		}
	}
	return bHandled;
}

LRESULT QContainer::OnCommand(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	WORD wNotifyCode = HIWORD(wParam); 
	WORD wID = LOWORD(wParam); 
	HWND hwndCtrl = (HWND)lParam;
	/*if (hwndCtrl) {
		switch(wNotifyCode) 
		{
		case EN_UPDATE:
		case STN_DBLCLK:
		default:
			bHandled = FALSE;
			break;
		}
	} else */{
		switch(wID)
		{
		case ID_EDIT_PANE_START_STOP:
			if (m_bEdit) {
				SaveLayout();
			}
			m_bEdit = !m_bEdit;
			break;
		case ID_EDIT_PANE_INSERTLR_2:
			{
				RemoveChilds(m_pP1);
				m_pP1->SetStyle((m_pP1->GetStyle()&~PANEL_STYLE_TB)|PANEL_STYLE_LR);
				InsertChilds(m_pP1, 2);
			}
			break;
		case ID_EDIT_PANE_INSERTLR_3:
			{
				RemoveChilds(m_pP1);
				m_pP1->SetStyle((m_pP1->GetStyle()&~PANEL_STYLE_TB)|PANEL_STYLE_LR);
				InsertChilds(m_pP1, 3);
			}
			break;
		case ID_EDIT_PANE_INSERTLR_4:
			{

			}
			break;
		case ID_EDIT_PANE_INSERTTB_2:
			{
				RemoveChilds(m_pP1);
				m_pP1->SetStyle((m_pP1->GetStyle()&~PANEL_STYLE_LR)|PANEL_STYLE_TB);
				InsertChilds(m_pP1, 2);
			}
			break;
		case ID_EDIT_PANE_INSERTTB_3:
			{
				RemoveChilds(m_pP1);
				m_pP1->SetStyle((m_pP1->GetStyle()&~PANEL_STYLE_LR)|PANEL_STYLE_TB);
				InsertChilds(m_pP1, 3);
			}
			break;
		case ID_EDIT_PANE_INSERTTB_4:
			{

			}
			break;
		case ID_EDIT_PANE_DELETE:
			{
				SendMessage(WM_COMMAND, ID_PANE_CLOSE, (LPARAM)m_pP1);
			}
			break;
		case ID_EDIT_PANE_LR_SCALE:
			{
				unsigned long Style = m_pP1->GetStyle();
				if (Style & PANEL_STYLE_LR_SCALE) {
					Style &= ~PANEL_STYLE_LR_SCALE;
				} else {
					Style |= PANEL_STYLE_LR_SCALE;
				}
				m_pP1->SetStyle(Style);
			}
			break;
		case ID_EDIT_PANE_TB_SCALE:
			{
				unsigned long Style = m_pP1->GetStyle();
				if (Style & PANEL_STYLE_TB_SCALE) {
					Style &= ~PANEL_STYLE_TB_SCALE;
				} else {
					Style |= PANEL_STYLE_TB_SCALE;
				}
				m_pP1->SetStyle(Style);
			}
			break;
		case ID_EDIT_PANE_L_SIZED:
			{
				unsigned long Style = m_pP1->GetStyle();
				if (Style & PANEL_STYLE_L_SIZED) {
					Style &= ~PANEL_STYLE_L_SIZED;
				} else {
					Style |= PANEL_STYLE_L_SIZED;
				}
				m_pP1->SetStyle(Style);
			}
			break;
		case ID_EDIT_PANE_R_SIZED:
			{
				unsigned long Style = m_pP1->GetStyle();
				if (Style & PANEL_STYLE_R_SIZED) {
					Style &= ~PANEL_STYLE_R_SIZED;
				} else {
					Style |= PANEL_STYLE_R_SIZED;
				}
				m_pP1->SetStyle(Style);
			}
			break;
		case ID_EDIT_PANE_T_SIZED:
			{
				unsigned long Style = m_pP1->GetStyle();
				if (Style & PANEL_STYLE_T_SIZED) {
					Style &= ~PANEL_STYLE_T_SIZED;
				} else {
					Style |= PANEL_STYLE_T_SIZED;
				}
				m_pP1->SetStyle(Style);
			}
			break;
		case ID_EDIT_PANE_B_SIZED:
			{
				unsigned long Style = m_pP1->GetStyle();
				if (Style & PANEL_STYLE_B_SIZED) {
					Style &= ~PANEL_STYLE_B_SIZED;
				} else {
					Style |= PANEL_STYLE_B_SIZED;
				}
				m_pP1->SetStyle(Style);
			}
			break;
		case ID_EDIT_VIEW_DEBUG:
			{
				//����PANE
				ViewSplitter::OnCreateControl(m_hWnd, (HWND)m_pP1, m_pP1->GetXmlPaneName(), _T("Report"), 0);
				//���Ӳ��󶨴���
				HWND hWndCtrl = ViewSplitter::CreateObjecter(_T("Report"), _T("Report"), m_hWnd, _T("<Report style=\"0x56000000\"></Report>"), XML_FLAG_STREAM);
				ViewSplitter::OnCreateControl(m_hWnd, hWndCtrl, _T("Report"), _T("Report"), 0);
				/*WndObjecter* pView = NULL;
				HWND hView = CreateObject(pView, _T("Report"), m_hWnd, _T("<Report style=\"0x56000000\"></Report>"), XML_FLAG_STREAM);
				if (!hView) {
					DestroyObject(pView);
				} else {
					m_Name2pObject[_T("Report")] = pView;
					ViewSplitter::OnCreateControl(m_hWnd, hView, pView->GetThisClassName(), _T("Report"), 0);
				}*/
			}
			break;
		case ID_EDIT_VIEW_GROUP:
			{

			}
			break;
		case ID_EDIT_VIEW_GROUP1:
			{

			}
			break;
		case ID_EDIT_VIEW_GROUP2:
			{

			}
			break;
		case ID_EDIT_VIEW_GROUP3:
			{

			}
			break;
		case ID_EDIT_VIEW_GROUP4:
			{

			}
			break;
		//////////////////////////////////////////////////////////////////////////
		default:
			bHandled = FALSE;
			break;
		}
		if (bHandled) {
			Invalidate();
		}
	}
	return bHandled;
}

LRESULT QContainer::OnTimer(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	switch (wParam)
	{
	case ID_TIMER_LOADDATA:
		{
			m_bLoading = FALSE;
			KillTimer(ID_TIMER_LOADDATA);

			LoadData();
			RequestData();
			RequestPush();
		}
		break;
	default:
		bHandled = FALSE;
		break;
	}
	return 0L;
}

void QContainer::OnDispInfoChanged()
{
	BroadcastSend(EVT_PLAT_CALL, MAKEVALUE(MSET_PLAT_OBJECT,CSET_OBJECT_DISPINFO), m_DispInfoPtr);
}

void QContainer::OnInfoChanged()
{
	const KindInfo& Kind = GetCurKind();
	SetWindowText(Kind.GetName());

	m_ViewInfoPtr->InfoPtr = m_InfoPtr;
	Reload();
}

void QContainer::UpdateViewInfo()
{
	//������ͼ��Ϣ
	BroadcastSend(EVT_PLAT_CALL, MAKEVALUE(MSET_PLAT_OBJECT,CSET_VIEW_INFO), m_ViewInfoPtr);
}

void QContainer::UpdateViewDispInfo()
{
	BroadcastSend(EVT_PLAT_CALL, MAKEVALUE(MSET_PLAT_OBJECT,CSET_VIEW_DISPINFO), m_ViewDispInfoPtr);
}

bool QContainer::IsLoading()
{
	return m_bLoading?true:false;
}

void QContainer::Reload()
{
	Reset();
#if 1
	m_bLoading = TRUE;
	UINT nIDEvent = SetTimer(ID_TIMER_LOADDATA,100);
#else
	LoadData();
	RequestData();
	RequestPush();
#endif//
}

void QContainer::Reset()
{
	UpdateViewInfo();
	UpdateViewDispInfo();
}

void QContainer::LoadData()
{
	BroadcastSend(EVT_PLAT_CALL, MAKEVALUE(MCALL_PLAT_OBJECT,CCALL_OBJECT_REFRESH), NULL);
}

void QContainer::RequestData()
{
	
}

void QContainer::RequestPush()
{
	SendEvent(_FramePtr, EVT_PLAT_CALL, MAKEVALUE(MCALL_PLAT_FRAME,CCALL_FRAME_REQPUSH), 0);
}

long QContainer::OnPost(Event& evt)
{
	switch(evt.value)
	{
	default:
		evt.handled = false;
		break;
	}
	return RLT_UNKNOWN;
}

long QContainer::OnCall(Event& evt)
{
	switch(evt.value)
	{
	//////////////////////////////////////////////////////////////////////////
	default:
		evt.handled = false;
		break;
	}
	return RLT_UNKNOWN;
}

long QContainer::OnNotify(Event& evt)
{
	switch(evt.value)
	{
	default:
		evt.handled = false;
		break;
	}
	return RLT_UNKNOWN;
}

//////////////////////////////////////////////////////////////////////////
///QTabContainer

IMPLEMENT_DYNCREATE_WND_OBJECTER(QTabContainer,Objecter)

QTabContainer::QTabContainer()
{
	m_bEdit = FALSE;
}

BOOL QTabContainer::GetLayoutRect(LPRECT lpRect)
{
	BOOL bRet = GetClientRect(lpRect);
	if (m_DispInfoPtr) {
		lpRect->left += m_DispInfoPtr->xyTabCtrl.cx  + GetHBorder();
	}
	return bRet;
}

void QTabContainer::Relayout(LPCRECT lpRect)
{
	Base::Relayout(lpRect);
	if (m_DispInfoPtr) {
		if (m_wndTabCtrl.m_hWnd) {
			RECT rcClient;
			GetClientRect(&rcClient);
			m_wndTabCtrl.MoveWindow(rcClient.left, rcClient.top
				, m_DispInfoPtr->xyTabCtrl.cx, rcClient.bottom-rcClient.top);
		}
	}
}

LRESULT QTabContainer::OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	LRESULT Res = Base::OnCreate(uMsg, wParam, lParam, bHandled);
	//LRESULT Res = DefWindowProc();

	if (!m_wndTabCtrl.m_hWnd) {
		m_wndTabCtrl.Create(m_hWnd, rcDefault, NULL, WS_CHILD|WS_VISIBLE|TCS_VERTICAL);
	}
	m_wndTabCtrl.AddItem(_T("���鱨��"));
	m_wndTabCtrl.AddItem(_T("���׷���"));
	m_wndTabCtrl.AddItem(_T("����ָ��"));
	m_wndTabCtrl.AddItem(_T("��������"));

	bHandled = TRUE;
	return Res;
}

LRESULT QTabContainer::OnDestroy(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& bHandled)
{
	bHandled = FALSE;

	return bHandled;
}

void QTabContainer::OnDispInfoChanged()
{
	Base::OnDispInfoChanged();

	m_wndTabCtrl.SetItemSize(m_DispInfoPtr->xyTabCtrl.cx, m_DispInfoPtr->xyTabTitle.cy);
	SIZE szPadding = {m_DispInfoPtr->xyTabTitle.cy/2, 1};
	m_wndTabCtrl.SetPadding(szPadding);

	SendEvent(&m_wndTabCtrl, EVT_PLAT_CALL, MAKEVALUE(MSET_PLAT_OBJECT,CSET_OBJECT_DISPINFO), m_DispInfoPtr);

	CRect rcLayout;
	GetLayoutRect(&rcLayout);
	if (rcLayout.Width() > 0 && rcLayout.Height() > 0) {
		Relayout(&rcLayout);
	}
}

//////////////////////////////////////////////////////////////////////////
///QRptContainer

IMPLEMENT_DYNCREATE_WND_OBJECTER(QRptContainer,Objecter)

QRptContainer::QRptContainer()
{
	
}

long QRptContainer::OnCall(Event& evt)
{
	switch(evt.value)
	{
	case MAKEVALUE(MGET_PLAT_OBJECT,CGET_OBJECT_PUSHINFO):
		{
			return RLT_OK;
		}
		break;
		//////////////////////////////////////////////////////////////////////////
	default:
		evt.handled = false;
		break;
	}
	return RLT_UNKNOWN;
}

//////////////////////////////////////////////////////////////////////////
///QScdtContainer

IMPLEMENT_DYNCREATE_WND_OBJECTER(QScdtContainer,Objecter)

QScdtContainer::QScdtContainer():Base()
{
	m_bEdit = FALSE;

	//GET
	m_FieldInfoPtr = new FIELDVALUEListInfo();

	//REQ
	m_ReqFieldPtr = new REQ_FIELDDATAInfo();

	//SET
}

BOOL QScdtContainer::PreTranslateMessage(MSG* pMsg)
{//���ﲻҪ����SendMessage����PostMessage��ת����Ϣ����Ҫ��ǰ��������Ϣ����ȷ���ö�Ӧ�ĺ�����������ȷ����������TRUE�����򷵻�FALSE
	BOOL bHandled = FALSE;
	if (m_InfoPtr->IsInteractive()) {
		switch(pMsg->message)
		{
		case WM_KEYDOWN:
			bHandled = TRUE;
			OnKeyDown(pMsg->message, pMsg->wParam, pMsg->lParam, bHandled);
			break;
		case WM_MOUSEWHEEL:
			bHandled = TRUE;
			OnMouse(pMsg->message, pMsg->wParam, pMsg->lParam, bHandled);
			break;
		default:
			break;
		}
	}
	return bHandled;
}

LRESULT QScdtContainer::OnKeyDown(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	int nVirtKey = (int)wParam; 
	LPARAM lKeyData = lParam;
	switch(nVirtKey)
	{
	case VK_HOME:
		PostMessage(WM_COMMAND, ID_CONTAINER_HOME);
		break;
	case VK_END:
		PostMessage(WM_COMMAND, ID_CONTAINER_END);
		break;
	case VK_PRIOR:
		PostMessage(WM_COMMAND, ID_CONTAINER_PAGEUP);
		break;
	case VK_NEXT:
		PostMessage(WM_COMMAND, ID_CONTAINER_PAGEDOWN);
		break;
	case VK_LEFT:
		PostMessage(WM_COMMAND, ID_CONTAINER_LEFT);
		break;
	case VK_RIGHT:
		PostMessage(WM_COMMAND, ID_CONTAINER_RIGHT);
		break;
	case VK_UP:
		PostMessage(WM_COMMAND, ID_CONTAINER_UP);
		break;
	case VK_DOWN:
		PostMessage(WM_COMMAND, ID_CONTAINER_DOWN);
		break;
	default:
		bHandled = FALSE;
		break;
	}
	return bHandled;
}

LRESULT QScdtContainer::OnMouse(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	switch(uMsg)
	{
	case WM_MOUSEWHEEL:
		{
			WORD fwKeys = LOWORD(wParam); 
			SHORT zDelta = HIWORD(wParam);
			WORD xPos = LOWORD(lParam); 
			WORD yPos = HIWORD(lParam);
			if(zDelta < 0)
			{
				PostMessage(WM_COMMAND, ID_CONTAINER_PAGEDOWN);
			}
			else
			{
				PostMessage(WM_COMMAND, ID_CONTAINER_PAGEUP);
			}
		}
		break;
	default:
		bHandled = FALSE;
		break;
	}
	return bHandled;
}

LRESULT QScdtContainer::OnCommand(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	WORD wNotifyCode = HIWORD(wParam); 
	WORD wID = LOWORD(wParam); 
	HWND hwndCtrl = (HWND)lParam;
	if (wID>=ID_CONTAINER_PERIOD && wID<=ID_CONTAINER_PERIOD_MAX) {
		ENUM_TIMEFRAMES Period = (ENUM_TIMEFRAMES)(wID - ID_CONTAINER_PERIOD);
		if (Period != m_ViewDispInfoPtr->Period) {
			m_ViewDispInfoPtr->Period = Period;
			switch(m_ViewDispInfoPtr->Period)
			{
			case CYC_ANYSEC:
				m_ViewDispInfoPtr->PeriodEx = 15;
				break;
			case CYC_ANYMIN:
				m_ViewDispInfoPtr->PeriodEx = 3;
				break;
			case CYC_ANYDAY:
				m_ViewDispInfoPtr->PeriodEx = 3;
				break;
			}
			UpdateViewDispInfo();
			ResetRequestHisData();
			if (!IsLoading()) {
				LoadData();
				RequestHisData();
			}
			
			CUpdateUIBase* pUpdateUI = dynamic_cast<CUpdateUIBase*>(_FramePtr);
			ASSERT(pUpdateUI);
			int i,j;
			const ViewDispInfoPtr& vDispInfoPtr = m_ViewDispInfoPtr;
			//DWORD dwState = pUpdateUI->UIGetState(ID_CONTAINER_PERIOD+vDispInfoPtr->Period);
			//if (dwState != TBSTATE_CHECKED)
			{
				for (i=0; i<CYC_MAX; i++)
				{
					if (i != vDispInfoPtr->Period) {
						pUpdateUI->UISetRadio(ID_CONTAINER_PERIOD+i, FALSE);
					} else {
						pUpdateUI->UISetRadio(ID_CONTAINER_PERIOD+vDispInfoPtr->Period, TRUE);
					}
				}
			}
		}
	} else if (wID>=ID_CONTAINER_DW && wID<=ID_CONTAINER_DW_MAX) {
		ENUM_DWTYPE DWType = (ENUM_DWTYPE)(wID - ID_CONTAINER_DW);
		if (DWType != m_ViewDispInfoPtr->DWType) {
			m_ViewDispInfoPtr->DWType = DWType;
			UpdateViewDispInfo();
			if (!IsLoading()) {
				LoadData();
			}
		}
	} else {
		BOOL bToTechView = FALSE;
		switch(wID)
		{
		case ID_COMMAND_BACK:
			break;
		case ID_CONTAINER_HOME:
		case ID_CONTAINER_END:
		case ID_CONTAINER_LEFT:
		case ID_CONTAINER_RIGHT:
		case ID_CONTAINER_UP:
		case ID_CONTAINER_DOWN:
			bToTechView = TRUE;
			break;
		case ID_CONTAINER_PAGEUP:
			SetCurCommodityPos(GetCurCommodityPos()-1);
			break;
		case ID_CONTAINER_PAGEDOWN:
			SetCurCommodityPos(GetCurCommodityPos()+1);
			break;
		case ID_CONTAINER_ORDER_BUY:
		case ID_CONTAINER_ORDER_SELL:
		case ID_CONTAINER_ORDER_SEND_LIMIT:
		case ID_CONTAINER_ORDER_SEND_STOP:
		case ID_CONTAINER_ORDER_CLOSE:
			bToTechView = TRUE;
			break;
		default:
			if (wID>=ID_TECHVIEW && wID<=ID_TECHVIEW_MAX) {
				bToTechView = TRUE;
			} else {
				bHandled = FALSE;
			}
			break;
		}
		if (bToTechView) {
			WndObjecter* pTechView = GetObjecterBy(_T("TechView"));
			if (pTechView) {
				UIWnd2 wndTechView = pTechView->GetThisHwnd();
				wndTechView.SendMessage(uMsg, wParam, lParam);
			}
		}
	}
	

	return bHandled;
}

int QScdtContainer::SetCurCommodity(COMREF& Commodity)
{
	if (m_InfoPtr) {
		for (int i=0; i<m_InfoPtr->CommodityListPtr->CommodityList.size(); i++)
		{
			if (Commodity == m_InfoPtr->CommodityListPtr->CommodityList[i]) {
				m_InfoPtr->CurCommodityPos = i;
				Reload();
				return i;
			}
		}
	}
	return RLT_UNKNOWN;
}

int QScdtContainer::SetCurCommodityPos(int Pos)
{
	if (m_InfoPtr) {
		if (Pos < 0) {
			Pos = m_InfoPtr->CommodityListPtr->CommodityList.size() - 1;
		} else if (Pos >= m_InfoPtr->CommodityListPtr->CommodityList.size()) {
			Pos = 0;
		}
		if (Pos >= 0 && Pos < m_InfoPtr->CommodityListPtr->CommodityList.size()) {
			m_InfoPtr->CurCommodityPos = Pos;
			Reload();
			return Pos;
		}
	}
	return -1;
}

void QScdtContainer::Reload()
{
	if (m_ViewDispInfoPtr->Period >= CYC_MAX) {
		m_ViewDispInfoPtr->Period = CYC_DAY;
	}
	if (m_ViewDispInfoPtr->DWType >= DW_MAX) {
		m_ViewDispInfoPtr->DWType = DW_FORWARD;
	}
	Base::Reload();
}

void QScdtContainer::Reset()
{
	COMREF Commodity;
	GetCurCommodity(&Commodity);

	UpdateViewInfo();
	UpdateViewDispInfo();

	ResetRequestHisData();
	ResetRequestFieldData();

	CString strWindowText;
	strWindowText.Format(_T("%S %s"), Commodity.Code, Commodity.Name);
	SetWindowText(strWindowText);
}

void QScdtContainer::ResetRequestHisData()
{
	ScdtDataMap::ClearCalcData();
	//ScdtDataMap::ResetRequestHisData();
	m_ReqHisDataEvts.clear();

	//COMREF Commodity;
	//GetCurCommodity(&Commodity);
	//
	//m_ReqHisDataPtr->Commodity = Commodity;
	//m_ReqHisDataPtr->Period = m_ViewDispInfoPtr->Period;
	//m_ReqHisDataPtr->PeriodEx = m_ViewDispInfoPtr->PeriodEx;
}

void QScdtContainer::ResetRequestFieldData()
{
	//�Ƿ���֪ͨ�¼������¼�δ���,���ڿ�������Ҫ
	if (!m_ReqFieldEvts.empty()) {
		SendEvent(_DataPtr, EVT_PLAT_POST, MAKEVALUE(MREQUEST_PLAT_DE,CREQUEST_DE_CANCEL), m_ReqFieldPtr);
		m_ReqFieldEvts.clear();
	}

	COMREF Commodity;
	GetCurCommodity(&Commodity);

	m_ReqFieldPtr->uFlags = REQ_FIELD_FLAG_SOME;
	m_ReqFieldPtr->Commoditys.assign(1, Commodity);
}

void QScdtContainer::LoadData()
{
	BroadcastSend(EVT_PLAT_CALL, MAKEVALUE(MCALL_PLAT_OBJECT,CCALL_OBJECT_REFRESH), NULL);

	ScdtDataMap::ClearCalcData();
	COMREF Commodity;
	GetCurCommodity(&Commodity);
	ScdtDataMap::LoadCalcData(Commodity,m_ViewDispInfoPtr->Period,m_ViewDispInfoPtr->PeriodEx,m_ViewDispInfoPtr->DWType,m_ViewDispInfoPtr->DWDate);
}

void QScdtContainer::RequestData()
{
	RequestHisData();
	RequestFieldData();
}

void QScdtContainer::RequestHisData()
{
	int i=0;
	for(;i<m_ReqHisDataEvts.size();i++)
	{
		//
	}
	//COMREF Commodity;
	//GetCurCommodity(&Commodity);
	//ScdtDataMap::RequestHisData(Commodity,m_ViewDispInfoPtr->Period,m_ViewDispInfoPtr->PeriodEx);
}

void QScdtContainer::RequestFieldData()
{
	if (!m_ReqFieldEvts.empty()) {
		m_ReqFieldPtr->SetFinishRate(0);
		SendEvent(_DataPtr, EVT_PLAT_POST, MAKEVALUE(MREQUEST_PLAT_DE,CREQUEST_DE_FIELD_VALUE), m_ReqFieldPtr);
	}
}

void QScdtContainer::OnFieldDataChanged(Event& evt)
{
	BroadcastSend(evt);
}

void QScdtContainer::OnHisDataChanged(Event& evt)
{
	//����Ҫ������û��OnRefresh���յ�OnHisDataChanged�����������������������У���ֱ�ӷ��أ���Ϊ�����Refresh��
	if (IsLoading()) {
		return;
	}

	BroadcastSend(evt);

	ScdtDataMap::ClearCalcData();
	COMREF Commodity;
	GetCurCommodity(&Commodity);
	ScdtDataMap::LoadCalcData(Commodity,m_ViewDispInfoPtr->Period,m_ViewDispInfoPtr->PeriodEx,m_ViewDispInfoPtr->DWType,m_ViewDispInfoPtr->DWDate);
}

long QScdtContainer::OnPost(Event& evt)
{
	switch(evt.value)
	{
	case MAKEVALUE(MREQUEST_PLAT_DE,CREQUEST_DE_FIELD_VALUE):
		{
			if (!m_InfoPtr || m_InfoPtr->CommodityListPtr->CommodityList.empty()) {
				break;
			}
			REQ_FIELDDATAInfoPtr reqfieldptr = REQ_FIELDDATAInfoPtr::dynamicCast(evt.objPtr);
			if (!reqfieldptr 
				|| reqfieldptr->uFlags != REQ_FIELD_FLAG_SOME
				|| reqfieldptr->Commoditys.size() != 1) {
				break;
			}
			if (reqfieldptr->Commoditys[0] != m_InfoPtr->CommodityListPtr->CommodityList[m_InfoPtr->CurCommodityPos]) {
				break;
			}
			m_ReqFieldEvts.push_back(evt);
			m_ReqFieldPtr->Fields.insert(m_ReqFieldPtr->Fields.end(), reqfieldptr->Fields.begin(), reqfieldptr->Fields.end());
			return RLT_OK;
		}
		break;
	case MAKEVALUE(MREQUEST_PLAT_DE,CREQUEST_DE_HISDATA):
		{
			if (!m_InfoPtr || m_InfoPtr->CommodityListPtr->CommodityList.empty()) {
				break;
			}
			/*REQ_HISDATAInfoPtr reqhisdataptr = REQ_HISDATAInfoPtr::dynamicCast(evt.objPtr);
			if (!reqhisdataptr) {
				break;
			}
			if (reqhisdataptr->Commodity != m_InfoPtr->InfoPtr->CommodityList[m_InfoPtr->CurCommodityPos]) {
				break;
			}
			m_ReqHisDataEvts.push_back(evt);
			m_ReqHisDataPtr->DateTime = max(m_ReqHisDataPtr->DateTime,reqhisdataptr->DateTime);
			m_ReqHisDataPtr->Size = max(m_ReqHisDataPtr->Size,reqhisdataptr->Size);*/
			REQ_HISDATAInfoPtr reqhisdataptr = REQ_HISDATAInfoPtr::dynamicCast(evt.objPtr);
			if (reqhisdataptr) {
				break; //��ʱ��֧�ֺϲ�������ʷ����
			} 
			//��������
			RequestHisData();
			return RLT_OK;
		}
		break;
	default:
		evt.handled = false;
		break;
	}
	return RLT_UNKNOWN;
}

long QScdtContainer::OnCall(Event& evt)
{
	switch(evt.value)
	{
	case MAKEVALUE(MGET_PLAT_OBJECT,CGET_OBJECT_PUSHINFO):
		{
			ObjectPushInfoPtr pushPtr = ObjectPushInfoPtr::dynamicCast(evt.objPtr);
			if (pushPtr) {
				COMREF Commodity;
				if(GetCurCommodity(&Commodity) != RLT_UNKNOWN) {
					pushPtr->Commoditys.insert(Commodity);
				}
			}
			return RLT_OK;
		}
		break;
	//////////////////////////////////////////////////////////////////////////
	default:
		evt.handled = false;
		break;
	}
	return RLT_UNKNOWN;
}

long QScdtContainer::OnNotify(Event& evt)
{
	switch(evt.value)
	{
	case MAKEVALUE(MNOTIFY_PLAT_DE,CNOTIFY_DE_RESPONSE_FIELD_VALUE):
		{
			if (m_ReqFieldPtr == evt.objPtr) {
				if (m_ReqFieldPtr->IsFinished()) {
					for (int i=0,j=m_ReqFieldEvts.size(); i<j; i++)
					{
						REQ_FIELDDATAInfoPtr reqfieldptr = REQ_FIELDDATAInfoPtr::dynamicCast(m_ReqFieldEvts[i].objPtr);
						reqfieldptr->SetFinishRate(100);
						SendEvent(m_ReqFieldEvts[i].src, evt.evt, evt.value, reqfieldptr);
					}
					m_ReqFieldEvts.clear();
				}
			}
			//���¼���������
			evt.handled = false;
		}
		break;
	default:
		evt.handled = false;
		break;
	}
	return RLT_UNKNOWN;
}
