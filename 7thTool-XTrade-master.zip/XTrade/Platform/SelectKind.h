#ifndef _H_SELECTKIND_H_
#define _H_SELECTKIND_H_

#endif//_H_SELECTKIND_H_