#include "stdafx.h"
#include "SmartKB.h"
#include "Platform.h"

//////////////////////////////////////////////////////////////////////////
///SmartKBEditCtrl

SmartKBEditCtrl::SmartKBEditCtrl()
{
	m_pList = NULL;
}

void SmartKBEditCtrl::SetList(SmartKBListCtrl* pList)
{
	m_pList = pList;
}

LRESULT SmartKBEditCtrl::OnKeyDown(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	bHandled = FALSE;
	switch(wParam)
	{
	case VK_UP:
		{
			if (m_pList) {
				bHandled = TRUE;
				m_pList->SelectItem(m_pList->GetSelectedIndex()-1);
			}
		}
		break;
	case VK_DOWN:
		{
			if (m_pList) {
				bHandled = TRUE;
				m_pList->SelectItem(m_pList->GetSelectedIndex()+1);
			}
		}
		break;
	default:
		//bHandled = TRUE;
		//return DefWindowProc(uMsg, wParam, lParam);
		break;
	}
	return bHandled;
}

LRESULT SmartKBEditCtrl::OnChar(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	//return DefWindowProc(uMsg, wParam, lParam);
	bHandled = FALSE;
	return bHandled;
}

//////////////////////////////////////////////////////////////////////////
///SmartKBListCtrl

SmartKBListCtrl::SmartKBListCtrl()
{
	
}

SmartKBListCtrl::~SmartKBListCtrl()
{
	
}

HWND SmartKBListCtrl::Create(HWND hWndParent, RECT& rcPos
							   , LPCTSTR szWindowName , DWORD dwStyle, DWORD dwExStyle, UINT nID, LPVOID lpCreateParam)
{
	return Base::Create(hWndParent, rcPos, szWindowName
		, dwStyle 
		//| LVS_REPORT 
		//| LVS_ICON 
		//| LVS_LIST 
		| LVS_OWNERDATA
		//| LVS_OWNERDRAWFIXED
		//| LVS_SHAREIMAGELISTS
		| LVS_SHOWSELALWAYS 
		//| LVS_AUTOARRANGE 
		| LVS_NOCOLUMNHEADER
		//| LVS_NOSCROLL
		//| LVS_EDITLABELS
		| LVS_SINGLESEL
		, dwExStyle
		, nID, lpCreateParam);
}

HWND SmartKBListCtrl::Create(HWND hWndParent, LPCTSTR lpszXml, UINT XmlFlag)
{
	return Base::Create(hWndParent, lpszXml, XmlFlag);
}

void SmartKBListCtrl::Relayout(LPCRECT lpRect)
{
	CRect rcClient;
	if (lpRect) {
		rcClient = *lpRect;
	} else {
		GetClientRect(&rcClient);
	}

	UIHeaderCtrl2 wndHeader = GetHeader();
	if (wndHeader) {
		int nCol = 0;
		int nColCount = wndHeader.GetItemCount();
		if (nColCount==1) {
			SetColumnWidth(0, rcClient.Width());
		} else {
			if (nColCount==3) {
				SetColumnWidth(0, rcClient.Width()/3);
				SetColumnWidth(1, rcClient.Width()/3);
				SetColumnWidth(2, rcClient.Width()/3);
			}
		}
	}
}

COLORREF SmartKBListCtrl::GetBkColor()
{
	return Base::GetBkColor();
}

BOOL SmartKBListCtrl::SetBkColor(COLORREF cr)
{
	return Base::SetBkColor(cr);
}

void SmartKBListCtrl::OnGetDispInfo(NMLVDISPINFO* lpDispInfo)
{
	if (lpDispInfo->item.iItem < 0) {
		return;
	}

	int i,j;
	TCHAR szBuf[1024] = {0};

	int nItem = lpDispInfo->item.iItem;

	switch(lpDispInfo->item.iSubItem) 
	{
	case 0: 
		if (lpDispInfo->item.mask & LVIF_TEXT) {
			_sntprintf(lpDispInfo->item.pszText, lpDispInfo->item.cchTextMax, _T("%s"), m_SmartKBPtrList[nItem]->GetKey());
		}
		break;
	case 1:
		if (lpDispInfo->item.mask & LVIF_TEXT) {
			_sntprintf(lpDispInfo->item.pszText, lpDispInfo->item.cchTextMax, _T("%s"), m_SmartKBPtrList[nItem]->GetName());
		}
		break;
	case 2: 
		if (lpDispInfo->item.mask & LVIF_TEXT) {
			_sntprintf(lpDispInfo->item.pszText, lpDispInfo->item.cchTextMax, _T("%s"), m_SmartKBPtrList[nItem]->GetOwner());
		}
		break;
	}
}

void SmartKBListCtrl::OnPaint(HDC hdc)
{
	CRect rcClient;
	GetClientRect(&rcClient);
	ListCtrlMap::PaintBkgnd(hdc,&rcClient);
	PaintMap::OnPaint(hdc);
}

LRESULT SmartKBListCtrl::OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	LRESULT rlt = DefWindowProc();

	SetExtendedListViewStyle(
		//LVS_EX_FLATSB | 
		LVS_EX_FULLROWSELECT
		);

	InitColList();

	return rlt;
}

LRESULT SmartKBListCtrl::OnGetBkColor(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	bHandled = FALSE;
	//
	return bHandled;
}

LRESULT SmartKBListCtrl::OnSetBkColor(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	bHandled = FALSE;
	ListCtrlMap::SetBkColor((COLORREF)lParam);
	return bHandled;
}

void SmartKBListCtrl::InitColList()
{
	InsertColumn(0, _T("����"), LVCFMT_LEFT, 100);
	InsertColumn(1, _T("����"), LVCFMT_LEFT, 100);
	InsertColumn(2, _T("���"), LVCFMT_RIGHT, 100);
}

long SmartKBListCtrl::OnCall(Event& evt)
{
	switch(evt.value)
	{
	case MAKEVALUE(MSET_PLAT_OBJECT,CSET_VIEW_SMARTKBINFO):
		{
			SmartKBInfoPtr InfoPtr = SmartKBInfoPtr::dynamicCast(evt.objPtr);
			DeleteAllItems();
			if (InfoPtr) {
				m_SmartKBPtrList = InfoPtr->SmartKBPtrList;
				SetItemCount(m_SmartKBPtrList.size());
				UpdateWindowPos();
			}
		}
		break;
		//////////////////////////////////////////////////////////////////////////
	default:
		evt.handled = false;
		break;
	}
	return RLT_UNKNOWN;
}

//////////////////////////////////////////////////////////////////////////
///SmartKBComboBox

SmartKBComboBox::SmartKBComboBox()
{
	m_InfoPtr = new SmartKBInfo(this);
	m_uTimer = 0;
}

SmartKBComboBox::~SmartKBComboBox()
{

}

HWND SmartKBComboBox::Create(HWND hWndParent, RECT& rcPos
							 , LPCTSTR szWindowName , DWORD dwStyle, DWORD dwExStyle, UINT nID, LPVOID lpCreateParam)
{
	return Base::Create(hWndParent, rcPos, szWindowName
		, dwStyle 
		, dwExStyle
		, nID, lpCreateParam);
}

HWND SmartKBComboBox::Create(HWND hWndParent, LPCTSTR lpszXml, UINT XmlFlag)
{
	return Base::Create(hWndParent, lpszXml, XmlFlag);
}

HWND SmartKBComboBox::GetEditCtrl()
{
	return m_input;
}

HWND SmartKBComboBox::GetListCtrl()
{
	return m_list;
}

void SmartKBComboBox::Relayout(LPCRECT lpRect)
{
	if (!m_input || !m_list) {
		return;
	}

	if (!m_DispInfoPtr) {
		return;
	}

	CRect rcClient;
	if (lpRect) {
		rcClient = *lpRect;
	} else {
		GetClientRect(&rcClient);
	}

	if(GetStyle()&CBS_SIMPLE) {
		CRect rcInput = rcClient;
		rcInput.bottom = rcInput.top+max(m_DispInfoPtr->xyText.cy+m_DispInfoPtr->xySpace.cy, 24);
		m_input.MoveWindow(&rcInput);

		CRect rcList = rcClient;
		rcList.top = rcInput.bottom;
		m_list.MoveWindow(&rcList);
	} else {
		CRect rcInput = rcClient;
		rcInput.DeflateRect(1,1,1,1);
		m_input.MoveWindow(&rcInput);

		/*CRect rcList;
		m_list.GetWindowRect(&rcList);
		rcList.top = rcInput.bottom;
		m_list.MoveWindow(&rcList);*/
	}
}

void SmartKBComboBox::ShowDropDown(BOOL bShow)
{
	if(!m_list) {
		return;
	}
	if (bShow) {
		CRect rcWnd;
		GetWindowRect(&rcWnd);

		CRect rcList;
		m_list.GetWindowRect(&rcList);
		m_list.MoveWindow(rcWnd.left, rcWnd.bottom, rcWnd.Width(), 350);

		m_list.ShowWindow(SW_SHOWNA);

		//SetCursor(GetCursor());
		SetCapture();
	} else {
		UIWnd2 wndTop = GetTopLevelWindow();
		wndTop.SetFocus();

		m_list.ShowWindow(SW_HIDE);

		ReleaseCapture();
	}
}


BOOL SmartKBComboBox::PreTranslateMessage(MSG* pMsg)
{
	switch(pMsg->message)
	{
	case WM_KEYDOWN:
		if (pMsg->wParam == VK_RETURN) {
			int nIndex = m_list.GetSelectedIndex();
			if (nIndex>=0 && nIndex<m_InfoPtr->SmartKBPtrList.size()) {
				SendEvent(_FramePtr, EVT_PLAT_CALL, MAKEVALUE(MCALL_PLAT_FRAME,CCALL_FRAME_SMARTKB)
					, m_InfoPtr->SmartKBPtrList[nIndex]);
				return TRUE;
			}
		}
		break;
	case WM_CHAR:
		break;
	}

	return Base::PreTranslateMessage(pMsg);
}

void SmartKBComboBox::OnPaint(HDC hdc)
{
	if (GetStyle()&CBS_SIMPLE) {
		CDCHandle dc = hdc;
		UIWnd2 wndParent = GetParent();
		if(wndParent) {
			// Forward this to the parent window, rebar bands are transparent
			POINT pt = { 0, 0 };
			MapWindowPoints(wndParent, &pt, 1);
			dc.OffsetWindowOrg(pt.x, pt.y, &pt);
			wndParent.SendMessage(WM_ERASEBKGND, (WPARAM)(HDC)dc);
			wndParent.SendMessage(WM_PAINT, (WPARAM)(HDC)dc);
			dc.SetWindowOrg(pt.x, pt.y);
		} else {
			CRect rcClient;
			GetClientRect(&rcClient);
			FillRect(hdc, &rcClient, GetStockBrush(WHITE_BRUSH));
		}
	} else {
		CRect rcClient;
		GetClientRect(&rcClient);
		if (m_input == GetFocus()) {
			FillRect(hdc, &rcClient, GetStockBrush(BLACK_BRUSH));
		} else {
			FillRect(hdc, &rcClient, GetStockBrush(WHITE_BRUSH));
		}
	}
}

HBRUSH SmartKBComboBox::OnCtlColor(HDC hdc, HWND hWnd, UINT nCtlColor)
{
	return OwnerDraw::OnCtlColor(hdc, hWnd, nCtlColor);
}

LRESULT SmartKBComboBox::OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	LRESULT Res = DefWindowProc(uMsg, wParam, lParam);

	BOOL bListChild = (GetStyle()&CBS_SIMPLE)?TRUE:FALSE;

	CRect rcClient;
	GetClientRect(&rcClient);

	CString strTitle;
	GetWindowText(strTitle);

	CRect rcInput = rcClient;
	rcInput.bottom = rcInput.top + 24;
	m_input.Create(m_hWnd, rcInput, strTitle
		, WS_CHILD|WS_VISIBLE|ES_AUTOHSCROLL
		| (bListChild?WS_BORDER:0)
		//, WS_EX_NOACTIVATE
		);
	
	CRect rcList = rcClient;
	rcList.top = rcInput.bottom + 2;
	m_list.Create(m_hWnd, rcList, _T("")
		, (bListChild?WS_CHILD:WS_POPUP)
		| (bListChild?WS_VISIBLE:0)
		| WS_BORDER
		| LVS_REPORT 
		//| LVS_ICON 
		//| LVS_LIST 
		//| LVS_OWNERDATA
		//| LVS_OWNERDRAWFIXED
		//| LVS_SHAREIMAGELISTS
		//| LVS_SHOWSELALWAYS 
		//| LVS_AUTOARRANGE 
		//| LVS_NOCOLUMNHEADER
		//| LVS_NOSCROLL
		//| LVS_EDITLABELS
		//| LVS_SINGLESEL
		, bListChild?0:WS_EX_TOOLWINDOW
		);
	//m_list.ModifyStyle(WS_HSCROLL, WS_VSCROLL, SWP_DRAWFRAME);
	//m_list.EnableScrollBar(SB_VERT, ESB_DISABLE_BOTH);

	m_input.SetList(&m_list);

	return Res;
}

LRESULT SmartKBComboBox::OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	bHandled = FALSE;
	if (m_uTimer) {
		KillTimer(m_uTimer);
	}
	return bHandled;
}

LRESULT SmartKBComboBox::OnSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	if (wParam != SIZE_MINIMIZED && lParam != 0) {
		Relayout();
	}
	return bHandled;
}

LRESULT SmartKBComboBox::OnTimer(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	KillTimer(m_uTimer);
	m_uTimer = 0;

	if (m_input && m_list) {
		m_input.GetWindowText(m_strInput);
		m_InfoPtr->strKey = (LPCTSTR)m_strInput;
		m_InfoPtr->SmartKBPtrList.clear();
		SendEvent(_FramePtr, EVT_PLAT_CALL, MAKEVALUE(MGET_PLAT_FRAME, CGET_FRAME_SMARTKBINFO), m_InfoPtr);
		SendEvent(&m_list, EVT_PLAT_CALL, MAKEVALUE(MSET_PLAT_OBJECT,CSET_VIEW_SMARTKBINFO), m_InfoPtr);
		//SetCursor(GetCursor());
		//SetCapture();
		if (!m_InfoPtr->SmartKBPtrList.empty()) {
			m_list.SelectItem(0);
		}
	}

	return bHandled;
}

LRESULT SmartKBComboBox::OnLButtonDown(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	bHandled = FALSE;
	if(GetStyle()&CBS_SIMPLE) {
		
	} else {
		POINT pt;
		POINTSTOPOINT(pt,lParam);
		ClientToScreen(&pt);

		RECT rcWnd;
		GetWindowRect(&rcWnd);
		if (!PtInRect(&rcWnd,pt)) {
			m_list.GetWindowRect(&rcWnd);
			if (!PtInRect(&rcWnd,pt)) {
				ShowDropDown(FALSE);
			}
		}
	}
	return bHandled;
}

LRESULT SmartKBComboBox::OnEnSetFocus(int wNotifyCode, int wID, HWND hwndCtl, BOOL& bHandled)
{
	if(GetStyle()&CBS_SIMPLE) {
	} else {
		ShowDropDown(TRUE);
		Invalidate();
	}
	return bHandled;
}

LRESULT SmartKBComboBox::OnEnKillFocus(int wNotifyCode, int wID, HWND hwndCtl, BOOL& bHandled)
{
	if(GetStyle()&CBS_SIMPLE) {
	} else {
		ShowDropDown(FALSE);
		Invalidate();
	}
	return bHandled;
}

LRESULT SmartKBComboBox::OnEnUpdate(int wNotifyCode, int wID, HWND hwndCtl, BOOL& bHandled)
{
#if 1
	if (m_input && m_list) {
		m_input.GetWindowText(m_strInput);
		Find();
	}
#else
	m_uTimer = SetTimer(101, 200);
#endif//
	return bHandled;
}

LRESULT SmartKBComboBox::OnFindComplete(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	SendEvent(&m_list, EVT_PLAT_CALL, MAKEVALUE(MSET_PLAT_OBJECT,CSET_VIEW_SMARTKBINFO), m_InfoPtr);
	if (!m_InfoPtr->SmartKBPtrList.empty()) {
		m_list.SelectItem(0);
	}
	return bHandled;
}

void SmartKBComboBox::OnIdle()
{
	AsyncFinder::OnIdle();
}

long SmartKBComboBox::OnFind()
{
	m_InfoPtr->strKey = m_strInput;
	m_InfoPtr->SmartKBPtrList.clear();
	return SendEvent(_Platform->GetFrame(GetWindowThreadID()), EVT_PLAT_CALL, MAKEVALUE(MGET_PLAT_FRAME, CGET_FRAME_SMARTKBINFO), m_InfoPtr);
}

void SmartKBComboBox::OnDispInfoChanged()
{
	m_input.SetFont(m_DispInfoPtr->hText);
	m_input.Invalidate();

	//m_list.SetBkColor(RGB(255,255,255));
	//m_list.SetTextColor(RGB(0,0,0));

	SendEvent(&m_list, EVT_PLAT_CALL, MAKEVALUE(MSET_PLAT_OBJECT,CSET_OBJECT_DISPINFO), GetDispInfoPtr());

	Relayout();
}
