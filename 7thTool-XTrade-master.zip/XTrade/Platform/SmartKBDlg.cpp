// aboutdlg.cpp : implementation of the CSmartKBDlg class
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "resource.h"

#include "SmartKBDlg.h"

BOOL CSmartKBDlg::PreTranslateMessage(MSG* pMsg)
{
	if (pMsg->message == WM_KEYDOWN) {
		if (pMsg->wParam == VK_ESCAPE || pMsg->wParam == VK_CANCEL) {
			SendMessage(WM_COMMAND, IDCANCEL, 0);
			return TRUE;
		} else if (pMsg->wParam == VK_BACK) {
			UIWnd2 wndInput(m_smartkb.GetEditCtrl());
			if (wndInput) {
				if (wndInput.GetWindowTextLength()<=1) {
					SendMessage(WM_COMMAND, IDCANCEL, 0);
					return TRUE;
				}
			}
		}
	}
	return FALSE;
}

BOOL CSmartKBDlg::PaintBkgnd(HDC hdc, LPRECT lpRect)
{
	ATLTRACE(_T("PaintBkgnd\n"));

	int i,j;
	CRect rcClient;
	GetClientRect(&rcClient);

	BOOL bRet = SkinDraw::PaintBkgnd(hdc,&rcClient);

	CDCHandle dc(hdc);

	//dc.Draw3dRect(&rcClient, RGB(0,0,0), RGB(0,0,0));
	for(i = 1, j = rcClient.Width()-2; i < j; i++)
	{
		dc.SetPixel(i, rcClient.top, UIgdi::AlphaColor(RGB(0,0,0), 0.5, dc.GetPixel(i, rcClient.top), 0.5));
		dc.SetPixel(i, rcClient.bottom-1, UIgdi::AlphaColor(RGB(0,0,0), 0.5, dc.GetPixel(i, rcClient.bottom-1), 0.5));
	}
	for(i = 1, j = rcClient.Height()-2; i < j; i++)
	{
		dc.SetPixel(rcClient.left, i, UIgdi::AlphaColor(RGB(0,0,0), 0.5, dc.GetPixel(rcClient.left,i), 0.5));
		dc.SetPixel(rcClient.right-1, i, UIgdi::AlphaColor(RGB(0,0,0), 0.5, dc.GetPixel(rcClient.right-1, i), 0.5));
	}
	for(i = 2, j = rcClient.Width()-4; i < j; i++)
	{
		dc.SetPixel(i, rcClient.top+1, UIgdi::AlphaColor(RGB(255,255,255), 0.5, dc.GetPixel(i, rcClient.top+1), 0.5));
		dc.SetPixel(i, rcClient.bottom-2, UIgdi::AlphaColor(RGB(255,255,255), 0.5, dc.GetPixel(i, rcClient.bottom-2), 0.5));
	}
	for(i = 2, j = rcClient.Height()-4; i < j; i++)
	{
		dc.SetPixel(rcClient.left+1, i, UIgdi::AlphaColor(RGB(255,255,255), 0.5, dc.GetPixel(rcClient.left+1,i), 0.5));
		dc.SetPixel(rcClient.right-2, i, UIgdi::AlphaColor(RGB(255,255,255), 0.5, dc.GetPixel(rcClient.right-2, i), 0.5));
	}
	for (i = 1; i < 2; i++)
	{
		// ����
		dc.SetPixel(rcClient.left+i, rcClient.top+i, UIgdi::AlphaColor(RGB(0,0,0), 0.5, dc.GetPixel(rcClient.left+i, rcClient.top+i), 0.5));
		// ����
		dc.SetPixel(rcClient.right-i-1, rcClient.top+i, UIgdi::AlphaColor(RGB(0,0,0), 0.5, dc.GetPixel(rcClient.right-i-1, rcClient.top+i), 0.5));
		// ����
		dc.SetPixel(rcClient.left+i, rcClient.bottom-i-1, UIgdi::AlphaColor(RGB(0,0,0), 0.5, dc.GetPixel(rcClient.left+i, rcClient.bottom-i-1), 0.5));
		// ����
		dc.SetPixel(rcClient.right-i-1, rcClient.bottom-i-1, UIgdi::AlphaColor(RGB(0,0,0), 0.5, dc.GetPixel(rcClient.right-i-1, rcClient.bottom-i-1), 0.5));
	}
	return bRet;
}

void CSmartKBDlg::OnOK()
{
	ShowWindow(SW_HIDE);
}

void CSmartKBDlg::OnCancel()
{
	ShowWindow(SW_HIDE);
}

LRESULT CSmartKBDlg::OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	bHandled = FALSE;

	EnableMove();

	SetBkImage(_pUISkinManager->GetImage(MAKESKINSTRRESID2(_T("Image"),_T("background")), NULL,_T("SmartKBDlg"))
		, UI_BK_STYLE_STRETCH | UI_BK_EFFECT_ALPHA_VERT);

	CenterWindow();

	return 0L;
}

LRESULT CSmartKBDlg::OnSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	return bHandled;
}

LRESULT CSmartKBDlg::OnSysCommand(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	bHandled = FALSE;
	return 0L;
}

LRESULT CSmartKBDlg::OnShowWindow(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	return bHandled;
}

LRESULT CSmartKBDlg::OnActivate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	if (wParam == WA_INACTIVE) { 
		PostMessage(WM_COMMAND, IDCANCEL, 0);
	}
	return bHandled;
}
