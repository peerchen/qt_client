#ifndef _H_QTRADEVIEW_H_
#define _H_QTRADEVIEW_H_

#include <Util/ViewObjecter.h>
#include <Util/CommodityView.h>

#include <XLib/UIXCtrl.h>
#include "CommCtrl.h"

class QTradeView 
	: public ViewObjecterImpl<QTradeView>
	, public UIPaint<QTradeView>
{
	typedef QTradeView This;
	typedef ViewObjecterImpl<QTradeView> Base;
	typedef UIPaint<QTradeView> Paint;
	DECLARE_XMLWND_CLASS(_T("TradeView"))
	DECLARE_DYNCREATE_WND_OBJECTER(QTradeView,Objecter)
public:
	BOOL IsDirectUI() { return TRUE; }

	BEGIN_MSG_MAP(This)
		CHAIN_MSG_MAP(Paint)
		CHAIN_MSG_MAP(Base)
	END_MSG_MAP()

	void OnPaint(HDC hdc);

public:
	void OnDispInfoChanged();
	void OnViewInfoChanged();
};

//////////////////////////////////////////////////////////////////////////

class QMiniTradeView : public CommodityViewImpl<QMiniTradeView>
{
	typedef QMiniTradeView This;
	typedef CommodityViewImpl<QMiniTradeView> Base;
	DECLARE_XMLWND_CLASS(_T("MiniTradeView"))
	DECLARE_DYNCREATE_WND_OBJECTER(QMiniTradeView,Objecter)
public:
	BOOL IsDirectUI() { return TRUE; }

	UIXEdit2 m_edVolume;
	UIUpDownCtrl2 m_udVolume;
	UIXEdit2 m_edPrice;
	UIUpDownCtrl2 m_udPrice;
	UIXButton2 m_chkAuto;
	UIXButton2 m_bnQuery;
	UIXButton2 m_bnReset;
	UIXButton2 m_bnClose;
	UIXButton2 m_bnCancel;
	TradeButton m_bnBuy;
	TradeButton m_bnSell;

	BEGIN_XML_CONTROL_MAP(This)
		XML_NAME_CTRL(_T("volume"), m_edVolume)
		//XML_NAME_CTRL(_T("updown_volume"), m_udVolume)
		XML_NAME_CTRL(_T("price"), m_edPrice)
		//XML_NAME_CTRL(_T("updown_price"), m_udPrice)
		XML_NAME_CTRL(_T("check_auto"), m_chkAuto)
		XML_NAME_CTRL(_T("query"), m_bnQuery)
		XML_NAME_CTRL(_T("close"), m_bnClose)
		XML_NAME_CTRL(_T("cancel"), m_bnCancel)
		XML_NAME_CTRL(_T("buy"), m_bnBuy)
		XML_NAME_CTRL(_T("sell"), m_bnSell)
	END_XML_CONTROL_MAP()

public:
	void OnPaint(HDC hdc);

	BEGIN_MSG_MAP(This)
		MESSAGE_HANDLER(WM_CREATE, OnCreate)
		MESSAGE_HANDLER(WM_SIZE, OnSize)
		CHAIN_MSG_MAP(Base)
	END_MSG_MAP()

	LRESULT OnCreate(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/);
	LRESULT OnSize(UINT /*uMsg*/, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

public:
	void OnDispInfoChanged();
	void OnViewInfoChanged();
};

#endif//_H_QTRADEVIEW_H_