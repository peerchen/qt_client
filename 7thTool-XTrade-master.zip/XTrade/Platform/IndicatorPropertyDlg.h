// aboutdlg.h : interface of the CIndicatorPrppertyDlg class
//
/////////////////////////////////////////////////////////////////////////////

#ifndef _H_QINDICATORPROPERTYDLG_H_
#define _H_QINDICATORPROPERTYDLG_H_

#include <XLib/UIXCtrl.h>
#include <Util/ViewObjecter.h>

class CIndicatorPrppertyDlg 
	: public DlgObjecterImpl<CIndicatorPrppertyDlg> 
	, public UIEnableMove<CIndicatorPrppertyDlg>
	, public UIRoundRectHelper<CIndicatorPrppertyDlg>
	, public UIBkgndSkinDrawMap<CIndicatorPrppertyDlg>
{
	typedef CIndicatorPrppertyDlg This;
	typedef DlgObjecterImpl<CIndicatorPrppertyDlg> Base;
	typedef UIBkgndSkinDrawMap<CIndicatorPrppertyDlg> SkinDraw;
	DECLARE_XMLWND_CLASS(_T("CIndicatorPrppertyDlg"))
	DECLARE_DYNCREATE_WND_OBJECTER(CIndicatorPrppertyDlg,Objecter)
public:
	enum { IDD = IDD_ABOUTBOX };

	CIndicatorPrppertyDlg() { }

	UIXTabCtrl m_TabCtrl;
	UIListCtrl m_ParamList;
	

	BEGIN_ATTRIBUTE_MAP(This)
		//ATTRIBUTE_STRING_HANDLER2(_T("image_background"), SetBgImage, Image::FromFile)
		CHAIN_ATTRIBUTE_MAP(Base)
	END_ATTRIBUTE_MAP()

	BEGIN_XML_CONTROL_MAP(This)
		
	END_XML_CONTROL_MAP()

	BOOL PaintBkgnd(HDC hdc, LPRECT lpRect)
	{
		ATLTRACE(_T("PaintBkgnd\n"));

		int i,j;
		CRect rcClient;
		GetClientRect(&rcClient);

		BOOL bRet = SkinDraw::PaintBkgnd(hdc,&rcClient);

		CDCHandle dc(hdc);

		//dc.Draw3dRect(&rcClient, RGB(0,0,0), RGB(0,0,0));
		for(i = 1, j = rcClient.Width()-2; i < j; i++)
		{
			dc.SetPixel(i, rcClient.top, UIgdi::AlphaColor(RGB(0,0,0), 0.5, dc.GetPixel(i, rcClient.top), 0.5));
			dc.SetPixel(i, rcClient.bottom-1, UIgdi::AlphaColor(RGB(0,0,0), 0.5, dc.GetPixel(i, rcClient.bottom-1), 0.5));
		}
		for(i = 1, j = rcClient.Height()-2; i < j; i++)
		{
			dc.SetPixel(rcClient.left, i, UIgdi::AlphaColor(RGB(0,0,0), 0.5, dc.GetPixel(rcClient.left,i), 0.5));
			dc.SetPixel(rcClient.right-1, i, UIgdi::AlphaColor(RGB(0,0,0), 0.5, dc.GetPixel(rcClient.right-1, i), 0.5));
		}
		for(i = 2, j = rcClient.Width()-4; i < j; i++)
		{
			dc.SetPixel(i, rcClient.top+1, UIgdi::AlphaColor(RGB(255,255,255), 0.5, dc.GetPixel(i, rcClient.top+1), 0.5));
			dc.SetPixel(i, rcClient.bottom-2, UIgdi::AlphaColor(RGB(255,255,255), 0.5, dc.GetPixel(i, rcClient.bottom-2), 0.5));
		}
		for(i = 2, j = rcClient.Height()-4; i < j; i++)
		{
			dc.SetPixel(rcClient.left+1, i, UIgdi::AlphaColor(RGB(255,255,255), 0.5, dc.GetPixel(rcClient.left+1,i), 0.5));
			dc.SetPixel(rcClient.right-2, i, UIgdi::AlphaColor(RGB(255,255,255), 0.5, dc.GetPixel(rcClient.right-2, i), 0.5));
		}
		for (i = 1; i < 2; i++)
		{
			// ����
			dc.SetPixel(rcClient.left+i, rcClient.top+i, UIgdi::AlphaColor(RGB(0,0,0), 0.5, dc.GetPixel(rcClient.left+i, rcClient.top+i), 0.5));
			// ����
			dc.SetPixel(rcClient.right-i-1, rcClient.top+i, UIgdi::AlphaColor(RGB(0,0,0), 0.5, dc.GetPixel(rcClient.right-i-1, rcClient.top+i), 0.5));
			// ����
			dc.SetPixel(rcClient.left+i, rcClient.bottom-i-1, UIgdi::AlphaColor(RGB(0,0,0), 0.5, dc.GetPixel(rcClient.left+i, rcClient.bottom-i-1), 0.5));
			// ����
			dc.SetPixel(rcClient.right-i-1, rcClient.bottom-i-1, UIgdi::AlphaColor(RGB(0,0,0), 0.5, dc.GetPixel(rcClient.right-i-1, rcClient.bottom-i-1), 0.5));
		}
		return bRet;
	}

	BEGIN_MSG_MAP(This)
		MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
		//MESSAGE_HANDLER(WM_CREATE, OnCreate)
		MESSAGE_HANDLER(WM_SYSCOMMAND, OnSysCommand)
		MESSAGE_HANDLER(WM_SHOWWINDOW, OnShowWindow)
		CHAIN_MSG_MAP(UIRoundRectHelper<CIndicatorPrppertyDlg>)
		CHAIN_MSG_MAP(UIEnableMove<CIndicatorPrppertyDlg>)
		CHAIN_MSG_MAP(SkinDraw)
		CHAIN_MSG_MAP(Base)
	END_MSG_MAP()

	LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	//LRESULT OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		bHandled = FALSE;

		EnableMove();

		SetBkImage(_pUISkinManager->GetImage(MAKESKINSTRRESID2(_T("Image"),_T("background")), NULL, _T("IndicatorPrppertyDlg"))
			, UI_BK_STYLE_STRETCH | UI_BK_EFFECT_ALPHA_VERT);

		CRect rcClient;
		GetClientRect(&rcClient);

		//CRect rcTabCtrl = rcClient;
		//rcTabCtrl.bottom = rcTabCtrl.top + m_DispInfoPtr->xyTabCtrl.cy + m_DispInfoPtr->xySpace.cy*2;
		//m_TabCtrl.Create(m_hWnd, rcDefault,  NULL, WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, 0, 0, NULL);
		//m_TabCtrl.Insert()

		CenterWindow();
		
		return 0L;
	}

	LRESULT OnSysCommand(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		bHandled = FALSE;
		return 0L;
	}

	LRESULT OnShowWindow(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		return 0;
	}
};

#endif//_H_QINDICATORPROPERTYDLG_H_
