// Platform.h
//
/////////////////////////////////////////////////////////////////////////////

#pragma once

#include <UI/UIApp.h>
#include "resource.h"
//#include <XLib/UIXModule.h>
#include <Util/Objecter.h>

class PlatformModule 
	: public UIAppModule
	//, public UIXModuleT<PlatformModule>
{
	typedef UIAppModule Base;
	//typedef UIXModuleT<PlatformModule> UXModule;
public:
	PlatformModule();
	~PlatformModule();

	HRESULT Init(ATL::_ATL_OBJMAP_ENTRY* pObjMap, HINSTANCE hInstance, const GUID* pLibID = NULL);
	void Term();

private:
	CriticalSection m_Section;
	std::map<CString,HMODULE,CStringNoCaseLess> m_mapModule;
public:
	HMODULE LoadLibrary(LPCTSTR lpFileName);
	//BOOL FreeLibrary(HMODULE hModule);
	void FreeAllLibrary();
};

#if USES_MULTITHREAD

class CMultiThreadThreadManager
{
public:
	CMultiThreadThreadManager();

	// Operations
	HANDLE AddThread(LPCTSTR lpstrName, LPCTSTR lpstrCmdLine, int nCmdShow);
};

extern CMultiThreadThreadManager _MultiThreadMgr;

#endif//


