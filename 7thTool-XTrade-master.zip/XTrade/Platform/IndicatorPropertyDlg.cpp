// aboutdlg.cpp : implementation of the CIndicatorPrppertyDlg class
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "resource.h"

#include "IndicatorPropertyDlg.h"

IMPLEMENT_DYNCREATE_WND_OBJECTER(CIndicatorPrppertyDlg,Objecter)

// LRESULT CIndicatorPrppertyDlg::OnInitDialog(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& bHandled)
// {
// 	bHandled = FALSE;
// 	CenterWindow(GetParent());
// 	return TRUE;
// }
// 
// LRESULT CIndicatorPrppertyDlg::OnCloseCmd(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
// {
// 	EndDialog(wID);
// 	return 0;
// }
