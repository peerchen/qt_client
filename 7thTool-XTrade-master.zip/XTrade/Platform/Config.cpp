#include "stdafx.h"
#include "Config.h"

void ConfigBase::CloseConfig(LPCTSTR lpszConfig)
{
	int len = _tcslen(lpszConfig);
	if (len > 4) {
		if (_tcsicmp(lpszConfig+len-4,_T(".xml")) == 0) {
			CloseMarkup(lpszConfig);
			return;
		} else if (_tcsicmp(lpszConfig+len-4,_T(".ini")) == 0) {
			CloseProfile(lpszConfig);
			return;
		}
	}
	CloseMarkup(lpszConfig);
	CloseProfile(lpszConfig);
}

long ConfigBase::GetConfigA(LPCSTR lpszName, LPSTR lpszValue, int nValueCount, LPCSTR lpszSpec /* = NULL */, LPCSTR lpszConfig /* = NULL */)
{
	long rlt = RLT_UNKNOWN;
#ifdef UNICODE
	std::string name(lpszName), val(lpszValue, nValueCount);
	std::wstring wname, wval(nValueCount, 0), wspec, wconfig;
	mb2wc(name, wname, CP_OEMCP);
	if (lpszSpec) {
		mb2wc(std::string(lpszSpec), wspec, CP_OEMCP);
	}
	if (lpszConfig) {
		mb2wc(std::string(lpszConfig), wconfig, CP_OEMCP);
	}
	rlt = GetConfigW((LPCWSTR)wname.c_str(), (LPWSTR)wval.c_str(), nValueCount,
		lpszSpec ? (LPCWSTR)wspec.c_str() : NULL, lpszConfig ? (LPCWSTR)wconfig.c_str() : NULL);
	if(rlt >= 0) {
		rlt = wc2mb((wchar_t*)wval.c_str(), rlt, lpszValue, nValueCount, CP_OEMCP);
	}
#else

#endif//
	return rlt;
}

long ConfigBase::GetConfigW(LPCWSTR lpszName, LPWSTR lpszValue, int nValueCount, LPCWSTR lpszSpec /* = NULL */, LPCWSTR lpszConfig /* = NULL */)
{
	long rlt = RLT_UNKNOWN;
#ifdef UNICODE
	bool bOk = false;
	Markup* pConfig = OpenMarkup(lpszConfig);
	if(pConfig) {
		pConfig->ResetPos();
		if (!lpszSpec || !lpszSpec[0]) {
			wcsref strrefname((wchar_t*)lpszName), strrefval;
			if (pConfig->Find(strrefname)) {
				bOk = true;
				if(pConfig->Get(strrefname, strrefval)) {
					rlt = MIN(strrefval.second, nValueCount);
					wcsncpy(lpszValue, strrefval.first, rlt);
				}
			}
		} else {
			wcsref strrefname((wchar_t*)lpszName), strrefattr((wchar_t*)lpszSpec), strrefval;
			if(pConfig->Find(strrefname)) {
				if(pConfig->Get(strrefname, strrefattr, strrefval)) {
					bOk = true;
					rlt = MIN(strrefval.second, nValueCount - 1);
					wcsncpy(lpszValue, strrefval.first, rlt);
				}
			}
		}
	}
	if(!bOk) {
		if (!lpszConfig || !lpszConfig[0]) {
		} else if (wcsicmp(lpszConfig, CONFIG_APPW) == 0) {
			rlt = GetConfigW(lpszName, lpszValue, nValueCount, lpszSpec, NULL);
		} else if (wcsicmp(lpszConfig, CONFIG_USERW) == 0) {
			rlt = GetConfigW(lpszName, lpszValue, nValueCount, lpszSpec, CONFIG_APPW);
		}
	} 
#else
	
#endif//
	return rlt;
}

long ConfigBase::SetConfigA(LPCSTR lpszName, LPCSTR lpszValue, int nValueCount /* = 0 */, LPCSTR lpszSpec /* = NULL */, LPCSTR lpszConfig /* = NULL */)
{
	long rlt = RLT_UNKNOWN;
#ifdef UNICODE
		std::string name(lpszName), val(lpszValue);
		std::wstring wname, wval;
		mb2wc(name, wname, CP_OEMCP);
		mb2wc(val, wval, CP_OEMCP);
		if (!lpszConfig || !lpszConfig[0]) {
			if (lpszSpec == NULL || lpszSpec[0]==0) {
				SetConfigW(wname.c_str(), wval.c_str(), wval.length());
			} else {
				std::string spec(lpszSpec);
				std::wstring wspec;
				mb2wc(spec, wspec, CP_OEMCP);
				SetConfigW(wname.c_str(), wval.c_str(), wval.length(), wspec.c_str());
			}
		} else {
			std::string config(lpszConfig);
			std::wstring wconfig;
			mb2wc(config, wconfig, CP_OEMCP);
			if (lpszSpec == NULL || lpszSpec[0]==0) {
				SetConfigW(wname.c_str(), wval.c_str(), wval.length(), NULL, wconfig.c_str());
			} else {
				std::string spec(lpszSpec);
				std::wstring wspec;
				mb2wc(spec, wspec, CP_OEMCP);
				SetConfigW(wname.c_str(), wval.c_str(), wval.length(), wspec.c_str(), wconfig.c_str());
			}
		}
#else
#endif
	return rlt;
}

long ConfigBase::SetConfigW(LPCWSTR lpszName, LPCWSTR lpszValue, int nValueCount /* = 0 */, LPCWSTR lpszSpec /* = NULL */, LPCWSTR lpszConfig /* = NULL */)
{
	long rlt = RLT_UNKNOWN;
	return rlt;
}