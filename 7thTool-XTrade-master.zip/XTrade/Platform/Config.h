#ifndef _H_CONFIGIMPL_H_
#define _H_CONFIGIMPL_H_

#include "../Util/IConfig.h"
#include <XLib/XConfig.h>

class ConfigBase : public IConfig
{
public:
	virtual Markup* OpenMarkup(LPCTSTR lpszConfig) = 0;
	virtual Profile* OpenProfile(LPCTSTR lpszConfig) = 0;
	virtual void CloseMarkup(LPCTSTR lpszConfig) = 0;
	virtual void CloseProfile(LPCTSTR lpszConfig) = 0;
	virtual void CloseConfig(LPCTSTR lpszConfig);

	long GetConfigA(LPCSTR lpszName, LPSTR lpszValue, int nValueCount, LPCSTR lpszSpec = NULL, LPCSTR lpszConfig = NULL);
	long GetConfigW(LPCWSTR lpszName, LPWSTR lpszValue, int nValueCount, LPCWSTR lpszSpec = NULL, LPCWSTR lpszConfig = NULL);
	long SetConfigA(LPCSTR lpszName, LPCSTR lpszValue, int nValueCount = 0, LPCSTR lpszSpec = NULL, LPCSTR lpszConfig = NULL);
	long SetConfigW(LPCWSTR lpszName, LPCWSTR lpszValue, int nValueCount = 0, LPCWSTR lpszSpec = NULL, LPCWSTR lpszConfig = NULL);
};

template<class T>
class ConfigImpl : public ConfigBase
{ 
protected:
	typedef std::map<std::tstring, Markup*, std::tstringiless> Name2pMarkup;
	typedef std::map<std::tstring, Profile*, std::tstringiless> Name2pProfile;
	Name2pMarkup m_Name2pMarkup;
	Name2pProfile m_Name2pProfile;

public:
	long Instance()
	{
		T* pT = static_cast<T*>(this);
		TCHAR szTemp[MAX_PATH];
		TCHAR szPath[MAX_PATH];
		TCHAR szTempPath[MAX_PATH];

		_stprintf(szPath, _T("%s\\%s.xml"), pT->GetAppPath(), pT->GetName());
		m_Name2pMarkup[_T("")] = new Markup(szPath);

		if (!File::IsFileExist(_Module.GetAppData())) {
			File::CreateDirectory(_Module.GetAppData());
		}
		_stprintf(szPath, _T("%s\\%s.xml"), pT->GetAppData(), pT->GetName());
		m_Name2pMarkup[CONFIG_APP] = new Markup(szPath,TRUE);//app data goto.xml for global store data.

		m_Name2pMarkup[CONFIG_MEM] = new Markup();
		
		//���ﲻ��ʼ�����Ⱥ�������Ӧ�ø����߼���ʼ��
		/*THEME
		GetConfig(_T("root/theme"), szTemp, MAX_PATH, _T("default"), _T("name"), CONFIG_APP);
		_stprintf(szTempPath, _T("%s\\theme\\%s\\theme.xml"), pT->GetAppData(), szTemp);
		if (PathFileExists(szTempPath)) {
			_stprintf(szTempPath, _T("%s\\theme\\default\\theme.xml"), pT->GetAppPath(), szTemp);
		}
		m_Name2pMarkup[CONFIG_THEME] = new Markup(szTempPath);*/

		/*USER
		*/

		return 1;
	}

	void Release()
	{
		Name2pMarkup::iterator iter = m_Name2pMarkup.begin();
		for (;iter != m_Name2pMarkup.end(); ++iter)
		{
			if (iter->second) {
				delete iter->second;
			}
		}
		m_Name2pMarkup.clear();
	}

	Markup* OpenMarkup(LPCTSTR lpszConfig)
	{
		if(!lpszConfig || !lpszConfig[0]) {
			return m_Name2pMarkup[_T("")];
		}
		Name2pMarkup::iterator iter = m_Name2pMarkup.find(lpszConfig);
 		if (iter != m_Name2pMarkup.end()) {
			return iter->second;
		} else {
			//
		}
		return NULL;
	}

	Profile* OpenProfile(LPCTSTR lpszConfig)
	{
		return NULL;
	}

	void CloseMarkup(LPCTSTR lpszConfig)
	{
		Name2pMarkup::iterator it = m_Name2pMarkup.find(lpszConfig);
		if(it != m_Name2pMarkup.end()) {
			it->second->Close();
			delete it->second;
			m_Name2pMarkup.erase(it);
		}
	}

	void CloseProfile(LPCTSTR lpszConfig)
	{
		Name2pProfile::iterator it = m_Name2pProfile.find(lpszConfig);
		if(it != m_Name2pProfile.end()) {
			it->second->Close();
			delete it->second;
			m_Name2pProfile.erase(it);
		}
	}
};

#endif//_H_CONFIGIMPL_H_