// aboutdlg.h : interface of the CSmartKBDlg class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_SMARTKBDLG_H__D162277B_2C97_476C_8350_1C15D73792DC__INCLUDED_)
#define AFX_SMARTKBDLG_H__D162277B_2C97_476C_8350_1C15D73792DC__INCLUDED_

#include <XLib/UIXCtrl.h>
#include "SmartKB.h"

class CSmartKBDlg 
	: public UIXDialog2Impl<CSmartKBDlg> 
	, public UIEnableMove<CSmartKBDlg>
	, public UIRoundRectHelper<CSmartKBDlg>
	, public UIBkgndSkinDrawMap<CSmartKBDlg>
	, public UIPreTranslateMessageMap<CSmartKBDlg>
{
	typedef CSmartKBDlg This;
	typedef UIXDialog2Impl<CSmartKBDlg> Base;
	typedef UIBkgndSkinDrawMap<CSmartKBDlg> SkinDraw;
	typedef UIPreTranslateMessageMap<CSmartKBDlg> UIPreTransateMessage;
public:
	enum { IDD = IDD_ABOUTBOX };

	DECLARE_XMLWND_CLASS(_T("CSmartKBDlg"))

	CSmartKBDlg() { }

	SmartKBComboBox m_smartkb;

	BEGIN_ATTRIBUTE_MAP(This)
		CHAIN_ATTRIBUTE_MAP(Base)
	END_ATTRIBUTE_MAP()

	BEGIN_XML_CONTROL_MAP(This)
		XML_NAME_CTRL(_T("smartkb"), m_smartkb)
	END_XML_CONTROL_MAP()

	BOOL PreTranslateMessage(MSG* pMsg);

	BOOL PaintBkgnd(HDC hdc, LPRECT lpRect);

	void OnOK();
	void OnCancel();

	BEGIN_MSG_MAP(This)
		MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
		MESSAGE_HANDLER(WM_SIZE, OnSize)
		MESSAGE_HANDLER(WM_SYSCOMMAND, OnSysCommand)
		MESSAGE_HANDLER(WM_SHOWWINDOW, OnShowWindow)
		MESSAGE_HANDLER(WM_ACTIVATE, OnActivate)
		CHAIN_MSG_MAP(UIPreTransateMessage)
		CHAIN_MSG_MAP(UIRoundRectHelper<CSmartKBDlg>)
		CHAIN_MSG_MAP(UIEnableMove<CSmartKBDlg>)
		CHAIN_MSG_MAP(SkinDraw)
		CHAIN_MSG_MAP(Base)
		REFLECT_NOTIFICATIONS()
	END_MSG_MAP()

	LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnSysCommand(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnShowWindow(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnActivate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
};

#endif // !defined(AFX_SMARTKBDLG_H__D162277B_2C97_476C_8350_1C15D73792DC__INCLUDED_)
