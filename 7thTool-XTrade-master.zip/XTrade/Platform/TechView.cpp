#include "stdafx.h"
#include "TechView.h"
#include "../Base/Holiday.h"
#include "IndicatorPropertyDlg.h"

//////////////////////////////////////////////////////////////////////////
///QWndIndicator

#define INDICATOR_DISP_CHANGED_CURRENT	0X01
#define INDICATOR_DISP_CHANGED_CROSSCURSOR	0X02

IMPLEMENT_DYNCREATE_WND_OBJECTER(QWndIndicator,Objecter)

QWndIndicator::QWndIndicator()
{
	//
	m_bMainIndicator = FALSE;
	//
	m_msgPtr = new MsgEvent();
	//
	m_iPointInfoPtr = new IndicatorPointInfoEx();
}

QWndIndicator::~QWndIndicator()
{
	/*
	m_DrawPtr = 0;
	m_DispInfoPtr = 0;*/
}

HWND QWndIndicator::CreateControl(HWND hWndParent, LPCTSTR lpszWndClass, LPCTSTR lpszCtrlName, UINT nID, LPCTSTR lpszXml, UINT XmlFlag)
{
	//������ָ���ȥ,ע����ؼ̳�ָ��ת��
	return AddIndicator(lpszWndClass, lpszXml, XmlFlag);
}

HWND QWndIndicator::AddIndicator(LPCTSTR lpszClass, LPCTSTR lpszXml, UINT XmlFlag)
{
	HWND hWnd = MultiIndicatorMap::CreateObjecter(lpszClass, (HWND)dynamic_cast<WndObjecter*>(this), lpszXml, XmlFlag);

	int i;
	Objecter* pIndicator = GetObjecterBy(m_iInfoPtrs.size());
	if (pIndicator) {
		IndicatorInfoPtr infoPtr = new IndicatorInfo();
		//SendEvent(pIndicator, EVT_PLAT_CALL,MAKEVALUE(MGET_PLAT_INDICATOR,CGET_INDICATOR_INFO), infoPtr);
		m_iInfoPtrs.push_back(infoPtr);

		m_iIndexInfoPtrs.resize(m_iInfoPtrs.size());
		/*for (i=0; i<m_iInfoPtrs.back()->count; i++)
		{
			m_iIndexInfoPtrs.back().push_back(new IndicatorIndexInfo());
		}*/

		m_iInfoRects.resize(m_iInfoPtrs.size());

		UpdateInfos(); //����ָ����Ϣ
	}

	return hWnd;
}

void QWndIndicator::RemoveIndicator(UINT Pos)
{
	if (Pos<m_iInfoPtrs.size()) {
		m_iInfoPtrs.erase(m_iInfoPtrs.begin()+Pos);
		m_iIndexInfoPtrs.erase(m_iIndexInfoPtrs.begin()+Pos);
		m_iInfoRects.erase(m_iInfoRects.begin()+Pos);
	}

	return MultiIndicatorMap::DestroyObjecter(Pos);
}

void QWndIndicator::RemoveAllIndicator()
{
	m_iInfoPtrs.clear();
	m_iIndexInfoPtrs.clear();
	m_iInfoRects.clear();
	return MultiIndicatorMap::DestroyAllObjecter();
}

void QWndIndicator::OnCreateObjecter(Objecter* pObjecter)
{
	ASSERT(pObjecter);

	CRect rc;
	GetRect(&rc);
	m_msgPtr->message = WM_SIZE;
	m_msgPtr->wParam = 0;
	m_msgPtr->lParam = MAKELONG(rc.Width(),rc.Height());
	SendEvent(pObjecter, EVT_PLAT_CALL, MAKEVALUE(MCALL_PLAT_OBJECT,CCALL_OBJECT_SIZE), m_msgPtr);

	const ObjectDispInfoPtr& DispInfoPtr = GetDispInfoPtr();
	if (DispInfoPtr) {
		SendEvent(pObjecter, EVT_PLAT_CALL, MAKEVALUE(MSET_PLAT_OBJECT,CSET_OBJECT_DISPINFO), DispInfoPtr);
	}
	const IndicatorCalcInfoPtr& iCalcInfoPtr = GetiCalcInfoPtr();
	if (iCalcInfoPtr) {
		SendEvent(pObjecter, EVT_PLAT_CALL, MAKEVALUE(MSET_PLAT_INDICATOR,CSET_INDICATOR_CALCINFO), iCalcInfoPtr);
	}
	const IndicatorDispInfoPtr& iDispInfoPtr = GetiDispInfoPtr();
	if (DispInfoPtr) {
		SendEvent(pObjecter, EVT_PLAT_CALL, MAKEVALUE(MSET_PLAT_INDICATOR,CSET_INDICATOR_DISPINFO), iDispInfoPtr);
	}
	const IndicatorDispInfoExPtr& iDispInfoExPtr = GetiDispInfoExPtr();
	if (iDispInfoExPtr) {
		SendEvent(pObjecter, EVT_PLAT_CALL, MAKEVALUE(MSET_PLAT_INDICATOR,CSET_INDICATOR_DISPINFOEX), iDispInfoExPtr);
	}

	m_dc.DeleteDC();
	m_dcInfo.DeleteDC();
	m_dcCrossCursor.DeleteDC();
	Invalidate();
}


LRESULT QWndIndicator::OnCreate(UINT /*uMsg*/, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	LRESULT Res = DefWindowProc();

	return Res;
}

LRESULT QWndIndicator::OnDestroy(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& bHandled)
{
	bHandled = FALSE;

	RemoveAllIndicator();

	ClearHisData();

	m_dc.DeleteDC();
	m_dcInfo.DeleteDC();
	m_dcCrossCursor.DeleteDC();

	return bHandled;
}

LRESULT QWndIndicator::OnSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	CRect rc;
	GetRect(&rc);
	m_msgPtr->message = WM_SIZE;
	m_msgPtr->wParam = 0;
	m_msgPtr->lParam = MAKELONG(rc.Width(),rc.Height());
	BroadcastSend(EVT_PLAT_CALL,MAKEVALUE(MCALL_PLAT_OBJECT,CCALL_OBJECT_SIZE), m_msgPtr);

	if (wParam != SIZE_MINIMIZED && lParam != 0) {
		m_dc.DeleteDC();
		m_dcInfo.DeleteDC();
		m_dcCrossCursor.DeleteDC();
	}

	return 0;
}

LRESULT QWndIndicator::OnMouse(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	int i,j;
	POINT pt;
	POINTSTOPOINT(pt,lParam);
	for (i=0; i<m_iInfoRects.size(); i++)
	{
		if (PtInRect(&m_iInfoRects[i],pt)) {
			return bHandled;
		}
	}
	
	m_msgPtr->message = uMsg;
	m_msgPtr->wParam = wParam;
	m_msgPtr->lParam = lParam;
	Event evt(this,NULL,EVT_PLAT_CALL,MAKEVALUE(MCALL_PLAT_OBJECT,CCALL_OBJECT_MOUSE), m_msgPtr);
	BroadcastHandle(evt);
	bHandled = evt.handled;
	if(bHandled) {
		switch(uMsg)
		{
		case WM_LBUTTONDOWN:
		case WM_LBUTTONDBLCLK:
		case WM_RBUTTONDOWN:
		case WM_RBUTTONDBLCLK:
		case WM_MOUSEMOVE:
			break;
		default:
			return bHandled;
			break;
		}
	} 
	//else 
	{
		switch(uMsg)
		{
		case WM_RBUTTONDOWN:
			{
				UpdateIndexInfosByPoint(pt);
				i = GetObjecterPosBy(m_iPointInfoPtr->indicator);
				j = m_iPointInfoPtr->index;
				if (i<m_iIndexInfoPtrs.size()) {
					if (j<m_iIndexInfoPtrs[i].size()) {
						//�Ҽ�ָ����
						bHandled = TRUE;

						CMenu menu;
						menu.CreatePopupMenu();
						CMenuHandle subMenu;

						menu.AppendMenu(MF_STRING, ID_COMMAND_OPTION, _T("����"));
						menu.AppendMenu(MF_STRING, ID_TECHVIEW_INDICATOR_REMOVE, _T("�Ƴ�"));

						ClientToScreen(&pt);
						int nRet = (int)menu.TrackPopupMenu(TPM_RETURNCMD, pt.x, pt.y, GetTopLevelWindow(), NULL);
						switch(nRet)
						{
						case ID_COMMAND_OPTION:
							{
								CIndicatorPrppertyDlg dlg;
								dlg.DoModal(GetActiveWindow(), _T("<CIndicatorPrppertyDlg rect=\"0,0,380,280\" style=\"0x56010000\"></CIndicatorPrppertyDlg>"), XML_FLAG_STREAM);
							}
							break;
						case ID_TECHVIEW_INDICATOR_REMOVE:
							{
								RemoveIndicator(i);
								m_dc.DeleteDC();
								m_dcInfo.DeleteDC();
								m_dcCrossCursor.DeleteDC();
								Invalidate();
							}
							break;
						default:
							::PostMessage(GetTopLevelWindow(), WM_COMMAND, MAKEWPARAM(nRet, 0), (LPARAM)m_hWnd);
							break;
						}
					} else if (j==m_iIndexInfoPtrs[i].size()) {
						//�Ҽ�����ָ��
						bHandled = TRUE;

						CMenu menu;
						menu.CreatePopupMenu();
						CMenuHandle subMenu;

						menu.AppendMenu(MF_STRING, ID_TECHVIEW_INDICATOR_REMOVE, _T("�Ƴ�"));

						ClientToScreen(&pt);
						int nRet = (int)menu.TrackPopupMenu(TPM_RETURNCMD, pt.x, pt.y, GetTopLevelWindow(), NULL);
						switch(nRet)
						{
						case ID_TECHVIEW_INDICATOR_REMOVE:
							{
								RemoveIndicator(i);
								m_dc.DeleteDC();
								m_dcInfo.DeleteDC();
								m_dcCrossCursor.DeleteDC();
								Invalidate();
							}
							break;
						default:
							::PostMessage(GetTopLevelWindow(), WM_COMMAND, MAKEWPARAM(nRet, 0), (LPARAM)m_hWnd);
							break;
						}
					}
				}
			}
			break;
		default:
			break;
		}
	}

	if(!bHandled) 
	{
		MSG msg = {0};
		msg.hwnd = m_hWnd;
		msg.message = uMsg;
		msg.wParam = wParam;
		msg.lParam = lParam;
		bHandled = SendMessage(GetParent(), WM_BACKWARDMSG, 0, (LPARAM)&msg);
		if (bHandled) {
			switch(uMsg)
			{
			case WM_MOUSEMOVE:
				{
					//POINT pt;
					//POINTSTOPOINT(pt,lParam);
					//UpdateCurInfos(pt);
				}
			default:
				break;
			}
		}
	}
	return bHandled;
}

LRESULT QWndIndicator::OnKey(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	m_msgPtr->message = uMsg;
	m_msgPtr->wParam = wParam;
	m_msgPtr->lParam = lParam;
	Event evt(this,NULL,EVT_PLAT_CALL,MAKEVALUE(MCALL_PLAT_OBJECT,CCALL_OBJECT_KEY), m_msgPtr);
	if (RLT_OK != BroadcastHandle(evt)) {
		bHandled = FALSE;
	}
	return bHandled;
}

LRESULT QWndIndicator::OnUpdateCommandUI(CUpdateUIBase* pUpdateUI, BOOL& bHandled)
{
	/*if (!m_DispInfoPtr) {
		bHandled = FALSE;
		return bHandled;
	}

	int i;

	BAR* pBar = GetBar();
	UINT nBarCount = GetBarCount();

	for (i=0; i<KLINE_MAX; i++)
	{
		if (i != m_iDispInfoPtr->KLineType) {
			pUpdateUI->UISetRadio(ID_TECHVIEW_KLINE+i, FALSE);
		} else {
			pUpdateUI->UISetRadio(ID_TECHVIEW_KLINE+m_iDispInfoPtr->KLineType, TRUE);
		}
	}
	if (m_iDispInfoPtr->Start+m_iDispInfoPtr->Count <= nBarCount) {
		pUpdateUI->UISetCheck(ID_TECHVIEW_AUTO, TRUE);
	} else {
		pUpdateUI->UISetCheck(ID_TECHVIEW_AUTO, FALSE);
	}
	if (m_iDispInfoPtr->Start+m_iDispInfoPtr->Count < nBarCount) {
		pUpdateUI->UISetCheck(ID_TECHVIEW_SHIFT, TRUE);
	} else {
		pUpdateUI->UISetCheck(ID_TECHVIEW_SHIFT, FALSE);
	}
	if (m_iDispInfoPtr->Scale>=(MAX_BAR_SCALE-1)) {
		pUpdateUI->UIEnable(ID_TECHVIEW_LARGER, FALSE);
	} else {
		pUpdateUI->UIEnable(ID_TECHVIEW_LARGER, TRUE);
	}
	if (m_iDispInfoPtr->Scale<=0) {
		pUpdateUI->UIEnable(ID_TECHVIEW_SMALLER, FALSE);
	} else {
		pUpdateUI->UIEnable(ID_TECHVIEW_SMALLER, TRUE);
	}*/

	return bHandled;
}

LRESULT QWndIndicator::OnCommand(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	WORD wNotifyCode = HIWORD(wParam); 
	WORD wID = LOWORD(wParam); 
	HWND hwndCtrl = (HWND)lParam;
	m_hWnd;
	/*if (hwndCtrl) {
		switch(wNotifyCode) 
		{
		case EN_UPDATE:
		case STN_DBLCLK:
		default:
			bHandled = FALSE;
			break;
		}
	} else */{
		if(0) {
			//
		} else {
			if (wID>=ID_TECHVIEW_INDICATOR_ADDOBJECT && wID<=ID_TECHVIEW_INDICATOR_ADDOBJECT_MAX) {
				if(wID==ID_TECHVIEW_INDICATOR_ADDOBJECT) {
					//
				} else {
					TCHAR szBuf[1024] = {0};

					int Drawline = wID-ID_TECHVIEW_INDICATOR_ADDOBJECT;
					TCHAR szDrawline[260] = {0};

					_stprintf(szBuf, _T("<DrawLine name=\"%s\" ></DrawLine>"), Drawline2String(szDrawline, Drawline));
					AddIndicator(_T("DrawLine"), szBuf, XML_FLAG_STREAM);
				}
			} else {
				switch(wID)
				{
				case ID_TECHVIEW_INDICATOR_REMOVE:
				case ID_TECHVIEW_INDICATOR_INFO:
				case ID_TECHVIEW_INDICATOR_MODIFY_PARAM:
				case ID_TECHVIEW_INDICATOR_MODIFY_FORMULA:
					break;
				default:
					bHandled = FALSE;
					break;
				}
			}
		}
	}
	return bHandled;
}

void QWndIndicator::OnPaint(HDC hdc)
{
	ASSERT(hdc);

	if(!m_DispInfoPtr) {
		return;
	}

	if (!m_iCalcInfoPtr || !m_iDispInfoPtr) {
		CDCHandle dc(hdc);
		CRect rcClient;
		GetRect(&rcClient);
		dc.FillSolidRect(&rcClient, m_DispInfoPtr->crBackgnd);
	} else {
		Draw(hdc);
		DrawInfo(hdc);
		//DrawCrossCursor(hdc);
	}
}

bool QWndIndicator::IsDispOk()
{
	ASSERT (m_iDispInfoPtr);
	if (!IsBarOk()) {
		return false;
	}
	if (m_iDispInfoPtr->Start>=0&&m_iDispInfoPtr->Count>=0 
		&& (m_iDispInfoPtr->Start+m_iDispInfoPtr->Count)<=m_pHisData->count) {
			return true;
	}
	return false;
}

void QWndIndicator::Draw(HDC hdc)
{
	CRect rcClient;
	GetRect(&rcClient);

	if(!m_dc) {
		HFONT hOldFont = NULL;

		m_dc.CreateCompatibleDC(hdc, &rcClient);

		m_dc.SetBkMode(TRANSPARENT);
		hOldFont = m_dc.SelectFont(m_DispInfoPtr->hTechTitle);

		if (!m_iDispInfoPtr) {
			m_dc.FillSolidRect(&rcClient, m_DispInfoPtr->crBackgnd);
		} else {
			//���ָ�걳����������ֻ����һ��ָ��ı���
			Objecter* pActiveIndicator = GetObjecterBy(0);
			if (pActiveIndicator) {
				m_msgPtr->message = WM_ERASEBKGND;
				m_msgPtr->wParam = (WPARAM)(HDC)m_dc;
				m_msgPtr->lParam = 0L;
				SendEvent(pActiveIndicator, EVT_PLAT_CALL, MAKEVALUE(MCALL_PLAT_OBJECT,CCALL_OBJECT_ERASEBKGND), m_msgPtr);
			}

			CRect rcInfoBar;
			GetInfoBarRect(&rcInfoBar);
			if (IsInfoBarLeft()) {
				UIgdi::DrawLine(m_dc, rcInfoBar.right, rcInfoBar.top, rcInfoBar.right, rcInfoBar.bottom, PS_SOLID, 0, m_DispInfoPtr->crXYLine, R2_COPYPEN);
			} else {
				UIgdi::DrawLine(m_dc, rcInfoBar.left, rcInfoBar.top, rcInfoBar.left, rcInfoBar.bottom, PS_SOLID, 0, m_DispInfoPtr->crXYLine, R2_COPYPEN);
			}

			m_msgPtr->message = WM_PAINT;
			m_msgPtr->wParam = (WPARAM)(HDC)m_dc;
			m_msgPtr->lParam = 0L;
			BroadcastSend(EVT_PLAT_CALL, MAKEVALUE(MCALL_PLAT_OBJECT,CCALL_OBJECT_PAINT), m_msgPtr);
		}

		m_dc.SelectFont(hOldFont);
	}

	//DrawTextA(hdc, "ASDF", 4, &rcClient, DT_VCENTER|DT_CENTER|DT_SINGLELINE);
	//DrawForegnd(hdc, rcClient);
	::BitBlt(hdc, rcClient.left, rcClient.top, rcClient.Width(), rcClient.Height()
		, m_dc, rcClient.left, rcClient.top, SRCCOPY);
	//::TransparentBlt(hdc, rcClient.left, rcClient.top, rcClient.Width(), rcClient.Height()
	//	, m_dc, 0, 0, rcClient.Width(), rcClient.Height(), RGB(0,0,0));
}

void QWndIndicator::DrawInfo(HDC hdc)
{
	int i,j;

	CRect rcClient;
	GetRect(&rcClient);

	CRect rcTitle;
	GetTitleRect(&rcTitle);
	rcTitle.left += m_DispInfoPtr->xySpace.cx;

	if (!m_dcInfo) {
		CRect rcDraw = rcTitle;
		HFONT hOldFont = NULL;
		COLORREF crOldColor = CLR_NONE;

		m_dcInfo.CreateCompatibleDC(hdc, &rcClient);

		m_dcInfo.SetBkMode(TRANSPARENT);
		hOldFont = m_dcInfo.SelectFont(m_DispInfoPtr->hTechTitle);
		crOldColor = m_dcInfo.SetTextColor(m_DispInfoPtr->crTitle);

		wchar_t szBuf[1024] = {0};
		WCHAR szTitle[1024] = {0};
		int nTitleLen = 0;

		CRect rcCalc = rcDraw;

		if (m_bMainIndicator) {
			if (m_iCalcInfoPtr->DWType==DW_NONE) {
				nTitleLen = _stprintf(szTitle, _T("%hS(%s) "), m_iCalcInfoPtr->Object.Code
					, Period2String(szBuf,m_iCalcInfoPtr->Period,m_iCalcInfoPtr->PeriodEx));
			} else {
				TCHAR szDWType[MAX_PATH] = {0};
				nTitleLen = _stprintf(szTitle, _T("%hS(%s %s) "), m_iCalcInfoPtr->Object.Code
					, Period2String(szBuf,m_iCalcInfoPtr->Period,m_iCalcInfoPtr->PeriodEx), DWType2String(szDWType,m_iCalcInfoPtr->DWType));
			}
			m_dcInfo.DrawText(szTitle, nTitleLen
				, &rcCalc
				, DT_SINGLELINE|DT_LEFT|DT_TOP|DT_CALCRECT);
			m_dcInfo.DrawText(szTitle, nTitleLen
				, &rcCalc
				, DT_SINGLELINE|DT_LEFT|DT_TOP);
			rcDraw.left += rcCalc.Width();
			rcCalc = rcDraw;
		}

		for(i=0; i<m_iInfoPtrs.size(); i++)
		{
			if (!m_iInfoPtrs[i]->bOk) {
				continue;
			}

			Objecter* pIndicator = GetObjecterBy(i);
			if (!pIndicator) {
				continue;
			}

			if (m_iInfoPtrs[i]->count==1 && m_iInfoPtrs[i]->input.count>0) {
				TCHAR szFormat[1024];
				_stprintf(szFormat, _T("%s%s:%%.%df"), pIndicator->ToStr(STR_NAME)
					, m_iInfoPtrs[i]->input.value[0]
					, m_iInfoPtrs[i]->index[0].digits);
				nTitleLen = _stprintf(szTitle, szFormat, m_iIndexInfoPtrs[i][0]->result);
				m_dcInfo.SetTextColor(m_iInfoPtrs[i]->index[0].color==CLR_NONE?m_DispInfoPtr->crILine[0]:m_iInfoPtrs[i]->index[0].color);
				m_dcInfo.DrawText(szTitle, nTitleLen
					, &rcCalc
					, DT_SINGLELINE|DT_LEFT|DT_TOP|DT_CALCRECT);
				m_dcInfo.DrawText(szTitle, nTitleLen
					, &rcCalc
					, DT_SINGLELINE|DT_LEFT|DT_TOP);
				m_iInfoRects[i] = rcCalc;
				rcDraw.left += rcCalc.Width();
				rcCalc = rcDraw;
			} else {
				if (m_iInfoPtrs[i]->count>1) {
					wcscpy(szTitle, pIndicator->ToStr(STR_NAME));
					wcscat(szTitle, _T("("));
					for (j=0; j<m_iInfoPtrs[i]->input.count; j++)
					{
						wcscat(szTitle, m_iInfoPtrs[i]->input.value[j]);
						if (j!=m_iInfoPtrs[i]->input.count-1) {
							wcscat(szTitle, _T(","));
						}
					}
					wcscat(szTitle, _T(") "));
					nTitleLen = _tcslen(szTitle);
				} else {
					nTitleLen = swprintf(szTitle, L"%s ", pIndicator->ToStr(STR_NAME));
				}
				wcsupr(szTitle);
				m_dcInfo.SetTextColor(m_DispInfoPtr->crTitle);
				m_dcInfo.DrawText(szTitle, nTitleLen
					, &rcCalc
					, DT_SINGLELINE|DT_LEFT|DT_TOP|DT_CALCRECT);
				m_dcInfo.DrawText(szTitle, nTitleLen
					, &rcCalc
					, DT_SINGLELINE|DT_LEFT|DT_TOP);
				m_iInfoRects[i] = rcCalc;
				rcDraw.left += rcCalc.Width();
				rcCalc = rcDraw;

				for (j=0; j<m_iInfoPtrs[i]->count; j++)
				{
					TCHAR szText[1024] = {0};
					int nTextLen = 0;
					if (m_iInfoPtrs[i]->index[j].name[0]) {
						TCHAR szFormat[1024];
						_stprintf(szFormat, _T("%%s:%%.%df"), m_iInfoPtrs[i]->index[j].digits);
						nTextLen = _stprintf(szText, szFormat, m_iInfoPtrs[i]->index[j].name, m_iIndexInfoPtrs[i][j]->result);
					} else {
						TCHAR szFormat[1024];
						_stprintf(szFormat, _T("%%.%df"), m_iInfoPtrs[i]->index[j].digits);
						nTextLen = _stprintf(szText, szFormat, m_iIndexInfoPtrs[i][j]->result);
					}
					m_dcInfo.SetTextColor(m_iInfoPtrs[i]->index[j].color==CLR_NONE?m_DispInfoPtr->crILine[j]:m_iInfoPtrs[i]->index[j].color);
					m_dcInfo.DrawText(szText, nTextLen
						, &rcCalc
						, DT_SINGLELINE|DT_LEFT|DT_TOP|DT_CALCRECT);
					m_dcInfo.DrawText(szText, nTextLen
						, &rcCalc
						, DT_SINGLELINE|DT_LEFT|DT_TOP);
					m_iInfoRects[i].right = rcCalc.right;
					rcDraw.left += rcCalc.Width() + m_DispInfoPtr->xySpace.cx;
					rcCalc = rcDraw;
				}
			}

			rcDraw.left += m_DispInfoPtr->xySpace.cx;
			rcCalc = rcDraw;
		}

		m_dcInfo.SetTextColor(crOldColor);
		m_dcInfo.SelectFont(hOldFont);
	}

	::BitBlt(hdc, rcTitle.left, rcTitle.top, rcTitle.Width(), rcTitle.Height()
		, m_dcInfo, rcTitle.left, rcTitle.top, SRCCOPY);
	//::TransparentBlt(hdc, rcClient.left, rcTitle.bottom, rcClient.Width(), rcClient.Height()-rcTitle.Height()
	//	, m_dcInfo, rcClient.left, rcTitle.bottom, rcClient.Width(), rcClient.Height()-rcTitle.Height(), RGB(0,0,0));
}

void QWndIndicator::DrawCrossCursor(HDC hdc)
{
	ASSERT(hdc);

	ASSERT(m_DispInfoPtr);

	if (!m_iDispInfoPtr) {
		return;
	}
	if (!IsDispOk()) {
		return;
	}
	if (!m_iDispInfoPtr->bCrossCursor) {
		return;
	}
	POINT pt;
	POINTSTOPOINT(pt,m_iDispInfoPtr->bCrossCursor);
	ScreenToClient(&pt);

	CRect rcClient;
	GetClientRect(&rcClient);

	CRect rcMain;
	GetTechRect(&rcMain);

	BOOL bCross = PtInRect(&rcMain,pt);

	if (m_bMainIndicator) {
	} else {
		rcMain.top = rcClient.top;
	}
	
	if (!m_dcCrossCursor) {
		
		BAR* pBar = GetBar();
		UINT nBarCount = GetBarCount();

		m_dcCrossCursor.CreateCompatibleDC(hdc, &rcClient);

		m_dcCrossCursor.FillSolidRect(&rcClient, m_DispInfoPtr->crBackgnd);
		int nRop2Old = ::SetROP2(m_dcCrossCursor, R2_NOTXORPEN);

		if (bCross) {

		if (m_iDispInfoPtr->Current>=m_iDispInfoPtr->Start 
			&& m_iDispInfoPtr->Current<(m_iDispInfoPtr->Start+m_iDispInfoPtr->Count)) {
				CRect rcText;
				CRect rcCalc;
				TCHAR szText[1024];
				int nTextLen;

				//nTextLen = _stprintf(szText, _T("%.2f"), m_iPointInfoPtr->result);
				nTextLen = _tcslen(FormatFloatString(szText,m_iPointInfoPtr->result,2));
				m_dcCrossCursor.DrawText(szText, nTextLen, &rcCalc, DT_RIGHT|DT_SINGLELINE|DT_CALCRECT);
				if (m_iDispInfoPtr->InfoWidth >= 0) {
					rcText = rcClient;
					rcText.top = pt.y - rcCalc.Height();
					rcText.right = rcMain.left;
					rcText.bottom = pt.y;
					m_dcCrossCursor.FillSolidRect(&rcText,m_DispInfoPtr->crRptSelBackgnd);
					UIgdi::DrawText(m_dcCrossCursor, szText, nTextLen, &rcText, DT_RIGHT|DT_SINGLELINE, m_DispInfoPtr->crCrossCursor, m_DispInfoPtr->hYText);
				} else {
					rcText = rcClient;
					rcText.left = rcMain.right;
					rcText.top = pt.y - rcCalc.Height();
					rcText.bottom = pt.y;
					m_dcCrossCursor.FillSolidRect(&rcText,m_DispInfoPtr->crRptSelBackgnd);
					UIgdi::DrawText(m_dcCrossCursor, szText, nTextLen, &rcText, DT_LEFT|DT_SINGLELINE, m_DispInfoPtr->crCrossCursor, m_DispInfoPtr->hYText);
				}

				//����Ҫ��ʱ���α�
				//if (m_iPointInfoPtr->pos>=m_iDispInfoPtr->Start && m_iPointInfoPtr->pos<(m_iDispInfoPtr->Start+m_iDispInfoPtr->Count)) {
				//	unsigned long Year,Month,Day,Hour,Minute,Second;
				//	ULONG_TO_YYMMDD(pBar[m_iPointInfoPtr->pos].Date, Year, Month, Day);
				//	ULONG_TO_HHMMSS(pBar[m_iPointInfoPtr->pos].Time, Hour, Minute, Second);
				//	/*if(m_vDispInfoPtr->Period >= CYC_TICK && m_vDispInfoPtr->Period <= CYC_ANYSEC) {
				//	nTextLen = _stprintf(szText, _T("%d��%d�� %dʱ%d��%d��"), Month, Day, Hour, Minute, Second);
				//	} else if(m_vDispInfoPtr->Period >= CYC_1MIN && m_vDispInfoPtr->Period <= CYC_ANYMIN) {
				//	nTextLen = _stprintf(szText, _T("%02d��%d��%d�� %dʱ%d��"), Year%100, Month, Day, Hour, Minute);
				//	} else if(m_vDispInfoPtr->Period >= CYC_DAY && m_vDispInfoPtr->Period <= CYC_ANYDAY) {
				//	nTextLen = _stprintf(szText, _T("%02d��%d��%d��"), Year%100, Month, Day);
				//	} else */{
				//		if (!Month) {
				//			nTextLen = _stprintf(szText, _T("%04d"), Year);
				//		} else if (!Day) {
				//			nTextLen = _stprintf(szText, _T("%04d/%02d"), Year, Month);
				//		} else if (!Hour) {
				//			nTextLen = _stprintf(szText, _T("%04d/%02d/%02d"), Year, Month, Day);
				//		} else if (!Minute) {
				//			nTextLen = _stprintf(szText, _T("%04d/%02d/%02d %02d"), Year, Month, Day, Hour);
				//		} else if (!Second) {
				//			nTextLen = _stprintf(szText, _T("%04d/%02d/%02d %02d:%02d"), Year, Month, Day, Hour, Minute);
				//		} else {
				//			nTextLen = _stprintf(szText, _T("%04d/%02d/%02d %02d:%02d:%02d"), Year, Month, Day, Hour, Minute, Second);
				//		}
				//	}
				//	m_dcCrossCursor.DrawText(szText, nTextLen, &rcCalc, DT_LEFT|DT_SINGLELINE|DT_CALCRECT);
				//	rcText = rcClient;
				//	rcText.left = (rcClient.right-pt.x)<rcCalc.Width()?pt.x-rcCalc.Width():pt.x;
				//	rcText.top = rcClient.bottom - rcCalc.Height();
				//	rcText.right = rcText.left + rcCalc.Width();
				//	m_dcCrossCursor.FillSolidRect(&rcText,m_DispInfoPtr->crRptSelBackgnd);
				//	UIgdi::DrawText(m_dcCrossCursor, szText, nTextLen, &rcText, DT_LEFT|DT_SINGLELINE, m_DispInfoPtr->crCrossCursor, m_DispInfoPtr->hXText);
				//}
		}

		::MoveToEx(m_dcCrossCursor, rcMain.left, pt.y, NULL);
		::LineTo(m_dcCrossCursor, rcMain.right, pt.y);

		}

		::MoveToEx(m_dcCrossCursor, pt.x, rcMain.top, NULL);
		::LineTo(m_dcCrossCursor, pt.x, rcMain.bottom);
		
		::SetROP2(m_dcCrossCursor, nRop2Old);
	}

	TransparentBlt(hdc, rcClient.left, rcClient.top, rcClient.Width(), rcClient.Height()
		, m_dcCrossCursor, 0, 0, rcClient.Width(), rcClient.Height(), RGB(0,0,0));
}

void QWndIndicator::UpdateInfos()
{
	if (!m_iCalcInfoPtr) {
		return;
	}

	int i,j;
	for (i=0; i<m_iInfoPtrs.size(); i++)
	{
		if (!m_iInfoPtrs[i]->bOk)
		{
			SendEvent(GetObjecterBy((UINT)i), EVT_PLAT_CALL,MAKEVALUE(MGET_PLAT_INDICATOR,CGET_INDICATOR_INFO), m_iInfoPtrs[i]);
			m_iInfoPtrs[i]->bOk = TRUE;
			for (j=0; j<m_iInfoPtrs[i]->count; j++)
			{
				m_iIndexInfoPtrs[i].push_back(new IndicatorIndexInfo());
				m_iIndexInfoPtrs[i][j]->index = j;
			}
		}
	}
}

void QWndIndicator::UpdateIndexInfos()
{
	int i,j;
	for (i=0; i<m_iInfoPtrs.size(); i++)
	{
		if (!m_iInfoPtrs[i]->bOk) {
			continue;
		}

		Objecter* pIndicator = GetObjecterBy(i);
		ASSERT(pIndicator);
		if (!pIndicator) {
			continue;
		}

		for (j=0; j<m_iInfoPtrs[i]->count; j++)
		{
			m_iIndexInfoPtrs[i][j]->minvalue = EMPTY_VALUE;
			m_iIndexInfoPtrs[i][j]->maxvalue = EMPTY_VALUE;
			m_iIndexInfoPtrs[i][j]->mindispvalue = EMPTY_VALUE;
			m_iIndexInfoPtrs[i][j]->maxdispvalue = EMPTY_VALUE;
			SendEvent(pIndicator, EVT_PLAT_CALL, MAKEVALUE(MGET_PLAT_INDICATOR,CGET_INDICATOR_INDEXINFO), m_iIndexInfoPtrs[i][j]);
		}
	}

	if (m_iDispInfoPtr) {
		UpdateIndexInfosByPos(m_iDispInfoPtr->Current);
	}
}

void QWndIndicator::UpdateIndexInfosByPos(unsigned long pos)
{
	int i,j;
	for (i=0; i<m_iInfoPtrs.size(); i++)
	{
		if (!m_iInfoPtrs[i]->bOk) {
			continue;
		}
		Objecter* pIndicator = GetObjecterBy(i);
		ASSERT(pIndicator);
		if (!pIndicator) {
			continue;
		}

		for (j=0; j<m_iInfoPtrs[i]->count; j++)
		{
			m_iIndexInfoPtrs[i][j]->pos = pos;
			SendEvent(pIndicator, EVT_PLAT_CALL, MAKEVALUE(MGET_PLAT_INDICATOR,CGET_INDICATOR_INDEXINFOEX), m_iIndexInfoPtrs[i][j]);
		}
	}
}

void QWndIndicator::UpdateIndexInfosByPoint(POINT pt)
{
	m_iPointInfoPtr->pt = pt;
	//m_iPointInfoPtr->pos = 0;
	//m_iPointInfoPtr->result = 0;
	m_iPointInfoPtr->indicator = NULL;
	m_iPointInfoPtr->index = 0;
	SendEvent(EVT_PLAT_CALL, MAKEVALUE(MGET_PLAT_INDICATOR,CGET_INDICATOR_POINTINFOEX), m_iPointInfoPtr);
	UpdateIndexInfosByPos(m_iPointInfoPtr->pos);
}

bool QWndIndicator::UpdateMmxValue()
{
	if (!m_iDispInfoPtr) {
		return false;
	}
	/*if (bFrist) {
		m_iDispInfoExPtr->MinValue = EMPTY_VALUE;
		m_iDispInfoExPtr->MaxValue = EMPTY_VALUE;
		return true;
	} else {*/
		if (!m_iDispInfoExPtr) {
			return false;
		}
		double MinValue = 0.;
		double MaxValue = 0.;
		if (IsBarOk()) {
			MinValue = m_pHisData->bars[m_iDispInfoPtr->LowPrice].Low;
			MaxValue = m_pHisData->bars[m_iDispInfoPtr->HighPrice].High;
			//if(IsDispOk()) {
				//�����MMX����Ϊ0��ʵ��������Ч�����ݣ�����Ļ���Ҫ������Ч��ֵ����ΪEMPTY_VALUE�����漰���ܶ�ط�
				int i,j;
				for (i=0; i<m_iInfoPtrs.size(); i++)
				{
					if (!m_iInfoPtrs[i]->bOk) {
						continue;
					}
					for (j=0; j<m_iInfoPtrs[i]->count; j++)
					{
						if(m_iInfoPtrs[i]->index[j].style!=INDEX_LINE) {
							continue;
						}
						if (IsOverFloat(m_iIndexInfoPtrs[i][j]->mindispvalue) || IsOverFloat(m_iIndexInfoPtrs[i][j]->maxdispvalue)) {
							continue;
						}
						if(m_iIndexInfoPtrs[i][j]->mindispvalue < MinValue) {
							MinValue = m_iIndexInfoPtrs[i][j]->mindispvalue;
						}
						if(m_iIndexInfoPtrs[i][j]->maxdispvalue > MaxValue) {
							MaxValue = m_iIndexInfoPtrs[i][j]->maxdispvalue;
						}
					}
				}
			//}
		}
		//if (!IsEqualFloat(m_iDispInfoExPtr->MinValue,MinValue) || !IsEqualFloat(m_iDispInfoExPtr->MaxValue,MaxValue)) {
			m_iDispInfoExPtr->MinValue = MinValue;
			m_iDispInfoExPtr->MaxValue = MaxValue;
			return true;
		//}
	//}
	return false;
}

void QWndIndicator::OnDispInfoChanged()
{
	//��ͨ��ʾ��Ϣ�仯
	//����ֻ��Ҫ���»���

	BroadcastSend(EVT_PLAT_CALL, MAKEVALUE(MSET_PLAT_OBJECT,CSET_OBJECT_DISPINFO), m_DispInfoPtr);

	//�ػ�
	m_dc.DeleteDC();
	m_dcInfo.DeleteDC();
	m_dcCrossCursor.DeleteDC();
	Invalidate();
}

void QWndIndicator::OnViewInfoChanged()
{
	//�������ָ������
	//�����
	//1��MAKEVALUE(MSET_PLAT_INDICATOR,CSET_INDICATOR_CALCINFO)�����»�ȡָ������
	//2��MAKEVALUE(MSET_PLAT_INDICATOR,CSET_INDICATOR_DISPINFO)������������ʾ��Ϣ

	m_iCalcInfoPtr = 0;
	BroadcastSend(EVT_PLAT_CALL, MAKEVALUE(MSET_PLAT_INDICATOR,CSET_INDICATOR_CALCINFO), m_iCalcInfoPtr);
	m_iDispInfoPtr = 0;
	BroadcastSend(EVT_PLAT_CALL, MAKEVALUE(MSET_PLAT_INDICATOR,CSET_INDICATOR_DISPINFO), m_iDispInfoPtr);

	ClearHisData();

	m_dc.DeleteDC();
	m_dcInfo.DeleteDC();
	m_dcCrossCursor.DeleteDC();
	Invalidate();
}

void QWndIndicator::OnViewDispInfoChanged()
{
	
}

void QWndIndicator::OnIndicatorCalcInfoChanged()
{
	//֪ͨ��ʾָ��ˢ������
	BroadcastSend(EVT_PLAT_CALL, MAKEVALUE(MSET_PLAT_INDICATOR,CSET_INDICATOR_CALCINFO), m_iCalcInfoPtr);

	//������ʾָ����Ϣ
	UpdateInfos();

	//ˢ�µ�����
	ClearHisData();
	LoadHisData(m_iCalcInfoPtr->Object,m_iCalcInfoPtr->Period,m_iCalcInfoPtr->PeriodEx,m_iCalcInfoPtr->DWType,m_iCalcInfoPtr->DWDate);

	//�ػ�
	m_dc.DeleteDC();
	m_dcInfo.DeleteDC();
	m_dcCrossCursor.DeleteDC();
	Invalidate();
}

//OnCall�ﴦ���˸��¼�
void QWndIndicator::OnIndicatorDispInfoChanged()
{
	//BroadcastSend(EVT_PLAT_CALL, MAKEVALUE(MSET_PLAT_INDICATOR,CSET_INDICATOR_DISPINFO), m_iDispInfoPtr);
}

void QWndIndicator::OnRefresh(ObjectPtr objPtr)
{
	ASSERT(m_iCalcInfoPtr && m_iDispInfoPtr);
	BroadcastSend(EVT_PLAT_CALL, MAKEVALUE(MCALL_PLAT_OBJECT,CCALL_OBJECT_REFRESH), NULL);

	m_dc.DeleteDC();
	m_dcInfo.DeleteDC();
	m_dcCrossCursor.DeleteDC();
	Invalidate();
}

void QWndIndicator::OnInvalidate(ObjectPtr objPtr)
{
	m_dc.DeleteDC();
	m_dcInfo.DeleteDC();
	m_dcCrossCursor.DeleteDC();
	Invalidate();
}

void QWndIndicator::OnHisDataChanged(Event& evt)
{
	//����Ҫ������û��OnRefresh���յ�OnHisDataChanged�������������������ᴦ����

	//BroadcastSend(evt); ָ��ϵͳ���Զ�������Щ���ݸ����¼���

	ClearHisData();
	LoadHisData(m_iCalcInfoPtr->Object,m_iCalcInfoPtr->Period,m_iCalcInfoPtr->PeriodEx,m_iCalcInfoPtr->DWType,m_iCalcInfoPtr->DWDate);

	m_dc.DeleteDC();
	m_dcInfo.DeleteDC();
	m_dcCrossCursor.DeleteDC();
	Invalidate();
}

long QWndIndicator::OnCall(Event& evt)
{
	switch(evt.value)
	{
	case MAKEVALUE(MGET_PLAT_INDICATOR,CGET_INDICATOR_INDEXINFO):
		{
			evt.handled = m_bMainIndicator ? true : false;
			if (evt.handled) {
				IndicatorIndexInfoPtr IndexInfoPtr = IndicatorIndexInfoPtr::dynamicCast(evt.objPtr);
				if (IndexInfoPtr) {
					if (!IsObjecterEmpty()) {
						return SendEvent(GetObjecterBy((UINT)0), evt.evt, evt.value, evt.objPtr);
					}
				}
			}
		}
		break;
	case MAKEVALUE(MGET_PLAT_INDICATOR,CGET_INDICATOR_POINTINFO):
		{
			IndicatorPointInfoPtr pointInfoPtr = IndicatorPointInfoPtr::dynamicCast(evt.objPtr);
			if (pointInfoPtr) {
				if (!IsObjecterEmpty()) {
					return SendEvent(GetObjecterBy((UINT)0), evt.evt, evt.value, evt.objPtr);
				}
			}
		}
		break;
	case MAKEVALUE(MGET_PLAT_INDICATOR,CGET_INDICATOR_POINTINFOEX):
		{
			if (!IsObjecterEmpty()) {
				if(RLT_OK==SendEvent(GetObjecterBy((UINT)0), evt.evt, MAKEVALUE(MGET_PLAT_INDICATOR,CGET_INDICATOR_POINTINFO), evt.objPtr)) {
					BroadcastSend(evt.evt, evt.value, evt.objPtr);
				}
				return RLT_OK;
			}
		}
		break;
	case MAKEVALUE(MSET_PLAT_INDICATOR,CSET_INDICATOR_DISPINFO):
		{
			UINT Changed = 0;
			IndicatorDispInfoPtr iDispInfoPtr = IndicatorDispInfoPtr::dynamicCast(evt.objPtr);
			IndicatorDispInfoPtr iPreDispInfoPtr = m_iDispInfoPtr;
			m_iDispInfoPtr = iDispInfoPtr;
			ASSERT(iPreDispInfoPtr != iDispInfoPtr);
			if (iPreDispInfoPtr && iDispInfoPtr
				//&& iPreDispInfoPtr->Object == iDispInfoPtr->Object
				//&& iPreDispInfoPtr->Period == iDispInfoPtr->Period
				//&& iPreDispInfoPtr->PeriodEx == iDispInfoPtr->PeriodEx
				//&& iPreDispInfoPtr->DWType == iDispInfoPtr->DWType
				//&& iPreDispInfoPtr->DWDate == iDispInfoPtr->DWDate
				&& iPreDispInfoPtr->Start == iDispInfoPtr->Start
				&& iPreDispInfoPtr->Count == iDispInfoPtr->Count
				&& iPreDispInfoPtr->MaxCount == iDispInfoPtr->MaxCount
				&& iPreDispInfoPtr->InfoHeight == iDispInfoPtr->InfoHeight
				&& iPreDispInfoPtr->InfoWidth == iDispInfoPtr->InfoWidth
				&& iPreDispInfoPtr->TopSpace == iDispInfoPtr->TopSpace
				&& iPreDispInfoPtr->BottomSpace == iDispInfoPtr->BottomSpace
				&& iPreDispInfoPtr->Scale == iDispInfoPtr->Scale
				&& iPreDispInfoPtr->KLineType == iDispInfoPtr->KLineType
				&& iPreDispInfoPtr->KVolumeType == iDispInfoPtr->KVolumeType
				&& iPreDispInfoPtr->YCoordType == iDispInfoPtr->YCoordType
				&& iPreDispInfoPtr->XCoordType == iDispInfoPtr->XCoordType) {
					if (iPreDispInfoPtr->Current != iDispInfoPtr->Current) {
						Changed |= INDICATOR_DISP_CHANGED_CURRENT;
					}
					if (iPreDispInfoPtr->bCrossCursor != iDispInfoPtr->bCrossCursor) {
						Changed |= INDICATOR_DISP_CHANGED_CROSSCURSOR;
					}
			} else {
				Changed = (UINT)-1;
			}
			if (Changed) {
				BroadcastSend(EVT_PLAT_CALL, MAKEVALUE(MSET_PLAT_INDICATOR,CSET_INDICATOR_DISPINFO), evt.objPtr);
				if (Changed&INDICATOR_DISP_CHANGED_CURRENT) {
					UpdateIndexInfosByPos(iDispInfoPtr->Current);
					m_dcInfo.DeleteDC();
					Invalidate();
				}
				if (Changed&INDICATOR_DISP_CHANGED_CROSSCURSOR) {
					if (iDispInfoPtr->bCrossCursor) {
						POINT pt;
						POINTSTOPOINT(pt,iDispInfoPtr->bCrossCursor);
						ScreenToClient(&pt);
						CRect rcMain;
						GetTechRect(&rcMain);
						if (PtInRect(&rcMain,pt)) {
							UpdateIndexInfosByPoint(pt);
						}
						m_dcCrossCursor.DeleteDC();
						Invalidate();
					}
				}
				UpdateIndexInfos();
				if(UpdateMmxValue()) {
					BroadcastSend(EVT_PLAT_CALL, MAKEVALUE(MSET_PLAT_INDICATOR,CSET_INDICATOR_DISPINFOEX), m_iDispInfoExPtr);
				}
				if (Changed==(UINT)-1) {
					m_dc.DeleteDC();
					m_dcInfo.DeleteDC();
					m_dcCrossCursor.DeleteDC();
					Invalidate();
				}
			}
			return RLT_OK;
		}
		break;
	//////////////////////////////////////////////////////////////////////////
	/*case MAKEVALUE(MCALL_PLAT_OBJECT,CCALL_OBJECT_CONTEXTMENU):
		{
			ContextMenuEventPtr objPtr = ContextMenuEventPtr::dynamicCast(evt.objPtr);
			if (objPtr) {
				CMenuHandle menu(objPtr->hMenu);
				CMenuHandle subMenu;

				if (menu.GetMenuItemCount() > 0) {
					menu.AppendMenu(MF_SEPARATOR);
				}

				subMenu.Detach();
				subMenu.CreatePopupMenu();
				subMenu.AppendMenu(MF_STRING, ID_TECHVIEW_INDICATOR_TEMPLATE, _T("ָ��ģ�����"));
				subMenu.AppendMenu(MF_STRING, ID_TECHVIEW_INDICATOR_TEMPLATE_SAVE, _T("����"));
				subMenu.AppendMenu(MF_SEPARATOR);
				subMenu.AppendMenu(MF_STRING, ID_TECHVIEW_INDICATOR_TEMPLATE+1, _T("ģ��1"));
				subMenu.AppendMenu(MF_STRING, ID_TECHVIEW_INDICATOR_TEMPLATE+2, _T("ģ��2"));
				subMenu.AppendMenu(MF_STRING, ID_TECHVIEW_INDICATOR_TEMPLATE+3, _T("ģ��3"));
				menu.AppendMenu(MF_POPUP, subMenu, _T("ָ��ģ��"));

				subMenu.Detach();
				subMenu.CreatePopupMenu();
				subMenu.AppendMenu(MF_STRING, ID_TECHVIEW_INDICATOR, _T("ѡ��ָ��"));
				subMenu.AppendMenu(MF_SEPARATOR);
				subMenu.AppendMenu(MF_STRING, ID_TECHVIEW_INDICATOR+1, _T("ָ��1"));
				subMenu.AppendMenu(MF_STRING, ID_TECHVIEW_INDICATOR+2, _T("ָ��2"));
				subMenu.AppendMenu(MF_STRING, ID_TECHVIEW_INDICATOR+3, _T("ָ��3"));
				menu.AppendMenu(MF_POPUP, subMenu, _T("ָ���л�"));

				subMenu.Detach();
				subMenu.CreatePopupMenu();
				subMenu.AppendMenu(MF_STRING, ID_TECHVIEW_INDICATOR_ADD, _T("ѡ��ָ��"));
				subMenu.AppendMenu(MF_SEPARATOR);
				subMenu.AppendMenu(MF_STRING, ID_TECHVIEW_INDICATOR_ADD+1, _T("ָ��1"));
				subMenu.AppendMenu(MF_STRING, ID_TECHVIEW_INDICATOR_ADD+2, _T("ָ��2"));
				subMenu.AppendMenu(MF_STRING, ID_TECHVIEW_INDICATOR_ADD+3, _T("ָ��3"));
				menu.AppendMenu(MF_POPUP, subMenu, _T("ָ�����"));

				subMenu.Detach();
				subMenu.CreatePopupMenu();
				subMenu.AppendMenu(MF_STRING, ID_TECHVIEW_INDICATOR_ADDCOMMODITY, _T("ѡ����Ʒ"));
				subMenu.AppendMenu(MF_STRING, ID_TECHVIEW_INDICATOR_ADDOBJECT, _T("���Ӷ�Ӧָ��/���"));
				menu.AppendMenu(MF_POPUP, subMenu, _T("��Ʒ����"));

				menu.AppendMenu(MF_SEPARATOR);

				subMenu.Detach();
				subMenu.CreatePopupMenu();
				objPtr->hMenu = subMenu;
				menu.AppendMenu(MF_POPUP, subMenu, _T("ָ��"));
				BroadcastSend(EVT);
				objPtr->hMenu = menu;

				menu.AppendMenu(MF_STRING, ID_TECHVIEW_INDICATOR_USER, _T("ָ�����"));
			}
			return RLT_OK;
		}
		break;*/
	default:
		evt.handled = false;
		break;
	}
	return RLT_UNKNOWN;
}

long QWndIndicator::OnNotify(Event& evt)
{
	switch(evt.value)
	{
	default:
		evt.handled = false;
		break;
	}
	return RLT_UNKNOWN;
}


//////////////////////////////////////////////////////////////////////////
///QMainWndIndicator

IMPLEMENT_DYNCREATE_WND_OBJECTER(QMainWndIndicator,Objecter)

QMainWndIndicator::QMainWndIndicator():QWndIndicator()
{
	m_bMainIndicator = TRUE;
	m_pWndTrader = NULL;
	//
	m_iDispInfoExPtr = new IndicatorDispInfoEx();
}

QMainWndIndicator::~QMainWndIndicator()
{

}

LRESULT QMainWndIndicator::OnDestroy(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& bHandled)
{
	bHandled = FALSE;

	DestroyObject(m_pWndTrader);

	return bHandled;
}

void QMainWndIndicator::ShowMiniTrader()
{
	return;
	HWND hWndTrader = NULL;
	if (!m_pWndTrader) {
		hWndTrader = CreateObject(m_pWndTrader, _T("MiniTradeView"), m_hWnd, _T("<MiniTradeView />"), XML_FLAG_STREAM);
		ASSERT(hWndTrader);
	} else {
		hWndTrader = m_pWndTrader->GetHwnd();
	}
	if(hWndTrader) {
		UIWnd2 wndTrader(hWndTrader);
		wndTrader.SetWindowSize(250,100);
		wndTrader.ShowWindow(SW_SHOW);
	}
}

void QMainWndIndicator::HideMiniTrader()
{
	if(m_pWndTrader) {
		UIWnd2 wndTrader(m_pWndTrader->GetHwnd());
		wndTrader.ShowWindow(SW_HIDE);
	}
}

long QMainWndIndicator::OnCall(Event& evt)
{
	switch(evt.value)
	{
	default:
		evt.handled = false;
		break;
	}
	return RLT_UNKNOWN;
}

//////////////////////////////////////////////////////////////////////////
///QTechView

IMPLEMENT_DYNCREATE_WND_OBJECTER(QTechView,Objecter)

QTechView::QTechView()
{
	m_bCrossCursor = FALSE;
	//
	memset(&m_ptCoordinate, 0, sizeof(m_ptCoordinate));
	m_bMoveCoordinate = FALSE;

	//SET
	m_iCalcInfoPtr = new IndicatorCalcInfo();
	m_iPreDispInfoPtr = new IndicatorDispInfo();
	m_iDispInfoPtr = new IndicatorDispInfo();
	m_iPointInfoPtr = new IndicatorPointInfo();
	m_iBufferInfoPtr = new IndicatorIndexInfo();
}

HWND QTechView::CreateControl(HWND hWndParent, LPCTSTR lpszWndClass, LPCTSTR lpszCtrlName, UINT nID, LPCTSTR lpszXml, UINT XmlFlag)
{
	/*if (_tcsicmp(lpszWndClass, Pane::GetXmlPaneName()) != 0) {
		HWND hWndCtrl = ViewSplitter::CreateObjecter(lpszWndClass, lpszCtrlName, hWndParent, lpszXml, XmlFlag);
		OnCreateControl(hWndParent, hWndCtrl, lpszWndClass, lpszCtrlName, nID);
		return hWndCtrl;
	}*/
	return ViewSplitter::CreateControl(hWndParent, lpszWndClass, lpszCtrlName, nID, lpszXml, XmlFlag);
}

/*void QTechView::OnCreateControl(HWND hWndParent, HWND hWndCtrl, LPCTSTR lpszWndClass, LPCTSTR lpszCtrlName, UINT nID)
{
	PaneSplitter::OnCreateControl(hWndParent, hWndCtrl, lpszWndClass, lpszCtrlName, nID);
}

void QTechView::OnCloseControl(HWND hWndCtrl, LPCTSTR lpszWndClass, LPCTSTR lpszCtrlName)
{
	PaneSplitter::OnCloseControl(hWndCtrl, lpszWndClass, lpszCtrlName);
}*/

BOOL QTechView::GetLayoutRect(LPRECT lpRect)
{
	BOOL bRet = GetClientRect(lpRect);
	if (m_DispInfoPtr) {
		lpRect->bottom -= m_DispInfoPtr->xyCoordinate.cy + GetHBorder();
	}
	return bRet;
}

void QTechView::AddWndIndicator(HWND hWnd)
{
	RECT rcClient;
	GetClientRect(&rcClient);

	UINT i = 0;
	UINT nObjecterCount = GetObjecterCount();
	
	TCHAR szName[260] = {0};
	_stprintf(szName, _T("%d"), nObjecterCount);

	Pane* pBefore = NULL;
	if (hWnd) {
		pBefore = ChildPaneFromWindow(hWnd);
		pBefore = pBefore->Next();
	}

	//����PANE
	/*Pane* pPane = NULL;
	RECT rcIndicator = rcClient;

	i = 0;
	pPane = ChildPaneFromPos(i);
	pPane->GetRect(&rcIndicator);
	rcIndicator.bottom -= (m_DispInfoPtr->xyWndIndicator.cy+GetHBorder());
	//pPane->Relayout(&rcIndicator);
	pPane->SetRect(&rcIndicator);

	i = 1;
	while(i<=Pos && (pPane=ChildPaneFromPos((UINT)i)))
	{
		pPane->GetRect(&rcIndicator);
		OffsetRect(&rcIndicator, 0, -(m_DispInfoPtr->xyWndIndicator.cy+GetHBorder()));
		//pPane->Relayout(&rcIndicator);
		pPane->SetRect(&rcIndicator);

		i++;
	}

	rcIndicator.top = rcIndicator.bottom + Pane::GetHBorder();
	rcIndicator.bottom = rcIndicator.top + m_DispInfoPtr->xyWndIndicator.cy;
	
	TCHAR szPane[1024];
	_stprintf(szPane, _T("<Pane name=\"%s\" rect=\"%d,%d,%d,%d\" style=\"196\"/>")
		, szName, rcIndicator.left, rcIndicator.top, rcIndicator.right, rcIndicator.bottom);
	m_pP->CreateControl(m_hWnd, Pane::GetXmlPaneName(), szName, 0, szPane, XML_FLAG_STREAM);
	pPane = m_pP->ChildPaneFromPos(Pos);
	Pane* pNew = m_pP->LastChild();
	pNew->Free();
	pPane->Next(pNew);*/
	RECT rcNew = {0};
	rcNew.bottom = m_DispInfoPtr->xyWndIndicator.cy;
	Insert(&rcNew, PANEL_STYLE_LR_SCALE|PANEL_STYLE_SIZED, szName, pBefore);
	//���Ӵ���
	TCHAR szXml[1024] = {0};
	_stprintf(szXml, _T("<WndIndicator name=\"%s\"></WndIndicator>"), szName);
	HWND hWndNew = CreateControl(m_hWnd, _T("WndIndicator"), szName, 0, szXml, XML_FLAG_STREAM);
	/*RECT rcNew = {0};
	rcNew.bottom = m_DispInfoPtr->xyWndIndicator.cy;
	TCHAR szXml[1024] = {0};
	_stprintf(szXml, _T("<WndIndicator name=\"%s\"></WndIndicator>"), szName);
	HWND hWndNew = InsertObjecter(&rcNew, PANEL_STYLE_LR_SCALE|PANEL_STYLE_SIZED, szName
		, ChildPaneFromPos(nPos)
		, _T("WndIndicator")
		, szXml, XML_FLAG_STREAM);*/
	//pNew->Relayout(&rcIndicator);

	/*ViewSplitter�Ѿ���������Щ
	WndObjecter* pWndObjecter = GetObjecterBy(hWnd);
	if (pWndObjecter) {
		const ViewInfoPtr & InfoPtr = GetViewInfoPtr();
		if (InfoPtr) {
			SendEvent(pWndObjecter, EVT_PLAT_CALL, MAKEVALUE(MSET_PLAT_OBJECT,CSET_VIEW_INFO), InfoPtr);
		}
		const ViewDispInfoPtr & DispInfoPtr = GetViewDispInfoPtr();
		if (DispInfoPtr) {
			SendEvent(pWndObjecter, EVT_PLAT_CALL, MAKEVALUE(MSET_PLAT_OBJECT,CSET_VIEW_DISPINFO), DispInfoPtr);
		}
	}*/

	Relayout();
	Invalidate();
}

void QTechView::RemoveWndIndicator(HWND hWnd)
{
	if (hWnd && hWnd != m_hWnd) {
		WndObjecter* pObjecter = GetObjecterBy(hWnd);
		DestroyObjecter(pObjecter);

		Pane* pPane = ChildPaneFromWindow(hWnd);
		if (pPane) {
			m_pP1 = pPane;
			SendMessage(WM_COMMAND, ID_PANE_CLOSE, (LPARAM)m_pP1);
		}

		Relayout();
		Invalidate();
	}
}

BOOL QTechView::PreTranslateMessage(MSG* pMsg)
{
	BOOL bHandled = FALSE;//Base::PreTranslateMessage(pMsg);
	if (pMsg->message == WM_KEYDOWN) {
		bHandled = TRUE;
		OnKey(pMsg->message, pMsg->wParam, pMsg->lParam, bHandled);
	}
	return bHandled;
}

LRESULT QTechView::OnCreate(UINT /*uMsg*/, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	LRESULT rlt = DefWindowProc();

	return rlt;
}

LRESULT QTechView::OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	bHandled = FALSE;

	ClearHisData();

	m_dcCoordinate.DeleteDC();
	m_dcCrossCursor.DeleteDC();

	return bHandled;
}

LRESULT QTechView::OnSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	ViewSplitter::OnSize(uMsg, wParam, lParam, bHandled);

	if (wParam != SIZE_MINIMIZED && lParam != 0) {
		if (m_DispInfoPtr) {
			if (IsDispOk()) {
				m_dcCrossCursor.DeleteDC();
				m_dcCoordinate.DeleteDC();

				SwapIndicatorDispInfo();
				//�����ʾС��������ʾ����Size�仯������ǰ����ʾ
				if (m_iDispInfoPtr->Count<m_iDispInfoPtr->MaxCount) {
					m_iDispInfoPtr->MaxCount = -1;
				}
				UpdateIndicatorDispInfo(UD_SIZECHANGE);
			}
		}
	}

	return 0;
}


LRESULT QTechView::OnMouse(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	switch(uMsg)
	{
	case WM_LBUTTONDOWN:
		{
			ViewSplitter::OnLButtonDown(uMsg, wParam, lParam, bHandled);
			if(bHandled) {
				break;
			}

			if (!IsDispOk()) {
				break;
			}

			POINT pt;
			POINTSTOPOINT(pt,lParam);
			RECT rcCoordinate;
			GetCoordinateRect(&rcCoordinate);
			if (PtInRect(&rcCoordinate,pt)) {
				m_ptCoordinate = pt;
				m_bMoveCoordinate = TRUE;
				SetCapture();
			}
		}
		break;
	case WM_LBUTTONUP:
		{
			ViewSplitter::OnLButtonUp(uMsg, wParam, lParam, bHandled);
			if(bHandled) {
				break;
			}

			if (m_bMoveCoordinate) {
				memset(&m_ptCoordinate, 0, sizeof(POINT));
				m_bMoveCoordinate = FALSE;
				ReleaseCapture();
			}
		}
		break;
	case WM_LBUTTONDBLCLK:
		{
			if (!IsDispOk()) {
				break;
			}

			POINT pt;
			POINTSTOPOINT(pt,lParam);

			RECT rcClient;
			GetTechRect(&rcClient);
			if (!PtInRect(&rcClient,pt)) {
				break;
			}

			ShowCurrent(pt,TRUE);
		}
		break;
	case WM_RBUTTONDOWN:
		{
			if (!IsDispOk()) {
				break;
			}

			BAR* pBar = GetBar();
			UINT nBarCount = GetBarCount();

			TCHAR szBuf[MAX_PATH] = {0};

			POINT pt;
			POINTSTOPOINT(pt,lParam);

			CMenu menu;
			menu.CreatePopupMenu();
			CMenuHandle subMenu;

			COMREF Commodity;
			GetCurCommodity(&Commodity);

			HWND hWnd = ChildWindowFromPointEx(pt,CWP_SKIPINVISIBLE);
			WndObjecter* pObjecter = GetObjecterBy(hWnd);

			if (pObjecter) {
				if (_tcsicmp(pObjecter->GetThisClassName(),QMainWndIndicator::GetClassName()) == 0) {
					m_iPointInfoPtr->pt = pt;
					ClientToScreen(&m_iPointInfoPtr->pt);
					UIWnd2 wndObjecter = pObjecter->GetHwnd();
					wndObjecter.ScreenToClient(&m_iPointInfoPtr->pt);
					m_iPointInfoPtr->pos = 0;
					m_iPointInfoPtr->result = 0.;
					Event evt(this, pObjecter, EVT_PLAT_CALL, MAKEVALUE(MGET_PLAT_INDICATOR,CGET_INDICATOR_POINTINFO), m_iPointInfoPtr);
					SendEvent(evt);
					if (evt.handled) {
						double price = m_iPointInfoPtr->result;
						double now = pBar[nBarCount-1].Close;
						if (price > now) {
							menu.AppendMenu(MF_STRING, ID_CONTAINER_ORDER_BUY, _T("����"));
							menu.AppendMenu(MF_STRING, ID_CONTAINER_ORDER_SELL, _T("����"));
							_stprintf(szBuf, _T("�޼�����\t%f"), price);
							menu.AppendMenu(MF_STRING, ID_CONTAINER_ORDER_SEND_LIMIT, szBuf);
							menu.AppendMenu(MF_STRING, ID_CONTAINER_ORDER_SEND_STOP, _T("ͻ������"));
						} else {
							menu.AppendMenu(MF_STRING, ID_CONTAINER_ORDER_BUY, _T("����"));
							menu.AppendMenu(MF_STRING, ID_CONTAINER_ORDER_SELL, _T("����"));
							_stprintf(szBuf, _T("�޼�����\t%f"), price);
							menu.AppendMenu(MF_STRING, ID_CONTAINER_ORDER_SEND_LIMIT, szBuf);
							menu.AppendMenu(MF_STRING, ID_CONTAINER_ORDER_SEND_STOP, _T("��������"));
						}
						//menu.AppendMenu(MF_STRING, ID_CONTAINER_ORDER_CLOSE, _T("ƽ��"));
						menu.AppendMenu(MF_SEPARATOR);
					}
					//menu.AppendMenu(MF_STRING, ID_TECHVIEW_SHOWMINITRADER, _T("һ������"));
					//menu.AppendMenu(MF_SEPARATOR);
				}
			}
			//menu.AppendMenu(MF_STRING, ID_COMMAND_BACK, _T("����"));
			//menu.AppendMenu(MF_STRING, ID_CONTAINER_PAGEUP, _T("ǰֻƷ��"));
			//menu.AppendMenu(MF_STRING, ID_CONTAINER_PAGEDOWN, _T("��ֻƷ��"));
			//menu.AppendMenu(MF_SEPARATOR);
			menu.AppendMenu(MF_STRING, ID_TECHVIEW_TEMPLATE, _T("ģ��"));
			menu.AppendMenu(MF_STRING, ID_TECHVIEW_TEMPLATE, _T("ʹ��Ĭ��"));
			//menu.AppendMenu(MF_STRING, ID_CONTAINER_F10, _T("F10"));
			//menu.AppendMenu(MF_STRING, ID_CONTAINER_F10, _T("������ͼ"));
			//menu.AppendMenu(MF_STRING, ID_CONTAINER_F10, _T("�Ҳ���Ϣ��"));
			//menu.AppendMenu(MF_STRING, ID_CONTAINER_F10, _T("�ײ���Ϣ��"));
			menu.AppendMenu(MF_SEPARATOR);

			subMenu.Detach();
			subMenu.CreatePopupMenu();
			subMenu.AppendMenu(MF_STRING, ID_TECHVIEW_KLINE+KLINE_K,		_T("K ������"));
			subMenu.AppendMenu(MF_STRING, ID_TECHVIEW_KLINE+KLINE_BAR,		_T("BAR ������"));
			//subMenu.AppendMenu(MF_SEPARATOR);
			subMenu.AppendMenu(MF_STRING, ID_TECHVIEW_KLINE+KLINE_TREND,	_T("TREND ������"));
			subMenu.CheckMenuItem(ID_TECHVIEW_KLINE+m_iDispInfoPtr->KLineType, MF_CHECKED);
			subMenu.AppendMenu(MF_SEPARATOR);
			subMenu.AppendMenu(MF_STRING, ID_TECHVIEW_VOLUME+STICK_LINE,	_T("(��/��)��"));
			subMenu.AppendMenu(MF_STRING, ID_TECHVIEW_VOLUME+STICK_BAR,		_T("(��/��)��"));
			subMenu.CheckMenuItem(ID_TECHVIEW_VOLUME+m_iDispInfoPtr->KVolumeType, MF_CHECKED);
			menu.AppendMenu(MF_POPUP, subMenu, _T("��ʾ"));

			subMenu.Detach();
			subMenu.CreatePopupMenu();
			subMenu.AppendMenu(MF_STRING, ID_TECHVIEW_COORDINATE+0, _T("��ͨ����"));
			subMenu.AppendMenu(MF_STRING, ID_TECHVIEW_COORDINATE+1, _T("��������"));
			if (m_iDispInfoPtr->YCoordType & CT_LOG) {
				subMenu.CheckMenuItem(ID_TECHVIEW_COORDINATE+1, MF_CHECKED);
			} else {
				subMenu.CheckMenuItem(ID_TECHVIEW_COORDINATE+0, MF_CHECKED);
			}
			subMenu.AppendMenu(MF_SEPARATOR);
			subMenu.AppendMenu(MF_STRING, ID_TECHVIEW_COORDINATE+2, _T("�Ȳ�����"));
			subMenu.AppendMenu(MF_STRING, ID_TECHVIEW_COORDINATE+3, _T("�ȱ�����"));
			subMenu.AppendMenu(MF_STRING, ID_TECHVIEW_COORDINATE+4, _T("�ٷֱ�����"));
			subMenu.AppendMenu(MF_STRING, ID_TECHVIEW_COORDINATE+5, _T("�ƽ�ָ�"));
			if (m_iDispInfoPtr->YCoordType & CT_DIFF) {
				subMenu.CheckMenuItem(ID_TECHVIEW_COORDINATE+2, MF_CHECKED);
			} else if (m_iDispInfoPtr->YCoordType & CT_SCALE) {
				subMenu.CheckMenuItem(ID_TECHVIEW_COORDINATE+3, MF_CHECKED);
			} else if (m_iDispInfoPtr->YCoordType & CT_PERCENT) {
				subMenu.CheckMenuItem(ID_TECHVIEW_COORDINATE+4, MF_CHECKED);
			} else if (m_iDispInfoPtr->YCoordType & CT_GOLDEN) {
				subMenu.CheckMenuItem(ID_TECHVIEW_COORDINATE+5, MF_CHECKED);
			}
			subMenu.AppendMenu(MF_SEPARATOR);
			subMenu.AppendMenu(MF_STRING, ID_TECHVIEW_COORDINATE_X_LR, m_iDispInfoPtr->InfoWidth>0?_T("������ʾ���Ҳ�"):_T("������ʾ�����"));
			menu.AppendMenu(MF_POPUP, subMenu, _T("����ϵͳ"));

			menu.AppendMenu(MF_SEPARATOR);

			subMenu.Detach();
			subMenu.CreatePopupMenu();
			subMenu.AppendMenu(MF_STRING, ID_CONTAINER_PERIOD+CYC_TICK, _T("��"));
			//subMenu.AppendMenu(MF_STRING, ID_CONTAINER_PERIOD+CYC_1SEC, _T("1��"));
			subMenu.AppendMenu(MF_STRING, ID_CONTAINER_PERIOD+CYC_5SEC, _T("5��"));
			subMenu.AppendMenu(MF_STRING, ID_CONTAINER_PERIOD+CYC_ANYSEC, _T("������"));
			subMenu.AppendMenu(MF_SEPARATOR);
			subMenu.AppendMenu(MF_STRING, ID_CONTAINER_PERIOD+CYC_1MIN, _T("1����"));
			subMenu.AppendMenu(MF_STRING, ID_CONTAINER_PERIOD+CYC_5MIN, _T("5����"));
			subMenu.AppendMenu(MF_STRING, ID_CONTAINER_PERIOD+CYC_15MIN, _T("15����"));
			subMenu.AppendMenu(MF_STRING, ID_CONTAINER_PERIOD+CYC_30MIN, _T("30����"));
			subMenu.AppendMenu(MF_STRING, ID_CONTAINER_PERIOD+CYC_60MIN, _T("60����"));
			subMenu.AppendMenu(MF_STRING, ID_CONTAINER_PERIOD+CYC_ANYMIN, _T("�������"));
			subMenu.AppendMenu(MF_SEPARATOR);
			subMenu.AppendMenu(MF_STRING, ID_CONTAINER_PERIOD+CYC_DAY, _T("����"));
			subMenu.AppendMenu(MF_STRING, ID_CONTAINER_PERIOD+CYC_WEEK, _T("����"));
			subMenu.AppendMenu(MF_STRING, ID_CONTAINER_PERIOD+CYC_MONTH, _T("����"));
			subMenu.AppendMenu(MF_STRING, ID_CONTAINER_PERIOD+CYC_SEASON, _T("����"));
			subMenu.AppendMenu(MF_STRING, ID_CONTAINER_PERIOD+CYC_YEAR, _T("����"));
			subMenu.AppendMenu(MF_STRING, ID_CONTAINER_PERIOD+CYC_ANYDAY, _T("��������"));
			subMenu.CheckMenuItem(ID_CONTAINER_PERIOD+m_vDispInfoPtr->Period, MF_CHECKED);
			menu.AppendMenu(MF_POPUP, subMenu, _T("����"));

			subMenu.Detach();
			subMenu.CreatePopupMenu();
			subMenu.AppendMenu(MF_STRING, ID_CONTAINER_DW+DW_NONE, _T("����Ȩ"));
			subMenu.AppendMenu(MF_STRING, ID_CONTAINER_DW+DW_FORWARD, _T("ǰ��Ȩ"));
			subMenu.AppendMenu(MF_SEPARATOR);
			subMenu.AppendMenu(MF_STRING, ID_CONTAINER_DW+DW_BACKWARD, _T("��Ȩ"));
			subMenu.AppendMenu(MF_STRING, ID_CONTAINER_DW+DW_DAY, _T("���㸴Ȩ"));
			if (m_vDispInfoPtr->DWType == DW_NONE) {
				subMenu.CheckMenuItem(ID_CONTAINER_DW+DW_NONE, MF_CHECKED);
			} else if (m_vDispInfoPtr->DWType == DW_FORWARD) {
				subMenu.CheckMenuItem(ID_CONTAINER_DW+DW_FORWARD, MF_CHECKED);
			} else if (m_vDispInfoPtr->DWType == DW_BACKWARD) {
				subMenu.CheckMenuItem(ID_CONTAINER_DW+DW_BACKWARD, MF_CHECKED);
			} else if (m_vDispInfoPtr->DWType == DW_DAY) {
				subMenu.CheckMenuItem(ID_CONTAINER_DW+DW_DAY, MF_CHECKED);
			}
			menu.AppendMenu(MF_POPUP, subMenu, _T("��Ȩ��Ȩ"));

			menu.AppendMenu(MF_SEPARATOR);
			menu.AppendMenu(MF_STRING, ID_TECHVIEW_ADD, _T("����ָ�괰��"));
			menu.AppendMenu(MF_STRING, ID_TECHVIEW_REMOVE, _T("ɾ��ָ�괰��"));

			//if (pObjecter) {
			//	SendEvent(pObjecter, EVT_PLAT_CALL, MAKEVALUE(MCALL_PLAT_OBJECT,CCALL_OBJECT_CONTEXTMENU), m_ContextMenuPtr);
			//}

			menu.AppendMenu(MF_SEPARATOR);
			menu.AppendMenu(MF_STRING, ID_COMMAND_OPTION, _T("����"));

			ClientToScreen(&pt);
			int nRet = (int)menu.TrackPopupMenu(TPM_RETURNCMD, pt.x, pt.y, GetTopLevelWindow(), NULL);
			switch(nRet)
			{
			case ID_CONTAINER_ORDER_BUY:
				{
					OrderSend(Commodity, OP_BUY, 0.1, m_iPointInfoPtr->result, 0, 0, 0);
				}
				break;
			case ID_CONTAINER_ORDER_SELL:
				{
					OrderSend(Commodity, OP_SELL, 0.1, m_iPointInfoPtr->result, 0, 0, 0);
				}
				break;
			case ID_CONTAINER_ORDER_SEND_LIMIT:
			case ID_CONTAINER_ORDER_SEND_STOP:
				{
					
				}
				break;
			case ID_CONTAINER_ORDER_CLOSE:
				break;
			default:
				::PostMessage(GetTopLevelWindow(), WM_COMMAND, MAKEWPARAM(nRet, 0), (LPARAM)hWnd);
				break;
			}
		}
		break;
	case WM_MOUSEMOVE:
		{
			ViewSplitter::OnMouseMove(uMsg, wParam, lParam, bHandled);
			if(bHandled) {
				break;
			}

			if (!IsDispOk()) {
				break;
			}
			
			POINT pt;
			POINTSTOPOINT(pt,lParam);

			if(m_bMoveCoordinate) {
				int kWidth = m_DispInfoPtr->nBarWidth[m_iDispInfoPtr->Scale] + m_DispInfoPtr->nBarSpace[m_iDispInfoPtr->Scale];
				short nOffset = (short)(pt.x-m_ptCoordinate.x)/kWidth;
				if(nOffset != 0) {
					m_ptCoordinate = pt;
					SendMessage(WM_COMMAND, MAKEWPARAM(ID_TECHVIEW_FORWARD,nOffset), 0);
					m_dcCoordinate.DeleteDC();
					m_dcCrossCursor.DeleteDC();
					Invalidate();
				}
				break;
			}

			RECT rcClient;
			GetTechRect(&rcClient);
			if (!PtInRect(&rcClient,pt)) {
				HideCrossCursor();
				break;
			}

			if (m_bCrossCursor) {
				ShowCurrent(pt);
				break;
			}
		}
		break;
	default:
		bHandled = FALSE;
		break;
	}
	return bHandled;
}

LRESULT QTechView::OnKey(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	bHandled = FALSE;
	switch(uMsg)
	{
	case WM_KEYDOWN:
	//case WM_KEYUP:
		if (wParam == VK_ESCAPE) {
			if (IsDispOk()) {
				if (m_bCrossCursor) {
					ShowCurrent(m_iDispInfoPtr->Current,FALSE);
					bHandled = TRUE;
				}
			}
		}
		break;
	}
	return bHandled;
}

LRESULT QTechView::OnPaintEffect(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	bHandled = FALSE;
	PPAINTEFFECT pPE = (PPAINTEFFECT)lParam;
	if (pPE) {
		if (m_bCrossCursor) {
#if 1
			DrawCrossCursor(pPE->hSrcDC);
#else
			CRect rcClient;
			GetClientRect(&rcClient);

			//BitBlt(pPE->hSrcDC, rcClient.left, rcClient.top, rcClient.Width(), rcClient.Height()
			//	, m_dcCrossCursor, rcClient.left, rcClient.top, SRCINVERT);
			TransparentBlt(pPE->hSrcDC, rcClient.left, rcClient.top, rcClient.Width(), rcClient.Height()
				, m_dcCrossCursor, 0, 0, rcClient.Width(), rcClient.Height(), RGB(0,0,0));
#endif//
		}
	}
	return bHandled;
}

LRESULT QTechView::OnBackwardMsg(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	MSG* pMsg = (MSG*)lParam;
	switch(pMsg->message)
	{
	case WM_LBUTTONDBLCLK:
	case WM_RBUTTONDOWN:
	case WM_MOUSEMOVE:
		{
			POINT pt;
			GetCursorPos(&pt);
			ScreenToClient(&pt);
			pMsg->lParam = POINTTOPOINTS(pt);
		}
	//case WM_MOUSEWHEEL:
		bHandled = TRUE;
		OnMouse(pMsg->message, pMsg->wParam, pMsg->lParam, bHandled);
		break;
	default:
		break;
	}
	return bHandled;
}

LRESULT QTechView::OnUpdateCommandUI(CUpdateUIBase* pUpdateUI, BOOL& bHandled)
{
	if (!m_DispInfoPtr) {
		bHandled = FALSE;
		return bHandled;
	}

	int i;

	BAR* pBar = GetBar();
	UINT nBarCount = GetBarCount();

	for (i=0; i<KLINE_MAX; i++)
	{
		if (i != m_iDispInfoPtr->KLineType) {
			pUpdateUI->UISetRadio(ID_TECHVIEW_KLINE+i, FALSE);
		} else {
			pUpdateUI->UISetRadio(ID_TECHVIEW_KLINE+m_iDispInfoPtr->KLineType, TRUE);
		}
	}
	if (m_iDispInfoPtr->Start+m_iDispInfoPtr->Count <= nBarCount) {
		pUpdateUI->UISetCheck(ID_TECHVIEW_AUTO, TRUE);
	} else {
		pUpdateUI->UISetCheck(ID_TECHVIEW_AUTO, FALSE);
	}
	if (m_iDispInfoPtr->Start+m_iDispInfoPtr->Count < nBarCount) {
		pUpdateUI->UISetCheck(ID_TECHVIEW_SHIFT, TRUE);
	} else {
		pUpdateUI->UISetCheck(ID_TECHVIEW_SHIFT, FALSE);
	}
	if (m_iDispInfoPtr->Scale>=(MAX_BAR_SCALE-1)) {
		pUpdateUI->UIEnable(ID_TECHVIEW_LARGER, FALSE);
	} else {
		pUpdateUI->UIEnable(ID_TECHVIEW_LARGER, TRUE);
	}
	if (m_iDispInfoPtr->Scale<=0) {
		pUpdateUI->UIEnable(ID_TECHVIEW_SMALLER, FALSE);
	} else {
		pUpdateUI->UIEnable(ID_TECHVIEW_SMALLER, TRUE);
	}

	return bHandled;
}

LRESULT QTechView::OnCommand(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	if (!IsDispOk()) {
		return bHandled;
	}
	BAR* pBar = GetBar();
	UINT nBarCount = GetBarCount();

	WORD wNotifyCode = HIWORD(wParam); 
	WORD wID = LOWORD(wParam); 
	HWND hwndCtrl = (HWND)lParam;
	m_hWnd;
	/*if (hwndCtrl) {
		switch(wNotifyCode) 
		{
		case EN_UPDATE:
		case STN_DBLCLK:
		default:
			bHandled = FALSE;
			break;
		}
	} else */{
		if(0) {
			//
		} else {
			BOOL bToIndicator = FALSE;
			switch(wID)
			{
			case ID_CONTAINER_HOME:
				MoveCurrent(nBarCount-(m_iDispInfoPtr->Current+1));
				break;
			case ID_CONTAINER_END:
				MoveCurrent(-m_iDispInfoPtr->Current);
				break;
			case ID_CONTAINER_LEFT:
				if (!m_iDispInfoPtr->bCrossCursor) {
					ShowCurrent(m_iDispInfoPtr->Start);
				} else {
					MoveCurrent(-max(1,wNotifyCode));
				}
				break;
			case ID_CONTAINER_RIGHT:
				if (!m_iDispInfoPtr->bCrossCursor) {
					ShowCurrent(m_iDispInfoPtr->Start+m_iDispInfoPtr->Count-1);
				} else {
					MoveCurrent(max(1,wNotifyCode));
				}
				break;
			case ID_CONTAINER_UP:
				Scale(1);
				break;
			case ID_CONTAINER_DOWN:
				Scale(-1);
				break;
			case ID_CONTAINER_ORDER_BUY:
			case ID_CONTAINER_ORDER_SELL:
			case ID_CONTAINER_ORDER_SEND_LIMIT:
			case ID_CONTAINER_ORDER_SEND_STOP:
				{
					//COMREF Commodity;
					//GetCurCommodity(&Commodity);
					//OrderSend(Commodity, OP_BUY, 0.1, );
				}
				break;
			case ID_CONTAINER_ORDER_CLOSE:
				break;
			case ID_TECHVIEW_BACK:
				{
					Move((short)wNotifyCode);
				}
				break;
			case ID_TECHVIEW_FORWARD:
				{
					Move(-(short)wNotifyCode);
				}
				break;
			case ID_TECHVIEW_SHOWMINITRADER:
				break;
			case ID_TECHVIEW_ROBOT:
				break;
			case ID_TECHVIEW_LARGER:
				Scale(1);
				break;
			case ID_TECHVIEW_SMALLER:
				Scale(-1);
				break;
			case ID_TECHVIEW_AUTO:
				break;
			case ID_TECHVIEW_SHIFT:
				break;
			case ID_TECHVIEW_KLINE+KLINE_K:
			case ID_TECHVIEW_KLINE+KLINE_BAR:
			case ID_TECHVIEW_KLINE+KLINE_TREND:
				SwapIndicatorDispInfo();
				m_iDispInfoPtr->KLineType = (wID-ID_TECHVIEW_KLINE);
				UpdateIndicatorDispInfo(UD_DISPCHANGE);
				break;
			case ID_TECHVIEW_VOLUME+STICK_LINE:
			case ID_TECHVIEW_VOLUME+STICK_BAR:
				SwapIndicatorDispInfo();
				m_iDispInfoPtr->KVolumeType = (wID-ID_TECHVIEW_VOLUME);
				UpdateIndicatorDispInfo(UD_DISPCHANGE);
				break;
			case ID_TECHVIEW_COORDINATE+0:
				SwapIndicatorDispInfo();
				m_iDispInfoPtr->YCoordType &= ~CT_LOG;
				UpdateIndicatorDispInfo(UD_DISPCHANGE);
				break;
			case ID_TECHVIEW_COORDINATE+1:
				SwapIndicatorDispInfo();
				m_iDispInfoPtr->YCoordType |= CT_LOG;
				UpdateIndicatorDispInfo(UD_DISPCHANGE);
				break;
			case ID_TECHVIEW_COORDINATE+2:
			case ID_TECHVIEW_COORDINATE+3:
			case ID_TECHVIEW_COORDINATE+4:
			case ID_TECHVIEW_COORDINATE+5:
				SwapIndicatorDispInfo();
				if (m_iDispInfoPtr->YCoordType & (0x10<<(wID-(ID_TECHVIEW_COORDINATE+2)))) {
					m_iDispInfoPtr->YCoordType &= ~(0x10<<(wID-(ID_TECHVIEW_COORDINATE+2)));
				} else {
					m_iDispInfoPtr->YCoordType |= (0x10<<(wID-(ID_TECHVIEW_COORDINATE+2)));
				}
				UpdateIndicatorDispInfo(UD_DISPCHANGE);
				break;
			case ID_TECHVIEW_COORDINATE_X_LR:
				SwapIndicatorDispInfo();
				m_iDispInfoPtr->InfoWidth = -m_iDispInfoPtr->InfoWidth;
				UpdateIndicatorDispInfo(UD_DISPCHANGE);
				m_dcCoordinate.DeleteDC();
				m_dcCrossCursor.DeleteDC();
				Invalidate();
				break;
			case ID_TECHVIEW_ADD:
				AddWndIndicator(hwndCtrl);
				break;
			case ID_TECHVIEW_REMOVE:
				if (hwndCtrl) {
					RemoveWndIndicator(hwndCtrl);
				}
				break;
			default:
				if (wID>=ID_TECHVIEW_INDICATOR && wID<=ID_TECHVIEW_MAX) {
					bToIndicator = TRUE;
				} else {
					bHandled = FALSE;
				}
				break;
			}
			if (bToIndicator) {
				WndObjecter* pWndIndicator = NULL;
				if ((wID>=ID_TECHVIEW_INDICATOR_ADDCOMMODITY && wID<=ID_TECHVIEW_INDICATOR_ADDCOMMODITY)
					|| (wID>=ID_TECHVIEW_INDICATOR_ADDOBJECT && wID<=ID_TECHVIEW_INDICATOR_ADDOBJECT_MAX)
				) {
					Pane* pPane = ChildPaneFromPos(0);
					if (pPane) {
						pWndIndicator = GetObjecterBy(*pPane);
					}
				} else {
					pWndIndicator = GetObjecterBy(GetFocus());
					if (pWndIndicator) {
						Pane* pPane = ChildPaneFromPos(0);
						if (pPane) {
							pWndIndicator = GetObjecterBy(*pPane);
						}
					}
				}
				if (pWndIndicator) {
					UIWnd2 wndIndicator = pWndIndicator->GetHwnd();
					wndIndicator.SendMessage(uMsg, wParam, lParam);
				}
			}
		}
	}
	return bHandled;
}

void QTechView::OnPaint(HDC hdc)
{
	ASSERT(m_DispInfoPtr);

	CDCHandle dc(hdc);

	CRect rcClient;
	GetClientRect(&rcClient);

	dc.SetBkMode(TRANSPARENT);
	dc.FillSolidRect(&rcClient, m_DispInfoPtr->crXYLine);

	DrawCoordinate(hdc);

	DrawCrossCursor(hdc);
}

void QTechView::UpdateIndicatorCalcInfo()
{
	BroadcastSend(EVT_PLAT_CALL, MAKEVALUE(MSET_PLAT_INDICATOR,CSET_INDICATOR_CALCINFO), m_iCalcInfoPtr);
}

void QTechView::SwapIndicatorDispInfo()
{
	IndicatorDispInfoPtr iDispInfoPtr = m_iPreDispInfoPtr;
	m_iPreDispInfoPtr = m_iDispInfoPtr;
	m_iDispInfoPtr = iDispInfoPtr;

	/*m_iDispInfoPtr->Object = m_iPreDispInfoPtr->Object;
	m_iDispInfoPtr->Period = m_iPreDispInfoPtr->Period;
	m_iDispInfoPtr->PeriodEx = m_iPreDispInfoPtr->PeriodEx;
	m_iDispInfoPtr->DWType = m_iPreDispInfoPtr->DWType;
	m_iDispInfoPtr->DWDate = m_iPreDispInfoPtr->DWDate;*/

	/*m_iDispInfoPtr->MinOpen = m_iPreDispInfoPtr->MinOpen;
	m_iDispInfoPtr->MaxOpen = m_iPreDispInfoPtr->MaxOpen;
	m_iDispInfoPtr->MinHigh = m_iPreDispInfoPtr->MinHigh;
	m_iDispInfoPtr->MaxHigh = m_iPreDispInfoPtr->MaxHigh;
	m_iDispInfoPtr->MinLow = m_iPreDispInfoPtr->MinLow;
	m_iDispInfoPtr->MaxLow = m_iPreDispInfoPtr->MaxLow;
	m_iDispInfoPtr->MinClose = m_iPreDispInfoPtr->MinClose;
	m_iDispInfoPtr->MaxClose = m_iPreDispInfoPtr->MaxClose;
	m_iDispInfoPtr->MinVolume = m_iPreDispInfoPtr->MinVolume;
	m_iDispInfoPtr->MaxVolume = m_iPreDispInfoPtr->MaxVolume;*/
	m_iDispInfoPtr->HighPrice = m_iPreDispInfoPtr->HighPrice;
	m_iDispInfoPtr->LowPrice = m_iPreDispInfoPtr->LowPrice;
	m_iDispInfoPtr->HighVolume = m_iPreDispInfoPtr->HighVolume;
	m_iDispInfoPtr->LowVolume = m_iPreDispInfoPtr->LowVolume;
	m_iDispInfoPtr->StartDate = m_iPreDispInfoPtr->StartDate;
	m_iDispInfoPtr->StartTime = m_iPreDispInfoPtr->StartTime;
	m_iDispInfoPtr->Start = m_iPreDispInfoPtr->Start;
	m_iDispInfoPtr->Count = m_iPreDispInfoPtr->Count;
	m_iDispInfoPtr->MaxCount = m_iPreDispInfoPtr->MaxCount;
	m_iDispInfoPtr->Current = m_iPreDispInfoPtr->Current;
	m_iDispInfoPtr->bCrossCursor = m_iPreDispInfoPtr->bCrossCursor;
	m_iDispInfoPtr->InfoHeight = m_iPreDispInfoPtr->InfoHeight;
	m_iDispInfoPtr->InfoWidth = m_iPreDispInfoPtr->InfoWidth;
	m_iDispInfoPtr->TopSpace = m_iPreDispInfoPtr->TopSpace;
	m_iDispInfoPtr->BottomSpace = m_iPreDispInfoPtr->BottomSpace;
	m_iDispInfoPtr->Scale = m_iPreDispInfoPtr->Scale;

	m_iDispInfoPtr->KLineType = m_iPreDispInfoPtr->KLineType;
	m_iDispInfoPtr->KVolumeType = m_iPreDispInfoPtr->KVolumeType;
	m_iDispInfoPtr->YCoordType = m_iPreDispInfoPtr->YCoordType;
	m_iDispInfoPtr->XCoordType = m_iPreDispInfoPtr->XCoordType;
}

void QTechView::UpdateIndicatorDispInfo(int udType)
{
	BAR* pBar = GetBar();
	UINT nBarCount = GetBarCount();

	int i,j;
	bool bResetPos = false;
	if (udType == UD_BARSCHANGE) {
		if (m_iDispInfoPtr->Count<m_iDispInfoPtr->MaxCount) {
			bResetPos = true;
		}

		/*m_iDispInfoPtr->MinOpen = 0;
		m_iDispInfoPtr->MaxOpen = 0;
		m_iDispInfoPtr->MinHigh = 0;
		m_iDispInfoPtr->MaxHigh = 0;
		m_iDispInfoPtr->MinLow = 0;
		m_iDispInfoPtr->MaxLow = 0;
		m_iDispInfoPtr->MinClose = 0;
		m_iDispInfoPtr->MaxClose = 0;
		m_iDispInfoPtr->MinVolume = 0;
		m_iDispInfoPtr->MaxVolume = 0;*/
		m_iDispInfoPtr->HighPrice = 0;
		m_iDispInfoPtr->LowPrice = 0;
		m_iDispInfoPtr->HighVolume = 0;
		m_iDispInfoPtr->LowVolume = 0;
		//m_iDispInfoPtr->StartDate = 0;
		//m_iDispInfoPtr->StartTime = 0;
		//m_iDispInfoPtr->Start = 0;
		//m_iDispInfoPtr->Count = 0;
		//m_iDispInfoPtr->MaxCount = 0;
		//m_iDispInfoPtr->Current = 0;
		//m_iDispInfoPtr->bCrossCursor = 0;
		if (pBar) {
			/*for (i=0,j=nBarCount; i<j; i++)
			{
				if (pBar[m_iDispInfoPtr->MinOpen].Open > pBar[i].Open) {
					m_iDispInfoPtr->MinOpen = i;
				}
				if (pBar[m_iDispInfoPtr->MaxOpen].Open < pBar[i].Open) {
					m_iDispInfoPtr->MaxOpen = i;
				}
				if (pBar[m_iDispInfoPtr->MinHigh].High > pBar[i].High) {
					m_iDispInfoPtr->MinHigh = i;
				}
				if (pBar[m_iDispInfoPtr->MaxHigh].High < pBar[i].High) {
					m_iDispInfoPtr->MaxHigh = i;
				}
				if (pBar[m_iDispInfoPtr->MinLow].Low > pBar[i].Low) {
					m_iDispInfoPtr->MinLow = i;
				}
				if (pBar[m_iDispInfoPtr->MaxLow].Low < pBar[i].Low) {
					m_iDispInfoPtr->MaxLow = i;
				}
				if (pBar[m_iDispInfoPtr->MinClose].Close > pBar[i].Close) {
					m_iDispInfoPtr->MinClose = i;
				}
				if (pBar[m_iDispInfoPtr->MaxClose].Close < pBar[i].Close) {
					m_iDispInfoPtr->MaxClose = i;
				}
				if (pBar[m_iDispInfoPtr->MinVolume].Volume > pBar[i].Volume) {
					m_iDispInfoPtr->MinVolume = i;
				}
				if (pBar[m_iDispInfoPtr->MaxVolume].Volume < pBar[i].Volume) {
					m_iDispInfoPtr->MaxVolume = i;
				}
			}*/
		}
	}
	if (m_iDispInfoPtr->MaxCount<=0 || udType==UD_SIZECHANGE) {
		if (m_iDispInfoPtr->MaxCount<=0) {
			bResetPos = true;
		}

		CRect rcClient;
		GetTechRect(&rcClient);

		int kWidth = m_DispInfoPtr->nBarWidth[m_iDispInfoPtr->Scale] + m_DispInfoPtr->nBarSpace[m_iDispInfoPtr->Scale];
		m_iDispInfoPtr->MaxCount = max(_countxofy(kWidth,rcClient.Width()),0);

		m_iDispInfoPtr->Count = min(nBarCount, m_iDispInfoPtr->MaxCount);
	}
	if (!IsDispOk()) {
		bResetPos = true;
	}

	if (bResetPos || udType==UD_BARSCHANGE || udType==UD_SIZECHANGE || udType==UD_DISPCHANGE) {
		if (pBar) {
			if (bResetPos) {
				//������ʾλ��
				int kWidth = m_DispInfoPtr->nBarWidth[m_iDispInfoPtr->Scale] + m_DispInfoPtr->nBarSpace[m_iDispInfoPtr->Scale];
				int nOffset = max(_countxofy(kWidth,m_DispInfoPtr->nBarShift),0);
				m_iDispInfoPtr->Count = max(0,min(nBarCount, m_iDispInfoPtr->MaxCount-nOffset));
				m_iDispInfoPtr->Start = max(0, nBarCount-m_iDispInfoPtr->Count);
			}
			if(m_iDispInfoPtr->Start+m_iDispInfoPtr->Count >= nBarCount) {
				m_iDispInfoPtr->Count = nBarCount - m_iDispInfoPtr->Start;
			}
			if(m_iDispInfoPtr->Count >= m_iDispInfoPtr->MaxCount) {
				m_iDispInfoPtr->Count = m_iDispInfoPtr->MaxCount;
			}
			if (m_iDispInfoPtr->Count>0) { 
				//��������ʾ��ʱ���ٴ���
				m_iDispInfoPtr->StartDate = pBar[m_iDispInfoPtr->Start].Date;
				m_iDispInfoPtr->StartTime = pBar[m_iDispInfoPtr->Start].Time;
			}

			if (!m_iDispInfoPtr->bCrossCursor) {
				m_iDispInfoPtr->Current = nBarCount - 1;
			} else {
				if (m_iDispInfoPtr->Current<m_iDispInfoPtr->Start && m_iDispInfoPtr->Current>=(m_iDispInfoPtr->Start+m_iDispInfoPtr->Count)) {
					m_iDispInfoPtr->Current = nBarCount - 1;
				}
			}
			
			m_iDispInfoPtr->HighPrice = m_iDispInfoPtr->Start;
			m_iDispInfoPtr->LowPrice = m_iDispInfoPtr->Start;
			m_iDispInfoPtr->HighVolume = m_iDispInfoPtr->Start;
			m_iDispInfoPtr->LowVolume = m_iDispInfoPtr->Start;
			for (i=m_iDispInfoPtr->Start+1,j=m_iDispInfoPtr->Start+m_iDispInfoPtr->Count; i<j; i++)
			{
				if (pBar[m_iDispInfoPtr->HighPrice].High < pBar[i].High) {
					m_iDispInfoPtr->HighPrice = i;
				}
				if (pBar[m_iDispInfoPtr->LowPrice].Low > pBar[i].Low) {
					m_iDispInfoPtr->LowPrice = i;
				}
				if (pBar[m_iDispInfoPtr->HighVolume].Volume < pBar[i].Volume) {
					m_iDispInfoPtr->HighVolume = i;
				}
				if (pBar[m_iDispInfoPtr->LowVolume].Volume > pBar[i].Volume) {
					m_iDispInfoPtr->LowVolume = i;
				}
			}
		}
	}

	BroadcastSend(EVT_PLAT_CALL, MAKEVALUE(MSET_PLAT_INDICATOR,CSET_INDICATOR_DISPINFO), m_iDispInfoPtr);
}

//
//void QTechView::ShowCrossCursor(POINT pt)
//{
//	if (!IsDispOk()) {
//		return;
//	}
//
//	BAR* pBar = GetBar();
//	UINT nBarCount = GetBarCount();
//
//	RECT rcClient;
//	GetClientRect(&rcClient);
//
//	RECT rcMain;
//	GetTechRect(&rcMain);
//
//	BOOL bPreCrossCursor = m_bCrossCursor;
//	m_bCrossCursor = TRUE;
//	m_bDrawCrossCursor = TRUE;
//
//	POINT ptPreCrossCursor = m_ptCrossCursor;
//	//ClientToScreen(&pt);
//	m_ptCrossCursor = pt;
//	POINT ptCrossCursor = m_ptCrossCursor;
//
//	HDC hdc = ::GetDC(NULL);
//	if (!m_dcCrossCursor) {
//		m_dcCrossCursor.CreateCompatibleDC(hdc, &rcClient);
//		bPreCrossCursor = FALSE;
//	}
//	m_dcCrossCursor.FillSolidRect(&rcClient, m_DispInfoPtr->crBackgnd);
//	int nRop2Old = ::SetROP2(m_dcCrossCursor, R2_NOTXORPEN);
//	/*if (bPreCrossCursor) {
//		::MoveToEx(m_dcCrossCursor, ptPreCrossCursor.x, rcMain.top, NULL);
//		::LineTo(m_dcCrossCursor, ptPreCrossCursor.x, rcMain.bottom);
//		::MoveToEx(m_dcCrossCursor, rcMain.left, ptPreCrossCursor.y, NULL);
//		::LineTo(m_dcCrossCursor, rcMain.right, ptPreCrossCursor.y);
//	}*/
//	if (m_bCrossCursor) {
//		if (m_iDispInfoPtr->Current>=m_iDispInfoPtr->Start 
//			&& m_iDispInfoPtr->Current<min((m_iDispInfoPtr->Start+m_iDispInfoPtr->Count),nBarCount)) {
//			CRect rcText;
//			CRect rcCalc;
//			TCHAR szText[1024];
//			int nTextLen;
//
//			nTextLen = _stprintf(szText, _T("%.2f"), m_iPointInfoPtr->result);
//			m_dcCrossCursor.DrawText(szText, nTextLen, &rcCalc, DT_RIGHT|DT_SINGLELINE|DT_CALCRECT);
//			if (m_iDispInfoPtr->InfoWidth >= 0) {
//				rcText = rcClient;
//				rcText.top = pt.y - rcCalc.Height();
//				rcText.right = rcMain.left;
//				rcText.bottom = pt.y;
//				m_dcCrossCursor.FillSolidRect(&rcText,m_DispInfoPtr->crRptSelBackgnd);
//				UIgdi::DrawText(m_dcCrossCursor, szText, nTextLen, &rcText, DT_RIGHT|DT_SINGLELINE, m_DispInfoPtr->crCrossCursor, m_DispInfoPtr->hYText);
//			} else {
//				rcText = rcClient;
//				rcText.left = rcMain.right;
//				rcText.top = pt.y - rcCalc.Height();
//				rcText.bottom = pt.y;
//				m_dcCrossCursor.FillSolidRect(&rcText,m_DispInfoPtr->crRptSelBackgnd);
//				UIgdi::DrawText(m_dcCrossCursor, szText, nTextLen, &rcText, DT_LEFT|DT_SINGLELINE, m_DispInfoPtr->crCrossCursor, m_DispInfoPtr->hYText);
//			}
//
//			if (m_iPointInfoPtr->pos>=m_iDispInfoPtr->Start && m_iPointInfoPtr->pos<(m_iDispInfoPtr->Start+m_iDispInfoPtr->Count)) {
//				unsigned long Year,Month,Day,Hour,Minute,Second;
//				ULONG_TO_YYMMDD(pBar[m_iPointInfoPtr->pos].Date, Year, Month, Day);
//				ULONG_TO_HHMMSS(pBar[m_iPointInfoPtr->pos].Time, Hour, Minute, Second);
//				/*if(m_vDispInfoPtr->Period >= CYC_TICK && m_vDispInfoPtr->Period <= CYC_ANYSEC) {
//					nTextLen = _stprintf(szText, _T("%d��%d�� %dʱ%d��%d��"), Month, Day, Hour, Minute, Second);
//				} else if(m_vDispInfoPtr->Period >= CYC_1MIN && m_vDispInfoPtr->Period <= CYC_ANYMIN) {
//					nTextLen = _stprintf(szText, _T("%02d��%d��%d�� %dʱ%d��"), Year%100, Month, Day, Hour, Minute);
//				} else if(m_vDispInfoPtr->Period >= CYC_DAY && m_vDispInfoPtr->Period <= CYC_ANYDAY) {
//					nTextLen = _stprintf(szText, _T("%02d��%d��%d��"), Year%100, Month, Day);
//				} else */{
//					if (!Month) {
//						nTextLen = _stprintf(szText, _T("%04d"), Year);
//					} else if (!Day) {
//						nTextLen = _stprintf(szText, _T("%04d/%02d"), Year, Month);
//					} else if (!Hour) {
//						nTextLen = _stprintf(szText, _T("%04d/%02d/%02d"), Year, Month, Day);
//					} else if (!Minute) {
//						nTextLen = _stprintf(szText, _T("%04d/%02d/%02d %02d"), Year, Month, Day, Hour);
//					} else if (!Second) {
//						nTextLen = _stprintf(szText, _T("%04d/%02d/%02d %02d:%02d"), Year, Month, Day, Hour, Minute);
//					} else {
//						nTextLen = _stprintf(szText, _T("%04d/%02d/%02d %02d:%02d:%02d"), Year, Month, Day, Hour, Minute, Second);
//					}
//				}
//				m_dcCrossCursor.DrawText(szText, nTextLen, &rcCalc, DT_LEFT|DT_SINGLELINE|DT_CALCRECT);
//				rcText = rcClient;
//				rcText.left = (rcClient.right-pt.x)<rcCalc.Width()?pt.x-rcCalc.Width():pt.x;
//				rcText.top = rcClient.bottom - rcCalc.Height();
//				rcText.right = rcText.left + rcCalc.Width();
//				m_dcCrossCursor.FillSolidRect(&rcText,m_DispInfoPtr->crRptSelBackgnd);
//				UIgdi::DrawText(m_dcCrossCursor, szText, nTextLen, &rcText, DT_LEFT|DT_SINGLELINE, m_DispInfoPtr->crCrossCursor, m_DispInfoPtr->hXText);
//			}
//		}
//
//		::MoveToEx(m_dcCrossCursor, ptCrossCursor.x, rcMain.top, NULL);
//		::LineTo(m_dcCrossCursor, ptCrossCursor.x, rcMain.bottom);
//		::MoveToEx(m_dcCrossCursor, rcMain.left, ptCrossCursor.y, NULL);
//		::LineTo(m_dcCrossCursor, rcMain.right, ptCrossCursor.y);
//	}
//	::SetROP2(m_dcCrossCursor, nRop2Old);
//	/*int nRop2Old = ::SetROP2(hdc, R2_NOTXORPEN);
//	if (bPreCrossCursor) {
//		::MoveToEx(hdc, ptPreCrossCursor.x, rcMain.top, NULL);
//		::LineTo(hdc, ptPreCrossCursor.x, rcMain.bottom);
//		::MoveToEx(hdc, rcMain.left, ptPreCrossCursor.y, NULL);
//		::LineTo(hdc, rcMain.right, ptPreCrossCursor.y);
//	}
//	if (m_bCrossCursor) {
//		::MoveToEx(hdc, ptCrossCursor.x, rcMain.top, NULL);
//		::LineTo(hdc, ptCrossCursor.x, rcMain.bottom);
//		::MoveToEx(hdc, rcMain.left, ptCrossCursor.y, NULL);
//		::LineTo(hdc, rcMain.right, ptCrossCursor.y);
//	}
//	::SetROP2(hdc, nRop2Old);*/
//	::ReleaseDC(NULL, hdc);
//	Invalidate();
//}
//
//void QTechView::ShowCrossCursor(int nPos)
//{
//	if (!IsDispOk()) {
//		return;
//	}
//
//	BAR* pBar = GetBar();
//	UINT nBarCount = GetBarCount();
//
//	m_iBufferInfoPtr->buffer = PRICE_CLOSE;
//	m_iBufferInfoPtr->pos = nPos;
//	Event evt(this, NULL, EVT_PLAT_CALL, MAKEVALUE(MGET_PLAT_INDICATOR,CGET_INDICATOR_INDEXINFO), m_iBufferInfoPtr);
//	BroadcastHandle(evt);
//	if (evt.handled) {
//		m_iPointInfoPtr->pt = m_iBufferInfoPtr->pt;
//		m_iPointInfoPtr->pos = m_iBufferInfoPtr->pos;
//		m_iPointInfoPtr->result = m_iBufferInfoPtr->result;
//		ShowCrossCursor(m_iBufferInfoPtr->pt);
//	}
//}

void QTechView::HideCrossCursor()
{
	if (!m_bCrossCursor) {
		return;
	}

	BAR* pBar = GetBar();
	UINT nBarCount = GetBarCount();

	SwapIndicatorDispInfo();

	m_iDispInfoPtr->Current = nBarCount-1;
	m_iDispInfoPtr->bCrossCursor = FALSE;

	UpdateIndicatorDispInfo(UD_DISPCHANGE);

	m_dcCrossCursor.DeleteDC();
	Invalidate();
}

void QTechView::DrawCrossCursor(HDC hdc)
{
	ASSERT(hdc);

	ASSERT(m_DispInfoPtr);

	if (!m_iDispInfoPtr) {
		return;
	}
	if (!IsDispOk()) {
		return;
	}
	if (!m_iDispInfoPtr->bCrossCursor) {
		return;
	}
	POINT pt;
	POINTSTOPOINT(pt,m_iDispInfoPtr->bCrossCursor);
	ScreenToClient(&pt);

	CRect rcClient;
	GetClientRect(&rcClient);

	BOOL bTechRect = TRUE; //TRUE��ʮ���α�ȫ�����ﻭ��FALSE�Ƿֿ�����
	CRect rcMain;
	if (bTechRect) {
		GetTechRect(rcMain);
	} else {
		GetCoordinateRect(&rcMain);
	}

	if (!m_dcCrossCursor) {
		
		BOOL bCross = TRUE;//PtInRect(&rcMain,pt);

		BAR* pBar = GetBar();
		UINT nBarCount = GetBarCount();

		m_dcCrossCursor.CreateCompatibleDC(hdc, &rcClient);

		m_dcCrossCursor.FillSolidRect(&rcClient, m_DispInfoPtr->crBackgnd);
		int nRop2Old = ::SetROP2(m_dcCrossCursor, R2_NOTXORPEN);

		if (bCross) {
		
		if (m_iDispInfoPtr->Current>=m_iDispInfoPtr->Start 
			&& m_iDispInfoPtr->Current<(m_iDispInfoPtr->Start+m_iDispInfoPtr->Count)) {
				CRect rcText;
				CRect rcCalc;
				TCHAR szText[1024];
				int nTextLen;

				if (bTechRect) {
				//nTextLen = _stprintf(szText, _T("%.2f"), m_iPointInfoPtr->result);
				nTextLen = _tcslen(FormatFloatString(szText,m_iPointInfoPtr->result,2));
				m_dcCrossCursor.DrawText(szText, nTextLen, &rcCalc, DT_RIGHT|DT_SINGLELINE|DT_CALCRECT);
				if (m_iDispInfoPtr->InfoWidth >= 0) {
					rcText = rcClient;
					rcText.top = pt.y - rcCalc.Height();
					rcText.right = rcMain.left;
					rcText.bottom = pt.y;
					m_dcCrossCursor.FillSolidRect(&rcText,m_DispInfoPtr->crRptSelBackgnd);
					UIgdi::DrawText(m_dcCrossCursor, szText, nTextLen, &rcText, DT_RIGHT|DT_SINGLELINE, m_DispInfoPtr->crCrossCursor, m_DispInfoPtr->hYText);
				} else {
					rcText = rcClient;
					rcText.left = rcMain.right;
					rcText.top = pt.y - rcCalc.Height();
					rcText.bottom = pt.y;
					m_dcCrossCursor.FillSolidRect(&rcText,m_DispInfoPtr->crRptSelBackgnd);
					UIgdi::DrawText(m_dcCrossCursor, szText, nTextLen, &rcText, DT_LEFT|DT_SINGLELINE, m_DispInfoPtr->crCrossCursor, m_DispInfoPtr->hYText);
				}
				}

				if (m_iDispInfoPtr->Current>=m_iDispInfoPtr->Start && m_iDispInfoPtr->Current<(m_iDispInfoPtr->Start+m_iDispInfoPtr->Count)) {
					unsigned long Year,Month,Day,Hour,Minute,Second;
					ULONG_TO_YYMMDD(pBar[m_iDispInfoPtr->Current].Date, Year, Month, Day);
					ULONG_TO_HHMMSS(pBar[m_iDispInfoPtr->Current].Time, Hour, Minute, Second);
					/*if(m_vDispInfoPtr->Period >= CYC_TICK && m_vDispInfoPtr->Period <= CYC_ANYSEC) {
					nTextLen = _stprintf(szText, _T("%d��%d�� %dʱ%d��%d��"), Month, Day, Hour, Minute, Second);
					} else if(m_vDispInfoPtr->Period >= CYC_1MIN && m_vDispInfoPtr->Period <= CYC_ANYMIN) {
					nTextLen = _stprintf(szText, _T("%02d��%d��%d�� %dʱ%d��"), Year%100, Month, Day, Hour, Minute);
					} else if(m_vDispInfoPtr->Period >= CYC_DAY && m_vDispInfoPtr->Period <= CYC_ANYDAY) {
					nTextLen = _stprintf(szText, _T("%02d��%d��%d��"), Year%100, Month, Day);
					} else */{
						if (!Month) {
							nTextLen = _stprintf(szText, _T("%04d"), Year);
						} else if (!Day) {
							nTextLen = _stprintf(szText, _T("%04d/%02d"), Year, Month);
						} else if (!Hour) {
							nTextLen = _stprintf(szText, _T("%04d/%02d/%02d"), Year, Month, Day);
						} else if (!Minute) {
							nTextLen = _stprintf(szText, _T("%04d/%02d/%02d %02d"), Year, Month, Day, Hour);
						} else if (!Second) {
							nTextLen = _stprintf(szText, _T("%04d/%02d/%02d %02d:%02d"), Year, Month, Day, Hour, Minute);
						} else {
							nTextLen = _stprintf(szText, _T("%04d/%02d/%02d %02d:%02d:%02d"), Year, Month, Day, Hour, Minute, Second);
						}
					}
					m_dcCrossCursor.DrawText(szText, nTextLen, &rcCalc, DT_LEFT|DT_SINGLELINE|DT_CALCRECT);
					rcText = rcClient;
					rcText.left = (rcClient.right-pt.x)<rcCalc.Width()?pt.x-rcCalc.Width():pt.x;
					rcText.top = rcClient.bottom - rcCalc.Height();
					rcText.right = rcText.left + rcCalc.Width();
					m_dcCrossCursor.FillSolidRect(&rcText,m_DispInfoPtr->crRptSelBackgnd);
					UIgdi::DrawText(m_dcCrossCursor, szText, nTextLen, &rcText, DT_LEFT|DT_SINGLELINE, m_DispInfoPtr->crCrossCursor, m_DispInfoPtr->hXText);
				}
		}

		::MoveToEx(m_dcCrossCursor, pt.x, rcMain.top, NULL);
		::LineTo(m_dcCrossCursor, pt.x, rcMain.bottom);

		}

		if (bTechRect) {
		::MoveToEx(m_dcCrossCursor, rcMain.left, pt.y, NULL);
		::LineTo(m_dcCrossCursor, rcMain.right, pt.y);
		}

		::SetROP2(m_dcCrossCursor, nRop2Old);
	}

	TransparentBlt(hdc, rcClient.left, rcClient.top, rcClient.Width(), rcClient.Height()
		, m_dcCrossCursor, 0, 0, rcClient.Width(), rcClient.Height(), RGB(0,0,0));
}

void QTechView::Scale(int nOffset)
{
	int nScale = m_iDispInfoPtr->Scale + nOffset;
	if (nScale < 0) {
		nScale = 0;
	}
	if (nScale >= MAX_BAR_SCALE) {
		nScale = MAX_BAR_SCALE - 1;
	}
	if (nScale != m_iDispInfoPtr->Scale) {
		SwapIndicatorDispInfo();

		m_iDispInfoPtr->Scale = nScale;
		//�����ʾС��������ʾ���򣬷Ŵ���С������ǰ����ʾ
		if (m_iDispInfoPtr->Count<m_iDispInfoPtr->MaxCount) {
			m_iDispInfoPtr->MaxCount = -1;
		}

		UpdateIndicatorDispInfo(UD_SIZECHANGE);

		if (m_bCrossCursor) {
			ShowCurrent(m_iDispInfoPtr->Current);
		}

		m_dcCoordinate.DeleteDC();
		Invalidate();
	}
}

void QTechView::Move(int nOffset)
{
	BAR* pBar = GetBar();
	UINT nBarCount = GetBarCount();

	int nStart = m_iDispInfoPtr->Start + nOffset;
	if (nStart >= nBarCount) {
		nStart = nBarCount - 1;
	} else if (nStart < 0) {
		nStart = 0;
	}
	if (nStart != m_iDispInfoPtr->Start) {
		SwapIndicatorDispInfo();

		if(nOffset > 0) {
			m_iDispInfoPtr->Start = min(nBarCount-1, m_iDispInfoPtr->Start+nOffset);
			m_iDispInfoPtr->Count = min(m_iDispInfoPtr->Count, nBarCount-m_iDispInfoPtr->Start);
		} else {
			m_iDispInfoPtr->Start = max(0, m_iDispInfoPtr->Start+nOffset);
			m_iDispInfoPtr->Count = min(m_iDispInfoPtr->MaxCount, m_iDispInfoPtr->Count-nOffset);
			if (m_iDispInfoPtr->Start <= 0) {
				//SendEvent(GetContainer(), EVT_PLAT_POST, MAKEVALUE(MREQUEST_PLAT_DE,CREQUEST_DE_HISDATA), NULL/*��������NULL*/);
				COMREF Commodity;
				GetCurCommodity(&Commodity);
				iRefCalcDataMore(Commodity,Period2iPeriod(m_vDispInfoPtr->Period,m_vDispInfoPtr->PeriodEx),m_vDispInfoPtr->DWType,m_vDispInfoPtr->DWDate);
			}
		}

		UpdateIndicatorDispInfo(UD_DISPCHANGE);

		if (m_bCrossCursor) {
			ShowCurrent(m_iDispInfoPtr->Current);
		}

		m_dcCoordinate.DeleteDC();
		Invalidate();
	}
}

void QTechView::MoveCurrent(int nOffset)
{
	int nPos = m_iDispInfoPtr->Current + nOffset;
	if (nPos<m_iDispInfoPtr->Start || nPos>=(m_iDispInfoPtr->Start+m_iDispInfoPtr->Count)) {
		Move(nOffset);
	}
	ShowCurrent(nPos);
}

void QTechView::ShowCurrent(int nPos)
{
	m_iBufferInfoPtr->index = PRICE_CLOSE;
	m_iBufferInfoPtr->pos = nPos;
	Event evt(this, NULL, EVT_PLAT_CALL, MAKEVALUE(MGET_PLAT_INDICATOR,CGET_INDICATOR_INDEXINFO), m_iBufferInfoPtr);
	BroadcastHandle(evt);
	if (evt.handled) {
		m_iPointInfoPtr->pt = m_iBufferInfoPtr->pt;
		m_iPointInfoPtr->pos = m_iBufferInfoPtr->pos;
		m_iPointInfoPtr->result = m_iBufferInfoPtr->result;
		POINT ptCrossCursor = m_iBufferInfoPtr->pt;
		ClientToScreen(&ptCrossCursor);
		ShowCurrent(nPos,POINTTOPOINTS(ptCrossCursor));
	}
}

void QTechView::ShowCurrent(POINT pt, BOOL bShowOrHide)
{
	int nPos = GetBarPosBy(pt);
	if (IsBarPosOk(nPos)) {
		POINT ptCrossCursor = pt;
		ClientToScreen(&ptCrossCursor);
		if (bShowOrHide) {
			ShowCurrent(nPos,m_bCrossCursor?FALSE:POINTTOPOINTS(ptCrossCursor));
		} else {
			ShowCurrent(nPos,POINTTOPOINTS(ptCrossCursor));
		}
	} else {
		HideCrossCursor();
	}
}

void QTechView::ShowCurrent(int nPos, BOOL bCrossCursor)
{
	BAR* pBar = GetBar();
	UINT nBarCount = GetBarCount();

	int nOffset = nPos - m_iDispInfoPtr->Current;
	if(nPos>=0 && nPos<nBarCount) {
		if ((bCrossCursor!=m_iDispInfoPtr->bCrossCursor) || (nPos!=m_iDispInfoPtr->Current)) {
			SwapIndicatorDispInfo();

			if(nPos < m_iDispInfoPtr->Start) {
				m_iDispInfoPtr->Start = nPos;
				m_iDispInfoPtr->Count = min(m_iDispInfoPtr->MaxCount, m_iDispInfoPtr->Count-nOffset);
			} else if(nPos >= (m_iDispInfoPtr->Start+m_iDispInfoPtr->Count)) {
				if (nPos < (nBarCount-1)) {
					m_iDispInfoPtr->Start = (nPos+1) - m_iDispInfoPtr->Count;
				} else {
					int kWidth = m_DispInfoPtr->nBarWidth[m_iDispInfoPtr->Scale] + m_DispInfoPtr->nBarSpace[m_iDispInfoPtr->Scale];
					int nBarOffset = max(_countxofy(kWidth,m_DispInfoPtr->nBarShift),0);
					m_iDispInfoPtr->Start = ((nPos+1) - m_iDispInfoPtr->Count) + nBarOffset;
				}
			}

			m_iDispInfoPtr->Current = nPos;
			m_iDispInfoPtr->bCrossCursor = bCrossCursor;

			UpdateIndicatorDispInfo(UD_DISPCHANGE);

			m_bCrossCursor = bCrossCursor;
			m_dcCrossCursor.DeleteDC();
			Invalidate();
		}
	}
}

void QTechView::GetTechRect(LPRECT lpRect)
{
	GetClientRect(lpRect);
	if (m_iDispInfoPtr->InfoWidth>0) {
		lpRect->left += m_iDispInfoPtr->InfoWidth;
	} else if (m_iDispInfoPtr->InfoWidth<0) {
		lpRect->right += m_iDispInfoPtr->InfoWidth;
	}
	lpRect->top += m_iDispInfoPtr->InfoHeight;
	lpRect->bottom -= m_DispInfoPtr->xyCoordinate.cy + GetHBorder();
}

void QTechView::GetInfoBarRect(PRECT lpRect)
{
	GetClientRect(lpRect);
	if (m_iDispInfoPtr->InfoWidth>0) {
		lpRect->left += m_iDispInfoPtr->InfoWidth;
	} else if (m_iDispInfoPtr->InfoWidth<0) {
		lpRect->right += m_iDispInfoPtr->InfoWidth;
	}
}

void QTechView::GetCoordinateRect(LPRECT lpRect)
{
	GetClientRect(lpRect);
	if (m_iDispInfoPtr->InfoWidth>0) {
		lpRect->left += m_iDispInfoPtr->InfoWidth;
	} else if (m_iDispInfoPtr->InfoWidth<0) {
		lpRect->right += m_iDispInfoPtr->InfoWidth;
	}
	lpRect->top = lpRect->bottom - (m_DispInfoPtr->xyCoordinate.cy + GetHBorder());
}

bool QTechView::IsDispOk()
{
	ASSERT (m_iDispInfoPtr);
	if (!IsBarOk()) {
		return false;
	}
	if (m_iDispInfoPtr->Start>=0&&m_iDispInfoPtr->Count>=0 
		&& (m_iDispInfoPtr->Start+m_iDispInfoPtr->Count)<=m_pHisData->count) {
		return true;
	}
	return false;
}

void QTechView::DrawCoordinate(HDC hdc)
{
	ASSERT(m_iDispInfoPtr);

	CDCHandle dc(hdc);

	CRect rcClient;
	GetClientRect(&rcClient);

	CRect rcCoordinate = rcClient;
	rcCoordinate.top = rcCoordinate.bottom - m_DispInfoPtr->xyCoordinate.cy;
	
	if (!m_dcCoordinate) {
		HFONT hOldFont = NULL;

		m_dcCoordinate.CreateCompatibleDC(dc, &rcCoordinate);
		m_dcCoordinate.FillSolidRect(&rcCoordinate, m_DispInfoPtr->crBackgnd);

		m_dcCoordinate.SetBkMode(OPAQUE);
		m_dcCoordinate.SelectFont(m_DispInfoPtr->hXText);
		m_dcCoordinate.SetTextColor(m_DispInfoPtr->crXText);
		m_dcCoordinate.SetBkColor(m_DispInfoPtr->crBackgnd);

		CRect rcTech;
		GetTechRect(&rcTech);

		CRect rcInfoBar;
		GetInfoBarRect(&rcInfoBar);

		if (m_iDispInfoPtr->InfoWidth >= 0) {
			UIgdi::DrawLine(m_dcCoordinate, rcTech.left, rcCoordinate.top, rcTech.left, rcCoordinate.bottom, PS_SOLID, 0, m_DispInfoPtr->crXYLine, R2_COPYPEN);
		} else {
			UIgdi::DrawLine(m_dcCoordinate, rcTech.right, rcCoordinate.top, rcTech.right, rcCoordinate.bottom, PS_SOLID, 0, m_DispInfoPtr->crXYLine, R2_COPYPEN);
		}

		if (IsDispOk()) {
			BAR* pBar = GetBar();
			UINT nBarCount = GetBarCount();

			int i,j,k;
			CRect rcTemp;
			CRect rcOffset = rcCoordinate;
			rcOffset.left = rcTech.left;
			rcOffset.right = rcTech.right;

			int kWidth = (m_DispInfoPtr->nBarWidth[m_iDispInfoPtr->Scale] + m_DispInfoPtr->nBarSpace[m_iDispInfoPtr->Scale]);
			int nStep = (5*m_DispInfoPtr->xyText.cx+kWidth-1)/kWidth;
			int nTickStep = nStep/4;

			unsigned long Date;
			unsigned long Time;
			unsigned long Year, Month, Day;
			unsigned long Hour, Minute, Second;
			unsigned long OldYear,OldMonth,OldDay;
			unsigned long OldHour, OldMinute, OldSecond;
			QTime Tm((int)pBar[m_iDispInfoPtr->Start].Date, (int)pBar[m_iDispInfoPtr->Start].Time);
			Date = Tm.GetYYMMDD();
			Time = Tm.GetHHMMSS();
			ULONG_TO_YYMMDD(Date,Year,Month,Day);
			ULONG_TO_HHMMSS(Time,Hour,Minute,Second);

			//unsigned long Days,Hours,Minutes,Seconds;
			//Period2TimeSpan(m_vDispInfoPtr->Period, m_vDispInfoPtr->PeriodEx, &Days, &Hours, &Minutes, &Seconds);
			//TimeSpan TmSpan(Days,Hours,Minutes,Seconds);

			TCHAR szText[1024] = {0};
			int nTextLen = 0;
			if(m_vDispInfoPtr->Period >= CYC_TICK && m_vDispInfoPtr->Period <= CYC_ANYSEC) {
				nTextLen = _stprintf(szText, _T("%d��%d�� %dʱ%d��%d��"), Month, Day, Hour, Minute, Second);
			}  else if(m_vDispInfoPtr->Period >= CYC_1MIN && m_vDispInfoPtr->Period <= CYC_ANYMIN) {
				nTextLen = _stprintf(szText, _T("%02d��%d��%d�� %dʱ%d��"), Year%100, Month, Day, Hour, Minute);
			} else if(m_vDispInfoPtr->Period >= CYC_DAY && m_vDispInfoPtr->Period <= CYC_ANYDAY) {
				nTextLen = _stprintf(szText, _T("%02d��%d��%d��"), Year%100, Month, Day);
			} else {
				if (!Month) {
					nTextLen = _stprintf(szText, _T("%04d"), Year);
				} else if (!Day) {
					nTextLen = _stprintf(szText, _T("%04d-%02d"), Year, Month);
				} else if (!Hour) {
					nTextLen = _stprintf(szText, _T("%04d-%02d-%02d"), Year, Month, Day);
				} else if (!Minute) {
					nTextLen = _stprintf(szText, _T("%04d-%02d-%02d %02d"), Year, Month, Day, Hour);
				} else if (!Second) {
					nTextLen = _stprintf(szText, _T("%04d-%02d-%02d %02d:%02d"), Year, Month, Day, Hour, Minute);
				} else {
					nTextLen = _stprintf(szText, _T("%04d-%02d-%02d %02d:%02d:%02d"), Year, Month, Day, Hour, Minute, Second);
				}
			}

			rcTemp = rcOffset;
			DrawTick(m_dcCoordinate, &rcTemp, szText, nTextLen);

			i=(10*m_DispInfoPtr->xyText.cx)/kWidth;
			j=rcTech.Width()/kWidth;
			k=i;
			rcOffset.left += i*kWidth;
			for (; i<j; )
			{
				if (i<m_iDispInfoPtr->Count) {
					//
				} else {
					break;
				}

				OldYear = Year, OldMonth = Month, OldDay = Day;
				OldHour = Hour, OldMinute = Minute, OldSecond = Second;

				nTextLen = 0;
				memset(szText, 0, sizeof(szText));

				Tm = QTime((int)pBar[m_iDispInfoPtr->Start+i].Date, (int)pBar[m_iDispInfoPtr->Start+i].Time);
				Date = Tm.GetYYMMDD();
				Time = Tm.GetHHMMSS();
				ULONG_TO_YYMMDD(Date,Year,Month,Day);
				ULONG_TO_HHMMSS(Time,Hour,Minute,Second);

				BOOL bDraw = FALSE;
				BOOL bDrawStep = FALSE;
				if((i-k)%nTickStep==0) {
					bDraw = TRUE;
				}
				if(m_vDispInfoPtr->Period>=CYC_TICK && m_vDispInfoPtr->Period<=CYC_ANYSEC) {
					if(Day!=OldDay) {
						bDraw = TRUE;
						nTextLen = _stprintf(szText, _T("%d��"), Day);
					} else if(Hour!=OldHour) {
						bDraw = TRUE;
						nTextLen = _stprintf(szText, _T("%dʱ"), Hour);
					} else if ((i-k)%nStep==0) {
						bDraw = TRUE;
						bDrawStep = TRUE;
						nTextLen = _stprintf(szText, _T("%02d:%02d"), Minute, Second);
					}
				} else if(m_vDispInfoPtr->Period>=CYC_1MIN && m_vDispInfoPtr->Period<=CYC_ANYMIN) {
					if (Year!=OldYear) {
						bDraw = TRUE;
						nTextLen = _stprintf(szText, _T("%02d��"), Year%100);
					} else if (Month!=OldMonth) {
						bDraw = TRUE;
						nTextLen = _stprintf(szText, _T("%d��"), Month);
					} else if(Day!=OldDay) {
						bDraw = TRUE;
						nTextLen = _stprintf(szText, _T("%d��"), Day);
					} else if ((i-k)%nStep==0) {
						bDraw = TRUE;
						bDrawStep = TRUE;
						nTextLen = _stprintf(szText, _T("%02d:%02d"), Hour, Minute);
					}
				} else if(m_vDispInfoPtr->Period>=CYC_DAY && m_vDispInfoPtr->Period<=CYC_ANYDAY) {
					if (m_vDispInfoPtr->Period!=CYC_YEAR && Year!=OldYear) {
						bDraw = TRUE;
						nTextLen = _stprintf(szText, _T("%02d��"), Year%100);
					} else if (m_vDispInfoPtr->Period!=CYC_SEASON && m_vDispInfoPtr->Period!=CYC_MONTH && Month!=OldMonth) {
						bDraw = TRUE;
						nTextLen = _stprintf(szText, _T("%d��"), Month);
					} else if ((i-k)%nStep==0) {
						bDraw = TRUE;
						bDrawStep = TRUE;
						if (!Month) {
							nTextLen = _stprintf(szText, _T("%02d"), Year%100);
						} else if (!Day) {
							nTextLen = _stprintf(szText, _T("%d"), Month);
						} else {
							nTextLen = _stprintf(szText, _T("%d"), Day);
						}
					}
				}

				if (bDraw) {
					if (nTextLen>0 && szText[0]) {
						k = i;

						if (bDrawStep) {
							int tPos = (i+nTickStep);
							if (tPos<m_iDispInfoPtr->Count) {
								QTime tTm((int)pBar[m_iDispInfoPtr->Start+tPos].Date, (int)pBar[m_iDispInfoPtr->Start+tPos].Time);
								unsigned long tDate = tTm.GetYYMMDD();
								unsigned long tTime = tTm.GetHHMMSS();
								unsigned long tYear, tMonth, tDay;
								unsigned long tHour, tMinute, tSecond;
								ULONG_TO_YYMMDD(tDate,tYear,tMonth,tDay);
								ULONG_TO_HHMMSS(tTime,tHour,tMinute,tSecond);
								if (tYear != Year) {
									nTextLen = 0,szText[0] = 0;
								}
								if (tMonth != Month) {
									nTextLen = 0,szText[0] = 0;
								}
								if(m_vDispInfoPtr->Period>=CYC_DAY && m_vDispInfoPtr->Period<=CYC_ANYDAY) {
								} else if(m_vDispInfoPtr->Period>=CYC_1MIN && m_vDispInfoPtr->Period<=CYC_ANYMIN) {
									if (tDay != Day) {
										nTextLen = 0,szText[0] = 0;
									}
								} else if(m_vDispInfoPtr->Period>=CYC_TICK && m_vDispInfoPtr->Period<=CYC_ANYSEC) {
									if (tDay != Day) {
										nTextLen = 0,szText[0] = 0;
									}
									if (tHour != Hour) {
										nTextLen = 0,szText[0] = 0;
									}
								}
							}
						}
					}

					rcTemp = rcOffset;
					DrawTick(m_dcCoordinate, rcTemp, szText, nTextLen);
				}

				rcOffset.left += kWidth;
				i++;
			}
		}

		m_dcCoordinate.SelectFont(hOldFont);
	}

	dc.BitBlt(rcCoordinate.left, rcCoordinate.top, rcCoordinate.Width(), rcCoordinate.Height()
		, m_dcCoordinate, rcCoordinate.left, rcCoordinate.top, SRCCOPY);
}

void QTechView::DrawTick(HDC hdc, LPRECT lprc, LPCTSTR lpszText, int nTextLen)
{
	int nBarWidth = m_DispInfoPtr->nBarWidth[m_iDispInfoPtr->Scale];
	int xspace = m_DispInfoPtr->xySpace.cx;
	int yspace = m_DispInfoPtr->xySpace.cy;
	int ydepth = m_DispInfoPtr->xyXText.cy/3;

	if(lpszText && nTextLen > 0) {
		UIgdi::DrawLine(hdc, lprc->left+nBarWidth/2, lprc->top, lprc->left+nBarWidth/2, lprc->bottom-ydepth, PS_SOLID, 0, m_DispInfoPtr->crXYLine, R2_COPYPEN);

		lprc->top += yspace;
		lprc->left += nBarWidth/2 + xspace;
		DrawText(hdc, lpszText, nTextLen
			, lprc
			, DT_SINGLELINE|DT_LEFT|DT_VCENTER);
	} else {
		UIgdi::DrawLine(hdc, lprc->left+nBarWidth/2, lprc->top, lprc->left+nBarWidth/2, lprc->top+yspace, PS_SOLID, 0, m_DispInfoPtr->crXYLine, R2_COPYPEN);
	}
}

int QTechView::GetBarPosBy(POINT pt)
{
	BAR* pBar = GetBar();
	UINT nBarCount = GetBarCount();

	if (!pBar) {
		return -1;
	}

	int nPos = -1;
	WndObjecter* pObjecter = GetObjecterBy(ChildWindowFromPointEx(pt,CWP_SKIPINVISIBLE));
	if (pObjecter) {
		m_iPointInfoPtr->pt = pt;
		ClientToScreen(&m_iPointInfoPtr->pt);
		UIWnd2 wndObjecter = pObjecter->GetHwnd();
		wndObjecter.ScreenToClient(&m_iPointInfoPtr->pt);
		if(RLT_OK == SendEvent(pObjecter, EVT_PLAT_CALL, MAKEVALUE(MGET_PLAT_INDICATOR,CGET_INDICATOR_POINTINFO), m_iPointInfoPtr)) {
			nPos = m_iPointInfoPtr->pos;
		}
	}
	return nPos;
}
/*
POINT QTechView::GetBarPointBy(int nPos)
{
	POINT pt = {0};

	m_iBufferInfoPtr->buffer = PRICE_CLOSE;
	m_iBufferInfoPtr->pos = nPos;
	Event evt(this, NULL, EVT_PLAT_CALL, MAKEVALUE(MGET_PLAT_INDICATOR,CGET_INDICATOR_INDEXINFO), m_iBufferInfoPtr);
	BroadcastHandle(evt);
	if (evt.handled) {
		return m_iBufferInfoPtr->pt;
	}

	return pt;
}*/

void QTechView::UpdateCalcInfo()
{
	COMREF Commodity = {0};
	GetCurCommodity(&Commodity);
	m_iCalcInfoPtr->Object = Commodity;
	m_iCalcInfoPtr->Period = m_vDispInfoPtr->Period;
	m_iCalcInfoPtr->PeriodEx = m_vDispInfoPtr->PeriodEx;
	m_iCalcInfoPtr->DWType = m_vDispInfoPtr->DWType;
	m_iCalcInfoPtr->DWDate = m_vDispInfoPtr->DWDate;
	UpdateIndicatorCalcInfo();
}

void QTechView::UpdateDispInfo()
{
	COMREF Commodity = {0};
	GetCurCommodity(&Commodity);

	//������ʾ��Ϣ

	//������ʷ����
	ClearHisData();
	LoadHisData(Commodity,m_vDispInfoPtr->Period,m_vDispInfoPtr->PeriodEx,m_vDispInfoPtr->DWType,m_vDispInfoPtr->DWDate);

	int StartDate = m_iDispInfoPtr->StartDate;
	int StartTime = m_iDispInfoPtr->StartTime;
	BAR* pBar = GetBar();
	UINT nBarCount =  GetBarCount();
	SwapIndicatorDispInfo();
	if (StartDate != 0) {
		unsigned long StartPos = 0;
		FindHisDataPos(&StartPos, pBar, nBarCount, StartDate, StartTime);
		m_iDispInfoPtr->Start = StartPos;
	}
	UpdateIndicatorDispInfo(UD_BARSCHANGE);

	if (IsDispOk()) {
		if (m_bCrossCursor) {
			POINT pt;
			GetCursorPos(&pt);
			ScreenToClient(&pt);
			ShowCurrent(pt);
		}
	}
}

void QTechView::OnDispInfoChanged()
{
	//��ͨ��ʾ��Ϣ�仯
	//�������OnRefresh����ˢ�½���?
	BroadcastSend(EVT_PLAT_CALL, MAKEVALUE(MSET_PLAT_OBJECT,CSET_OBJECT_DISPINFO), m_DispInfoPtr);

	m_iDispInfoPtr->InfoHeight = m_DispInfoPtr->xyInfoIndicator.cy;
	m_iDispInfoPtr->InfoWidth = m_DispInfoPtr->xyInfoIndicator.cx;
	m_iDispInfoPtr->TopSpace = 0;
	m_iDispInfoPtr->BottomSpace = m_DispInfoPtr->xySpace.cy;

	m_iDispInfoPtr->Scale = m_DispInfoPtr->nBarScale;

	m_iDispInfoPtr->KLineType = KLINE_K;
	m_iDispInfoPtr->KVolumeType = STICK_BAR;
	//m_iDispInfoPtr->YCoordType = CT_GOLDEN;
}

void QTechView::OnViewInfoChanged()
{
	//��ͼ��Ϣ�仯����Ҫ�ǽ����������ݱ仯����Ҫ����ս���
	//������Ҫ����Ʒ�仯
	//�������OnRefresh����ˢ�½���
	BroadcastSend(EVT_PLAT_CALL, MAKEVALUE(MSET_PLAT_OBJECT,CSET_VIEW_INFO), GetViewInfoPtr());

	ClearHisData();
	
	//�ػ�
	m_dcCoordinate.DeleteDC();
	m_dcCrossCursor.DeleteDC();
	Invalidate();
}

void QTechView::OnViewDispInfoChanged()
{
	//��ͼ��ʾ��Ϣ�仯����Ҫ�ǽ�����ʾ��Ϣ�仯����Ҫ�ػ�
	//������Ҫ�ǳ���Ȩ�����ڵ�
	//�������OnRefresh����ˢ�½���
	BroadcastSend(EVT_PLAT_CALL, MAKEVALUE(MSET_PLAT_OBJECT,CSET_VIEW_DISPINFO), m_vDispInfoPtr);

	//�ػ�
	m_dcCoordinate.DeleteDC();
	m_dcCrossCursor.DeleteDC();
	Invalidate();
}

void QTechView::OnRefresh(ObjectPtr objPtr)
{
	//ˢ�¼�����Ϣ
	UpdateCalcInfo();

	//ˢ����ʾ��Ϣ
	UpdateDispInfo();

	//֪ͨ����ָ�괰��ˢ��
	BroadcastSend(EVT_PLAT_CALL, MAKEVALUE(MCALL_PLAT_OBJECT,CCALL_OBJECT_REFRESH), NULL);

	//�ػ�
	m_dcCoordinate.DeleteDC();
	m_dcCrossCursor.DeleteDC();
	Invalidate();
}

void QTechView::OnHisDataChanged(Event& evt)
{
	//����Ҫ������û��OnRefresh���յ�OnHisDataChanged�������������������ᴦ����

	BroadcastSend(evt);

	//ˢ����ʾ��Ϣ
	UpdateDispInfo();

	m_dcCoordinate.DeleteDC();
	m_dcCrossCursor.DeleteDC();
	Invalidate();

	evt.handled = true;
}

long QTechView::OnCall(Event& evt)
{
	switch(evt.value)
	{
	//////////////////////////////////////////////////////////////////////////
	default:
		evt.handled = false;
		break;
	}
	return RLT_UNKNOWN;
}

long QTechView::OnNotify(Event& evt)
{
	switch(evt.value)
	{
	//////////////////////////////////////////////////////////////////////////
	default:
		evt.handled = false;
		break;
	}
	return RLT_UNKNOWN;
}
