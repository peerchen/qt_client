#ifndef _H_QDataManagerIMPL_H_
#define _H_QDataManagerIMPL_H_

#include <XLib/UIEvent.h>
#include <DataEngine/DataListener.h>

#include <Util/ObjecterMap.h>

class DataManager 
	: public EvtListenerT<DataHandler,DataListener>
	, public EvtRequestT<DataManager,Event,EventLess>
	, public EvtIdler
{
	typedef DataManager This;
	typedef EvtListenerT<DataHandler,DataListener> Base;
	typedef EvtListenerT<DataHandler,DataListener> Listener;
	typedef EvtRequestT<DataManager,Event,EventLess> EvtRequest;
protected:
	CriticalSection m_Section;
	AccountListInfoPtr m_AccountListPtr;
	ServerListInfoPtr m_ServerListPtr;
	typedef std::vector<DataHandler*> pHandlers;
	//��֤��������Register��β�Ķ��󣬱���QL4XRegister
	pHandlers m_pRegisters;
	//��������������󣨰��裩
	pHandlers m_pExchanges;
	//���׶�������Trader��β�Ķ��󣬱���CTPTrader
	pHandlers m_pTraders;
	//��������
	//std::vector<DataHandler*> m_pOthers;

public:
	DataManager();
	~DataManager();

	long Instance();
	void Release();

	void LoadFromFile();
	void SaveToFile();

	//ÿ���ʺ���ɾ�������Init
	virtual void Init();
	//�����˳�ʱ��DeInit
	virtual void DeInit();

public:
	virtual void OnIdle();

protected:
	enum
	{
		FIND_FLAG_NONE				= 0,
		FIND_FLAG_ADD_IFNOTEXIST	= 0X01,
		FIND_FLAG_REMOVE_IFEXIST	= 0X02,
		FIND_FLAG_UPDATE_IFEXIST	= 0X04,
		FIND_FLAG_GET_IFEXIST		= 0X08,
	};

	bool AddAccount(const AccountInfoPtr & objPtr);
	bool RemoveAccount(const AccountInfoPtr & objPtr);
	bool UpdateAccount(const AccountInfoPtr & objPtr);
	bool FindAccount(AccountInfoPtr & objPtr, UINT nFlags = FIND_FLAG_NONE);

	bool AddServer(const ServerInfoPtr & objPtr);
	bool RemoveServer(const ServerInfoPtr & objPtr);
	bool UpdateServer(const ServerInfoPtr & objPtr);
	bool FindServer(ServerInfoPtr & objPtr, UINT nFlags = FIND_FLAG_NONE);

	DataHandler* OpenHandler(LPCSTR lpszName, LPCSTR lpszUser = NULL);
	void CloseHandler(DataHandler* pHandler);
	DataHandler* FindHandler(LPCSTR lpszName, LPCSTR lpszUser = NULL);

	//////////////////////////////////////////////////////////////////////////
	//����ʵ��Ӧ�ò�����ݲ��л�����֤Ӧ�ò�����ݲ��¼�����Ϣ����ֻ�����߳�
	//��ɣ�������Ӧ�ò�Ͳ��ù��Ķ��߳������ˡ�
protected:
	BOOL IsRegister(LPCSTR lpszName);
	BOOL IsExchange(LPCSTR lpszName);
	BOOL IsTrader(LPCSTR lpszName);

	BOOL IsRegister(DataHandler* pHandler);
	BOOL IsExchange(DataHandler* pHandler);
	BOOL IsTrader(DataHandler* pHandler);

	unsigned char Exchange2IdA(const char* szExchange);
	unsigned char Exchange2IdW(const wchar_t* szExchange);
	const char* Id2ExchangeA(const unsigned char Id);
	const wchar_t* Id2ExchangeW(const unsigned char Id);
	DataHandler* FindExchangeBy(const int Pos);
	DataHandler* FindExchangeBy(const char* szExchange);
	DataHandler* FindExchangeBy(const wchar_t* szExchange);
	DataHandler* FindExchangeBy(const unsigned char Exchange);
	DataHandler* FindExchangeBy(const COMREF &  Commodity);
	
public:
	virtual void OnRemoveRequest(const Event& Req,const Event& SubReq);
	virtual void OnAddRequest(const Event& Req, const Event& SubReq);
	virtual void OnUpdateRequest(const Event& Req, const Event& SubReq, long SubReqCount);

protected:
	virtual void OnOffline(OnlineInfoPtr& objPtr);
	virtual void OnInitData(OnlineInfoPtr& objPtr);
	virtual void OnOnline(OnlineInfoPtr& objPtr);
	unsigned char IsOnlineRegister(LPCSTR lpszName, LPCSTR lpszUser = NULL);
	unsigned char IsOnline(LPCSTR lpszName, LPCSTR lpszUser = NULL);
	unsigned char IsOnlineTrader(LPCSTR lpszName, LPCSTR lpszUser = NULL);

protected:
	KindInfo m_SelfKind[KIND_INDEX_SELFMAX];
	std::vector<unsigned long> m_SelfKindIdxs;
	COMREFLIST m_SelfCommoditys[KIND_INDEX_SELFMAX];
	struct CommodityAttrLess
	{
		bool operator()(const CommodityAttr& x, const CommodityAttr& y) const
		{
			return x.Commodity < y.Commodity;
		}
	};
	typedef std::set<CommodityAttr,CommodityAttrLess> CommodityAttrs;
	CommodityAttrs m_CommodityAttrs;
	bool m_bSelfChanged;

	void LoadSelfCommodity(LPCTSTR lpszFileName);
	void SaveSelfCommodity(LPCTSTR lpszFileName);

	typedef std::vector<HisDataInfoPtr> HisDataInfos;
	HisDataInfos m_HisDataInfos;
	long RefHisData(HisDataInfoPtr& objPtr);
	void CleanHisData(const COMREF & Commodity, ENUM_TIMEFRAMES Period);
	void CleanHisData(const unsigned char Exchange);
	void UpdateHisData(const COMREF & Commodity, ENUM_TIMEFRAMES Period);

	//�¼��������̴߳��������Բ��ü���,���������Ҫ������Ӧ����Ҫӳ�������������
	BEGIN_EVT_MAP(This)
		//��������¼�
		ON_EVT(EVT_PLAT_CALL,OnCall)
		ON_EVT(EVT_PLAT_POST,OnRequest)
		//���ݲ�����¼�
		ON_EVT(EVT_DE_NOTIFY,OnNotify)
	END_EVT_MAP()

	long OnCall(Event& evt);
	long OnRequest(Event& evt);
	long OnNotify(Event& evt);
};
//////////////////////////////////////////////////////////////////////////

template<class T, class TBase = DataManager>
class DataManagerT
	: public TBase
	, public Objecter
	, public ObjecterMap<T>
{
	typedef DataManagerT<T,TBase> This;
	typedef TBase Base;
	typedef ObjecterMap<T> ObjectMap;
public:
	DataManagerT()
	{
	}

	~DataManagerT()
	{

	}

	long Instance()
	{
		long rlt = RLT_OK;

		SetDataPtr(this);
 
		rlt = Base::Instance();

		return rlt;
	}

	void Release()
	{
		Base::Release();

		SetDataPtr(NULL);
	}

	void LoadFromFile()
	{
		TCHAR szPath[MAX_PATH];
		TCHAR szUserDir[MAX_PATH];
		ReadValue(USERDIR, szUserDir, MAX_PATH);

		_stprintf(szPath, _T("%s\\usercomm.xml"), szUserDir);
		Base::LoadSelfCommodity(szPath);
	}

	void SaveToFile()
	{
		TCHAR szPath[MAX_PATH];
		TCHAR szUserDir[MAX_PATH];
		ReadValue(USERDIR, szUserDir, MAX_PATH);

		if (m_bSelfChanged) {
			_stprintf(szPath, _T("%s\\usercomm.xml"), szUserDir);
			Base::SaveSelfCommodity(szPath);
			m_bSelfChanged = false;
		}
	}

	virtual void OnIdle()
	{
		SaveToFile();

		Base::OnIdle();
	}

	//////////////////////////////////////////////////////////////////////////

	void OnAccountInfoChanged()
	{//���ﴦ�����Ӻ�ɾ���ʺţ����ʺ��µ���ط���
		int i=0;

		Init();

		DataHandler* pExchange = NULL;
		while(pExchange = FindExchangeBy(i++))
		{
			SendToHandler(pExchange, EVT_DE_SET, SET_DE_ACCOUNTINFO, m_AccountPtr);
		}
	}

	//�¼��������̴߳��������Բ��ü���,���������Ҫ������Ӧ����Ҫӳ�������������
	BEGIN_EVT_MAP(This)
		CHAIN_EVT_MAP(ObjectMap)
		CHAIN_EVT_MAP(Base)
	END_EVT_MAP()
};

//////////////////////////////////////////////////////////////////////////

class QDataManager : public DataManager
{
	typedef QDataManager This;
	typedef DataManager Base;
public:
	QDataManager();
	~QDataManager();

protected:
	virtual void Init();
	virtual void DeInit();

	BEGIN_EVT_MAP(This)
		//��������¼�
		ON_EVT(EVT_PLAT_CALL,OnCall)
		ON_EVT(EVT_PLAT_POST,OnRequest)
		//���ݲ�����¼�
		ON_EVT(EVT_DE_NOTIFY,OnNotify)
		CHAIN_EVT_MAP(Base)
	END_EVT_MAP()

	long OnCall(Event& evt);
	long OnRequest(Event& evt);
	long OnNotify(Event& evt);
};

//////////////////////////////////////////////////////////////////////////

class QDataEngine : public DataManagerT<QDataEngine,QDataManager>
{
public:
};

#endif//_H_QDataManagerIMPL_H_