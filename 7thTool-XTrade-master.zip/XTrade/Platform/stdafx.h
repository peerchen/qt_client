// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//  are changed infrequently
//

#pragma once

// Change these values to use different versions
#define WINVER		0x0500
#define _WIN32_WINNT	0x0501
#define _WIN32_IE	0x0501
#define _RICHEDIT_VER	0x0200

#define	WIN32_LEAN_AND_MEAN   

#include <ShlObj.h>
#include <Shlwapi.h>
#include <ShellAPI.h>
#include <Psapi.h>
//#pragma comment(lib, "ShlObj.lib")
#pragma comment(lib, "Shlwapi.lib")
//#pragma comment(lib, "ShellAPI.lib")
#pragma comment(lib, "Psapi.lib")

#if !defined(_CONSOLE) && !defined(XPLATFORMAPI_EXPORTS)

#include <XLib/UILite.h>

#include <NetIO/NetIO.h>
#pragma comment(lib, "NetIO.lib")

#include <DataEngine/DataEngine.h>
#pragma comment(lib, "DataEngine.lib")

#include <Util/Util.h>

#include "PlatformModule.h"
extern PlatformModule _Module;

#else

#include <XLib/XLib.h>
#include <XLib/XSocket.h>

#include <NetIO/NetIO.h>
#pragma comment(lib, "NetIO.lib")

#include <DataEngine/DataEngine.h>
#pragma comment(lib, "DataEngine.lib")

#endif//_CONSOLE

#pragma comment(lib, "XPlatformLib.lib")
#pragma comment(lib, "XLoginLib.lib")
#pragma comment(lib, "XLogin.lib")

#if defined _M_IX86
  #pragma comment(linker, "/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='x86' publicKeyToken='6595b64144ccf1df' language='*'\"")
#elif defined _M_IA64
  #pragma comment(linker, "/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='ia64' publicKeyToken='6595b64144ccf1df' language='*'\"")
#elif defined _M_X64
  #pragma comment(linker, "/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='amd64' publicKeyToken='6595b64144ccf1df' language='*'\"")
#else
  #pragma comment(linker, "/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='*' publicKeyToken='6595b64144ccf1df' language='*'\"")
#endif
