#ifndef _H_QREPORT_H_
#define _H_QREPORT_H_

#include <XLib/UIXWnd.h>
#include <Util/ViewObjecter.h>

#include <FieldDef.h>

#include "CommCtrl.h"

void ConvertFieldName2LVCOLUMN(FIELD_NAME& FieldName, LVCOLUMN& lvColumn);

template<class T, class TBase = UIXWnd2>
class ReportImpl 
	: public ViewObjecterImpl<T,TBase>
	, public MyListCtrlMap<T>
{
public:
	typedef ReportImpl<T,TBase> This;
	typedef ViewObjecterImpl<T,TBase> Base;
	typedef MyListCtrlMap<T> ListCtrlMap;
protected:
	typedef std::vector<FIELD_NAME> FIELDNAMELIST;
	typedef std::vector<FIELD_VALUE> FIELDVALUELIST;
	FIELDNAMELIST m_FieldNameList;
	FIELDVALUEListInfoPtr m_FieldValueListPtr;
	std::map<const COMREF*,FIELDVALUELIST> m_FieldValueListCache;

public:
	ReportImpl()
	{
		m_FieldValueListPtr = new FIELDVALUEListInfo();
	}

	void OnGetDispInfo(NMLVDISPINFO* lpDispInfo)
	{
		T* pT = static_cast<T*>(this);
		if (lpDispInfo->item.iItem < 0) {
			return;
		}
		DWORD Pos = lpDispInfo->item.iItem;
		int i,j;
		TCHAR szBuf[1024] = {0};

		const COMREF & Commodity = pT->GetCommodityList()[Pos];
		FIELDVALUELIST & FieldValueList = m_FieldValueListCache[&Commodity];
		if (FieldValueList.empty()) {
			m_FieldValueListPtr->Commodity = Commodity;
			for (i=0; i<m_FieldValueListPtr->FieldValueList.size(); i++)
			{
				m_FieldValueListPtr->FieldValueList[i].bCalculated = 0;
				m_FieldValueListPtr->FieldValueList[i].szText[0] = 0;
			}
			SendEvent(_DataPtr, EVT_PLAT_CALL, MAKEVALUE(MGET_PLAT_DE,CGET_DE_FIELD_VALUE), m_FieldValueListPtr);
			SendEvent(_DataPtr, EVT_PLAT_CALL, MAKEVALUE(MGET_PLAT_DE,CGET_DE_FIELD_VALUETEXT), m_FieldValueListPtr);
			FieldValueList = m_FieldValueListPtr->FieldValueList;
		} else if (FieldValueList[1].cTextType != FIELD_VALUE_STRING) {
			m_FieldValueListPtr->Commodity = Commodity;
			m_FieldValueListPtr->FieldValueList.swap(FieldValueList);
			SendEvent(_DataPtr, EVT_PLAT_CALL, MAKEVALUE(MGET_PLAT_DE,CGET_DE_FIELD_VALUETEXT), m_FieldValueListPtr);
			FieldValueList.swap(m_FieldValueListPtr->FieldValueList);
		}
		if (lpDispInfo->item.iSubItem<0 || lpDispInfo->item.iSubItem>=FieldValueList.size()) {
			return;
		}
		if (lpDispInfo->item.mask & LVIF_TEXT) {
			switch (FieldValueList[lpDispInfo->item.iSubItem].FieldID)
			{
			case IDF_INDEX:
				_sntprintf(lpDispInfo->item.pszText, lpDispInfo->item.cchTextMax, _T("%d"), Pos);
				break;
			default:
				lstrcpyn(lpDispInfo->item.pszText, FieldValue2String(FieldValueList[lpDispInfo->item.iSubItem]), lpDispInfo->item.cchTextMax);
				break;
			}
		}
	}

	void OnDrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct)
	{
		T* pT = static_cast<T*>(this);
		UIListCtrl2 wndListCtrl = pT->GetListCtrl();

		UIHeaderCtrl2 wndHeader = wndListCtrl.GetHeader();
		if (!wndHeader) {
			return;
		}

		ObjectDispInfoPtr DispInfoPtr = pT->GetDispInfoPtr();
		if (!DispInfoPtr) {
			return;
		}

		int nColCount = wndHeader.GetItemCount();

		int nCount = wndListCtrl.GetItemCount();

		CDCHandle dc(lpDrawItemStruct->hDC);

		int nPos =lpDrawItemStruct->itemID;
		CRect rcItem = lpDrawItemStruct->rcItem;

		const COMREF & Commodity = pT->GetCommodityList()[nPos];
		FIELDVALUELIST & FieldValueList = m_FieldValueListCache[&Commodity];

		if (lpDrawItemStruct->itemState & ODS_SELECTED) {
			dc.FillSolidRect(rcItem, DispInfoPtr->crRptSelBackgnd);
		}

		dc.SetBkMode(TRANSPARENT);

		COLORREF crOldTextColor = dc.SetTextColor(wndListCtrl.GetTextColor());

		RECT rcSubItem;
		TCHAR szBuffer[MAX_PATH] = {0};
		for (int nCol=0; nCol<nColCount; nCol++)
		{
			if (!wndListCtrl.GetSubItemRect(nPos,nCol,LVIR_LABEL,&rcSubItem))   
				continue; 

			dc.SetTextColor(CalcFieldColor(FieldValueList[nCol]));

			LV_ITEM lvi;
			lvi.mask = LVIF_TEXT;
			lvi.iItem = nPos; 
			lvi.iSubItem = nCol;
			lvi.pszText = szBuffer;
			lvi.cchTextMax = sizeof(szBuffer);
			wndListCtrl.GetItem(&lvi);

			UINT uFormat = DT_SINGLELINE | DT_NOPREFIX | DT_NOCLIP | DT_BOTTOM;
			HD_ITEM hditem = {0};
			hditem.mask = HDI_FORMAT;
			wndHeader.GetItem(nCol, &hditem);
			if( hditem.fmt & HDF_CENTER) {
				uFormat |= DT_CENTER;
			} else if( hditem.fmt & HDF_RIGHT) {
				uFormat |= DT_RIGHT;
			} else {
				uFormat |= DT_LEFT;
			}

			dc.DrawText(szBuffer, lstrlen(szBuffer), &rcSubItem, uFormat);
		}

		dc.SetTextColor(crOldTextColor);
	}

	BEGIN_MSG_MAP(This)
		MESSAGE_HANDLER(WM_COMMAND, OnCommand)

		REFLECTED_NOTIFY_CODE_HANDLER(NM_RCLICK, OnNmRClick)
		REFLECTED_NOTIFY_CODE_HANDLER(NM_DBLCLK, OnNmDblClick)
		
		NOTIFY_CODE_HANDLER(NM_RCLICK, OnNmRClick)
		NOTIFY_CODE_HANDLER(NM_DBLCLK, OnNmDblClick)

		CHAIN_MSG_MAP(ListCtrlMap)
		CHAIN_MSG_MAP(Base)
	END_MSG_MAP()

	LRESULT OnCommand(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		T* pT = static_cast<T*>(this);
		UIListCtrl2 wndListCtrl = pT->GetListCtrl();

		WORD wNotifyCode = HIWORD(wParam); 
		WORD wID = LOWORD(wParam); 
		HWND hwndCtrl = (HWND)lParam;
		switch(wID)
		{
		case ID_REPORT_GOTOCONTAINER:
		case ID_REPORT_NEWCONTAINER:
			{
				LVITEM item = {0};
				if(wndListCtrl.GetSelectedItem(&item)) {
					ContainerInfoPtr infoPtr = new ContainerInfo();
					infoPtr->KindList;
					infoPtr->CommodityListPtr->Kind = pT->GetCurKind();
					infoPtr->CommodityListPtr->CommodityList = pT->GetCommodityList();
					infoPtr->CurCommodityPos = item.iItem;

					TCHAR szPath[MAX_PATH] = {0};
					_stprintf(szPath, _T("%s\\%s"), _Module.GetAppPath(), _T("scdtcontainer.xml"));
					DoGotoContainerPtr gotoPtr = new DoGotoContainer(_T("ScdtContainer"), szPath, XML_FLAG_FILE);
					gotoPtr->InfoPtr = infoPtr;
					if (wID == ID_REPORT_NEWCONTAINER) {
						gotoPtr->bNew = TRUE;
					}
					SendEvent(_FramePtr, EVT_PLAT_CALL, MAKEVALUE(MCALL_PLAT_FRAME,CCALL_FRAME_GOTOCONTAINER), gotoPtr);
				}
			}
			break;
		case ID_COMMAND_ADD_SELFCOMMODITY:
			{
				LVITEM item = {0};
				if(wndListCtrl.GetSelectedItem(&item)) {
					COMREF Commodity = pT->GetCommodityList()[item.iItem];
					AddCommodity(0, &Commodity);
				}
			}
			break;
		case ID_COMMAND_REMOVE_SELFCOMMODITY:
			{
				LVITEM item = {0};
				if(wndListCtrl.GetSelectedItem(&item)) {
					COMREF Commodity = pT->GetCommodityList()[item.iItem];
					RemoveCommodity(0, &Commodity);
				}
			}
			break;
		default:
			bHandled = FALSE;
			break;
		}
		return bHandled;
	}

	LRESULT OnLvnCacheHint(int /*idCtrl*/, LPNMHDR pnmh, BOOL& /*bHandled*/)
	{
		return 0;
	}

	LRESULT OnNmRClick(int /*idCtrl*/, LPNMHDR pnmh, BOOL& /*bHandled*/)
	{
		T* pT = static_cast<T*>(this);
		UIListCtrl2 wndListCtrl = pT->GetListCtrl();

		LPNMITEMACTIVATE pNMLVIC = reinterpret_cast<LPNMITEMACTIVATE>(pnmh);

		LVITEM item = {0};
		if(wndListCtrl.GetSelectedItem(&item)) {
			CMenu menu;
			menu.CreatePopupMenu();

			menu.AppendMenu(MF_STRING, ID_REPORT_GOTOCONTAINER, _T("��������"));
			menu.AppendMenu(MF_STRING, ID_REPORT_NEWCONTAINER, _T("�½���������"));
			menu.AppendMenu(MF_SEPARATOR);
			menu.AppendMenu(MF_STRING, ID_COMMAND_ADD_SELFCOMMODITY, _T("������ѡ��"));
			menu.AppendMenu(MF_STRING, ID_COMMAND_REMOVE_SELFCOMMODITY, _T("�Ƴ���ѡ��"));

			//POINT pt = pNMLVIC->ptAction;
			//ClientToScreen(&pt);
			POINT pt;
			GetCursorPos(&pt);
			menu.TrackPopupMenu(TPM_LEFTALIGN | TPM_LEFTBUTTON | TPM_VERTICAL, pt.x, pt.y, *pT);
		}
		return 0;
	}

	LRESULT OnNmDblClick(int /*idCtrl*/, LPNMHDR pnmh, BOOL& /*bHandled*/)
	{
		T* pT = static_cast<T*>(this);
		pT->SendMessage(WM_COMMAND, MAKEWPARAM(ID_REPORT_GOTOCONTAINER,0), 0L);
		return 0;
	}

public:
	UINT CalcFieldWidth(const FIELD_NAME& FieldName)
	{

	}

	COLORREF CalcFieldColor(const FIELD_VALUE& FieldValue)
	{
		T* pT = static_cast<T*>(this);
		if (m_DispInfoPtr) {
			m_DispInfoPtr->GetFieldColor(FieldValue);
		} else {
			UIListCtrl2 wndListCtrl = pT->GetListCtrl();
			return wndListCtrl.GetTextColor();
		}
	}

	void InitColList()
	{

	}

	void InitCommodityList()
	{
		T* pT = static_cast<T*>(this);
		UIListCtrl2 wndListCtrl = pT->GetListCtrl();

		long i,j;
		m_FieldValueListCache.clear();

		//m_CommodityValueList.resize(m_CommodityList.size(), FieldValueList);
		wndListCtrl.SetItemCount(pT->GetCommodityList().size());
	}

	void RequestData()
	{
		T* pT = static_cast<T*>(this);
		UIListCtrl2 wndListCtrl = pT->GetListCtrl();

		if (!pT->GetCommodityList().empty() && !m_FieldNameList.empty()) {
			REQ_FIELDDATAInfoPtr reqfieldptr = new REQ_FIELDDATAInfo();
			reqfieldptr->uFlags = REQ_FIELD_FLAG_ALL;
			reqfieldptr->Commoditys.push_back(pT->GetCommodityList()[0]);
			reqfieldptr->Fields.reserve(m_FieldNameList.size());
			for (FIELDNAMELIST::iterator it = m_FieldNameList.begin(); it != m_FieldNameList.end(); ++it)
			{
				if (!it->szValue[0]) {
					break;
				}
				reqfieldptr->Fields.push_back(it->FieldID);
			}
			PostEvent(_DataPtr, EVT_PLAT_POST, MAKEVALUE(MREQUEST_PLAT_DE,CREQUEST_DE_FIELD_VALUE), reqfieldptr);
		}
	}

	void OnDispInfoChanged()
	{
		T* pT = static_cast<T*>(this);
		UIListCtrl2 wndListCtrl = pT->GetListCtrl();

		CRect rcWnd;
		GetWindowRect(&rcWnd);

		wndListCtrl.SetBkColor(m_DispInfoPtr->crBackgnd);
		wndListCtrl.SetTextColor(m_DispInfoPtr->crName);
		wndListCtrl.SetTextBkColor(CLR_NONE);
		wndListCtrl.SetInsertMarkColor(CLR_NONE);
		wndListCtrl.SetOutlineColor(CLR_NONE);

		wndListCtrl.SetFont(m_DispInfoPtr->hText);

		UIHeaderCtrl2 wndHeader = wndListCtrl.GetHeader();
		if (wndHeader) {
			wndHeader.SetFont(m_DispInfoPtr->hRptTitle);
		}

		SetItemHeight(m_DispInfoPtr->xyRptText.cy+m_DispInfoPtr->xySpace.cy);
	}

	void OnViewInfoChanged()
	{
		T* pT = static_cast<T*>(this);
		UIListCtrl2 wndListCtrl = pT->GetListCtrl();

		wndListCtrl.DeleteAllItems();
		UIHeaderCtrl2 Header = wndListCtrl.GetHeader();
		for (int i=Header.GetItemCount()-1; i>=0; i--)
		{
			wndListCtrl.DeleteColumn(i);
		}
		pT->InitColList();
		pT->InitCommodityList();
		pT->RequestData();
		pT->UpdateWindowPos();
	}

	BEGIN_EVT_MAP(This)
		ON_EVT(EVT_DE_NOTIFY,OnNotify)
		CHAIN_EVT_MAP(Base)
	END_EVT_MAP()

	long OnNotify(Event& evt)
	{
		T* pT = static_cast<T*>(this);
		
		switch(evt.value)
		{
		case MAKEVALUE(MNOTIFY_PLAT_DE,CNOTIFY_DE_ONLINE):
			{
				if (evt.src == GetDataPtr()) {
					pT->InitCommodityList();
					pT->RequestData();
				} else {
					/*QExchange* pExchange = dynamic_cast<QExchange*>(evt.src);
					if (pExchange) {
					int i,j;
					unsigned char Exchange = pExchange->GetExchangeId();
					const KindInfo& Kind = GetCurKind();
					for (i=0,j=Kind.KindList.size(); i<j; i++)
					{
					if (Exchange == Kind.KindList[i].Exchange) {
					break;
					}
					}
					if (i < j) {
					InitCommodityList();
					RequestData();
					}
					}*/
				}
			}
			break;
		default:
			evt.handled = false;
			break;
		}
		return RLT_UNKNOWN;
	}
};

class CommodityHeaderCtrl 
	: public UIXWnd2Impl<CommodityHeaderCtrl,UIHeaderCtrl2>
	, public UIPaint<CommodityHeaderCtrl>
	, public COwnerDraw<CommodityHeaderCtrl>
{
	typedef CommodityHeaderCtrl This;
	typedef UIXWnd2Impl<CommodityHeaderCtrl,UIHeaderCtrl2> Base;
	typedef UIPaint<CommodityHeaderCtrl> PaintMap;
	typedef COwnerDraw<CommodityHeaderCtrl> OwnerDrawMap;
public:
	CommodityHeaderCtrl();
	virtual ~CommodityHeaderCtrl();

	void OnPaint(HDC hdc);
	
	void DrawItem(LPDRAWITEMSTRUCT lpdis)  
	{  
		 
	} 
	void DeleteItem(LPDELETEITEMSTRUCT lpdis)  
	{  

	} 

	BEGIN_MSG_MAP(This)
		MESSAGE_HANDLER(HDM_LAYOUT, OnLayout) 
		CHAIN_MSG_MAP_ALT(OwnerDrawMap, 1) //����Ϣ������Լ�  1  �и��ദ����Ϣ 0
		CHAIN_MSG_MAP(PaintMap)
		CHAIN_MSG_MAP(Base)
	END_MSG_MAP()

	LRESULT OnLayout(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)  
	{  
		LRESULT lResult = Base::DefWindowProc(uMsg, wParam, lParam);  
		HD_LAYOUT &hdl = *( HD_LAYOUT * ) lParam;  
		/*RECT *prc = hdl.prc;  
		WINDOWPOS *pwpos = hdl.pwpos;  
		int nHeight = (int)(pwpos->cy);  
		if(m_nHeight>=0)  
			nHeight = m_nHeight;  
		pwpos->cy = nHeight;  
		prc->top = nHeight;  */
		return lResult;  
	}  
};

class CommodityReport
	: public ReportImpl<CommodityReport,UIListCtrl2>
	, public UIPaint<CommodityReport>
{
public:
	typedef CommodityReport This;
	typedef ReportImpl<CommodityReport,UIListCtrl2> Base;
	typedef UIPaint<CommodityReport> PaintMap;
	DECLARE_XMLWND_CLASS(_T("ReportView"))
	DECLARE_DYNCREATE_WND_OBJECTER(CommodityReport,Objecter)
public:
	CommodityReport();
	virtual ~CommodityReport();

	//CommodityHeaderCtrl m_wndHeader;

	//BOOL IsDirectUI() { return TRUE; }

	//HWND Create(HWND hWndParent, RECT& rcPos
	//	, LPCTSTR szWindowName = NULL, DWORD dwStyle = 0, DWORD dwExStyle = 0, UINT nID = 0, LPVOID lpCreateParam = NULL);
	//HWND Create(HWND hWndParent, LPCTSTR lpszXml = NULL, UINT XmlFlag = XML_FLAG_FILE);

	void Relayout(LPCRECT lpRect = NULL);

	void GetMinMaxInfo(MINMAXINFO* pMMInfo);

	BOOL OnEraseBkgnd(HDC hdc);
	void OnPaint(HDC hdc);

	BEGIN_MSG_MAP(This)
		MESSAGE_HANDLER(WM_CREATE, OnCreate)
		MESSAGE_HANDLER(WM_DESTROY, OnDestroy)
		//CHAIN_MSG_MAP(PaintMap)
		CHAIN_MSG_MAP(Base)
		DEFAULT_REFLECTION_HANDLER()
	END_MSG_MAP()

	LRESULT OnCreate(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/);
	LRESULT OnDestroy(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& bHandled);

public:
	UINT CalcFieldWidth(const FIELD_NAME& FieldName);
	void InitColList();
};


class QReport 
	: public ReportImpl<QReport>
	, public UIPaint<QReport>
{
	typedef QReport This;
	typedef ReportImpl<QReport> Base;
	typedef UIPaint<QReport> PaintMap;
	DECLARE_XMLWND_CLASS(_T("Report"))
	DECLARE_DYNCREATE_WND_OBJECTER(QReport,Objecter)
protected:
	//����
	static FIELD_NAME m_DefField_Stk[];			//��Ʊ
	static FIELD_NAME m_DefField_Idx[];			//ָ��
	static FIELD_NAME m_DefField_Fund[];		//����
	static FIELD_NAME m_DefField_Warrant[];		//Ȩ֤
	static FIELD_NAME m_DefField_Bond[];		//ծȯ
	static FIELD_NAME m_DefField_Futures[];		//�ڻ�
	static FIELD_NAME m_DefField_Option[];		//��Ȩ
	static FIELD_NAME m_DefField_FX[];			//���

	//����
	static FIELD_NAME m_FinaField_Default[];	//��Ʊ,ָ��
	static FIELD_NAME m_FinaField_Fund[];		//����
	static FIELD_NAME m_FinaField_Warrant[];	//Ȩ֤
	static FIELD_NAME m_FinaField_Option[];		//��Ȩ
	static FIELD_NAME m_FinaField_Bond[];		//ծȯ
public:
	QReport();

	UIListCtrl2 m_wndListCtrl;
	UIListCtrl2 GetListCtrl() { return m_wndListCtrl; }

	HWND Create(HWND hWndParent, RECT& rcPos
		, LPCTSTR szWindowName = NULL, DWORD dwStyle = 0, DWORD dwExStyle = 0, UINT nID = 0, LPVOID lpCreateParam = NULL);
	HWND Create(HWND hWndParent, LPCTSTR lpszXml = NULL, UINT XmlFlag = XML_FLAG_FILE);

	BOOL OnEraseBkgnd(HDC hdc);
	void OnPaint(HDC hdc);
	
	BEGIN_MSG_MAP(This)
		MESSAGE_HANDLER(WM_CREATE, OnCreate)
		MESSAGE_HANDLER(WM_DESTROY, OnDestroy)
		MESSAGE_HANDLER(WM_SIZE, OnSize)
		CHAIN_MSG_MAP(PaintMap)
		CHAIN_MSG_MAP(Base)
	END_MSG_MAP()

	LRESULT OnCreate(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/);
	LRESULT OnDestroy(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& bHandled);
	LRESULT OnSize(UINT /*uMsg*/, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

public:
	void InitColList();
};

#endif//_H_QREPORT_H_