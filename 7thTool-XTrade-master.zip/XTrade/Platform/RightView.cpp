#include "stdafx.h"
#include "RightView.h"

//////////////////////////////////////////////////////////////////////////
///CommodityInfoView

IMPLEMENT_DYNCREATE_WND_OBJECTER(CommodityTitleView,Objecter)

CommodityTitleView::CommodityTitleView()
{
	m_FieldValueListPtr = new FIELDVALUEListInfo();
	FIELD_VALUE Field = {0};
	Field.FieldID = IDF_COMMODITY_NAME;
	m_FieldValueListPtr->FieldValueList.push_back(Field);
}

CommodityTitleView::~CommodityTitleView()
{

}

void CommodityTitleView::GetMinMaxInfo(MINMAXINFO* pMMInfo)
{
	if (!m_DispInfoPtr) {
		return;
	}
	//pMMInfo->ptMinTrackSize.x = m_DispInfoPtr->xyInfoIndicator.cx;
	pMMInfo->ptMinTrackSize.y = m_DispInfoPtr->xyInfoIndicator.cy;
}

void CommodityTitleView::OnPaint(HDC hdc)
{
	CDCHandle dc(hdc);

	CRect rcClient;
	GetClientRect(&rcClient);

	dc.FillSolidRect(&rcClient, m_DispInfoPtr->crBackgnd);

	CPoint ptCenter = rcClient.CenterPoint();
	RECT rc = rcClient;
	CHAR szTitle[1024] = {0};
	int nTitleLen = 0;

	rc = rcClient;
	rc.right = ptCenter.x - m_DispInfoPtr->xySpace.cx;
	nTitleLen = sprintf(szTitle, "%s", m_FieldValueListPtr->FieldValueList[0].szValueA);
	UIgdi::DrawTextA(hdc, szTitle, nTitleLen, &rc, DT_RIGHT|DT_VCENTER|DT_SINGLELINE, m_DispInfoPtr->crCommodityName, m_DispInfoPtr->hText);

	rc = rcClient;
	rc.left = ptCenter.x + m_DispInfoPtr->xySpace.cx;
	nTitleLen = sprintf(szTitle, "%s", m_FieldValueListPtr->Commodity.Code);
	UIgdi::DrawTextA(hdc, szTitle, nTitleLen, &rc, DT_LEFT|DT_VCENTER|DT_SINGLELINE, m_DispInfoPtr->crCommodityCode, m_DispInfoPtr->hText);
}

void CommodityTitleView::OnDispInfoChanged()
{
	Invalidate();
}

void CommodityTitleView::OnViewInfoChanged()
{
	GetCurCommodity(&m_FieldValueListPtr->Commodity);
	m_FieldValueListPtr->FieldValueList[0].bCalculated = 0;
	SendEvent(_DataPtr, EVT_PLAT_CALL, MAKEVALUE(MGET_PLAT_DE,CGET_DE_FIELD_VALUE), m_FieldValueListPtr);
	Invalidate();
	UpdateWindow();
}

void CommodityTitleView::OnRefresh(ObjectPtr objPtr)
{
	
}

//////////////////////////////////////////////////////////////////////////
///CommodityMmpView

IMPLEMENT_DYNCREATE_WND_OBJECTER(CommodityMmpView,Objecter)

CommodityMmpView::CommodityMmpView()
{
	int i,j;

	m_FieldNameListPtr = new FIELDNAMEListInfo();
	FIELD_NAME FieldName = {0};
	FieldName.cValueType = FIELD_VALUE_STRING;
	m_FieldNameListPtr->FieldNameList.resize(5*2,FieldName);
	m_FieldNameListPtr->FieldNameList[0].FieldID = IDF_ASK_PRICE_5;
	m_FieldNameListPtr->FieldNameList[1].FieldID = IDF_ASK_PRICE_4;
	m_FieldNameListPtr->FieldNameList[2].FieldID = IDF_ASK_PRICE_3;
	m_FieldNameListPtr->FieldNameList[3].FieldID = IDF_ASK_PRICE_2;
	m_FieldNameListPtr->FieldNameList[4].FieldID = IDF_ASK_PRICE_1;
	m_FieldNameListPtr->FieldNameList[5].FieldID = IDF_BID_PRICE_1;
	m_FieldNameListPtr->FieldNameList[6].FieldID = IDF_BID_PRICE_2;
	m_FieldNameListPtr->FieldNameList[7].FieldID = IDF_BID_PRICE_3;
	m_FieldNameListPtr->FieldNameList[8].FieldID = IDF_BID_PRICE_4;
	m_FieldNameListPtr->FieldNameList[9].FieldID = IDF_BID_PRICE_5;

	m_FieldValueListPtr = new FIELDVALUEListInfo();
	FIELD_VALUE FieldValue = {0};
	FieldValue.cTextType = FIELD_VALUE_STRING;
	m_FieldValueListPtr->FieldValueList.resize(5*3*2,FieldValue);
	//
	m_FieldValueListPtr->FieldValueList[0].FieldID = IDF_ASK_PRICE_5;
	m_FieldValueListPtr->FieldValueList[1].FieldID = IDF_ASK_VOLUME_5;
	m_FieldValueListPtr->FieldValueList[2].FieldID = IDF_ASK_VOL_DIFF_5;
	//
	m_FieldValueListPtr->FieldValueList[3].FieldID = IDF_ASK_PRICE_4;
	m_FieldValueListPtr->FieldValueList[4].FieldID = IDF_ASK_VOLUME_4;
	m_FieldValueListPtr->FieldValueList[5].FieldID = IDF_ASK_VOL_DIFF_4;
	//
	m_FieldValueListPtr->FieldValueList[6].FieldID = IDF_ASK_PRICE_3;
	m_FieldValueListPtr->FieldValueList[7].FieldID = IDF_ASK_VOLUME_3;
	m_FieldValueListPtr->FieldValueList[8].FieldID = IDF_ASK_VOL_DIFF_3;
	//
	m_FieldValueListPtr->FieldValueList[9].FieldID = IDF_ASK_PRICE_2;
	m_FieldValueListPtr->FieldValueList[10].FieldID = IDF_ASK_VOLUME_2;
	m_FieldValueListPtr->FieldValueList[11].FieldID = IDF_ASK_VOL_DIFF_2;
	//
	m_FieldValueListPtr->FieldValueList[12].FieldID = IDF_ASK_PRICE_1;
	m_FieldValueListPtr->FieldValueList[13].FieldID = IDF_ASK_VOLUME_1;
	m_FieldValueListPtr->FieldValueList[14].FieldID = IDF_ASK_VOL_DIFF_1;
	//
	m_FieldValueListPtr->FieldValueList[15].FieldID = IDF_BID_PRICE_1;
	m_FieldValueListPtr->FieldValueList[16].FieldID = IDF_BID_VOLUME_1;
	m_FieldValueListPtr->FieldValueList[17].FieldID = IDF_BID_VOL_DIFF_1;
	//
	m_FieldValueListPtr->FieldValueList[18].FieldID = IDF_BID_PRICE_2;
	m_FieldValueListPtr->FieldValueList[19].FieldID = IDF_BID_VOLUME_2;
	m_FieldValueListPtr->FieldValueList[20].FieldID = IDF_BID_VOL_DIFF_2;
	//
	m_FieldValueListPtr->FieldValueList[21].FieldID = IDF_BID_PRICE_3;
	m_FieldValueListPtr->FieldValueList[22].FieldID = IDF_BID_VOLUME_3;
	m_FieldValueListPtr->FieldValueList[23].FieldID = IDF_BID_VOL_DIFF_3;
	//
	m_FieldValueListPtr->FieldValueList[24].FieldID = IDF_BID_PRICE_4;
	m_FieldValueListPtr->FieldValueList[25].FieldID = IDF_BID_VOLUME_4;
	m_FieldValueListPtr->FieldValueList[26].FieldID = IDF_BID_VOL_DIFF_4;
	//
	m_FieldValueListPtr->FieldValueList[27].FieldID = IDF_BID_PRICE_5;
	m_FieldValueListPtr->FieldValueList[28].FieldID = IDF_BID_VOLUME_5;
	m_FieldValueListPtr->FieldValueList[29].FieldID = IDF_BID_VOL_DIFF_5;

	m_ReqFieldDataPtr = new REQ_FIELDDATAInfo();
	m_ReqFieldDataPtr->uFlags = REQ_FIELD_FLAG_SOME;
	m_ReqFieldDataPtr->Commoditys.resize(1);
	m_ReqFieldDataPtr->Fields.resize(5*3*2);
	//
	m_ReqFieldDataPtr->Fields[0] = IDF_ASK_PRICE_5;
	m_ReqFieldDataPtr->Fields[1] = IDF_ASK_VOLUME_5;
	m_ReqFieldDataPtr->Fields[2] = IDF_ASK_VOL_DIFF_5;
	//
	m_ReqFieldDataPtr->Fields[3] = IDF_ASK_PRICE_4;
	m_ReqFieldDataPtr->Fields[4] = IDF_ASK_VOLUME_4;
	m_ReqFieldDataPtr->Fields[5] = IDF_ASK_VOL_DIFF_4;
	//
	m_ReqFieldDataPtr->Fields[6] = IDF_ASK_PRICE_3;
	m_ReqFieldDataPtr->Fields[7] = IDF_ASK_VOLUME_3;
	m_ReqFieldDataPtr->Fields[8] = IDF_ASK_VOL_DIFF_3;
	//
	m_ReqFieldDataPtr->Fields[9] = IDF_ASK_PRICE_2;
	m_ReqFieldDataPtr->Fields[10] = IDF_ASK_VOLUME_2;
	m_ReqFieldDataPtr->Fields[11] = IDF_ASK_VOL_DIFF_2;
	//
	m_ReqFieldDataPtr->Fields[12] = IDF_ASK_PRICE_1;
	m_ReqFieldDataPtr->Fields[13] = IDF_ASK_VOLUME_1;
	m_ReqFieldDataPtr->Fields[14] = IDF_ASK_VOL_DIFF_1;
	//
	m_ReqFieldDataPtr->Fields[15] = IDF_BID_PRICE_1;
	m_ReqFieldDataPtr->Fields[16] = IDF_BID_VOLUME_1;
	m_ReqFieldDataPtr->Fields[17] = IDF_BID_VOL_DIFF_1;
	//
	m_ReqFieldDataPtr->Fields[18] = IDF_BID_PRICE_2;
	m_ReqFieldDataPtr->Fields[19] = IDF_BID_VOLUME_2;
	m_ReqFieldDataPtr->Fields[20] = IDF_BID_VOL_DIFF_2;
	//
	m_ReqFieldDataPtr->Fields[21] = IDF_BID_PRICE_3;
	m_ReqFieldDataPtr->Fields[22] = IDF_BID_VOLUME_3;
	m_ReqFieldDataPtr->Fields[23] = IDF_BID_VOL_DIFF_3;
	//
	m_ReqFieldDataPtr->Fields[24] = IDF_BID_PRICE_4;
	m_ReqFieldDataPtr->Fields[25] = IDF_BID_VOLUME_4;
	m_ReqFieldDataPtr->Fields[26] = IDF_BID_VOL_DIFF_4;
	//
	m_ReqFieldDataPtr->Fields[27] = IDF_BID_PRICE_5;
	m_ReqFieldDataPtr->Fields[28] = IDF_BID_VOLUME_5;
	m_ReqFieldDataPtr->Fields[29] = IDF_BID_VOL_DIFF_5;
}

CommodityMmpView::~CommodityMmpView()
{

}

void CommodityMmpView::GetMinMaxInfo(MINMAXINFO* pMMInfo)
{
	if (!m_DispInfoPtr) {
		return;
	}
	//pMMInfo->ptMinTrackSize.x = m_DispInfoPtr->xyTitleCtrl.cx;
	pMMInfo->ptMinTrackSize.y = (m_DispInfoPtr->xyName.cy + m_DispInfoPtr->xySpace.cy) * 10;
}

void CommodityMmpView::OnPaint(HDC hdc)
{
	CDCHandle dc(hdc);

	CRect rcClient;
	GetClientRect(&rcClient);

	dc.FillSolidRect(&rcClient, m_DispInfoPtr->crBackgnd);

	HFONT hOldFont = NULL;

	CPoint ptCenter = rcClient.CenterPoint();

	int i;
	CRect rcText = rcClient;
	for (i=0; i<10; i++)
	{
		rcText.bottom = rcText.top + m_DispInfoPtr->xyName.cy + m_DispInfoPtr->xySpace.cy;

		RECT rcName,rcPrice,rcVolume,rcVolDif;
		rcName = rcPrice = rcVolume = rcVolDif = rcText;
		rcName.right = ptCenter.x;
		rcPrice.right = ptCenter.x;
		rcVolume.left = ptCenter.x;
		rcVolume.right = rcVolume.left + (rcVolume.right-rcVolume.left)/2;
		rcVolDif.left = rcVolume.right;

		FIELD_NAME FieldName = {0};
		FIELD_VALUE FieldValue = {0};

		TCHAR szText[1024] = {0};
		int nTextLen = 0;

		if (i == 5) {
			UIgdi::DrawLine(hdc, rcText.left, rcText.top, rcText.right, rcText.top, PS_SOLID, 1, m_DispInfoPtr->crXYLine, R2_COPYPEN);
		}
		
		FieldName = m_FieldNameListPtr->FieldNameList[i];
		nTextLen = _stprintf(szText, _T("%s"), FieldName2String(FieldName));
		UIgdi::DrawText(hdc, szText, nTextLen, &rcName, DT_LEFT|DT_BOTTOM|DT_SINGLELINE, m_DispInfoPtr->crName, m_DispInfoPtr->hName);

		FieldValue = m_FieldValueListPtr->FieldValueList[i*3+0];
		nTextLen = _stprintf(szText, _T("%s"), FieldValue2String(FieldValue));
		UIgdi::DrawText(hdc, szText, nTextLen, &rcPrice, DT_RIGHT|DT_BOTTOM|DT_SINGLELINE, m_DispInfoPtr->GetFieldColor(FieldValue), m_DispInfoPtr->hText);

		FieldValue = m_FieldValueListPtr->FieldValueList[i*3+1];
		nTextLen = _stprintf(szText, _T("%s"), FieldValue2String(FieldValue));
		UIgdi::DrawText(hdc, szText, nTextLen, &rcVolume, DT_RIGHT|DT_BOTTOM|DT_SINGLELINE, m_DispInfoPtr->GetFieldColor(FieldValue), m_DispInfoPtr->hText);

		FieldValue = m_FieldValueListPtr->FieldValueList[i*3+2];
		nTextLen = _stprintf(szText, _T("%s"), FieldValue2String(FieldValue,_T("")));
		UIgdi::DrawText(hdc, szText, nTextLen, &rcVolDif, DT_RIGHT|DT_BOTTOM|DT_SINGLELINE, m_DispInfoPtr->GetFieldColor(FieldValue), m_DispInfoPtr->hText);

		rcText.top = rcText.bottom;
	}
}

void CommodityMmpView::OnDispInfoChanged()
{
	Invalidate();
}

void CommodityMmpView::OnViewInfoChanged()
{
	int i,j;
	COMREF Commodity;
	GetCurCommodity(&Commodity);
	m_FieldNameListPtr->Commodity = Commodity;
	for (i=0,j=m_FieldNameListPtr->FieldNameList.size(); i<j; i++)
	{
		m_FieldNameListPtr->FieldNameList[i].bCalculated = 0;
	}

	m_FieldValueListPtr->Commodity = Commodity;
	for (i=0,j=m_FieldValueListPtr->FieldValueList.size(); i<j; i++)
	{
		m_FieldValueListPtr->FieldValueList[i].bCalculated = 0;
		m_FieldValueListPtr->FieldValueList[i].szText[0] = 0;
	}

	m_ReqFieldDataPtr->Commoditys[0] = Commodity;

	Invalidate();
}

void CommodityMmpView::OnRefresh(ObjectPtr objPtr)
{
	int i,j;
	COMREF Commodity;
	GetCurCommodity(&Commodity);
	m_FieldNameListPtr->Commodity = Commodity;
	for (i=0,j=m_FieldNameListPtr->FieldNameList.size(); i<j; i++)
	{
		m_FieldNameListPtr->FieldNameList[i].bCalculated = 0;
	}
	SendEvent(_DataPtr, EVT_PLAT_CALL, MAKEVALUE(MGET_PLAT_DE,CGET_DE_FIELD_NAME), m_FieldNameListPtr);

	m_FieldValueListPtr->Commodity = Commodity;
	for (i=0,j=m_FieldValueListPtr->FieldValueList.size(); i<j; i++)
	{
		m_FieldValueListPtr->FieldValueList[i].bCalculated = 0;
		m_FieldValueListPtr->FieldValueList[i].szText[0] = 0;
	}
	SendEvent(_DataPtr, EVT_PLAT_CALL, MAKEVALUE(MGET_PLAT_DE,CGET_DE_FIELD_VALUE), m_FieldValueListPtr);

	m_ReqFieldDataPtr->Commoditys[0] = Commodity;
	SendEvent(GetContainer(), EVT_PLAT_POST, MAKEVALUE(MREQUEST_PLAT_DE,CREQUEST_DE_FIELD_VALUE), m_ReqFieldDataPtr);

	Invalidate();
}

void CommodityMmpView::OnFieldDataChanged(Event& evt)
{
	int i,j;
	//SendToData(EVT_PLAT_CALL, MAKEVALUE(MGET_PLAT_DE,CGET_DE_FIELD_NAME), m_FieldNameListPtr);
	for (i=0,j=m_FieldValueListPtr->FieldValueList.size(); i<j; i++)
	{
		m_FieldValueListPtr->FieldValueList[i].bCalculated = 0;
		m_FieldValueListPtr->FieldValueList[i].szText[0] = 0;
	}
	SendEvent(_DataPtr, EVT_PLAT_CALL, MAKEVALUE(MGET_PLAT_DE,CGET_DE_FIELD_VALUE), m_FieldValueListPtr);

	Invalidate();
}

//////////////////////////////////////////////////////////////////////////
///CommodityInfoView

IMPLEMENT_DYNCREATE_WND_OBJECTER(CommodityInfoView,Objecter)

CommodityInfoView::CommodityInfoView()
{
	//m_FieldFlag;
	m_MaxFieldPerLine = 0;
	m_FieldNameListPtr = new FIELDNAMEListInfo();
	m_FieldValueListPtr = new FIELDVALUEListInfo();
	m_ReqFieldDataPtr = new REQ_FIELDDATAInfo();
}

CommodityInfoView::~CommodityInfoView()
{

}

HWND CommodityInfoView::CreateControl(HWND hWndParent, LPCTSTR lpszWndClass, LPCTSTR lpszCtrlName, UINT nID, LPCTSTR lpszXml, UINT XmlFlag)
{
	//�ȴ�������ɣ�������Ʒ��ȥ��ȡFIELDID�͸���FIELDVALUE
	/*m_FieldFlag.resize(m_FieldFlag.size() + 1);
	m_FieldNameListPtr->FieldNameList.resize(m_FieldNameListPtr->FieldNameList.size() + 1);
	//m_FieldValueListPtr->FieldValueList.resize(m_FieldValueListPtr->FieldValueList.size() + 1);
	UINT& Flag = m_FieldFlag.back();
	FIELD_NAME& FieldName = m_FieldNameListPtr->FieldNameList.back();
	//FIELD_VALUE& FieldValue = m_FieldValueListPtr->FieldValueList.back();

	if (_tcsicmp(lpszWndClass, _T("break")) == 0) {
		Flag = FIELD_FLAG_BREAK;
		return NULL;
	} else if (_tcsicmp(lpszWndClass, _T("field")) == 0) {
		_tcscpy(FieldName.szValue, lpszCtrlName);
		return NULL;
	}*/

	return Base::CreateControl(hWndParent, lpszWndClass, lpszCtrlName, nID, lpszXml, XmlFlag);
}

void CommodityInfoView::GetMinMaxInfo(MINMAXINFO* pMMInfo)
{
	int i,j;
	LONG cy = max(m_DispInfoPtr->xyName.cy,m_DispInfoPtr->xyText.cy);
	i=0,j=m_FieldFlag.size();
	if(j>0) {
		//pMMInfo->ptMinTrackSize.x = 0;
		pMMInfo->ptMinTrackSize.y = m_DispInfoPtr->xySpace.cy;
		for (; i<j; i++)
		{
			if (m_FieldFlag[i]) {
				pMMInfo->ptMinTrackSize.y += m_DispInfoPtr->xyName.cy + m_DispInfoPtr->xySpace.cy;
				if(m_FieldFlag[i] == FIELD_FLAG_BREAKLINE) {
					pMMInfo->ptMinTrackSize.y += m_DispInfoPtr->xySpace.cy;
				}
			}
		}
		pMMInfo->ptMinTrackSize.y += m_DispInfoPtr->xyName.cy + m_DispInfoPtr->xySpace.cy;
	}
}

LRESULT CommodityInfoView::OnCreate(UINT /*uMsg*/, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	LRESULT Res = DefWindowProc();
#if 1//test
	SetTimer(100,1000);
#endif//
	return Res;
}

LRESULT CommodityInfoView::OnDestroy(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& bHandled)
{
	bHandled = FALSE;

	m_dc.DeleteDC();

	return bHandled;
}

LRESULT CommodityInfoView::OnSize(UINT /*uMsg*/, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	if (wParam != SIZE_MINIMIZED && lParam != 0) {
		m_dc.DeleteDC();
	}
	return 0;
}

LRESULT CommodityInfoView::OnMouse(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	return bHandled;
}

void CommodityInfoView::OnPaint(HDC hdc)
{
	if(!m_dc) {
		Draw();
	}
	if(!m_dc) {
		return;
	}

	CDCHandle dc(hdc);
	
	CRect rcClient;
	GetClientRect(&rcClient);

	dc.BitBlt(rcClient.left, rcClient.top, rcClient.Width(), rcClient.Height()
		, m_dc, 0, 0, SRCCOPY);
	//dc.TransparentBlt(rcClient.left, rcClient.top, rcClient.Width(), rcClient.Height()
	//	, m_dc, 0, 0, rcClient.Width(), rcClient.Height(), RGB(0,0,0));
}

void CommodityInfoView::Draw()
{
	if (!m_DispInfoPtr) {
		return;
	}

	if(!m_dc) {
		int i,j;

		CRect rcClient;
		GetClientRect(&rcClient);

		HDC hdc = GetDC();

		m_dc.CreateCompatibleDC(hdc, &rcClient);

		m_dc.SetBkMode(TRANSPARENT);
		m_dc.FillSolidRect(&rcClient, m_DispInfoPtr->crBackgnd);
		
		LPCTSTR szText = NULL;
		int nTextLen = 0;

		UINT nFieldWidth = rcClient.Width()/m_MaxFieldPerLine;

		CRect rcText = rcClient;
		rcText.bottom = rcClient.top + m_DispInfoPtr->xySpace.cy;

		rcText.left = rcClient.left;
		rcText.right = rcText.left + nFieldWidth;
		rcText.top = rcText.bottom;
		rcText.bottom = rcText.top + m_DispInfoPtr->xyName.cy;

		rcText.left += m_DispInfoPtr->xySpace.cx;
		for (i=0,j=m_FieldFlag.size(); i<j; i++)
		{
			szText = FieldName2String(m_FieldNameListPtr->FieldNameList[i]);
			nTextLen = _tcslen(szText);
			UIgdi::DrawText(m_dc, szText, nTextLen, &rcText, DT_SINGLELINE|DT_LEFT|DT_BOTTOM, m_DispInfoPtr->crName, m_DispInfoPtr->hName);
			szText = FieldValue2String(m_FieldValueListPtr->FieldValueList[i]);
			nTextLen = _tcslen(szText);
			UIgdi::DrawText(m_dc, szText, nTextLen, &rcText, DT_SINGLELINE|DT_RIGHT|DT_BOTTOM
				, m_DispInfoPtr->GetFieldColor(m_FieldValueListPtr->FieldValueList[i]), m_DispInfoPtr->hText);
			rcText.OffsetRect(nFieldWidth, 0);
			if (m_FieldFlag[i]) {
				rcText.bottom += m_DispInfoPtr->xySpace.cy;

				rcText.left = rcClient.left;
				rcText.right = rcText.left + nFieldWidth;
				rcText.top = rcText.bottom;
				rcText.bottom = rcText.top + m_DispInfoPtr->xyName.cy;

				rcText.left += m_DispInfoPtr->xySpace.cx;

				if (m_FieldFlag[i] == FIELD_FLAG_BREAKLINE) {
					//rcText.top += 1;
					UIgdi::DrawLine(m_dc, rcClient.left, rcText.top, rcClient.right, rcText.top, PS_SOLID, 1, m_DispInfoPtr->crXYLine, R2_COPYPEN);
					rcText.top += m_DispInfoPtr->xySpace.cy;
					rcText.bottom = rcText.top + m_DispInfoPtr->xyName.cy;
				}
			}
		}

		ReleaseDC(hdc);
	}
}

void CommodityInfoView::OnDispInfoChanged()
{
	m_dc.DeleteDC();
	Invalidate();
}

void CommodityInfoView::OnViewInfoChanged()
{
	COMREF Commodity = {0};
	GetCurCommodity(&Commodity);
	m_FieldFlag.clear();
	m_FieldNameListPtr->FieldNameList.clear();
	m_FieldValueListPtr->FieldValueList.clear();
	m_ReqFieldDataPtr->Commoditys.clear();
	m_ReqFieldDataPtr->Fields.clear();
	switch (MarketType(Commodity.Exchange))
	{
	case XMT_FUTURES:
		{
			m_FieldFlag.resize(20);
			m_MaxFieldPerLine = 2;
			m_FieldNameListPtr->Commodity = Commodity;
			FIELD_NAME FieldName = {0};
			FieldName.cValueType = FIELD_VALUE_STRING;
			m_FieldNameListPtr->FieldNameList.resize(20, FieldName);
			m_FieldValueListPtr->Commodity = Commodity;
			FIELD_VALUE FieldValue = {0};
			FieldValue.cTextType = FIELD_VALUE_STRING;
			m_FieldValueListPtr->FieldValueList.resize(20, FieldValue);
			m_FieldNameListPtr->FieldNameList[0].FieldID = IDF_NOW;
			m_FieldValueListPtr->FieldValueList[0].FieldID = IDF_NOW;
			m_FieldNameListPtr->FieldNameList[1].FieldID = IDF_OPEN;
			m_FieldValueListPtr->FieldValueList[1].FieldID = IDF_OPEN;
			m_FieldFlag[1] = FIELD_FLAG_BREAK;
			m_FieldNameListPtr->FieldNameList[2].FieldID = IDF_DELTA;
			m_FieldValueListPtr->FieldValueList[2].FieldID = IDF_DELTA;
			m_FieldNameListPtr->FieldNameList[3].FieldID = IDF_HIGH;
			m_FieldValueListPtr->FieldValueList[3].FieldID = IDF_HIGH;
			m_FieldFlag[3] = FIELD_FLAG_BREAK;
			m_FieldNameListPtr->FieldNameList[4].FieldID = IDF_DELTA_PERCENT;
			m_FieldValueListPtr->FieldValueList[4].FieldID = IDF_DELTA_PERCENT;
			m_FieldNameListPtr->FieldNameList[5].FieldID = IDF_LOW;
			m_FieldValueListPtr->FieldValueList[5].FieldID = IDF_LOW;
			m_FieldFlag[5] = FIELD_FLAG_BREAK;
			m_FieldNameListPtr->FieldNameList[6].FieldID = IDF_VOLUME;
			m_FieldValueListPtr->FieldValueList[6].FieldID = IDF_VOLUME;
			m_FieldNameListPtr->FieldNameList[7].FieldID = IDF_LAST_VOLUME;
			m_FieldValueListPtr->FieldValueList[7].FieldID = IDF_LAST_VOLUME;
			m_FieldFlag[7] = FIELD_FLAG_BREAK;
			m_FieldNameListPtr->FieldNameList[8].FieldID = IDF_POSITION;
			m_FieldValueListPtr->FieldValueList[8].FieldID = IDF_POSITION;
			m_FieldNameListPtr->FieldNameList[9].FieldID = IDF_SETTLEMENT;
			m_FieldValueListPtr->FieldValueList[9].FieldID = IDF_SETTLEMENT;
			m_FieldFlag[9] = FIELD_FLAG_BREAK;
			m_FieldNameListPtr->FieldNameList[10].FieldID = IDF_PREV_POSITION;
			m_FieldValueListPtr->FieldValueList[10].FieldID = IDF_PREV_POSITION;
			m_FieldNameListPtr->FieldNameList[11].FieldID = IDF_PREV_SETTLEMENT;
			m_FieldValueListPtr->FieldValueList[11].FieldID = IDF_PREV_SETTLEMENT;
			m_FieldFlag[11] = FIELD_FLAG_BREAK;
			m_FieldNameListPtr->FieldNameList[12].FieldID = IDF_OPEN_POSITION;
			m_FieldValueListPtr->FieldValueList[12].FieldID = IDF_OPEN_POSITION;
			m_FieldNameListPtr->FieldNameList[13].FieldID = IDF_CLOSE_POSITION;
			m_FieldValueListPtr->FieldValueList[13].FieldID = IDF_CLOSE_POSITION;
			m_FieldFlag[13] = FIELD_FLAG_BREAK;
			m_FieldNameListPtr->FieldNameList[14].FieldID = IDF_LAST_OPEN_POSITION;
			m_FieldValueListPtr->FieldValueList[14].FieldID = IDF_LAST_OPEN_POSITION;
			m_FieldNameListPtr->FieldNameList[15].FieldID = IDF_LAST_CLOSE_POSITION;
			m_FieldValueListPtr->FieldValueList[15].FieldID = IDF_LAST_CLOSE_POSITION;
			m_FieldFlag[15] = FIELD_FLAG_BREAK;
			m_FieldNameListPtr->FieldNameList[16].FieldID = IDF_AVERAGE_PRICE;
			m_FieldValueListPtr->FieldValueList[16].FieldID = IDF_AVERAGE_PRICE;
			m_FieldNameListPtr->FieldNameList[17].FieldID = IDF_DELTA_POSITION;
			m_FieldValueListPtr->FieldValueList[17].FieldID = IDF_DELTA_POSITION;
			m_FieldFlag[17] = FIELD_FLAG_BREAKLINE;
			m_FieldNameListPtr->FieldNameList[18].FieldID = IDF_BOUGHT_VOLUME;
			m_FieldValueListPtr->FieldValueList[18].FieldID = IDF_BOUGHT_VOLUME;
			m_FieldNameListPtr->FieldNameList[19].FieldID = IDF_SOLD_VOLUME;
			m_FieldValueListPtr->FieldValueList[19].FieldID = IDF_SOLD_VOLUME;

			m_ReqFieldDataPtr->uFlags = REQ_FIELD_FLAG_SOME;
			m_ReqFieldDataPtr->Commoditys.resize(1,Commodity);
			m_ReqFieldDataPtr->Fields.resize(20);
			m_ReqFieldDataPtr->Fields[0] = IDF_NOW;
			m_ReqFieldDataPtr->Fields[1] = IDF_OPEN;
			m_ReqFieldDataPtr->Fields[2] = IDF_DELTA;
			m_ReqFieldDataPtr->Fields[3] = IDF_HIGH;
			m_ReqFieldDataPtr->Fields[4] = IDF_DELTA_PERCENT;
			m_ReqFieldDataPtr->Fields[5] = IDF_LOW;
			m_ReqFieldDataPtr->Fields[6] = IDF_VOLUME;
			m_ReqFieldDataPtr->Fields[7] = IDF_LAST_VOLUME;
			m_ReqFieldDataPtr->Fields[8] = IDF_POSITION;
			m_ReqFieldDataPtr->Fields[9] = IDF_SETTLEMENT;
			m_ReqFieldDataPtr->Fields[10] = IDF_PREV_POSITION;
			m_ReqFieldDataPtr->Fields[11] = IDF_PREV_SETTLEMENT;
			m_ReqFieldDataPtr->Fields[12] = IDF_OPEN_POSITION;
			m_ReqFieldDataPtr->Fields[13] = IDF_CLOSE_POSITION;
			m_ReqFieldDataPtr->Fields[14] = IDF_LAST_OPEN_POSITION;
			m_ReqFieldDataPtr->Fields[15] = IDF_LAST_CLOSE_POSITION;
			m_ReqFieldDataPtr->Fields[16] = IDF_AVERAGE_PRICE;
			m_ReqFieldDataPtr->Fields[17] = IDF_DELTA_POSITION;
			m_ReqFieldDataPtr->Fields[18] = IDF_BOUGHT_VOLUME;
			m_ReqFieldDataPtr->Fields[19] = IDF_SOLD_VOLUME;
		}
		break;
	case XMT_STOCK:
	default:
		{
			if(IsStockIndex(Commodity)) {
				m_FieldFlag.resize(20);
				m_MaxFieldPerLine = 2;
				m_FieldNameListPtr->Commodity = Commodity;
				FIELD_NAME FieldName = {0};
				FieldName.cValueType = FIELD_VALUE_STRING;
				m_FieldNameListPtr->FieldNameList.resize(20, FieldName);
				m_FieldValueListPtr->Commodity = Commodity;
				FIELD_VALUE FieldValue = {0};
				FieldValue.cTextType = FIELD_VALUE_STRING;
				m_FieldValueListPtr->FieldValueList.resize(20, FieldValue);
				m_FieldNameListPtr->FieldNameList[0].FieldID = IDF_NOW;
				m_FieldValueListPtr->FieldValueList[0].FieldID = IDF_NOW;
				m_FieldNameListPtr->FieldNameList[1].FieldID = IDF_AVERAGE_PRICE;
				m_FieldValueListPtr->FieldValueList[1].FieldID = IDF_AVERAGE_PRICE;
				m_FieldFlag[1] = FIELD_FLAG_BREAK;
				m_FieldNameListPtr->FieldNameList[2].FieldID = IDF_DELTA;
				m_FieldValueListPtr->FieldValueList[2].FieldID = IDF_DELTA;
				m_FieldNameListPtr->FieldNameList[3].FieldID = IDF_TURNOVER_RATE;
				m_FieldValueListPtr->FieldValueList[3].FieldID = IDF_TURNOVER_RATE;
				m_FieldFlag[3] = FIELD_FLAG_BREAK;
				m_FieldNameListPtr->FieldNameList[4].FieldID = IDF_DELTA_PERCENT;
				m_FieldValueListPtr->FieldValueList[4].FieldID = IDF_DELTA_PERCENT;
				m_FieldNameListPtr->FieldNameList[5].FieldID = IDF_OPEN;
				m_FieldValueListPtr->FieldValueList[5].FieldID = IDF_OPEN;
				m_FieldFlag[5] = FIELD_FLAG_BREAK;
				m_FieldNameListPtr->FieldNameList[6].FieldID = IDF_VOLUME;
				m_FieldValueListPtr->FieldValueList[6].FieldID = IDF_VOLUME;
				m_FieldNameListPtr->FieldNameList[7].FieldID = IDF_HIGH;
				m_FieldValueListPtr->FieldValueList[7].FieldID = IDF_HIGH;
				m_FieldFlag[7] = FIELD_FLAG_BREAK;
				m_FieldNameListPtr->FieldNameList[8].FieldID = IDF_LAST_VOLUME;
				m_FieldValueListPtr->FieldValueList[8].FieldID = IDF_LAST_VOLUME;
				m_FieldNameListPtr->FieldNameList[9].FieldID = IDF_LOW;
				m_FieldValueListPtr->FieldValueList[9].FieldID = IDF_LOW;
				m_FieldFlag[9] = FIELD_FLAG_BREAK;
				m_FieldNameListPtr->FieldNameList[10].FieldID = IDF_WEIBI;
				m_FieldValueListPtr->FieldValueList[10].FieldID = IDF_WEIBI;
				m_FieldNameListPtr->FieldNameList[11].FieldID = IDF_VOLUME_RATIO;
				m_FieldValueListPtr->FieldValueList[11].FieldID = IDF_VOLUME_RATIO;
				m_FieldFlag[11] = FIELD_FLAG_BREAK;
				m_FieldNameListPtr->FieldNameList[12].FieldID = IDF_AMOUNT;
				m_FieldValueListPtr->FieldValueList[12].FieldID = IDF_AMOUNT;
				m_FieldNameListPtr->FieldNameList[13].FieldID = IDF_PRICE_EARNING_RATIO;
				m_FieldValueListPtr->FieldValueList[13].FieldID = IDF_PRICE_EARNING_RATIO;
				m_FieldFlag[13] = FIELD_FLAG_BREAK;
				m_FieldNameListPtr->FieldNameList[14].FieldID = IDF_RANGE_PERCENT;
				m_FieldValueListPtr->FieldValueList[14].FieldID = IDF_RANGE_PERCENT;
				m_FieldNameListPtr->FieldNameList[15].FieldID = IDF_PRICE_BOOK_VALUE_RATIO;
				m_FieldValueListPtr->FieldValueList[15].FieldID = IDF_PRICE_BOOK_VALUE_RATIO;
				m_FieldFlag[15] = FIELD_FLAG_BREAK;
				m_FieldNameListPtr->FieldNameList[16].FieldID = IDF_CEILING_PRICE;
				m_FieldValueListPtr->FieldValueList[16].FieldID = IDF_CEILING_PRICE;
				m_FieldNameListPtr->FieldNameList[17].FieldID = IDF_FLOOR_PRICE;
				m_FieldValueListPtr->FieldValueList[17].FieldID = IDF_FLOOR_PRICE;
				m_FieldFlag[17] = FIELD_FLAG_BREAKLINE;
				m_FieldNameListPtr->FieldNameList[18].FieldID = IDF_BOUGHT_VOLUME;
				m_FieldValueListPtr->FieldValueList[18].FieldID = IDF_BOUGHT_VOLUME;
				m_FieldNameListPtr->FieldNameList[19].FieldID = IDF_SOLD_VOLUME;
				m_FieldValueListPtr->FieldValueList[19].FieldID = IDF_SOLD_VOLUME;

				m_ReqFieldDataPtr->uFlags = REQ_FIELD_FLAG_SOME;
				m_ReqFieldDataPtr->Commoditys.resize(1,Commodity);
				m_ReqFieldDataPtr->Fields.resize(20);
				m_ReqFieldDataPtr->Fields[0] = IDF_NOW;
				m_ReqFieldDataPtr->Fields[1] = IDF_AVERAGE_PRICE;
				m_ReqFieldDataPtr->Fields[2] = IDF_TURNOVER_RATE;
				m_ReqFieldDataPtr->Fields[3] = IDF_HIGH;
				m_ReqFieldDataPtr->Fields[4] = IDF_DELTA_PERCENT;
				m_ReqFieldDataPtr->Fields[5] = IDF_OPEN;
				m_ReqFieldDataPtr->Fields[6] = IDF_VOLUME;
				m_ReqFieldDataPtr->Fields[7] = IDF_HIGH;
				m_ReqFieldDataPtr->Fields[8] = IDF_LAST_VOLUME;
				m_ReqFieldDataPtr->Fields[9] = IDF_LOW;
				m_ReqFieldDataPtr->Fields[10] = IDF_WEIBI;
				m_ReqFieldDataPtr->Fields[11] = IDF_VOLUME_RATIO;
				m_ReqFieldDataPtr->Fields[12] = IDF_AMOUNT;
				m_ReqFieldDataPtr->Fields[13] = IDF_PRICE_EARNING_RATIO;
				m_ReqFieldDataPtr->Fields[14] = IDF_RANGE_PERCENT;
				m_ReqFieldDataPtr->Fields[15] = IDF_PRICE_BOOK_VALUE_RATIO;
				m_ReqFieldDataPtr->Fields[16] = IDF_CEILING_PRICE;
				m_ReqFieldDataPtr->Fields[17] = IDF_FLOOR_PRICE;
				m_ReqFieldDataPtr->Fields[18] = IDF_BOUGHT_VOLUME;
				m_ReqFieldDataPtr->Fields[19] = IDF_SOLD_VOLUME;
			} else {
				m_FieldFlag.resize(20);
				m_MaxFieldPerLine = 2;
				m_FieldNameListPtr->Commodity = Commodity;
				FIELD_NAME FieldName = {0};
				FieldName.cValueType = FIELD_VALUE_STRING;
				m_FieldNameListPtr->FieldNameList.resize(20, FieldName);
				m_FieldValueListPtr->Commodity = Commodity;
				FIELD_VALUE FieldValue = {0};
				FieldValue.cTextType = FIELD_VALUE_STRING;
				m_FieldValueListPtr->FieldValueList.resize(20, FieldValue);
				m_FieldNameListPtr->FieldNameList[0].FieldID = IDF_NOW;
				m_FieldValueListPtr->FieldValueList[0].FieldID = IDF_NOW;
				m_FieldNameListPtr->FieldNameList[1].FieldID = IDF_AVERAGE_PRICE;
				m_FieldValueListPtr->FieldValueList[1].FieldID = IDF_AVERAGE_PRICE;
				m_FieldFlag[1] = FIELD_FLAG_BREAK;
				m_FieldNameListPtr->FieldNameList[2].FieldID = IDF_DELTA;
				m_FieldValueListPtr->FieldValueList[2].FieldID = IDF_DELTA;
				m_FieldNameListPtr->FieldNameList[3].FieldID = IDF_TURNOVER_RATE;
				m_FieldValueListPtr->FieldValueList[3].FieldID = IDF_TURNOVER_RATE;
				m_FieldFlag[3] = FIELD_FLAG_BREAK;
				m_FieldNameListPtr->FieldNameList[4].FieldID = IDF_DELTA_PERCENT;
				m_FieldValueListPtr->FieldValueList[4].FieldID = IDF_DELTA_PERCENT;
				m_FieldNameListPtr->FieldNameList[5].FieldID = IDF_OPEN;
				m_FieldValueListPtr->FieldValueList[5].FieldID = IDF_OPEN;
				m_FieldFlag[5] = FIELD_FLAG_BREAK;
				m_FieldNameListPtr->FieldNameList[6].FieldID = IDF_VOLUME;
				m_FieldValueListPtr->FieldValueList[6].FieldID = IDF_VOLUME;
				m_FieldNameListPtr->FieldNameList[7].FieldID = IDF_HIGH;
				m_FieldValueListPtr->FieldValueList[7].FieldID = IDF_HIGH;
				m_FieldFlag[7] = FIELD_FLAG_BREAK;
				m_FieldNameListPtr->FieldNameList[8].FieldID = IDF_LAST_VOLUME;
				m_FieldValueListPtr->FieldValueList[8].FieldID = IDF_LAST_VOLUME;
				m_FieldNameListPtr->FieldNameList[9].FieldID = IDF_LOW;
				m_FieldValueListPtr->FieldValueList[9].FieldID = IDF_LOW;
				m_FieldFlag[9] = FIELD_FLAG_BREAK;
				m_FieldNameListPtr->FieldNameList[10].FieldID = IDF_WEIBI;
				m_FieldValueListPtr->FieldValueList[10].FieldID = IDF_WEIBI;
				m_FieldNameListPtr->FieldNameList[11].FieldID = IDF_VOLUME_RATIO;
				m_FieldValueListPtr->FieldValueList[11].FieldID = IDF_VOLUME_RATIO;
				m_FieldFlag[11] = FIELD_FLAG_BREAK;
				m_FieldNameListPtr->FieldNameList[12].FieldID = IDF_AMOUNT;
				m_FieldValueListPtr->FieldValueList[12].FieldID = IDF_AMOUNT;
				m_FieldNameListPtr->FieldNameList[13].FieldID = IDF_PRICE_EARNING_RATIO;
				m_FieldValueListPtr->FieldValueList[13].FieldID = IDF_PRICE_EARNING_RATIO;
				m_FieldFlag[13] = FIELD_FLAG_BREAK;
				m_FieldNameListPtr->FieldNameList[14].FieldID = IDF_RANGE_PERCENT;
				m_FieldValueListPtr->FieldValueList[14].FieldID = IDF_RANGE_PERCENT;
				m_FieldNameListPtr->FieldNameList[15].FieldID = IDF_PRICE_BOOK_VALUE_RATIO;
				m_FieldValueListPtr->FieldValueList[15].FieldID = IDF_PRICE_BOOK_VALUE_RATIO;
				m_FieldFlag[15] = FIELD_FLAG_BREAK;
				m_FieldNameListPtr->FieldNameList[16].FieldID = IDF_CEILING_PRICE;
				m_FieldValueListPtr->FieldValueList[16].FieldID = IDF_CEILING_PRICE;
				m_FieldNameListPtr->FieldNameList[17].FieldID = IDF_FLOOR_PRICE;
				m_FieldValueListPtr->FieldValueList[17].FieldID = IDF_FLOOR_PRICE;
				m_FieldFlag[17] = FIELD_FLAG_BREAKLINE;
				m_FieldNameListPtr->FieldNameList[18].FieldID = IDF_BOUGHT_VOLUME;
				m_FieldValueListPtr->FieldValueList[18].FieldID = IDF_BOUGHT_VOLUME;
				m_FieldNameListPtr->FieldNameList[19].FieldID = IDF_SOLD_VOLUME;
				m_FieldValueListPtr->FieldValueList[19].FieldID = IDF_SOLD_VOLUME;

				m_ReqFieldDataPtr->uFlags = REQ_FIELD_FLAG_SOME;
				m_ReqFieldDataPtr->Commoditys.resize(1,Commodity);
				m_ReqFieldDataPtr->Fields.resize(20);
				m_ReqFieldDataPtr->Fields[0] = IDF_NOW;
				m_ReqFieldDataPtr->Fields[1] = IDF_AVERAGE_PRICE;
				m_ReqFieldDataPtr->Fields[2] = IDF_TURNOVER_RATE;
				m_ReqFieldDataPtr->Fields[3] = IDF_HIGH;
				m_ReqFieldDataPtr->Fields[4] = IDF_DELTA_PERCENT;
				m_ReqFieldDataPtr->Fields[5] = IDF_OPEN;
				m_ReqFieldDataPtr->Fields[6] = IDF_VOLUME;
				m_ReqFieldDataPtr->Fields[7] = IDF_HIGH;
				m_ReqFieldDataPtr->Fields[8] = IDF_LAST_VOLUME;
				m_ReqFieldDataPtr->Fields[9] = IDF_LOW;
				m_ReqFieldDataPtr->Fields[10] = IDF_WEIBI;
				m_ReqFieldDataPtr->Fields[11] = IDF_VOLUME_RATIO;
				m_ReqFieldDataPtr->Fields[12] = IDF_AMOUNT;
				m_ReqFieldDataPtr->Fields[13] = IDF_PRICE_EARNING_RATIO;
				m_ReqFieldDataPtr->Fields[14] = IDF_RANGE_PERCENT;
				m_ReqFieldDataPtr->Fields[15] = IDF_PRICE_BOOK_VALUE_RATIO;
				m_ReqFieldDataPtr->Fields[16] = IDF_CEILING_PRICE;
				m_ReqFieldDataPtr->Fields[17] = IDF_FLOOR_PRICE;
				m_ReqFieldDataPtr->Fields[18] = IDF_BOUGHT_VOLUME;
				m_ReqFieldDataPtr->Fields[19] = IDF_SOLD_VOLUME;
			}
		}
		break;
	}
			
	m_dc.DeleteDC();
	Invalidate();
}

void CommodityInfoView::OnRefresh(ObjectPtr objPtr)
{
	COMREF Commodity = {0};
	GetCurCommodity(&Commodity);
	m_FieldFlag.clear();
	m_FieldNameListPtr->FieldNameList.clear();
	m_FieldValueListPtr->FieldValueList.clear();
	m_ReqFieldDataPtr->Commoditys.clear();
	m_ReqFieldDataPtr->Fields.clear();
	switch (MarketType(Commodity.Exchange))
	{
	case XMT_FUTURES:
		{
			m_FieldFlag.resize(20);
			m_MaxFieldPerLine = 2;
			m_FieldNameListPtr->Commodity = Commodity;
			FIELD_NAME FieldName = {0};
			FieldName.cValueType = FIELD_VALUE_STRING;
			m_FieldNameListPtr->FieldNameList.resize(20, FieldName);
			m_FieldValueListPtr->Commodity = Commodity;
			FIELD_VALUE FieldValue = {0};
			FieldValue.cTextType = FIELD_VALUE_STRING;
			m_FieldValueListPtr->FieldValueList.resize(20, FieldValue);
			m_FieldNameListPtr->FieldNameList[0].FieldID = IDF_NOW;
			m_FieldValueListPtr->FieldValueList[0].FieldID = IDF_NOW;
			m_FieldNameListPtr->FieldNameList[1].FieldID = IDF_OPEN;
			m_FieldValueListPtr->FieldValueList[1].FieldID = IDF_OPEN;
			m_FieldFlag[1] = FIELD_FLAG_BREAK;
			m_FieldNameListPtr->FieldNameList[2].FieldID = IDF_DELTA;
			m_FieldValueListPtr->FieldValueList[2].FieldID = IDF_DELTA;
			m_FieldNameListPtr->FieldNameList[3].FieldID = IDF_HIGH;
			m_FieldValueListPtr->FieldValueList[3].FieldID = IDF_HIGH;
			m_FieldFlag[3] = FIELD_FLAG_BREAK;
			m_FieldNameListPtr->FieldNameList[4].FieldID = IDF_DELTA_PERCENT;
			m_FieldValueListPtr->FieldValueList[4].FieldID = IDF_DELTA_PERCENT;
			m_FieldNameListPtr->FieldNameList[5].FieldID = IDF_LOW;
			m_FieldValueListPtr->FieldValueList[5].FieldID = IDF_LOW;
			m_FieldFlag[5] = FIELD_FLAG_BREAK;
			m_FieldNameListPtr->FieldNameList[6].FieldID = IDF_VOLUME;
			m_FieldValueListPtr->FieldValueList[6].FieldID = IDF_VOLUME;
			m_FieldNameListPtr->FieldNameList[7].FieldID = IDF_LAST_VOLUME;
			m_FieldValueListPtr->FieldValueList[7].FieldID = IDF_LAST_VOLUME;
			m_FieldFlag[7] = FIELD_FLAG_BREAK;
			m_FieldNameListPtr->FieldNameList[8].FieldID = IDF_POSITION;
			m_FieldValueListPtr->FieldValueList[8].FieldID = IDF_POSITION;
			m_FieldNameListPtr->FieldNameList[9].FieldID = IDF_SETTLEMENT;
			m_FieldValueListPtr->FieldValueList[9].FieldID = IDF_SETTLEMENT;
			m_FieldFlag[9] = FIELD_FLAG_BREAK;
			m_FieldNameListPtr->FieldNameList[10].FieldID = IDF_PREV_POSITION;
			m_FieldValueListPtr->FieldValueList[10].FieldID = IDF_PREV_POSITION;
			m_FieldNameListPtr->FieldNameList[11].FieldID = IDF_PREV_SETTLEMENT;
			m_FieldValueListPtr->FieldValueList[11].FieldID = IDF_PREV_SETTLEMENT;
			m_FieldFlag[11] = FIELD_FLAG_BREAK;
			m_FieldNameListPtr->FieldNameList[12].FieldID = IDF_OPEN_POSITION;
			m_FieldValueListPtr->FieldValueList[12].FieldID = IDF_OPEN_POSITION;
			m_FieldNameListPtr->FieldNameList[13].FieldID = IDF_CLOSE_POSITION;
			m_FieldValueListPtr->FieldValueList[13].FieldID = IDF_CLOSE_POSITION;
			m_FieldFlag[13] = FIELD_FLAG_BREAK;
			m_FieldNameListPtr->FieldNameList[14].FieldID = IDF_LAST_OPEN_POSITION;
			m_FieldValueListPtr->FieldValueList[14].FieldID = IDF_LAST_OPEN_POSITION;
			m_FieldNameListPtr->FieldNameList[15].FieldID = IDF_LAST_CLOSE_POSITION;
			m_FieldValueListPtr->FieldValueList[15].FieldID = IDF_LAST_CLOSE_POSITION;
			m_FieldFlag[15] = FIELD_FLAG_BREAK;
			m_FieldNameListPtr->FieldNameList[16].FieldID = IDF_AVERAGE_PRICE;
			m_FieldValueListPtr->FieldValueList[16].FieldID = IDF_AVERAGE_PRICE;
			m_FieldNameListPtr->FieldNameList[17].FieldID = IDF_DELTA_POSITION;
			m_FieldValueListPtr->FieldValueList[17].FieldID = IDF_DELTA_POSITION;
			m_FieldFlag[17] = FIELD_FLAG_BREAKLINE;
			m_FieldNameListPtr->FieldNameList[18].FieldID = IDF_BOUGHT_VOLUME;
			m_FieldValueListPtr->FieldValueList[18].FieldID = IDF_BOUGHT_VOLUME;
			m_FieldNameListPtr->FieldNameList[19].FieldID = IDF_SOLD_VOLUME;
			m_FieldValueListPtr->FieldValueList[19].FieldID = IDF_SOLD_VOLUME;

			m_ReqFieldDataPtr->uFlags = REQ_FIELD_FLAG_SOME;
			m_ReqFieldDataPtr->Commoditys.resize(1,Commodity);
			m_ReqFieldDataPtr->Fields.resize(20);
			m_ReqFieldDataPtr->Fields[0] = IDF_NOW;
			m_ReqFieldDataPtr->Fields[1] = IDF_OPEN;
			m_ReqFieldDataPtr->Fields[2] = IDF_DELTA;
			m_ReqFieldDataPtr->Fields[3] = IDF_HIGH;
			m_ReqFieldDataPtr->Fields[4] = IDF_DELTA_PERCENT;
			m_ReqFieldDataPtr->Fields[5] = IDF_LOW;
			m_ReqFieldDataPtr->Fields[6] = IDF_VOLUME;
			m_ReqFieldDataPtr->Fields[7] = IDF_LAST_VOLUME;
			m_ReqFieldDataPtr->Fields[8] = IDF_POSITION;
			m_ReqFieldDataPtr->Fields[9] = IDF_SETTLEMENT;
			m_ReqFieldDataPtr->Fields[10] = IDF_PREV_POSITION;
			m_ReqFieldDataPtr->Fields[11] = IDF_PREV_SETTLEMENT;
			m_ReqFieldDataPtr->Fields[12] = IDF_OPEN_POSITION;
			m_ReqFieldDataPtr->Fields[13] = IDF_CLOSE_POSITION;
			m_ReqFieldDataPtr->Fields[14] = IDF_LAST_OPEN_POSITION;
			m_ReqFieldDataPtr->Fields[15] = IDF_LAST_CLOSE_POSITION;
			m_ReqFieldDataPtr->Fields[16] = IDF_AVERAGE_PRICE;
			m_ReqFieldDataPtr->Fields[17] = IDF_DELTA_POSITION;
			m_ReqFieldDataPtr->Fields[18] = IDF_BOUGHT_VOLUME;
			m_ReqFieldDataPtr->Fields[19] = IDF_SOLD_VOLUME;
		}
		break;
	case XMT_STOCK:
	default:
		{
			if(IsStockIndex(Commodity)) {
				m_FieldFlag.resize(20);
				m_MaxFieldPerLine = 2;
				m_FieldNameListPtr->Commodity = Commodity;
				FIELD_NAME FieldName = {0};
				FieldName.cValueType = FIELD_VALUE_STRING;
				m_FieldNameListPtr->FieldNameList.resize(20, FieldName);
				m_FieldValueListPtr->Commodity = Commodity;
				FIELD_VALUE FieldValue = {0};
				FieldValue.cTextType = FIELD_VALUE_STRING;
				m_FieldValueListPtr->FieldValueList.resize(20, FieldValue);
				m_FieldNameListPtr->FieldNameList[0].FieldID = IDF_NOW;
				m_FieldValueListPtr->FieldValueList[0].FieldID = IDF_NOW;
				m_FieldNameListPtr->FieldNameList[1].FieldID = IDF_AVERAGE_PRICE;
				m_FieldValueListPtr->FieldValueList[1].FieldID = IDF_AVERAGE_PRICE;
				m_FieldFlag[1] = FIELD_FLAG_BREAK;
				m_FieldNameListPtr->FieldNameList[2].FieldID = IDF_DELTA;
				m_FieldValueListPtr->FieldValueList[2].FieldID = IDF_DELTA;
				m_FieldNameListPtr->FieldNameList[3].FieldID = IDF_TURNOVER_RATE;
				m_FieldValueListPtr->FieldValueList[3].FieldID = IDF_TURNOVER_RATE;
				m_FieldFlag[3] = FIELD_FLAG_BREAK;
				m_FieldNameListPtr->FieldNameList[4].FieldID = IDF_DELTA_PERCENT;
				m_FieldValueListPtr->FieldValueList[4].FieldID = IDF_DELTA_PERCENT;
				m_FieldNameListPtr->FieldNameList[5].FieldID = IDF_OPEN;
				m_FieldValueListPtr->FieldValueList[5].FieldID = IDF_OPEN;
				m_FieldFlag[5] = FIELD_FLAG_BREAK;
				m_FieldNameListPtr->FieldNameList[6].FieldID = IDF_VOLUME;
				m_FieldValueListPtr->FieldValueList[6].FieldID = IDF_VOLUME;
				m_FieldNameListPtr->FieldNameList[7].FieldID = IDF_HIGH;
				m_FieldValueListPtr->FieldValueList[7].FieldID = IDF_HIGH;
				m_FieldFlag[7] = FIELD_FLAG_BREAK;
				m_FieldNameListPtr->FieldNameList[8].FieldID = IDF_LAST_VOLUME;
				m_FieldValueListPtr->FieldValueList[8].FieldID = IDF_LAST_VOLUME;
				m_FieldNameListPtr->FieldNameList[9].FieldID = IDF_LOW;
				m_FieldValueListPtr->FieldValueList[9].FieldID = IDF_LOW;
				m_FieldFlag[9] = FIELD_FLAG_BREAK;
				m_FieldNameListPtr->FieldNameList[10].FieldID = IDF_WEIBI;
				m_FieldValueListPtr->FieldValueList[10].FieldID = IDF_WEIBI;
				m_FieldNameListPtr->FieldNameList[11].FieldID = IDF_VOLUME_RATIO;
				m_FieldValueListPtr->FieldValueList[11].FieldID = IDF_VOLUME_RATIO;
				m_FieldFlag[11] = FIELD_FLAG_BREAK;
				m_FieldNameListPtr->FieldNameList[12].FieldID = IDF_AMOUNT;
				m_FieldValueListPtr->FieldValueList[12].FieldID = IDF_AMOUNT;
				m_FieldNameListPtr->FieldNameList[13].FieldID = IDF_PRICE_EARNING_RATIO;
				m_FieldValueListPtr->FieldValueList[13].FieldID = IDF_PRICE_EARNING_RATIO;
				m_FieldFlag[13] = FIELD_FLAG_BREAK;
				m_FieldNameListPtr->FieldNameList[14].FieldID = IDF_RANGE_PERCENT;
				m_FieldValueListPtr->FieldValueList[14].FieldID = IDF_RANGE_PERCENT;
				m_FieldNameListPtr->FieldNameList[15].FieldID = IDF_PRICE_BOOK_VALUE_RATIO;
				m_FieldValueListPtr->FieldValueList[15].FieldID = IDF_PRICE_BOOK_VALUE_RATIO;
				m_FieldFlag[15] = FIELD_FLAG_BREAK;
				m_FieldNameListPtr->FieldNameList[16].FieldID = IDF_CEILING_PRICE;
				m_FieldValueListPtr->FieldValueList[16].FieldID = IDF_CEILING_PRICE;
				m_FieldNameListPtr->FieldNameList[17].FieldID = IDF_FLOOR_PRICE;
				m_FieldValueListPtr->FieldValueList[17].FieldID = IDF_FLOOR_PRICE;
				m_FieldFlag[17] = FIELD_FLAG_BREAKLINE;
				m_FieldNameListPtr->FieldNameList[18].FieldID = IDF_BOUGHT_VOLUME;
				m_FieldValueListPtr->FieldValueList[18].FieldID = IDF_BOUGHT_VOLUME;
				m_FieldNameListPtr->FieldNameList[19].FieldID = IDF_SOLD_VOLUME;
				m_FieldValueListPtr->FieldValueList[19].FieldID = IDF_SOLD_VOLUME;

				m_ReqFieldDataPtr->uFlags = REQ_FIELD_FLAG_SOME;
				m_ReqFieldDataPtr->Commoditys.resize(1,Commodity);
				m_ReqFieldDataPtr->Fields.resize(20);
				m_ReqFieldDataPtr->Fields[0] = IDF_NOW;
				m_ReqFieldDataPtr->Fields[1] = IDF_AVERAGE_PRICE;
				m_ReqFieldDataPtr->Fields[2] = IDF_TURNOVER_RATE;
				m_ReqFieldDataPtr->Fields[3] = IDF_HIGH;
				m_ReqFieldDataPtr->Fields[4] = IDF_DELTA_PERCENT;
				m_ReqFieldDataPtr->Fields[5] = IDF_OPEN;
				m_ReqFieldDataPtr->Fields[6] = IDF_VOLUME;
				m_ReqFieldDataPtr->Fields[7] = IDF_HIGH;
				m_ReqFieldDataPtr->Fields[8] = IDF_LAST_VOLUME;
				m_ReqFieldDataPtr->Fields[9] = IDF_LOW;
				m_ReqFieldDataPtr->Fields[10] = IDF_WEIBI;
				m_ReqFieldDataPtr->Fields[11] = IDF_VOLUME_RATIO;
				m_ReqFieldDataPtr->Fields[12] = IDF_AMOUNT;
				m_ReqFieldDataPtr->Fields[13] = IDF_PRICE_EARNING_RATIO;
				m_ReqFieldDataPtr->Fields[14] = IDF_RANGE_PERCENT;
				m_ReqFieldDataPtr->Fields[15] = IDF_PRICE_BOOK_VALUE_RATIO;
				m_ReqFieldDataPtr->Fields[16] = IDF_CEILING_PRICE;
				m_ReqFieldDataPtr->Fields[17] = IDF_FLOOR_PRICE;
				m_ReqFieldDataPtr->Fields[18] = IDF_BOUGHT_VOLUME;
				m_ReqFieldDataPtr->Fields[19] = IDF_SOLD_VOLUME;
			} else {
				m_FieldFlag.resize(20);
				m_MaxFieldPerLine = 2;
				m_FieldNameListPtr->Commodity = Commodity;
				FIELD_NAME FieldName = {0};
				FieldName.cValueType = FIELD_VALUE_STRING;
				m_FieldNameListPtr->FieldNameList.resize(20, FieldName);
				m_FieldValueListPtr->Commodity = Commodity;
				FIELD_VALUE FieldValue = {0};
				FieldValue.cTextType = FIELD_VALUE_STRING;
				m_FieldValueListPtr->FieldValueList.resize(20, FieldValue);
				m_FieldNameListPtr->FieldNameList[0].FieldID = IDF_NOW;
				m_FieldValueListPtr->FieldValueList[0].FieldID = IDF_NOW;
				m_FieldNameListPtr->FieldNameList[1].FieldID = IDF_AVERAGE_PRICE;
				m_FieldValueListPtr->FieldValueList[1].FieldID = IDF_AVERAGE_PRICE;
				m_FieldFlag[1] = FIELD_FLAG_BREAK;
				m_FieldNameListPtr->FieldNameList[2].FieldID = IDF_DELTA;
				m_FieldValueListPtr->FieldValueList[2].FieldID = IDF_DELTA;
				m_FieldNameListPtr->FieldNameList[3].FieldID = IDF_TURNOVER_RATE;
				m_FieldValueListPtr->FieldValueList[3].FieldID = IDF_TURNOVER_RATE;
				m_FieldFlag[3] = FIELD_FLAG_BREAK;
				m_FieldNameListPtr->FieldNameList[4].FieldID = IDF_DELTA_PERCENT;
				m_FieldValueListPtr->FieldValueList[4].FieldID = IDF_DELTA_PERCENT;
				m_FieldNameListPtr->FieldNameList[5].FieldID = IDF_OPEN;
				m_FieldValueListPtr->FieldValueList[5].FieldID = IDF_OPEN;
				m_FieldFlag[5] = FIELD_FLAG_BREAK;
				m_FieldNameListPtr->FieldNameList[6].FieldID = IDF_VOLUME;
				m_FieldValueListPtr->FieldValueList[6].FieldID = IDF_VOLUME;
				m_FieldNameListPtr->FieldNameList[7].FieldID = IDF_HIGH;
				m_FieldValueListPtr->FieldValueList[7].FieldID = IDF_HIGH;
				m_FieldFlag[7] = FIELD_FLAG_BREAK;
				m_FieldNameListPtr->FieldNameList[8].FieldID = IDF_LAST_VOLUME;
				m_FieldValueListPtr->FieldValueList[8].FieldID = IDF_LAST_VOLUME;
				m_FieldNameListPtr->FieldNameList[9].FieldID = IDF_LOW;
				m_FieldValueListPtr->FieldValueList[9].FieldID = IDF_LOW;
				m_FieldFlag[9] = FIELD_FLAG_BREAK;
				m_FieldNameListPtr->FieldNameList[10].FieldID = IDF_WEIBI;
				m_FieldValueListPtr->FieldValueList[10].FieldID = IDF_WEIBI;
				m_FieldNameListPtr->FieldNameList[11].FieldID = IDF_VOLUME_RATIO;
				m_FieldValueListPtr->FieldValueList[11].FieldID = IDF_VOLUME_RATIO;
				m_FieldFlag[11] = FIELD_FLAG_BREAK;
				m_FieldNameListPtr->FieldNameList[12].FieldID = IDF_AMOUNT;
				m_FieldValueListPtr->FieldValueList[12].FieldID = IDF_AMOUNT;
				m_FieldNameListPtr->FieldNameList[13].FieldID = IDF_PRICE_EARNING_RATIO;
				m_FieldValueListPtr->FieldValueList[13].FieldID = IDF_PRICE_EARNING_RATIO;
				m_FieldFlag[13] = FIELD_FLAG_BREAK;
				m_FieldNameListPtr->FieldNameList[14].FieldID = IDF_RANGE_PERCENT;
				m_FieldValueListPtr->FieldValueList[14].FieldID = IDF_RANGE_PERCENT;
				m_FieldNameListPtr->FieldNameList[15].FieldID = IDF_PRICE_BOOK_VALUE_RATIO;
				m_FieldValueListPtr->FieldValueList[15].FieldID = IDF_PRICE_BOOK_VALUE_RATIO;
				m_FieldFlag[15] = FIELD_FLAG_BREAK;
				m_FieldNameListPtr->FieldNameList[16].FieldID = IDF_CEILING_PRICE;
				m_FieldValueListPtr->FieldValueList[16].FieldID = IDF_CEILING_PRICE;
				m_FieldNameListPtr->FieldNameList[17].FieldID = IDF_FLOOR_PRICE;
				m_FieldValueListPtr->FieldValueList[17].FieldID = IDF_FLOOR_PRICE;
				m_FieldFlag[17] = FIELD_FLAG_BREAKLINE;
				m_FieldNameListPtr->FieldNameList[18].FieldID = IDF_BOUGHT_VOLUME;
				m_FieldValueListPtr->FieldValueList[18].FieldID = IDF_BOUGHT_VOLUME;
				m_FieldNameListPtr->FieldNameList[19].FieldID = IDF_SOLD_VOLUME;
				m_FieldValueListPtr->FieldValueList[19].FieldID = IDF_SOLD_VOLUME;

				m_ReqFieldDataPtr->uFlags = REQ_FIELD_FLAG_SOME;
				m_ReqFieldDataPtr->Commoditys.resize(1,Commodity);
				m_ReqFieldDataPtr->Fields.resize(20);
				m_ReqFieldDataPtr->Fields[0] = IDF_NOW;
				m_ReqFieldDataPtr->Fields[1] = IDF_AVERAGE_PRICE;
				m_ReqFieldDataPtr->Fields[2] = IDF_TURNOVER_RATE;
				m_ReqFieldDataPtr->Fields[3] = IDF_HIGH;
				m_ReqFieldDataPtr->Fields[4] = IDF_DELTA_PERCENT;
				m_ReqFieldDataPtr->Fields[5] = IDF_OPEN;
				m_ReqFieldDataPtr->Fields[6] = IDF_VOLUME;
				m_ReqFieldDataPtr->Fields[7] = IDF_HIGH;
				m_ReqFieldDataPtr->Fields[8] = IDF_LAST_VOLUME;
				m_ReqFieldDataPtr->Fields[9] = IDF_LOW;
				m_ReqFieldDataPtr->Fields[10] = IDF_WEIBI;
				m_ReqFieldDataPtr->Fields[11] = IDF_VOLUME_RATIO;
				m_ReqFieldDataPtr->Fields[12] = IDF_AMOUNT;
				m_ReqFieldDataPtr->Fields[13] = IDF_PRICE_EARNING_RATIO;
				m_ReqFieldDataPtr->Fields[14] = IDF_RANGE_PERCENT;
				m_ReqFieldDataPtr->Fields[15] = IDF_PRICE_BOOK_VALUE_RATIO;
				m_ReqFieldDataPtr->Fields[16] = IDF_CEILING_PRICE;
				m_ReqFieldDataPtr->Fields[17] = IDF_FLOOR_PRICE;
				m_ReqFieldDataPtr->Fields[18] = IDF_BOUGHT_VOLUME;
				m_ReqFieldDataPtr->Fields[19] = IDF_SOLD_VOLUME;
			}
		}
		break;
	}

	SendEvent(_DataPtr, EVT_PLAT_CALL, MAKEVALUE(MGET_PLAT_DE,CGET_DE_FIELD_NAME), m_FieldNameListPtr);
	SendEvent(_DataPtr, EVT_PLAT_CALL, MAKEVALUE(MGET_PLAT_DE,CGET_DE_FIELD_VALUE), m_FieldValueListPtr);

	SendEvent(GetContainer(), EVT_PLAT_POST, MAKEVALUE(MREQUEST_PLAT_DE,CREQUEST_DE_FIELD_VALUE), m_ReqFieldDataPtr);

	m_dc.DeleteDC();
	Invalidate();
}

void CommodityInfoView::OnFieldDataChanged(Event& evt)
{
	int i,j;
	//SendToData(EVT_PLAT_CALL, MAKEVALUE(MGET_PLAT_DE,CGET_DE_FIELD_NAME), m_FieldNameListPtr);
	for (i=0,j=m_FieldValueListPtr->FieldValueList.size(); i<j; i++)
	{
		m_FieldValueListPtr->FieldValueList[i].bCalculated = 0;
		m_FieldValueListPtr->FieldValueList[i].szText[0] = 0;
	}
	SendEvent(_DataPtr, EVT_PLAT_CALL, MAKEVALUE(MGET_PLAT_DE,CGET_DE_FIELD_VALUE), m_FieldValueListPtr);

	m_dc.DeleteDC();
	Invalidate();
}

//////////////////////////////////////////////////////////////////////////
///CommodityTickView

#define ID_TIMER_COMMODITY_TICK	100

IMPLEMENT_DYNCREATE_WND_OBJECTER(CommodityTickView,Objecter)

CommodityTickView::CommodityTickView()
{
	m_uTimer = 0;
	memset(&m_LastBar, 0, sizeof(m_LastBar));
	m_nMaxTickData = 0;
}

CommodityTickView::~CommodityTickView()
{
	
}

HWND CommodityTickView::Create(HWND hWndParent, RECT& rcPos
			, LPCTSTR szWindowName , DWORD dwStyle, DWORD dwExStyle, UINT nID, LPVOID lpCreateParam)
{
	return Base::Create(hWndParent, rcPos, szWindowName
		, dwStyle 
		| WS_CHILD | WS_VISIBLE
		| LVS_REPORT 
		//| LVS_ICON 
		//| LVS_LIST 
		| LVS_OWNERDATA
		| LVS_OWNERDRAWFIXED
		//| LVS_SHAREIMAGELISTS
		//| LVS_SHOWSELALWAYS 
		//| LVS_AUTOARRANGE 
		| LVS_NOCOLUMNHEADER
		//| LVS_NOSCROLL
		//| LVS_EDITLABELS
		//| LVS_SINGLESEL
		, dwExStyle
		, nID, lpCreateParam);
}

HWND CommodityTickView::Create(HWND hWndParent, LPCTSTR lpszXml, UINT XmlFlag)
{
	return Base::Create(hWndParent, lpszXml, XmlFlag);
}

void CommodityTickView::Relayout(LPCRECT lpRect)
{
	if (!m_DispInfoPtr) {
		return;
	}

	CRect rcClient;
	if (lpRect) {
		rcClient = *lpRect;
	} else {
		GetClientRect(&rcClient);
	}

	UIHeaderCtrl2 wndHeader = GetHeader();
	if (wndHeader) {
		int nCol = 0;
		int nColCount = wndHeader.GetItemCount();
		if (nColCount==3) {
			SetColumnWidth(0, rcClient.Width()/4);
			SetColumnWidth(1, rcClient.Width()/4);
			SetColumnWidth(2, rcClient.Width()/2);
		} else if (nColCount==4) {
			SetColumnWidth(0, rcClient.Width()/4);
			SetColumnWidth(1, rcClient.Width()/4);
			SetColumnWidth(2, rcClient.Width()/4);
			SetColumnWidth(3, rcClient.Width()/4);
		} else {
			CRect rcOffset = rcClient;
			if (nColCount>0) {
				for (nCol=0; nCol<nColCount-1; nCol++)
				{
					rcOffset.left += GetColumnWidth(nCol);
				}
				SetColumnWidth(nCol, rcOffset.right-rcOffset.left);
			}
		}
	}

	if (m_nItemHeight) {
		int nMaxTickData = rcClient.Height()/m_nItemHeight;
		m_nMaxTickData = nMaxTickData;
		BAR* pBar = GetBar();
		UINT nBarCount = GetBarCount();
		if (pBar && nBarCount) {
			int nItemCount = GetItemCount();
			int nNewItemCount = min(nBarCount,m_nMaxTickData);
			if (nItemCount != nNewItemCount) {
				DeleteAllItems();
				SetItemCount(nNewItemCount);
			}
		} else {
			DeleteAllItems();
		}
	}
}

void CommodityTickView::GetMinMaxInfo(MINMAXINFO* pMMInfo)
{
	pMMInfo->ptMinTrackSize.x += 10*(m_DispInfoPtr->xyRptText.cx+m_DispInfoPtr->xySpace.cx);
}

void CommodityTickView::OnCacheHint(NMLVCACHEHINT* lpCacheHint)
{

}

void CommodityTickView::OnGetDispInfo(NMLVDISPINFO* lpDispInfo)
{
	if (!IsBarOk()) {
		return;
	}
	if (lpDispInfo->item.iItem < 0) {
		return;
	}

	int i,j;
	TCHAR szBuf[1024] = {0};

	int nCount = GetItemCount();
	int nPos = lpDispInfo->item.iItem;
	int nDataPos = (nCount-1) - nPos;

	BAR* pBar = GetBar();
	UINT nBarCount = GetBarCount();
	nDataPos = ReversePos(nDataPos,nBarCount);

	switch(lpDispInfo->item.iSubItem) 
	{
	case 0: 
		if (lpDispInfo->item.mask & LVIF_TEXT) {
			//ʱ��
			unsigned int PreTime = pBar[nDataPos-1].Time;
			unsigned int PreHour,PreMinute,PreSecond;
			ULONG_TO_HHMMSS(PreTime,PreHour,PreMinute,PreSecond);
			unsigned int Time = pBar[nDataPos].Time;
			unsigned int Hour,Minute,Second;
			ULONG_TO_HHMMSS(Time,Hour,Minute,Second);

			if (Hour == PreHour && Minute == PreMinute) {
				_sntprintf(lpDispInfo->item.pszText, lpDispInfo->item.cchTextMax, _T("         :%02d"), Second);
			} else {
				_sntprintf(lpDispInfo->item.pszText, lpDispInfo->item.cchTextMax, _T("%02d:%02d:%02d"), Hour, Minute, Second);
			}
		}
		break;
	case 1:
		if (lpDispInfo->item.mask & LVIF_TEXT) {
			_sntprintf(lpDispInfo->item.pszText, lpDispInfo->item.cchTextMax, _T("%.2lf"), pBar[nDataPos].Close);
		}
		break;
	case 2: 
		if (lpDispInfo->item.mask & LVIF_TEXT) {
			_sntprintf(lpDispInfo->item.pszText, lpDispInfo->item.cchTextMax, _T("%.0lf"), pBar[nDataPos].Volume);
		}
		break;
	}
}

//void CommodityTickView::OnMeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct)
//{
//	lpMeasureItemStruct->itemHeight = m_nItemHeight;
//}

void CommodityTickView::OnDrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct)
{
	if (!m_DispInfoPtr) {
		return;
	}

	UIHeaderCtrl2 wndHeader = GetHeader();
	if (!wndHeader) {
		return;
	}
	int nColCount = wndHeader.GetItemCount();

	int nCount = GetItemCount();

	CDCHandle dc(lpDrawItemStruct->hDC);

	int nPos =lpDrawItemStruct->itemID;
	CRect rcItem = lpDrawItemStruct->rcItem;

	if (lpDrawItemStruct->itemAction & ODA_SELECT) {
		dc.FillSolidRect(rcItem, m_DispInfoPtr->crRptSelBackgnd);
	}
	if (lpDrawItemStruct->itemState & ODS_SELECTED) {
		dc.FillSolidRect(rcItem, m_DispInfoPtr->crRptSelBackgnd);
	}

	dc.SetBkMode(TRANSPARENT);

	COLORREF crOldTextColor = dc.SetTextColor(GetTextColor());

	int nDataPos = (nCount-1) - nPos;

	BAR* pBar = GetBar();
	UINT nBarCount = GetBarCount();
	nDataPos = ReversePos(nDataPos,nBarCount);

	int nUpDown = 0;
	if (nDataPos == 0) {
		nUpDown = 0;
	} else {
		double Close = pBar[nDataPos].Close;
		double PreClose = pBar[nDataPos-1].Close;
		if (Close>PreClose) {
			nUpDown = 1;
		} else if (Close<PreClose) {
			nUpDown = -1;
		} else {
			
		}
	}

	RECT rcSubItem;
	TCHAR szBuffer[MAX_PATH] = {0};
	for (int nCol=0; nCol<nColCount; nCol++)
	{
		if (!GetSubItemRect(nPos,nCol,LVIR_LABEL,&rcSubItem))   
			continue; 

		switch (nCol)
		{
		case 1:
		case 2:
			if (nUpDown>0) {
				dc.SetTextColor(m_DispInfoPtr->crRising);
			} else if (nUpDown<0) {
				dc.SetTextColor(m_DispInfoPtr->crFalling);
			} else {
				dc.SetTextColor(m_DispInfoPtr->crText);
			}
			break;
		} 

		LV_ITEM lvi;
		lvi.mask = LVIF_TEXT;
		lvi.iItem = nPos; 
		lvi.iSubItem = nCol;
		lvi.pszText = szBuffer;
		lvi.cchTextMax = sizeof(szBuffer);
		GetItem(&lvi);

		UINT uFormat = DT_SINGLELINE | DT_NOPREFIX | DT_NOCLIP | DT_BOTTOM;
		HD_ITEM hditem = {0};
		hditem.mask = HDI_FORMAT;
		wndHeader.GetItem(nCol, &hditem);
		if( hditem.fmt & HDF_CENTER) {
			uFormat |= DT_CENTER;
		} else if( hditem.fmt & HDF_RIGHT) {
			uFormat |= DT_RIGHT;
		} else {
			uFormat |= DT_LEFT;
		}
	
		dc.DrawText(szBuffer, lstrlen(szBuffer), &rcSubItem, uFormat);
	}

	dc.SetTextColor(crOldTextColor);
}

void CommodityTickView::OnPaint(HDC hdc)
{
	CRect rcClient;
	GetClientRect(&rcClient);
	ListCtrlMap::PaintBkgnd(hdc,&rcClient);
	PaintMap::OnPaint(hdc);
}

LRESULT CommodityTickView::OnCreate(UINT /*uMsg*/, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	LRESULT rlt = DefWindowProc();

	SetExtendedListViewStyle(
		//LVS_EX_FLATSB | 
		LVS_EX_FULLROWSELECT
		);

	/*SetBkColor(CLR_NONE);
	SetTextColor(GetSysColor(COLOR_HIGHLIGHTTEXT));
	SetTextBkColor(CLR_NONE);
	SetInsertMarkColor(CLR_NONE);
	SetOutlineColor(CLR_NONE);*/

	InitColList();

	return rlt;
}

LRESULT CommodityTickView::OnDestroy(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& bHandled)
{
	bHandled = FALSE;

	if (m_uTimer) {
		KillTimer(m_uTimer);
		m_uTimer = 0;
	}

	return 1;
}

LRESULT CommodityTickView::OnSize(UINT /*uMsg*/, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	if (wParam != SIZE_MINIMIZED && lParam != 0) {
		Relayout();
	}
	return 0;
}

LRESULT CommodityTickView::OnTimer(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	if (wParam == m_uTimer) {
		KillTimer(m_uTimer);
		POSITION Pos = GetFirstSelectedItemPosition();
		while (Pos)
		{
			int nItem = GetNextSelectedItem(Pos);
			SetItemState(nItem, 0, (UINT)-1);
		}
	} 
	return bHandled;
}

void CommodityTickView::InitColList()
{
	InsertColumn(0, _T("ʱ��"), LVCFMT_LEFT, 100);
	InsertColumn(1, _T("�ɽ���"), LVCFMT_RIGHT, 100);
	InsertColumn(2, _T("�ɽ���"), LVCFMT_RIGHT, 100);
}

void CommodityTickView::LoadData(bool bRequest)
{
	int i,j;

	ClearCalcData();
	//ResetRequestHisData();
	
	COMREF Commodity;
	GetCurCommodity(&Commodity);
	if(bRequest) {
		//RequestHisData(Commodity, CYC_TICK);
	} 

	LoadCalcData(Commodity, CYC_TICK, 0, m_vDispInfoPtr->DWType, m_vDispInfoPtr->DWDate, REF_CALCDATA_LOADDATA|REF_CALCDATA_AUTOREQDATA);

	DeleteAllItems();
	if (IsBarOk()) {
		BAR* pBar = GetBar();
		UINT nBarCount = GetBarCount();
		int nCount = min(nBarCount,m_nMaxTickData);
		SetItemCount(nCount);
		UpdateWindowPos();
		nCount = GetItemCount();
		if (nCount > 0) {
			int nLastPos = -1;
			for (i=nCount-1; i>=0; i--)
			{
				int nDataPos = ReversePos((nCount-1)-i,nBarCount);
				if (memcmp(&m_LastBar,pBar+nDataPos,sizeof(BAR))==0) {
					break;
				}
			}
			if (i>0) {
				for (i++;i<nCount; i++)
				{
					SetItemState(i, LVIS_FOCUSED|LVIS_SELECTED, LVIS_FOCUSED|LVIS_SELECTED);
				}
			} else {
				SelectItem(nCount-1);
			}
			m_LastBar = pBar[nBarCount-1];
			m_uTimer = SetTimer(ID_TIMER_COMMODITY_TICK, 500);
		}
	}
}

void CommodityTickView::OnDispInfoChanged()
{
	CRect rcWnd;
	GetWindowRect(&rcWnd);

	Base::SetBkColor(m_DispInfoPtr->crBackgnd);
	SetTextColor(m_DispInfoPtr->crName);
	SetTextBkColor(CLR_NONE);
	SetInsertMarkColor(CLR_NONE);
	SetOutlineColor(CLR_NONE);

	SetFont(m_DispInfoPtr->hText);

	UIHeaderCtrl2 wndHeader = GetHeader();
	if (wndHeader) {
		wndHeader.SetFont(m_DispInfoPtr->hRptTitle);
	}

	SetItemHeight(m_DispInfoPtr->xyRptText.cy+m_DispInfoPtr->xySpace.cy);

	if (rcWnd.Width()>0 && rcWnd.Height()>0) {
		Relayout();
	}
}

void CommodityTickView::OnViewInfoChanged()
{
	memset(&m_LastBar, 0, sizeof(m_LastBar));
	ClearCalcData();
	//ResetRequestHisData();

	DeleteAllItems();
}

void CommodityTickView::OnRefresh(ObjectPtr objPtr)
{
	LoadData(true);
}

void CommodityTickView::OnHisDataChanged(Event& evt)
{
	if (!IsViewOk()) {
		return;
	}
	LoadData(false);
}

//////////////////////////////////////////////////////////////////////////
///QRightView

IMPLEMENT_DYNCREATE_WND_OBJECTER(QRightView,Objecter)

enum
{
	ID_PAGE_NONE = 0,
	ID_PAGE_TICK,
	ID_PAGE_SELF,
	ID_PAGE_SELECT,
	ID_PAGE_RELAY,
	ID_PAGE_KIND,
	ID_PAGE_TRADE,
};

QRightView::QRightView()
{
	
}

QRightView::~QRightView()
{
	
}

HWND QRightView::CreateControl(HWND hWndParent, LPCTSTR lpszWndClass, LPCTSTR lpszCtrlName, UINT nID, LPCTSTR lpszXml, UINT XmlFlag)
{
	/*if (_tcsicmp(lpszWndClass, Pane::GetXmlPaneName()) != 0) {
		HWND hWndCtrl = ViewSplitter::CreateObjecter(lpszWndClass, lpszCtrlName, hWndParent, lpszXml, XmlFlag);
		OnCreateControl(hWndParent, hWndCtrl, lpszWndClass, lpszCtrlName, nID);
		return hWndCtrl;
	}*/
	return ViewSplitter::CreateControl(hWndParent, lpszWndClass, lpszCtrlName, nID, lpszXml, XmlFlag);
}

BOOL QRightView::GetLayoutRect(LPRECT lpRect)
{
	BOOL bRet = GetClientRect(lpRect);
	if (m_DispInfoPtr) {
		lpRect->bottom -= m_DispInfoPtr->xyTabCtrl.cy  + GetHBorder();
	}
	return bRet;
}

void QRightView::Relayout(LPCRECT lpRect)
{
	ViewSplitter::Relayout(lpRect);
	if (m_DispInfoPtr) {
		if (m_wndTabCtrl.m_hWnd) {
			RECT rcClient;
			GetClientRect(&rcClient);
			m_wndTabCtrl.MoveWindow(rcClient.left, rcClient.bottom-m_DispInfoPtr->xyTabCtrl.cx
				, rcClient.right-rcClient.left, m_DispInfoPtr->xyTabCtrl.cx);
		}
	}
}

LRESULT QRightView::OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	//Base::OnCreate(uMsg, wParam, lParam, bHandled);
	LRESULT Res = DefWindowProc();

	ViewSplitter::OnCreate(uMsg, wParam, lParam, bHandled);

	if (!m_wndTabCtrl.m_hWnd) {
		m_wndTabCtrl.Create(m_hWnd, rcDefault, NULL, WS_CHILD|WS_VISIBLE|TCS_BOTTOM);
	}
	
	bHandled = TRUE;
	return Res;
}

LRESULT QRightView::OnDestroy(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& bHandled)
{
	bHandled = FALSE;

	return bHandled;
}

LRESULT QRightView::OnSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	//Base::OnSize(uMsg, wParam, lParam, bHandled);
	ViewSplitter::OnSize(uMsg, wParam, lParam, bHandled);
	if (wParam != SIZE_MINIMIZED && lParam != 0) {
		
	}
	bHandled = TRUE;
	return bHandled;
}

LRESULT QRightView::OnMouse(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	return bHandled;
}

LRESULT QRightView::OnTabSelChange(int nCode, LPNMHDR lpNMHdr, BOOL& bHandled)
{
	ReInitLayout();

	return bHandled;
}

void QRightView::ReInitLayout(BOOL bInfoChanged)
{
	TCHAR szBuf[1024];

	COMREF Commodity;
	GetCurCommodity(&Commodity);

	m_wndTabCtrl.DeleteAllItems();
	//m_wndTabCtrl.AddItem(TCIF_TEXT|TCIF_PARAM, _T("��"), -1, ID_PAGE_NONE);
	m_wndTabCtrl.AddItem(TCIF_TEXT|TCIF_PARAM, _T("��"), -1, ID_PAGE_TICK);
	m_wndTabCtrl.AddItem(TCIF_TEXT|TCIF_PARAM, _T("T"), -1, ID_PAGE_TRADE);
	m_wndTabCtrl.AddItem(TCIF_TEXT|TCIF_PARAM, _T("��"), -1, ID_PAGE_SELF);
	m_wndTabCtrl.AddItem(TCIF_TEXT|TCIF_PARAM, _T("ѡ"), -1, ID_PAGE_SELECT);
	m_wndTabCtrl.AddItem(TCIF_TEXT|TCIF_PARAM, _T("��"), -1, ID_PAGE_RELAY);
	_stprintf(szBuf, _T("%s"), GetCurKind().GetName());
	m_wndTabCtrl.AddItem(TCIF_TEXT|TCIF_PARAM, szBuf, -1, ID_PAGE_KIND);
	
	int nCurSel = m_wndTabCtrl.GetCurSel();
	if (nCurSel < 0) {
		m_wndTabCtrl.SetCurSel(0);
		nCurSel = 0;
	}
	TCITEM tcItem = {0};
	tcItem.mask = TCIF_PARAM;
	m_wndTabCtrl.GetItem(nCurSel, &tcItem);
	int nCurData = tcItem.lParam;

	TCHAR szXml[8192] = {0};

	Show(SW_HIDE);
	//RemoveAllObjecter();
	RemoveAll();
	switch (MarketType(Commodity.Exchange))
	{
	case XMT_FUTURES:
		switch(nCurData)
		{
		case ID_PAGE_SELF:
			_stprintf(szXml, _T("%s\\rightview_self.xml"), _Module.GetAppPath());
			LoadAllObjecter(szXml, XML_FLAG_FILE);
			break;
		case 0:
		default:
			_stprintf(szXml, _T("%s\\rightview_stock_tick.xml"), _Module.GetAppPath());
			LoadAllObjecter(szXml, XML_FLAG_FILE);
			break;
		}
		break;
	case XMT_STOCK:
	default:
		switch(nCurData)
		{
		case ID_PAGE_SELF:
			_stprintf(szXml, _T("%s\\rightview_self.xml"), _Module.GetAppPath());
			LoadAllObjecter(szXml, XML_FLAG_FILE);
			break;
		case 0:
		default:
			if (IsStockIndex(Commodity)) {
				_stprintf(szXml, _T("%s\\rightview_index_tick.xml"), _Module.GetAppPath());
			} else {
				_stprintf(szXml, _T("%s\\rightview_stock_tick.xml"), _Module.GetAppPath());
			}
			LoadAllObjecter(szXml, XML_FLAG_FILE);
			break;
		}
		break;
	}
	Show(SW_SHOW);
	
	if (bInfoChanged) {
		BroadcastSend(EVT_PLAT_CALL, MAKEVALUE(MSET_PLAT_OBJECT,CSET_VIEW_INFO), GetViewInfoPtr());
	}

	CRect rcLayout;
	GetLayoutRect(&rcLayout);
	if (rcLayout.Width() > 0 && rcLayout.Height() > 0) {
		Relayout(&rcLayout);
	}
}

void QRightView::OnDispInfoChanged()
{
	m_wndTabCtrl.SetItemSize(m_DispInfoPtr->xyTabTitle.cx, m_DispInfoPtr->xyTabCtrl.cy);
	SIZE szPadding = {1, m_DispInfoPtr->xyTabTitle.cx/2};
	m_wndTabCtrl.SetPadding(szPadding);

	BroadcastSend(EVT_PLAT_CALL, MAKEVALUE(MSET_PLAT_OBJECT,CSET_OBJECT_DISPINFO), m_DispInfoPtr);
	SendEvent(&m_wndTabCtrl, EVT_PLAT_CALL, MAKEVALUE(MSET_PLAT_OBJECT,CSET_OBJECT_DISPINFO), m_DispInfoPtr);
}

void QRightView::OnViewInfoChanged()
{
	ReInitLayout(TRUE);
}

void QRightView::OnViewDispInfoChanged()
{
	BroadcastSend(EVT_PLAT_CALL, MAKEVALUE(MSET_PLAT_OBJECT,CSET_VIEW_DISPINFO), m_vDispInfoPtr);
}

void QRightView::OnRefresh(ObjectPtr objPtr)
{
	BroadcastSend(EVT_PLAT_CALL, MAKEVALUE(MCALL_PLAT_OBJECT,CCALL_OBJECT_REFRESH), NULL);
	Invalidate();
}

long QRightView::OnCall(Event& evt)
{
	switch(evt.value)
	{
	//////////////////////////////////////////////////////////////////////////
	default:
		evt.handled = false;
		break;
	}
	return RLT_UNKNOWN;
}
