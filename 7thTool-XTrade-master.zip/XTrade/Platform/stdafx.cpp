// stdafx.cpp : source file that includes just the standard includes
//	Platform.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"

#if !defined(_CONSOLE) && !defined(XPLATFORMAPI_EXPORTS)

#if (_ATL_VER < 0x0700)
#include <atlimpl.cpp>
#endif //(_ATL_VER < 0x0700)

#endif//
