# XTrade
基于XIndicator的通用交易平台项目