#pragma once

#include "../LogicLib/User.h"

using namespace NLogicLib;

class MockUser : public User
{
public:
	MockUser() {}


	

};