# UDPPackageTool
用Poco和Qt5.8.0实现UDP的带有界面的发送和接收Demo版工具
