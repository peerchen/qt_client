#ifndef _COMM_AP_H
#define _COMM_AP_H
#include "Config.h"

#include "Comm.h"
#include "ApConstant.h"

#ifdef _WIN32
#ifdef COMMAP_EXPORT
#define COMMAP_API			__declspec(dllexport)
#define COMMAP_CLASS		__declspec(dllexport)
#else
#define COMMAP_API			__declspec(dllimport)
#define COMMAP_CLASS		__declspec(dllimport)
#endif
#else
#define COMMAP_API
#define COMMAP_CLASS
#endif

#endif