#include "MainServiceHandler.h"
#include "RiskCpMgr.h"

// F1 �ӿ� [3088]���յȼ���ѯ ��ҵ��ʵ��
int CMainServiceHandler::OnRiskGradeQueryReq(CTradePacket& pkt)
{
	HEADER_REQ stHeaderReq;
	RiskGradeQueryReq stBodyReq;

	HEADER_RSP stHeaderRsp;
	RiskGradeQueryRsp stBodyRsp;

	pkt.GetHeader(stHeaderReq);
	CPacketStructTradeRisk::Packet2Struct(stBodyReq, pkt);

	//ҵ��ʵ��......
	string sRspCode = RSP_SUCCESS;
	string sRspMsg;
	if (stBodyReq.oper_flag == 1) 
	{
		SearchRiskGrade(stBodyRsp, sRspCode, sRspMsg);
	}
	else {
		sRspCode = RSP_PARAM_ERROR;
		sRspMsg = "�������oper_flag����";
	}

	//������Ӧ����
	CTradePacket pktRsp;
	CPacketStructTradeRisk::HeadReq2Rsp(stHeaderReq,stHeaderRsp);
	strcpy(stHeaderRsp.rsp_code, sRspCode.substr(0,8).c_str());
	if (sRspCode != RSP_SUCCESS)
	{
		pktRsp.AddParameter(RSP_MSG, sRspMsg);
	}
	pktRsp.SetHeader(stHeaderRsp);
	CPacketStructTradeRisk::Struct2Packet(stBodyRsp,pktRsp);

	//ת������
	m_pRiskCpMgr->ToInterfaceF1(pktRsp,m_ulKey);

	return 0;
};

//���ط��յȼ�
void CMainServiceHandler::SearchRiskGrade(RiskGradeQueryRsp& stBodyRsp, string& sRspCode, string& sRspMsg)
{
	try
	{
		//���ռ���
		otl_stream_read_iterator<otl_stream,otl_exception,otl_lob_stream> rs;
		string sql = "select * from risk_grade order by grade_id "; 
		otl_stream stream(50, sql.c_str(), GetOtlConn());
		rs.attach(stream); 

		string sGradeName, sGradeColor;
		int nGradeId, nRiskType;
		while (rs.next_row())
		{
			rs.get("grade_id", nGradeId);
			rs.get("grade_name", sGradeName);
			rs.get("grade_color", sGradeColor);
			rs.get("risk_type", nRiskType);
			
			ArrayListMsg alMsg;
			alMsg.AddValue(nGradeId);
			alMsg.AddValue(sGradeName);
			alMsg.AddValue(sGradeColor);
			alMsg.AddValue(nRiskType);

			stBodyRsp.query_result.AddValue(alMsg);
		}
		rs.detach();

		stBodyRsp.oper_flag = 1;
	}
	catch(otl_exception &p)
	{
		CRLog(E_ERROR, "3088���յȼ���ѯotl excepiton: %s, %s, %s, %s", p.msg, p.stm_text, p.sqlstate, p.var_info);
		sRspCode = RSP_EXCEPTION;
		sRspMsg = "��ѯ���յȼ����ݳ���";
	}
	catch(std::exception& e)
	{
		sRspCode = RSP_EXCEPTION;
		sRspMsg = ToString(3088) + "-ִ��ʱ��������,exp[" + e.what() + "]" ;
		CRLog(E_ERROR,"%s", sRspMsg.c_str());
	}
	catch(...)
	{
		sRspCode = RSP_UNKNOWN_EXCEPTION;
		sRspMsg = ToString(3088) + "-ִ��ʱ����δ֪����,unknown exception" ;
		CRLog(E_ERROR,"%s", sRspMsg.c_str());
	}
}