#include "RiskHandler.h"
#include "RiskConstant.h"
#include "RiskCpMgr.h"

using namespace RiskConst;

// A1 �ӿ� [onRecvRtnDeferMatch]DeferMatch ��ҵ��ʵ��
int CRiskHandler::OnDeferMatch(CBroadcastPacket& pkt)
{
	DeferMatch stBody;
	CPacketStructBroadcastRisk::Packet2Struct(stBody, pkt);

	//ҵ��ʵ��......
	SendAck(pkt);

	CCustomer* p = FindCustomer(stBody.acctNo);
	if (!p)
		return -1;

	if(stBody.offsetFlag=='2')
	{
		m_pMemDb->GetEntrFlowTbl().DeleteEntrFlow(stBody.localOrderNo);
	}
	

	std::string sKey = stBody.matchNo + stBody.orderNo;
	CMatchDetailTbl& tblMatch = m_pMemDb->GetMatchDetailTbl();
	if (tblMatch.IsHandled(sKey,stBody.acctNo))
		return -1;

	CRLog(E_APPINFO,"OnDeferMatch %s %c %c %s %d %f %s\n",stBody.acctNo.c_str(),stBody.buyOrSell,stBody.offsetFlag,stBody.instID.c_str(),stBody.volume,stBody.price,sKey.c_str());

	CQuotationTbl& tblQuotation = m_pMemDb->GetQuotationTbl();
	//double dlaPrice[gc_nProdNum];
	//tblQuotation.GetPriceArray(dlaPrice,gc_nProdNum);

	vector<double> dlPrice=tblQuotation.GetPriceArray();

	CustRiskInfo oCustRiskInfo;
	int nType = 0;
	
	
	m_pMemDb->GetProdCodeTbl().GetVarietyType(stBody.instID,nType);
	double dlUnit = GetMeasureUnit(stBody.instID);


	//����ƽ���������Ƿ���ݵ��ղֺ���ʷ�ַֿ�����
	int nDiffCovFare = m_pMemDb->GetBasicParaTbl().GetDiffCovFareByCurrOrHisFlag();
	p->SetDiffCovFareByCurrOrHisFlag(nDiffCovFare);

	int nRtn = gc_cStateNormal;
	if (gc_nAu == nType)
	{
		CDeferAuMatch pDeferMatch = CDeferAuMatch(stBody.instID,nType,stBody.offsetFlag,stBody.buyOrSell,stBody.price,stBody.volume,dlUnit);
		
		nRtn = p->OnRtnMatchDefer(pDeferMatch,dlPrice,oCustRiskInfo);
	}
	else if (gc_nAg == nType)
	{
		CDeferAgMatch pDeferMatch = CDeferAgMatch(stBody.instID,nType,stBody.offsetFlag,stBody.buyOrSell,stBody.price,stBody.volume,dlUnit);
		nRtn = p->OnRtnMatchDefer(pDeferMatch,dlPrice,oCustRiskInfo);
	}
	else
	{
		CRLog(E_APPINFO,"Unknkown Spot Type:%d",nType);
		return -1;
	}
	
	if (nRtn == gc_cStateNormal)
	{
	}
	if (nRtn == gc_cStateValueChange)
	{
		//����� 
		m_pRiskNotify->Enque(oCustRiskInfo);
	}
	if (nRtn == gc_cStateRiskTransfer)
	{
		//����� 
		m_pRiskNotify->Enque(oCustRiskInfo);
	}

	p->UpdateAgentBalanceStat();
	p->UpdateAgentDebtStat();

	// ���׳ɹ������¼��㱬����Ϣ  add by liuwei 2012-3-28
	double dlup,dldown,dlup1,dldown1;
	tblQuotation.UpLimitPrice("Ag(T+D)", dlup);
	tblQuotation.DownLimitPrice("Ag(T+D)", dldown);
	tblQuotation.UpLimitPrice1("Ag(T+D)", dlup1);
	tblQuotation.UpLimitPrice1("Ag(T+D)", dldown1);
	double dlup2,dldown2,dlup21,dldown21;
	tblQuotation.UpLimitPrice("Au(T+D)", dlup2);
	tblQuotation.DownLimitPrice("Au(T+D)", dldown2);
	tblQuotation.UpLimitPrice1("Au(T+D)", dlup21);
	tblQuotation.UpLimitPrice1("Au(T+D)", dldown21);
	p->CalculateOutStockInfo(dlup, dldown, dlup1, dldown1, dlup2, dldown2, dlup21, dldown21);

	return 0;
};
