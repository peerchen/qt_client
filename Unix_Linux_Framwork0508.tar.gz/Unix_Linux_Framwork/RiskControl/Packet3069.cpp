#include "MainServiceHandler.h"
#include "RiskCpMgr.h"

// F1 �ӿ� [3069]ǿƽ����ѯ���� ��ҵ��ʵ��
int CMainServiceHandler::OnFCOrderQueryReq(CTradePacket& pkt)
{
	HEADER_REQ stHeaderReq;
	FCOrderQueryReq stBodyReq;

	HEADER_RSP stHeaderRsp;
	FCOrderQueryRsp stBodyRsp;

	pkt.GetHeader(stHeaderReq);
	CPacketStructTradeRisk::Packet2Struct(stBodyReq, pkt);

	CTradePacket pktRsp;
	CPacketStructTradeRisk::HeadReq2Rsp(stHeaderReq,stHeaderRsp);

	//ҵ��ʵ��......
	try
	{ 
		if (GetFCOrder(stHeaderReq, stBodyReq, stBodyRsp) < 0)
		{
			strcpy(stHeaderRsp.rsp_code, RSP_NO_RECORD.c_str());
			pktRsp.AddParameter("rsp_msg", "û�м�¼");
		}
		else
			strcpy(stHeaderRsp.rsp_code, "00000000"); 
	}
	catch(otl_exception& p)
	{   
		CRLog(E_ERROR, "DB:MSG:%s\nTEXT:%s\nVARINFO:%s", p.msg, p.stm_text, p.var_info); 
		strcpy(stHeaderRsp.rsp_code, RSP_EXCEPTION.c_str()); 
		pktRsp.AddParameter("rsp_msg", (const char *)p.msg);
	}

	//������Ӧ����
	pktRsp.SetHeader(stHeaderRsp);
	CPacketStructTradeRisk::Struct2Packet(stBodyRsp,pktRsp);

	//ת������
	m_pRiskCpMgr->ToInterfaceF1(pktRsp,m_ulKey);

	return 0;
}

/*
���������������ݿ��в�ѯǿƽ��
���������HEADER_REQ:�����ͷ����
		  FCOrderQueryReq:���������
���������FCOrderQueryRsp:Ӧ�������
����ֵ���쳣��otl_exception,����ִ���м�¼����0���޼�¼����-1
*/
#ifdef _VER_25_DB2
int CMainServiceHandler::GetFCOrder(const HEADER_REQ &stHeaderReq, const FCOrderQueryReq &stBodyReq, FCOrderQueryRsp & stBodyRsp) throw(otl_exception)
{
	//char buffer[6000];

	/*�����̱��	branch_id	string
	��Լ����	instID	string
	���ɷ�ʽ	gene_type	string
	ǿƽ����Ա	f_teller_id	string
	����״̬	order_status_set	ArrayListMsg*/
	string branchID=stHeaderReq.BranchID();
	char cForceType[10];
	double risk_degree1=0.0;
	double risk_degree2=0.0;
	double price=0.0;
	double volume=0.0;
	double curr_bal=0.0;
	double total_margin=0.0;
	double float_surplus=0.0;
	double m_margin=0.0;
	double b_margin=0.0;
	string sSql = "select "
					" (case when  order_no is null then '' else order_no end) as order_no , "
					" acct_no, "
					" (case when  cust_abbr is null then '' else cust_abbr end) as cust_abbr , "
					" (case when  instid is null then '' else instid end) as instid , "
					" bs,  "
					" price, "
					" volume, "
					" (case when  match_amount is null  then '' else match_amount end) as match_amount, "
					" (case when  match_price is null  then '' else match_price end) as match_price, "
					" entr_stat, "
					" (case when  cover_no is null then '' else cover_no end) as cover_no , "
					" (case when  e_teller_id is null then '' else e_teller_id end) as e_teller_id , "
					" (case when  c_teller_id is null then '' else c_teller_id end) as c_teller_id , "
					" (case when  e_exch_time is null then '' else e_exch_time end) as e_exch_time , "
					" (case when  c_exch_time is null then '' else c_exch_time end) as c_exch_time, "
					" branch_id, "
					" batch_no, "
					" curr_bal, "
					" total_margin, "
					" float_surplus, "
					" risk_degree1, "
					" inst_prices, "
					" acct_type, "
					" gradeid, "
					" m_margin, "
					" b_margin, "
					" risk_degree2, "
					" FC_TYPE,"
					" branch_name "
					" from	"
					"( " 
					"  select " 
					"     a.local_order_no, " 
					"     a.acct_no, " 
					"     d.cust_abbr, " 
					"     d.acct_type, " 
					"     d.grade_id, " 
					"     a.instid, " 
					"	  a.FC_TYPE, "
					"     a.bs, " 
					"     a.price, " 
					"     a.volume, " 
					"     a.COVER_NO, " 
					"	  a.order_status, "
					"     (case when b.entr_stat = '1' or b.entr_stat = 'o' then '1' " 
					"          when b.entr_stat = 'p' or ((b.entr_stat = 'd' or b.entr_stat = 's') and c.match_amount > 0) then '2' " 
					"          when b.entr_stat = 'c' then '3' " 
					"          when b.entr_stat = 'd' or b.entr_stat = 's' then '4' " 
					"          else '5' end ) as entr_stat, " 
					"     b.order_no, " 
					"     FG_CovToChar(c.match_price) as match_price , " 
					"     FG_CovToChar(c.match_amount) as match_amount, " 
					"     b.e_teller_id, " 
					"     case when b.order_no is not null or b.order_no =''  then b.c_teller_id else '' end as c_teller_id, " 
					"	  a.exch_date, "
					"     case when b.e_exch_time is null or b.e_exch_time='' then '' else FG_Concat(FG_Concat(FG_CovToDate10(b.exch_date),' '),FG_CovToTime8(b.e_exch_time)) end  as  e_exch_time,"
					"     case when b.order_no is not null or b.order_no <> '' then case when b.c_exch_time is null or b.c_exch_time='' then '' else FG_Concat(FG_Concat(FG_CovToDate10(b.exch_date),' '),FG_CovToTime8(b.c_exch_time)) end else '' end as c_exch_time , " 
					"     d.branch_id, "
					"     d.grade_id gradeid, "
					"     a.batch_no, " 
					"     e.curr_bal, " 
					"     e.m_margin, " 
					"     e.b_margin, " 
					"     e.total_margin, " 
					"     e.float_surplus, " 
					"     e.risk_degree1, " 
					"     e.risk_degree2, " 
					"     e.inst_prices, " 
					"	  f.branch_name "  
					"  from " 
					" force_cov_order a "
					"	left join "
					"    (select exch_date,order_no,local_order_no,entr_price,entr_amount,entr_stat,e_teller_id,e_exch_time,c_teller_id,c_exch_time from entr_flow where offset_flag = '2' union " 
					"     select exch_date,order_no,local_order_no,entr_price,entr_amount,entr_stat,e_teller_id,e_exch_time,c_teller_id,c_exch_time from his_entr_flow where offset_flag = '2' ) b  " 
					"	on a.local_order_no = b.local_order_no and a.exch_date = b.exch_date "
					"	left join "
					"    (  select exch_date ,local_order_no,sum(match_price*match_amount)/sum(match_amount) as match_price,sum(match_amount) as match_amount from " 
					"        ( select exch_date,local_order_no,match_price,match_amount from busi_back_flow  where offset_flag = '2' union " 
					"          select exch_date,local_order_no,match_price,match_amount from his_m_match_flow where offset_flag = '2'  )  x" 
					"       group by exch_date, local_order_no ) c " 
					"	on a.local_order_no = c.local_order_no and a.exch_date = c.exch_date "
					"	left join "
					"   cust_info d "
					"	on a.acct_no = d.acct_no "
					"   left join branch_info f on d.branch_id = f.branch_id "
					"	left join "
					" force_cov_condition e "
					"	on a.batch_no = e.batch_no and a.acct_no = e.acct_no and a.exch_date = e.exch_date "
					") k ";
	//ʱ������
	sSql += "where k.exch_date between '" + stBodyReq.begin_date +  "' and '" +  stBodyReq.end_date + "' ";

	//��������
	if (stBodyReq.branch_id == "")
	{
		sSql += GetBranchSql(branchID, 1);
	}
	else if (stBodyReq.branch_id != branchID)
	{
		
		sSql += GetBranchSql(stBodyReq.branch_id, 1);
	}
	else
	{
		sSql += "and k.branch_id = '" + stBodyReq.branch_id + "'";
	}

	//���ɷ�ʽ
	if (stBodyReq.gene_type != "")
	{
		sSql += " and k.FC_TYPE = '" + stBodyReq.gene_type + "'";
	}

	//����״̬
	if (stBodyReq.order_status_set.size() > 0)
	{
		sSql += " and (";
		for (size_t i=0; i<stBodyReq.order_status_set.size(); i++)
		{
			string sFcOrderStatus = stBodyReq.order_status_set.GetValue<string>(i);

			if (i != 0)
			{
				sSql += " or ";
			}

			sSql += "entr_stat = '" + sFcOrderStatus + "'";
			
		}
		sSql += ") ";
	}

	//��Լ����
	if (stBodyReq.instid != "")
	{
		sSql += " and k.instid = '" + stBodyReq.instid + "'";
	}

	//ǿƽ����Ա
	if (stBodyReq.f_teller_id != "")
	{
		sSql += " and k.e_teller_id = '" + stBodyReq.f_teller_id + "'";
	}

	//�ͻ���
	if (stBodyReq.acct_no != "")
	{
		sSql += " and k.acct_no = '" + stBodyReq.acct_no + "'";
	}

	//�˻�����
	if (stBodyReq.acct_type != "")
	{
		sSql += " and k.acct_type = '" + stBodyReq.acct_type + "'";
	}
	//�ͻ�����
	if(stBodyReq.cust_type!="")
	{
		sSql += " and k.gradeid = '" + stBodyReq.cust_type + "'";
	}
	
	//����
	sSql += " order by  e_exch_time desc, batch_no desc, acct_no desc ";

	//CRLog(E_DEBUG, "sql:%s", sSql.c_str()); 
	otl_stream o(1, sSql.c_str(), GetOtlConn());
	
	
	ArrayListMsg msg;

	int nFlag = -1;
	while(!o.eof())
	{
		RSP3069 stRsp3069;
		o >> stRsp3069.sOrderNo >> stRsp3069.sCustomerId >> stRsp3069.sCustomerName >> stRsp3069.sProcCode 
			>> stRsp3069.sBs >> price >> volume >>stRsp3069.sExchAmount >> stRsp3069.sExchPrice
			>> stRsp3069.sOrderState >> stRsp3069.sForceOrderNo >> stRsp3069.sForceOper >> stRsp3069.sCancelOper 
			>> stRsp3069.sEntrTime >> stRsp3069.sCancelTime >> stRsp3069.sBranchId 
			>> stRsp3069.sBatchNo >> curr_bal >> total_margin >> float_surplus >>risk_degree1 >> stRsp3069.sInstPrices >> stRsp3069.sAcctType>>stRsp3069.sCustType>>m_margin>>b_margin>>risk_degree2>>cForceType>>stRsp3069.sBranchName;
	
		msg.clear();
		stRsp3069.sRiskDegree1=ToString(risk_degree1);
		stRsp3069.sRiskDegree2=ToString(risk_degree2);
		stRsp3069.sEntrPrice=ToString(price);
		stRsp3069.sEntrAmount=ToString(volume);
		//stRsp3069.sExchPrice=ToString(risk_degree1);
		//stRsp3069.sExchAmount=ToString(risk_degree1);
		stRsp3069.sCurrBal=ToString(curr_bal);
		stRsp3069.sFloatSurplus=ToString(float_surplus);
		stRsp3069.sMarginMem=ToString(m_margin);
		stRsp3069.sMarginExch=ToString(b_margin);
		stRsp3069.sMarginTotal=ToString(total_margin);
// 		stRsp3069.sBranchName=m_pMemDb->GetCustTble().GetCustomer(stRsp3069.sCustomerId)->AgentName();
		msg.AddValue(stRsp3069.sCustomerId);   //  �ͻ���
		msg.AddValue(stRsp3069.sCustomerName);//�ͻ����
		msg.AddValue(stRsp3069.sCustType);//�ͻ�����
		msg.AddValue(stRsp3069.sAcctType);//�˻�����
		msg.AddValue(stRsp3069.sProcCode);  //��Լ     
		msg.AddValue(stRsp3069.sBs); //��������
		msg.AddValue(stRsp3069.sEntrPrice);   //ί�м۸�   
		msg.AddValue(stRsp3069.sEntrAmount);//ί������
		msg.AddValue(stRsp3069.sForceOrderNo); //ǿƽ����
		msg.AddValue(stRsp3069.sOrderState);    // ����״̬
		msg.AddValue(stRsp3069.sOrderNo);      //������
		msg.AddValue(stRsp3069.sExchPrice);    //�ɽ�����
		msg.AddValue(stRsp3069.sExchAmount);  //�ɽ�����     
		msg.AddValue(stRsp3069.sForceOper);   //ǿƽ����Ա   
		msg.AddValue(stRsp3069.sCancelOper);  // ��������Ա 
		msg.AddValue(stRsp3069.sEntrTime);    //ί��ʱ�� 
		msg.AddValue(stRsp3069.sCancelTime);  //����ʱ��   
		msg.AddValue(stRsp3069.sBranchId);    //�����̱��   
		msg.AddValue(stRsp3069.sBranchName);  //�����̼��
		msg.AddValue(stRsp3069.sBatchNo);     //���κ�
		msg.AddValue(stRsp3069.sCurrBal); //��ʱ�����ʽ�
		msg.AddValue(stRsp3069.sFloatSurplus); //��ʱ����ӯ��
		msg.AddValue(stRsp3069.sRiskDegree1); //��ʱ���ն�1
		msg.AddValue(stRsp3069.sRiskDegree2); //��ʱ���ն�2
		msg.AddValue(stRsp3069.sMarginMem);//��ʱ��Ա��֤��
		msg.AddValue(stRsp3069.sMarginExch);//��ʱ��������֤��
		msg.AddValue(stRsp3069.sMarginTotal);//��ʱ�ܱ�֤��
		msg.AddValue(stRsp3069.sInstPrices); //��ʱ��Լ�۸�
		msg.AddValue(cForceType);			 //���ɷ�ʽ
		stBodyRsp.alm_result.AddValue(msg);
		nFlag = 0;
	}

	return nFlag;
}
#else
int CMainServiceHandler::GetFCOrder(const HEADER_REQ &stHeaderReq, const FCOrderQueryReq &stBodyReq, FCOrderQueryRsp & stBodyRsp) throw(otl_exception)
{
	//char buffer[6000];

	/*�����̱��	branch_id	string
	��Լ����	instID	string
	���ɷ�ʽ	gene_type	string
	ǿƽ����Ա	f_teller_id	string
	����״̬	order_status_set	ArrayListMsg*/
	string branchID=stHeaderReq.BranchID();
	double risk_degree1=0.0;
	double risk_degree2=0.0;
	char cForceType[10];
	string sSql = "select "
					" nvl(order_no, ''), "
					" acct_no, "
					" nvl(cust_abbr, ''), "
					" nvl(instid, ''), "
					" nvl(bs, ''), "
					" nvl(to_char(price), ''), "
					" nvl(to_char(volume), ''), "
					" nvl(to_char(match_amount), ''), "
					" nvl(to_char(match_price), ''), "
					" entr_stat, "
					" nvl(to_char(cover_no), ''), "
					" nvl(e_teller_id, ''), "
					" nvl(c_teller_id, ''), "
					" nvl(e_exch_time, ''), "
					" nvl(c_exch_time, ''), "
					" nvl(branch_id, ''), "
					" to_char(batch_no), "
					" to_char(curr_bal), "
					" to_char(total_margin), "
					" to_char(float_surplus), "
					" risk_degree1, "
					" to_char(inst_prices), "
					" to_char(acct_type), "
					" to_char(gradeid), "
					" to_char(m_margin), "
					" to_char(b_margin), "
					" risk_degree2,"
					" nvl(FC_TYPE,''),"
					" branch_name "
					"from	"
					"( " 
					"  select " 
					"     a.local_order_no, " 
					"     a.acct_no, " 
					"     d.cust_abbr, " 
					"     d.acct_type, " 
					"     d.grade_id, " 
					"     a.instid, " 
					"	  a.FC_TYPE, "
					"     a.bs, " 
					"     a.price, " 
					"     a.volume, " 
					"     a.COVER_NO, " 
					"	  a.order_status, "
					"     (case when b.entr_stat = '1' or b.entr_stat = 'o' then '1' " 
					"          when b.entr_stat = 'p' or ((b.entr_stat = 'd' or b.entr_stat = 's') and c.match_amount > 0) then '2' " 
					"          when b.entr_stat = 'c' then '3' " 
					"          when b.entr_stat = 'd' or b.entr_stat = 's' then '4' " 
					"          else '5' end ) as entr_stat, " 
					"     b.order_no, " 
					"     c.match_price, " 
					"     c.match_amount, " 
					"     b.e_teller_id, " 
					"     case when b.order_no is not null then b.c_teller_id else '' end as c_teller_id, " 
					"	  a.exch_date, "
					"     nvl2(b.e_exch_time, substr(b.exch_date, 1, 4)||'-'||substr(b.exch_date, 5, 2)||'-'||substr(b.exch_date, 7, 2)||' '||substr(b.e_exch_time, 1, 2)||':'||substr(b.e_exch_time, 3, 2)||':'||substr(b.e_exch_time, 5, 2), b.e_exch_time) as e_exch_time, " 
					"     case when b.order_no is not null then nvl2(b.c_exch_time, substr(b.exch_date, 1, 4)||'-'||substr(b.exch_date, 5, 2)||'-'||substr(b.exch_date, 7, 2)||' '||substr(b.c_exch_time, 1, 2)||':'||substr(b.c_exch_time, 3, 2)||':'||substr(b.c_exch_time, 5, 2), b.c_exch_time) else '' end as c_exch_time , " 
					"     d.branch_id, "
					"     d.grade_id gradeid, "
					"     a.batch_no, " 
					"     e.curr_bal, " 
					"     e.m_margin, " 
					"     e.b_margin, " 
					"     e.total_margin, " 
					"     e.float_surplus, " 
					"     e.risk_degree1, " 
					"     e.risk_degree2, " 
					"     e.inst_prices, "
					"	  f.branch_name "  
					"  from force_cov_order a "
					"	left join "
					"    (select exch_date,order_no,local_order_no,entr_price,entr_amount,entr_stat,e_teller_id,e_exch_time,c_teller_id,c_exch_time from entr_flow where offset_flag = '2' union all " 
					"     select exch_date,order_no,local_order_no,entr_price,entr_amount,entr_stat,e_teller_id,e_exch_time,c_teller_id,c_exch_time from his_entr_flow where offset_flag = '2' ) b  " 
					"	on a.local_order_no = b.local_order_no and a.exch_date = b.exch_date "
					"	left join "
					"    (  select exch_date ,local_order_no,sum(match_price*match_amount)/sum(match_amount) as match_price,sum(match_amount) as match_amount from " 
					"        ( select exch_date,local_order_no,match_price,match_amount from busi_back_flow  where offset_flag = '2' union all " 
					"          select exch_date,local_order_no,match_price,match_amount from his_m_match_flow where offset_flag = '2'  ) " 
					"       group by exch_date, local_order_no ) c " 
					"	on a.local_order_no = c.local_order_no and a.exch_date = c.exch_date "
					"	left join cust_info d on a.acct_no = d.acct_no "
					"   left join branch_info f on d.branch_id = f.branch_id "
					"	left join force_cov_condition e on a.batch_no = e.batch_no and a.acct_no = e.acct_no and a.exch_date = e.exch_date "
					") k ";
	//ʱ������
	sSql += "where k.exch_date between '" + stBodyReq.begin_date +  "' and '" +  stBodyReq.end_date + "' ";

	//��������
	if (stBodyReq.branch_id == "")
	{
		sSql += GetBranchSql(branchID, 1);
	}
	else if (stBodyReq.branch_id != branchID)
	{
		
		sSql += GetBranchSql(stBodyReq.branch_id, 1);
	}
	else
	{
		sSql += "and k.branch_id = '" + stBodyReq.branch_id + "'";
	}

	//���ɷ�ʽ
	if (stBodyReq.gene_type != "")
	{
		sSql += " and k.FC_TYPE = '" + stBodyReq.gene_type + "'";
	}

	//����״̬
	if (stBodyReq.order_status_set.size() > 0)
	{
		sSql += " and (";
		for (size_t i=0; i<stBodyReq.order_status_set.size(); i++)
		{
			string sFcOrderStatus = stBodyReq.order_status_set.GetValue<string>(i);

			if (i != 0)
			{
				sSql += " or ";
			}

			sSql += "entr_stat = '" + sFcOrderStatus + "'";
			
		}
		sSql += ") ";
	}

	//��Լ����
	if (stBodyReq.instid != "")
	{
		sSql += " and k.instid = '" + stBodyReq.instid + "'";
	}

	//ǿƽ����Ա
	if (stBodyReq.f_teller_id != "")
	{
		sSql += " and k.e_teller_id = '" + stBodyReq.f_teller_id + "'";
	}

	//�ͻ���
	if (stBodyReq.acct_no != "")
	{
		sSql += " and k.acct_no = '" + stBodyReq.acct_no + "'";
	}

	//�˻�����
	if (stBodyReq.acct_type != "")
	{
		sSql += " and k.acct_type = '" + stBodyReq.acct_type + "'";
	}
	//�ͻ�����
	if(stBodyReq.cust_type!="")
	{
		sSql += " and k.gradeid = '" + stBodyReq.cust_type + "'";
	}
	
	//����
	sSql += " order by e_exch_time desc, batch_no desc, acct_no desc ";

	CRLog(E_DEBUG, "sql:%s", sSql.c_str()); 
	otl_stream o(1, sSql.c_str(), GetOtlConn());
	
	RSP3069 stRsp3069;
	ArrayListMsg msg;
	unsigned int uiCount = 0;
	int nFlag = -1;
	while(!o.eof())
	{
		o >> stRsp3069.sOrderNo >> stRsp3069.sCustomerId >> stRsp3069.sCustomerName >> stRsp3069.sProcCode 
			>> stRsp3069.sBs >> stRsp3069.sEntrPrice >> stRsp3069.sEntrAmount >> stRsp3069.sExchAmount >> stRsp3069.sExchPrice 
			>> stRsp3069.sOrderState >> stRsp3069.sForceOrderNo >> stRsp3069.sForceOper >> stRsp3069.sCancelOper 
			>> stRsp3069.sEntrTime >> stRsp3069.sCancelTime >> stRsp3069.sBranchId 
			>> stRsp3069.sBatchNo >> stRsp3069.sCurrBal >> stRsp3069.sMarginTotal >> stRsp3069.sFloatSurplus >>risk_degree1 >> stRsp3069.sInstPrices 	
			>> stRsp3069.sAcctType>>stRsp3069.sCustType>>stRsp3069.sMarginMem>>stRsp3069.sMarginExch>>risk_degree2>>cForceType >>stRsp3069.sBranchName;

		msg.clear();
		stRsp3069.sRiskDegree1=ToString(risk_degree1);
		stRsp3069.sRiskDegree2=ToString(risk_degree2);
		CRLog(E_APPINFO, "loop %u-2", uiCount);
		CRLog(E_APPINFO, "custID:%s", stRsp3069.sCustomerId.c_str());
		msg.AddValue(stRsp3069.sCustomerId);   //  �ͻ���
		msg.AddValue(stRsp3069.sCustomerName);//�ͻ����
		msg.AddValue(stRsp3069.sCustType);//�ͻ�����
		msg.AddValue(stRsp3069.sAcctType);//�˻�����
		msg.AddValue(stRsp3069.sProcCode);  //��Լ     
		msg.AddValue(stRsp3069.sBs); //��������
		msg.AddValue(stRsp3069.sEntrPrice);   //ί�м۸�   
		msg.AddValue(stRsp3069.sEntrAmount);//ί������
		msg.AddValue(stRsp3069.sForceOrderNo); //ǿƽ����
		msg.AddValue(stRsp3069.sOrderState);    // ����״̬
		msg.AddValue(stRsp3069.sOrderNo);      //������
		msg.AddValue(stRsp3069.sExchPrice);    //�ɽ�����
		msg.AddValue(stRsp3069.sExchAmount);  //�ɽ�����     
		msg.AddValue(stRsp3069.sForceOper);   //ǿƽ����Ա   
		msg.AddValue(stRsp3069.sCancelOper);  // ��������Ա 
		msg.AddValue(stRsp3069.sEntrTime);    //ί��ʱ�� 
		msg.AddValue(stRsp3069.sCancelTime);  //����ʱ��   
		msg.AddValue(stRsp3069.sBranchId);    //�����̱��   
		msg.AddValue(stRsp3069.sBranchName);  //�����̼��
		msg.AddValue(stRsp3069.sBatchNo);     //���κ�
		msg.AddValue(stRsp3069.sCurrBal); //��ʱ�����ʽ�
		msg.AddValue(stRsp3069.sFloatSurplus); //��ʱ����ӯ��
		msg.AddValue(stRsp3069.sRiskDegree1); //��ʱ���ն�1
		msg.AddValue(stRsp3069.sRiskDegree2); //��ʱ���ն�2
		msg.AddValue(stRsp3069.sMarginMem);//��ʱ��Ա��֤��
		msg.AddValue(stRsp3069.sMarginExch);//��ʱ��������֤��
		msg.AddValue(stRsp3069.sMarginTotal);//��ʱ�ܱ�֤��
		msg.AddValue(stRsp3069.sInstPrices); //��ʱ��Լ�۸�
		msg.AddValue(cForceType);			 //���ɷ�ʽ
		stBodyRsp.alm_result.AddValue(msg);
		uiCount++;
		nFlag = 0;
	}

	return nFlag;
}

#endif
