#include "FpOrderFlow.h"


void CFpOrderFlowStatistics::SetNumBuy(int nNum)
{
	m_nNumBuy = nNum;
}
void CFpOrderFlowStatistics::SetNumSell(int nNum)
{
	m_nNumSell = nNum;
}
void CFpOrderFlowStatistics::SetMarginBuy(double dlMargin)
{
	m_dlMarginBuy = dlMargin;
}
void CFpOrderFlowStatistics::SetMarginSell(double dlMargin)
{
	m_dlMarginSell = dlMargin;
}
void CFpOrderFlowStatistics::SetFareBuy(double dlFare)
{
	m_dlFareBuy = dlFare;
}
void CFpOrderFlowStatistics::SetFareSell(double dlFare)
{
	m_dlFareSell = dlFare;
}



void CFpOrderFlowStatistics::UpdateNumBuy(int nNum)
{
	m_nNumBuy += nNum;
}
void CFpOrderFlowStatistics::UpdateNumSell(int nNum)
{
	m_nNumSell += nNum;
}
void CFpOrderFlowStatistics::UpdateMarginBuy(double dlMargin)
{
	m_dlMarginBuy += dlMargin;
}
void CFpOrderFlowStatistics::UpdateMarginSell(double dlMargin)
{
	m_dlMarginSell += dlMargin;
}
void CFpOrderFlowStatistics::UpdateFareBuy(double dlFare)
{
	m_dlFareBuy += dlFare;
}
void CFpOrderFlowStatistics::UpdateFareSell(double dlFare)
{
	m_dlFareSell += dlFare;
}
void CFpOrderFlowStatistics::UpdateEntrPrice(double dlPrice)
{
	m_dlPrice = dlPrice;
}