#include <time.h>
#include "CustomerTbl.h"
#include "RiskAlgorithmDef.h"
#include "DebtAlgorithmDef.h"
#include "Logger.h"
#include "DB_Version.h" 
#include "Agent.h"
#include "Customer.h"
#include "RiskAlgorithm2.h"
#include "DebtAlgorithm2.h"
//#include "VersionMacro.h"
#include "strutils.h"
using namespace strutils;
#include "Global.h"



CCustomerTbl::CCustomerTbl()
{
	
}

CCustomerTbl::~CCustomerTbl()
{
	Finish();
}

//##ModelId=4913F93402AF
CCustomer* CCustomerTbl::GetCustomer(const string& sID)
{
	map<string,CCustomer*>::iterator it = m_mapCust.find(sID);
	if (it != m_mapCust.end())
	{
		return it->second;
	}
	else
	{
		return 0;
	}
}

//ɾ���ͻ�
int CCustomerTbl::DelRec(const string& sID)
{
	map<string,CCustomer*>::iterator it = m_mapCust.find(sID);
	if (it != m_mapCust.end())
	{
		delete it->second;
		m_mapCust.erase(it);
		return 0;
	}
	else
	{
		return 0;
	}
}

//##ModelId=4913F960006D
const vector<CCustomer*>& CCustomerTbl::GetRecordSet()
{
	return m_vecCust;
}

/*
//��ȡ�ͻ������¼����
int CCustomerTbl::GetCustTypeRecord(const string &sCustType, vector<CCustomer*> &vecCustType)
{
	map<string, vector<CCustomer*>>::iterator it = m_vecCustType.find(sCustType);
	if (it != m_vecCustType.end())
	{
		vecCustType = it->second;
		return 0;
	}
	else
	{
		return -1;
	}
}
*/

//��ȡ�˻����ͼ�¼����
int CCustomerTbl::GetAcctTypeRecord(const string &sAcctType, vector<CCustomer*> &vecAcctType)
{
	map<string, vector<CCustomer*> >::iterator it = m_vecAcctType.find(sAcctType);
	if (it != m_vecAcctType.end())
	{
		vecAcctType = it->second;
		return 0;
	}
	else
	{
		return -1;
	}
}

//��ȡ�ͻ������¼����
int CCustomerTbl::GetGradeIdRecord(const string &sGradeId, vector<CCustomer*> &vecGradeId)
{
	map<string, vector<CCustomer*> >::iterator it = m_vecGradeId.find(sGradeId);
	if (it != m_vecGradeId.end())
	{
		vecGradeId = it->second;
		return 0;
	}
	else
	{
		return -1;
	}
}

//���¿ͻ�������Ϣ
int CCustomerTbl::UpdateCustRisk(const string &sAcctNo, double dExchValue, double dCallValue, ArrayListMsg almRiskGrade)
{
	map<string, CCustomer*>::iterator it = m_mapCust.find(sAcctNo);
	if (it != m_mapCust.end())
	{
		it->second->UpdateRiskGrade(dExchValue, dCallValue, almRiskGrade);
		return 0;
	}
	else
	{
		return -1;
	}
}


//##ModelId=4916CAC200EA
int CCustomerTbl::Init(otl_connect& dbConnection, CAgentTbl& AgentTbl, CCustFeeDetailTbl& CustFeeTbl, CExchFeeDetailTbl &ExchFeeTbl, CFeeModelDetailTbl& ModelFeeTbl,CEtfFeeDetailTbl& EtfFeeTbl, CProdCodeTbl& ProdTbl, CBasicParaTbl &BasicParaTbl,
					   map<string, FUND>& mapFund, map<string, vector<CPosi*> >& mapDeferPosiToday, map<string, vector<CPosi*> >& mapDeferPosiHis, map<string,map<string,CCustSymbolDeferPosi > >& mapCustSymbolDeferPosi)
{
	char cAcctNo[128];					//�ͻ���
	char cTAccNo[128];					//�������ÿͻ���Ϣ
	char cCustAbbr[128];					//�ͻ����
	char cAcctType[128];					//�˻�����
	char cCustMobile[128];				//�ͻ��ֻ���
	char cBkAmountNo[128];				//�����˺�
	char cCustId[128];					//���ױ���
	char cBankId[128];					//����ID
	char cBankAcct[128];					//�����˺�
	char cBranchId[128];				//��������
	char cBFareModel[128];				//����������ģ��ID
	char cMFareModel[128];				//��Ա����ģ��ID
	char cProdCode[128];					//��Լ����
	char cCustType[128];					//�ͻ�����
	char cGradeId[128];					//�ͻ�����
	char cGradeName[128];
	short cRiskGrade = gc_cRiskGradeNormal;				//���ռ���
	short cRiskType = gc_cRiskTypeNormal;					//��������
	char cDir[2];						//��������
	unsigned int nNum = 0;					//����
	int nIndex = 0;						//��Լ������
	int nType = 0;						//��Լ����
	int nRiskDays = 0;                      //������������
	int iNotifyPeriod = 0;                 //���տͻ���ʱ֪ͨ������
	double dMeasureUnit = 0.0;			//��λ����
	double dMatchPrice = 0.0;			//�ɽ��۸� / ���ս����
	double dDebtLineMem = 1.0;			//׷����
	double dDebtLineEx = 1.5;			//ǿƽ��
	double dDebtLineCal = 1.0;			//׷����������

	double dTmpDebtLineMem =  0.00;
	double dTmpDebtLineEx = 0.5;
	double dTmpDebtLineCal =-0.90;

	double dCapital = 0.0;				//���ý��
	double dInCapital = 0.0;			//���
	double dOutCapital = 0.0;			//����
	double dMarginCall =0.0;            //׷�����
	int nRowNum = 0;					//��¼��
	short nGradeId=gc_cRiskGradeNormal;	//���ռ���
	char cLastAcctNo[16];
	char cLastBranchId[7];					
	char cLastAcctType[3];					//������¼���ʺ�
	char cExchDate[9];
	char cSysVal[10];	
	const string sAcctNo = "XXXXXXXX";
	const string sGradeId = "XXXXXX";
	const string sBranchId = "XXXXXX";
	const string sAcctType = "XX";
	string sSql = "";
	string sTempKey = "";
	CCustomer *pCustomer;

	memset(cAcctNo, 0, sizeof(cAcctNo));
	memset(cCustAbbr, 0, sizeof(cCustAbbr));
	memset(cCustType, 0, sizeof(cCustType));
	memset(cAcctType, 0, sizeof(cAcctType));
	memset(cCustId, 0, sizeof(cCustId));
	memset(cBankId, 0, sizeof(cBankId));
	memset(cBankAcct, 0, sizeof(cBankAcct));
	memset(cBFareModel, 0, sizeof(cBFareModel));
	memset(cMFareModel, 0, sizeof(cMFareModel));
	memset(cBranchId, 0, sizeof(cBranchId));
	memset(cProdCode, 0, sizeof(cProdCode));
	memset(cCustType, 0, sizeof(cCustType));
	memset(cLastAcctNo, 0, sizeof(cLastAcctNo));
	memset(cLastBranchId, 0, sizeof(cLastBranchId));
	memset(cLastAcctType, 0, sizeof(cLastAcctType));
	memset(cDir, 0, sizeof(cDir));
	memset(cGradeName, 0, sizeof(cGradeName));
	memset(cExchDate, 0, sizeof(cExchDate));
	memset(cGradeId, 0, sizeof(cGradeId));
	memset(cCustMobile, 0, sizeof(cCustMobile));

	//�ͻ���Ϣ��
	map<string, CUST_INFO> mapCustInfo;
	CUST_INFO stCustInfo;

	//������Ϣ��
	map<string, CUST_DEBT_LINE> mapCustDebtLine;
	CUST_DEBT_LINE stCustDebtLine;

	//���ռ����
	map<string, CUST_RISK_GRADE_VAL> mapRiskGradeCust;
	CUST_RISK_GRADE_VAL stCustRiskGradeVal;

	//�ͻ����չ�ϵ��
	map<string, CUST_RISK> mapCustRisk;
	CUST_RISK stCustRisk;

	//�ͻ��ȼ����ȼ����ƶ�Ӧ��
	map<string,string> mapCustGrade;
	//��Լ�����
	map<string, double> mapProdMarket;

	//���յȼ�����
	map<short, string> mapGradeCfg;
	try
	{
		//ȡ�ͻ���Ϣ������
		CRLog(E_DEBUG, "%s","loading cust info");

#ifdef _VER_25_DB2
		sSql = "select a.acct_no, a.cust_abbr, a.acct_type, a.branch_id, "
			"a.cust_id, a.m_fare_model_id, a.b_fare_model_id,a.grade_id,"
			"(case when b.mobile_phone is null then '' else b.mobile_phone end) as  mobile_phone "
			"(case when b.account_no is null then '' else b.account_no end) as  account_no "
			"(case when b.bank_no is null then '' else b.bank_no end) as  bank_no "
			"from cust_info a ,cust_append_info b  "
			" where a.acct_no = b.acct_no and a.acct_type!='1' and a.acct_stat <> '4' and  a.acct_stat <> '5' and a.acct_stat <> '6' and FG_SubStr(a.acct_no,1,2)<> '09'";
#else
		sSql = "select a.acct_no,nvl(a.cust_abbr,'') cust_abbr,nvl(a.acct_type,'') acct_type,nvl(a.branch_id,'') branch_id,"
			"a.cust_id ,nvl(a.m_fare_model_id,'') m_fare_model_id,nvl(a.b_fare_model_id,'') b_fare_model_id,nvl(a.grade_id,'') grade_id,"
			"nvl(b.mobile_phone,'') as mobile_phone,nvl(account_no,'') account_no,nvl(bank_no,'') bank_no"
			" from cust_info a ,cust_append_info b  "
			" where  a.acct_no = b.acct_no"
        #ifndef _VER_25_PSBC   // �����ʴ��������汾����Ҫ������Ӫ�ͻ�
			" and a.acct_type!='1'" 
        #endif
			"and substr( a.acct_no,0,2)<> '09' and a.acct_stat not in('4','5','6')";
#endif

		otl_stream oCustInfo(50, sSql.c_str(), dbConnection);
		while (!oCustInfo.eof())
		{
			oCustInfo >> cAcctNo >> cCustAbbr >> cAcctType >> cBranchId >> cCustId >> cMFareModel >> cBFareModel >>cGradeId >> cCustMobile >> cBkAmountNo >> cBankId;
			
			stCustInfo.sAcctNo = cAcctNo;
			stCustInfo.sCustAbbr = cCustAbbr;
			stCustInfo.sCustMobile = cCustMobile;
			stCustInfo.sAcctType = cAcctType;
			stCustInfo.sBranchId = cBranchId;
			stCustInfo.sCustId = cCustId;
			stCustInfo.sMFareModel = cMFareModel;
			stCustInfo.sBFareModel = cBFareModel;
			stCustInfo.sBankId = cBankId;   //����ID
			stCustInfo.sBankAcct = cBkAmountNo;    //�����˺�
			stCustInfo.sGradeId=cGradeId;
			stCustInfo.usRiskGrade = gc_cRiskGradeNormal;
			stCustInfo.usRiskType = gc_cRiskTypeNormal;
			stCustInfo.dlMarginCall=0.0;
			stCustInfo.nRiskDays=0;
			mapCustInfo[stCustInfo.sAcctNo] = stCustInfo;
		}
		CRLog(E_DEBUG, "�ͻ���Ϣ:%d ",mapCustInfo.size());

		//ȡ������Ϣ����
		sSql = "select acct_type,acct_grade_id, branch_id, acct_no, 0, debt_exch_value, debt_call_value from cust_debt_line";
		otl_stream oCustDebtLine(1, sSql.c_str(), dbConnection);
		while (!oCustDebtLine.eof())
		{
			oCustDebtLine >> cAcctType >> cGradeId >> cBranchId >> cAcctNo >> stCustDebtLine.dDebtLineMem >> stCustDebtLine.dDebtLineEx >> stCustDebtLine.dDebtLineCal;

			sTempKey = cAcctNo;
			sTempKey += cGradeId;
			sTempKey += cBranchId;
			sTempKey += cAcctType;

			mapCustDebtLine[sTempKey] = stCustDebtLine;
		}
		CRLog(E_DEBUG, "ȡ������Ϣ����:%d ",mapCustDebtLine.size());

		//ȡ���յȼ�����
		sSql = "select acct_type, acct_grade_id, branch_id, acct_no, grade_id, grade_vale_down, grade_vale_up from (select * from risk_grade_cust order by acct_type, branch_id, acct_no,grade_id)";
		otl_stream oRiskGrade(1, sSql.c_str(), dbConnection);
		nRowNum = 0;
		while (!oRiskGrade.eof())
		{
			oRiskGrade >> cAcctType >> cGradeId >> cBranchId >> cAcctNo >> nGradeId >> stCustRiskGradeVal.dGradeValueDown >> stCustRiskGradeVal.dGradeValueUp;
			
			sTempKey = cAcctNo;
			sTempKey += cGradeId;
			sTempKey += cBranchId;
			sTempKey += cAcctType;
			sTempKey += ToString(nGradeId);
			mapRiskGradeCust[sTempKey] = stCustRiskGradeVal;
		}
		CRLog(E_DEBUG, "ȡ�ͻ����յȼ�����:%d ",mapRiskGradeCust.size());

		sSql = "select grade_id, grade_name from risk_grade order by grade_id";
		otl_stream oRiskGradeCfg(1,sSql.c_str(), dbConnection);
		short usGradeID;

		while (!oRiskGradeCfg.eof())
		{
			oRiskGradeCfg >> usGradeID >> cGradeName;
			mapGradeCfg[usGradeID] = cGradeName;
		}

		//ȡ�ͻ����չ�ϵ
		CRLog(E_DEBUG, "ȡ���յȼ�:%d ",mapGradeCfg.size());

#ifdef _VER_25_DB2
		sSql = "select z.acct_no,"
			"(select FG_CovNull(y.acct_grade_id,'') from cust_debt_line y WHERE ACCT_GRADE_ID = Z.grade_id) grade_id,"
			"FG_CovNull((select parent_branch_id from v_rte_branch_info x LEFT JOIN cust_debt_line y ON x.branch_id = y.branch_id where y.branch_id IS NOT NULL and  x.branch_id=z.branch_id ),'') branch_id,"
			"FG_CovNull((SELECT acct_no FROM CUST_DEBT_LINE WHERE acct_no = z.acct_no),'') tacct_no,"
			"FG_CovNull((SELECT acct_type FROM cust_debt_line WHERE acct_type = z.acct_type),'') acct_type "
			"FROM cust_info z order by z.acct_no";
#else
		sSql = "SELECT z.acct_no,"
			"(select nvl(y.acct_grade_id,'') from CUST_DEBT_LINE y WHERE ACCT_GRADE_ID = Z.grade_id) grade_id,"
			"(SELECT nvl(y.branch_id,'') FROM V_RTE_BRANCH_INFO x LEFT JOIN cust_debt_line y ON x.branch_id = y.branch_id "
			" WHERE y.branch_id IS NOT NULL AND ROWNUM = 1 AND X.parent_branch_id =Z.BRANCH_ID) branch_id"
			",(SELECT nvl(acct_no,'') FROM CUST_DEBT_LINE WHERE acct_no = z.acct_no) acct_no "
			",(SELECT acct_type FROM cust_debt_line WHERE acct_type = z.acct_type) acct_type "
			" FROM CUST_INFO Z";
#endif

		

		otl_stream oCustRisk(2000, sSql.c_str(), dbConnection);
		while (!oCustRisk.eof())
		{
			memset(cLastAcctNo, 0,sizeof(cLastAcctNo));
			memset(cTAccNo, 0,sizeof(cTAccNo));
			memset(cGradeId, 0, sizeof(cGradeId));
			memset(cBranchId, 0, sizeof(cBranchId));
			memset(cAcctType, 0, sizeof(cAcctType));

			oCustRisk >> cLastAcctNo >> cGradeId >> cBranchId >> cTAccNo >> cAcctType;

			stCustRisk.sAcctNo = cTAccNo;
			stCustRisk.sGradeId = cGradeId;  //�ͻ��ȼ�
			stCustRisk.sAcctType = cAcctType;
			stCustRisk.sBranchId = cBranchId;
			mapCustRisk[cLastAcctNo] = stCustRisk;
		}

		CRLog(E_DEBUG, "ȡ�ͻ����չ�ϵ:%d ",mapCustRisk.size());

		//���շ���
		//ȡ��һ������
		CRLog(E_DEBUG, "cust_debt_line %d",mapCustRisk.size());
		sSql = "select exch_date from system_stat where exch_date < :f1<char[9]> order by exch_date desc";
		otl_stream oExDate(1, sSql.c_str(), dbConnection);
		oExDate << BasicParaTbl.GetExchDate().c_str();
		if (!oExDate.eof())
		{
			oExDate >> cExchDate;
		}
		CRLog(E_DEBUG, "%s","loading cust ss End_day_risk_detail");

		sSql = "select acct_no, grade_id, risk_type,MARGIN_CALL ,RISK_DAYS from End_day_risk_detail where exch_date = :f1<char[9]> ";
		otl_stream oEndRisk(1, sSql.c_str(), dbConnection);
		oEndRisk << cExchDate;
		while (!oEndRisk.eof())
		{
			oEndRisk >> cAcctNo >> cRiskGrade >> cRiskType>>dMarginCall>>nRiskDays;
			map<string, CUST_INFO>::iterator it = mapCustInfo.find(cAcctNo);
			if (it != mapCustInfo.end())
			{
				(*it).second.usRiskGrade = cRiskGrade;
				(*it).second.usRiskType = cRiskType;
				(*it).second.dlMarginCall=dMarginCall;
				(*it).second.nRiskDays=nRiskDays;
			}
		}

		//�����ݿ��ȡ���Ᵽ֤����ʿͻ�   add by zengweiwei 2013-11-18
		memset(cAcctNo, 0x00, sizeof(cAcctNo));
		vector<string> vecSpeCustList;
		sSql="select distinct(acct_no) from acct_fare_detail where fare_type_id in('"+gc_sTranMargin +"','"+gc_sTranMarginShort+"')";
		otl_stream oSpeCust(1,sSql.c_str(),dbConnection);
		while (!oSpeCust.eof())
		{
			oSpeCust>>cAcctNo;
			vecSpeCustList.push_back(cAcctNo);
		}

		//����Ĭ�Ϸ��յȼ�����
		sTempKey = sAcctNo + sGradeId + sBranchId + sAcctType;
		map<string, CUST_DEBT_LINE>::iterator itDebtLine = mapCustDebtLine.find(sTempKey);
		if ( itDebtLine != mapCustDebtLine.end())
		{
			dTmpDebtLineMem = itDebtLine->second.dDebtLineMem;
			dTmpDebtLineEx = itDebtLine->second.dDebtLineEx;
			dTmpDebtLineCal = itDebtLine->second.dDebtLineCal;
		}
			
		sSql = "select grade_id,grade_name from grade_info";
		otl_stream oGradeInfo(1,sSql.c_str(),dbConnection);
		while(!oGradeInfo.eof())
		{
			memset(cGradeId, 0, sizeof(cGradeId));
			memset(cGradeName, 0, sizeof(cGradeName));
			oGradeInfo >> cGradeId >> cGradeName;
			mapCustGrade[cGradeId] = cGradeName;
		}
		CRLog(E_DEBUG, "ȡ�ͻ��ȼ�������ӳ��:%d ",mapCustGrade.size());
		sSql = "select para_value from system_para where para_id = '" + RiskConst::gc_sRiskNotifyPeriod + "'";
		otl_stream oNotifyPeriod(1,sSql.c_str(),dbConnection);
		if (!oNotifyPeriod.eof())
		{
			memset(cSysVal,0x00,sizeof(cSysVal));
			oNotifyPeriod >> cSysVal;
			iNotifyPeriod = atoi(cSysVal);
		}
		else 
			iNotifyPeriod = CGlobal::Instance()->GetNotifyPeriod();

		//����ʽ��
		map<string,OffsetFund> mapOffsetFund;
		OffsetFund stOffsetFund;
		//ȡ�ͻ�����ʽ�� 
		sSql = "select acct_no," 
			"last_offset_quota,"
			"today_offset_quota,"
			"last_avaliable_offset_quota,"
			"today_avaliable_offset_quota,"
			"b_today_used_offset_quota ,"
			"m_today_used_offset_quota ,"
			"b_last_used_offset_quota,"
			"m_last_used_offset_quota,"
			"entr_margin "
			"from offset_fund";

		memset(cAcctNo, 0x00, sizeof(cAcctNo));
		otl_stream oOffset(1,sSql.c_str(),dbConnection);
		while(!oOffset.eof())
		{
			oOffset >> cAcctNo >> stOffsetFund.dlOffsetTotalLast >> stOffsetFund.dlOffsetTotal >> stOffsetFund.dlOffsetCanUseLast >>
				stOffsetFund.dlOffsetCanUse >> stOffsetFund.dlOffsetMarginExch >> stOffsetFund.dlOffsetMarginMem >> 
				stOffsetFund.dlOffsetMarginExchLast >> stOffsetFund.dlOffsetMarginMemLast >> stOffsetFund.dlOffsetFrozen;

			mapOffsetFund[cAcctNo] = stOffsetFund;
		}
		CRLog(E_DEBUG, "��ʼ���ͻ�����ʽ��:%d ",mapOffsetFund.size());

		//��ʼ���ͻ�
		CRLog(E_DEBUG, "%s","loading cust mem");
		map<string, CUST_INFO>::iterator itCust = mapCustInfo.begin();

		for (; itCust != mapCustInfo.end(); ++itCust)
		{		
			sTempKey = "";
			try
			{
				//ȡ�ͻ����չ�ϵ
				map<string, CUST_RISK>::iterator itCustRisk = mapCustRisk.find(itCust->second.sAcctNo);
				if (itCustRisk != mapCustRisk.end())
				{
					if (itCustRisk->second.sAcctNo != "")
					{
						sTempKey = itCustRisk->second.sAcctNo + sGradeId + sBranchId + sAcctType;
					}
					else if (itCustRisk->second.sGradeId != "")
					{
						sTempKey = sAcctNo + itCustRisk->second.sGradeId + sBranchId + sAcctType;
					}
					else if (itCustRisk->second.sBranchId != "")
					{
						sTempKey = sAcctNo + sGradeId + itCustRisk->second.sBranchId + sAcctType;
					}
					else if (itCustRisk->second.sAcctType != "")
					{
						sTempKey = sAcctNo + sGradeId + sBranchId + itCustRisk->second.sAcctType;
					}
					else
					{
						sTempKey = sAcctNo + sGradeId + sBranchId + sAcctType;
					}				
				}

				//ȡ������Ϣ
				itDebtLine = mapCustDebtLine.find(sTempKey);
				if ( itDebtLine != mapCustDebtLine.end())
				{
					dDebtLineMem = itDebtLine->second.dDebtLineMem;
					dDebtLineEx = itDebtLine->second.dDebtLineEx;
					dDebtLineCal = itDebtLine->second.dDebtLineCal;
				}
				else
				{
					dDebtLineMem = dTmpDebtLineMem;
					dDebtLineEx = dTmpDebtLineEx;
					dDebtLineCal = dTmpDebtLineCal;
				}

		
				//CRLog(E_DEBUG,"AcctNo=%s,key=%s,dDebtLineMem=%lf,dDebtLineEx=%lf,dDebtLineCal=%lf",
				//		itCust->second.sAcctNo.c_str(),sTempKey.c_str(),dDebtLineMem,dDebtLineEx,dDebtLineCal); 

				CAgent* pAgent =AgentTbl.GetAgent(itCust->second.sBranchId);
				if(0 == pAgent)
				{
					CRLog(E_DEBUG,"AcctNo=%s,key=%s,dDebtLineMem=%lf,dDebtLineEx=%lf,dDebtLineCal=%lf",
						itCust->second.sAcctNo.c_str(),sTempKey.c_str(),dDebtLineMem,dDebtLineEx,dDebtLineCal); 
					CRLog(E_ERROR,"�ͻ���������[%s]�Ҳ���!",itCust->second.sBranchId.c_str());
					return -1;	
				}
			
				//����customer
				pCustomer = new CCustomer(itCust->second.sAcctNo,
											itCust->second.sCustAbbr,
											itCust->second.sAcctType,
											itCust->second.sCustId,
											itCust->second.sBankId,
											itCust->second.sBankAcct,
											dDebtLineMem,
											dDebtLineEx,
											dDebtLineCal,
											itCust->second.sBFareModel,
											itCust->second.sMFareModel,
											pAgent,
											CustFeeTbl,
											ExchFeeTbl,
											ModelFeeTbl,
											EtfFeeTbl,
											ProdTbl,
											itCust->second.sCustMobile,
											iNotifyPeriod);
				if (0 == pCustomer)
				{
					CRLog(E_DEBUG,"�ͻ�[%s]���󴴽�ʧ��!",itCust->second.sAcctNo.c_str());
					return -1;	
					//break;
				}
				//���ն�1���㹫ʽ
				CRiskAlgorithm* pRiskAlgorithm = new CRiskAlgorithmDef();
				pCustomer->BindRiskAlgorithm(pRiskAlgorithm);

				//���ն�2���㹫ʽ
				CRiskAlgorithm* pRiskAlgorithm2 = new CRiskAlgorithm2();
				pCustomer->BindRiskAlgorithm2(pRiskAlgorithm2);

				//׷���㷨���㹫ʽ
				CDebtAlgorithm* pDebtAlgorithm = new CDebtAlgorithmDef();
				pCustomer->BindDebtAlgorithm(pDebtAlgorithm);

				//׷���㷨���㹫ʽ2
				CDebtAlgorithm* pDebtAlgorithm2 = new CDebtAlgorithm2();
				pCustomer->BindDebtAlgorithm2(pDebtAlgorithm2);
				
				//z���ÿͻ�����
				pCustomer->SetGradeId(itCust->second.sGradeId);
				//���ÿͻ��������� add 20140925
				map<string,string>::iterator itGradeMap;
				itGradeMap = mapCustGrade.find(itCust->second.sGradeId);
				if(itGradeMap != mapCustGrade.end())
				{
					pCustomer->SetGradeName(itGradeMap->second);
				}
				else
					CRLog(E_ERROR,"�ͻ�����[%s]�Ҳ�����Ӧ�Ŀͻ���������",itCust->second.sGradeId.c_str());
				//������������
				pCustomer->SetRiskDays(itCust->second.nRiskDays);

				//��ʼ������ʽ�
				map<string,OffsetFund>::iterator itOffset = mapOffsetFund.find(itCust->second.sAcctNo);
				if(itOffset != mapOffsetFund.end())
				{
					pCustomer->InitOffsetFund(itOffset->second);
				}

				//���ÿͻ����ռ���
				map<string, CUST_RISK_GRADE_VAL>::iterator itRiskGrade;
				map<short, string>::iterator itGradeCfg;
				for (itGradeCfg = mapGradeCfg.begin(); itGradeCfg != mapGradeCfg.end(); ++itGradeCfg)
				{
					bool blFind = true;
					itRiskGrade = mapRiskGradeCust.find(sTempKey + ToString((*itGradeCfg).first));
					if (itRiskGrade != mapRiskGradeCust.end())
					{
						stCustRiskGradeVal.dGradeValueDown = (*itRiskGrade).second.dGradeValueDown;
						stCustRiskGradeVal.dGradeValueUp = (*itRiskGrade).second.dGradeValueUp;
					}
					else
					{
						blFind = false;					 
					}

					if (blFind)
					{
						CRiskGrade oRiskGrade( (*itGradeCfg).first, (*itGradeCfg).second,stCustRiskGradeVal.dGradeValueDown,stCustRiskGradeVal.dGradeValueUp,(*itGradeCfg).first/10);
						pCustomer->AddRiskGrade(oRiskGrade);
					}
				}

				//��ʼ���ʽ�
				map<string, FUND>::iterator itFund = mapFund.find(itCust->second.sAcctNo);
				if (itFund != mapFund.end())
				{
					pCustomer->InitCurr(itFund->second);
					pCustomer->Init(itFund->second.dCapital, fabs(itFund->second.dInCapital), fabs(itFund->second.dOutCapital), (*itCust).second.usRiskGrade, (*itCust).second.usRiskType,(*itCust).second.dlMarginCall);
					pCustomer->InitAgentMargin(abs(itFund->second.dlMarginMemLastDay), abs(itFund->second.dlMarginExchLastDay));
				}

				//��ʼ�����ճֲ�
				map<string, vector<CPosi*> >::iterator itPosiToday = mapDeferPosiToday.find(itCust->second.sAcctNo);
				if (itPosiToday != mapDeferPosiToday.end())
				{
					vector<CPosi*>::iterator itVecTdy;
					for (itVecTdy = (*itPosiToday).second.begin(); itVecTdy != (*itPosiToday).second.end(); ++itVecTdy)
					{
						pCustomer->AddPosiToday(*itVecTdy);
					}
				}

				//��ʼ����ʷ�ֲ�
				map<string, vector<CPosi*> >::iterator itPosiHis = mapDeferPosiHis.find(itCust->second.sAcctNo);
				if (itPosiHis != mapDeferPosiHis.end())
				{
					vector<CPosi*>::iterator itVecHis;
					for (itVecHis = (*itPosiHis).second.begin(); itVecHis != (*itPosiHis).second.end(); ++itVecHis)
					{
						pCustomer->AddPosiHis(*itVecHis);
					}
				}

				//��customer����customertbl
				m_mapCust[itCust->second.sAcctNo] = pCustomer;
				m_vecCust.push_back(pCustomer);

				//��customer��������������
				CAgent* pTmpAgent = AgentTbl.GetAgent(itCust->second.sBranchId);
				if (0 != pTmpAgent)
				{
					pTmpAgent->AddCustomer(itCust->second.sAcctNo, pCustomer);
				}
				//�����Ƿ�������ͻ� add by zengweiwei 2013-11-18
				vector<string>::iterator speCustIt;
				speCustIt=vecSpeCustList.begin();
				for (;speCustIt<vecSpeCustList.end();speCustIt++)
				{
					if (*speCustIt==pCustomer->CustAcctNo())
					{
						pCustomer->SetIsSpeCust(1);
						break;
					}
				}

			}
			catch (std::exception e)
			{
				CRLog(E_ERROR, "Init Cust_No = [%s] exception:%s",itCust->second.sAcctNo.c_str(),e.what()); 
				continue;
			}
			catch(...)
			{
				CRLog(E_CRITICAL," Init Cust_No = [%s] Unknown exception",itCust->second.sAcctNo.c_str());
				continue;
			}
		}

	/*
		//��ʼ���ͻ������Ӧ�Ŀͻ�����
		string sOldCustType;
		string sNewCustType;
		vector<CCustomer*> vecCustTypeAcct;

		int nRowNum = 0;
		sSql = "select cust_type_id, acct_no from cust_type_info_detail order by cust_type_id";
		otl_stream oCustType(1, sSql.c_str(), dbConnection);
		while (!oCustType.eof())
		{
			oCustType >> cCustType >> cAcctNo;
			sNewCustType = cCustType;
			if (nRowNum == 0)
			{
				nRowNum++;
				sOldCustType = cCustType;
			}
			if (sNewCustType != sOldCustType)
			{
				if (vecCustTypeAcct.size() > 0)
				{
				m_vecCustType[sNewCustType] = vecCustTypeAcct;
				}
				vecCustTypeAcct.clear();
			}

			//���ҿͻ���Ӧ��¼
			map<string,CCustomer*>::iterator it = m_mapCust.find(cAcctNo);
			if (it != m_mapCust.end())
			{
				vecCustTypeAcct.push_back(it->second);
			}
		}
		if (0 < vecCustTypeAcct.size())
		{
			m_vecCustType[sNewCustType] = vecCustTypeAcct;
		}
		*/

		//��ʼ���˻����Ͷ�Ӧ�Ŀͻ�����
		string sNewAcctType;
		string sOldAcctType;
		vector<CCustomer*> vecAcctTypeAcct;

		nRowNum = 0;
		sSql = "select acct_type, acct_no from cust_info order by acct_type,acct_no";
		otl_stream oAcctType(1, sSql.c_str(), dbConnection);

		while (!oAcctType.eof())
		{
			oAcctType >> cAcctType >> cAcctNo;
			sNewAcctType = cAcctType;
			if (nRowNum == 0)
			{
				nRowNum++;
				sOldAcctType = cAcctType;
			}
			if (sOldAcctType != sNewAcctType)
			{
				if (vecAcctTypeAcct.size() > 0)
				{
					m_vecAcctType[sOldAcctType] = vecAcctTypeAcct;
				}
				vecAcctTypeAcct.clear();
				sOldAcctType = cAcctType;
			}
			//���ҿͻ���Ӧ��¼
			map<string, CCustomer*>::iterator it = m_mapCust.find(cAcctNo);
			if (it != m_mapCust.end())
			{
				vecAcctTypeAcct.push_back(it->second);
			}
		}
		if (vecAcctTypeAcct.size() > 0)
		{
			m_vecAcctType[cAcctType] = vecAcctTypeAcct;
		}
		CRLog(E_DEBUG, "ȡ�ͻ����͹�ϵ:%d ",m_vecAcctType.size());

		//��ʼ�ͻ������Ӧ�Ŀͻ�����
		string sNewGradeId;
		string sOldGradeId;
		vector<CCustomer*> vecGradeIdAcct;

		nRowNum = 0;
		sSql = "select grade_id, acct_no from cust_info order by acct_type";
		otl_stream oGradeId(1, sSql.c_str(), dbConnection);

		while (!oGradeId.eof())
		{
			oGradeId >> cGradeId >> cAcctNo;
			sNewGradeId = cGradeId;
			if (nRowNum == 0)
			{
				nRowNum++;
				sOldGradeId = cGradeId;
			}
			if (sOldGradeId != sNewGradeId)
			{
				if (vecGradeIdAcct.size() > 0)
				{
					m_vecGradeId[sOldGradeId] = vecGradeIdAcct;
				}
				vecGradeIdAcct.clear();
				sOldGradeId = cGradeId;
			}
			//���ҿͻ���Ӧ��¼
			map<string, CCustomer*>::iterator it = m_mapCust.find(cAcctNo);
			if (it != m_mapCust.end())
			{
				vecGradeIdAcct.push_back(it->second);
			}
		}
		if (vecGradeIdAcct.size() > 0)
		{
			m_vecGradeId[cGradeId] = vecGradeIdAcct;
		}
		CRLog(E_DEBUG, "�ͻ������Ӧ�Ŀͻ�����:%d ",m_vecGradeId.size());

		mapGradeCfg.clear();
		mapRiskGradeCust.clear();
		mapCustDebtLine.clear();
		mapCustInfo.clear();
		mapProdMarket.clear();
		mapCustGrade.clear();

		vecAcctTypeAcct.clear();
		vecGradeIdAcct.clear();

		return 0;
	}
	catch(otl_exception &p)
	{
		CRLog(E_ERROR, "otl exception:%s,%s,%s,%s", p.msg, p.stm_text, p.sqlstate, p.var_info);
		return -1;
	}
	catch(std::exception e)
	{
		CRLog(E_ERROR,"exception:%s", e.what());
		return -1;
	}
	catch(...)
	{
		CRLog(E_ERROR,"%s","Unknown exception");
		return -1;
	}
	return 0;
}


int CCustomerTbl::SimInit(int nSimNum, CAgentTbl& AgentTbl, CCustFeeDetailTbl& CustFeeTbl, CExchFeeDetailTbl &ExchFeeTbl, CFeeModelDetailTbl& ModelFeeTbl,CEtfFeeDetailTbl& EtfFeeTbl, CProdCodeTbl& ProdTbl, CBasicParaTbl &BasicParaTbl)
{
	//////////////
	//ȡ�ͻ���Ϣ
	try
	{
	srand(static_cast<unsigned int>(time(0)));

	clock_t ctStart = clock();
	for (int i =0; i < nSimNum; i++)
	{
		string sNo("");
		stringstream ss;
		ss << 8888 << setw(6) << setfill('0') << i;
		string cAcctNo = ss.str();
		string cCustAbbr = cAcctNo;
		string cCustId = cAcctNo;
		string cAcctType = "1";
        string sCustMobile="";
		string cBranchId;
		if (i % 2 == 0)
			cBranchId = "B00000";	
		else
			cBranchId = "B00000";//"B01002";
		
		string cMFareModel = "F50001";
		string cBFareModel = "F00001";
		string cBankId = "11";
		string cBankAcct = "22"; 
		
		string cCustType = "1";

		double dDebtLineMem = 1.00;
		double dDebtLineEx = 1.25;
		double dDebtLineCal = 0.95;
		int iNotifyPro = 60;

		CAgent* pAgent =AgentTbl.GetAgent(cBranchId);
		if(0 == pAgent)
		{
			CRLog(E_ERROR,"�ͻ���������[%s]�Ҳ���!",cBranchId.c_str());
			return -1;	
		}

		//����customer
		CCustomer* pCustomer = new CCustomer(cAcctNo,
									cCustAbbr,
									cAcctType,
									cCustId,
									cBankId,
									cBankAcct,
									dDebtLineMem,
									dDebtLineEx,
									dDebtLineCal,
									cBFareModel,
									cMFareModel,
									pAgent,
									CustFeeTbl,
									ExchFeeTbl,
									ModelFeeTbl,
									EtfFeeTbl,
									ProdTbl,
									sCustMobile,
									iNotifyPro);	

		if (0 == pCustomer)
		{
			//CRLog
			break;
		}

			//���ն�1���㹫ʽ
			CRiskAlgorithm* pRiskAlgorithm = new CRiskAlgorithmDef();
			pCustomer->BindRiskAlgorithm(pRiskAlgorithm);

			//���ն�2���㹫ʽ
			CRiskAlgorithm* pRiskAlgorithm2 = new CRiskAlgorithm2();
			pCustomer->BindRiskAlgorithm2(pRiskAlgorithm2);

			//׷���㷨���㹫ʽ
			CDebtAlgorithm* pDebtAlgorithm = new CDebtAlgorithmDef();
			pCustomer->BindDebtAlgorithm(pDebtAlgorithm);
			//׷���㷨���㹫ʽ2
			CDebtAlgorithm* pDebtAlgorithm2 = new CDebtAlgorithm2();
			pCustomer->BindDebtAlgorithm2(pDebtAlgorithm2);

		//���ÿͻ����ռ���
		short nGradeId = 0;			//���ռ���
		double dGradeValueDown = 0.0;		//����ֵ
		double dGradeValueUp = 0.0;			//����ֵ
		string sName = "name";

		
		dGradeValueDown = 0.0;
		dGradeValueUp = 1.00;
		pCustomer->AddRiskGrade(CRiskGrade(static_cast<unsigned short>(11), sName, dGradeValueDown, dGradeValueUp,1));

		dGradeValueDown = 1.00;
		dGradeValueUp = 1.25;
		pCustomer->AddRiskGrade(CRiskGrade(static_cast<unsigned short>(21), sName, dGradeValueDown, dGradeValueUp,2));

		dGradeValueDown = 1.25;
		dGradeValueUp = 101.00;
		pCustomer->AddRiskGrade(CRiskGrade(static_cast<unsigned short>(31), sName, dGradeValueDown, dGradeValueUp,3));
			

		int RANGE_MIN = 2000;
		int RANGE_MAX = 20000;
		double dCapital = static_cast<double>(rand()) / static_cast<double>(RAND_MAX) * (RANGE_MAX - RANGE_MIN) + RANGE_MIN;

		double dInCapital = 0.00;
		double dOutCapital = 0.00;
		unsigned char cRiskType = 1;
		unsigned char cRiskGrade = 1;
			double dlMarginCall=0.0;
			pCustomer->Init(dCapital, dInCapital, dOutCapital, cRiskGrade, cRiskType,dlMarginCall);

		map<string,PROD_CODE> mapProd;
		map<string,PROD_CODE>::iterator it;
		ProdTbl.GetRecordSet(mapProd);
		int n = 0;			
		unsigned char cDir = 1;
		double dMatchPrice = 0.0;
		int nNum = 1;
		for (it = mapProd.begin(); it != mapProd.end(); ++it)
		{
			if ((*it).second.nIndex > 3)
				continue;

			RANGE_MIN = 1;
			RANGE_MAX = 10;
			int nKey = static_cast<int>(static_cast<double>(rand()) / static_cast<double>(RAND_MAX) * (RANGE_MAX - RANGE_MIN) + RANGE_MIN);
	
			RANGE_MIN = 225;//180;
			RANGE_MAX = 225;
			dMatchPrice = static_cast<double>(rand()) / static_cast<double>(RAND_MAX) * (RANGE_MAX - RANGE_MIN) + RANGE_MIN;
			
			if (nKey % 2 == 0)
			{
				cDir = gc_cLong;
			}
			else
			{
				cDir = gc_cShort;
			}

			nNum = nKey;
			
			pCustomer->AddPosiToday(new CPosiToday((*it).second.sProdCode, (*it).second.nVarietyType,cDir, nNum, (*it).second.dlMeasureUnit, dMatchPrice, (*it).second.nIndex));


			//pCustomer->AddPosiHis(new CPosiHis((*it).second.sProdCode,(*it).second.nVarietyType, cDir, nNum, (*it).second.dlMeasureUnit, dMatchPrice, (*it).second.nIndex));


		}
		

		//��customer����customertbl
		m_mapCust[cAcctNo] = pCustomer;
		m_vecCust.push_back(pCustomer);

		//��customer��������������
		AgentTbl.GetAgent(cBranchId)->AddCustomer(cAcctNo, pCustomer);
	}

	clock_t ctEnd = clock();
	clock_t ctDiff = (ctEnd - ctStart) * 1000 / CLOCKS_PER_SEC;
	cout << "sim spend " << ctDiff << endl;

	return 0;
	}
	catch(...)
	{
		return 0;
	}
	
}

//��������
void CCustomerTbl::Finish()
{	
	try
	{		
		vector<CPosi*>::iterator itVec;
		map<string,CCustomer*> ::iterator it = m_mapCust.begin();
		for ( ; it != m_mapCust.end(); ++it)
		{
			delete it->second;
		}
		m_mapCust.clear();  
		
		m_vecAcctType.clear();
		m_vecCust.clear();
		m_vecGradeId.clear();
	/*	
		map<string, vector<CCustomer*> >::iterator itMap=m_vecAcctType.begin();
		for ( ; itMap != m_vecAcctType.end(); ++itMap)
		{

			itVec= (itMap->second).begin();
			for(;itVec!=(itMap->second).end();++itVec)
			{
				delete (*itVec);
			}

			(itMap->second).clear();
		}
		m_vecAcctType.clear();

		itMap=m_vecGradeId.begin();
		for ( ; itMap != m_vecGradeId.end(); ++itMap)
		{

			itVec= (itMap->second).begin();
			for(;itVec!=(itMap->second).end();++itVec)
			{
				delete (*itVec);
			}

			(itMap->second).clear();

		}
		m_vecGradeId.clear();

		itVec= m_vecCust.begin();
		for(;itVec!=m_vecCust.end();++itVec)
		{
			delete (*itVec);
		}
		m_vecCust.clear();
	*/
	}
	catch (std::exception e)
	{
		/*m_vecAcctType.clear();
		m_vecCust.clear();
		m_vecGradeId.clear();*/
		CRLog(E_CRITICAL,"CCustomerTbl.Finish() exception:%s", e.what());
		return ;
	}
}
