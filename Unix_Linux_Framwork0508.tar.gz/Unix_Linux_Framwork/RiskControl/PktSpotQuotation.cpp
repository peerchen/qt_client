#include "RiskHandler.h"

// A1 �ӿ� [onRecvSpotQuotation]SpotQuotation ��ҵ��ʵ��
int CRiskHandler::OnSpotQuotation(CBroadcastPacket& pkt)
{
	SpotQuotation stBody;
	CPacketStructBroadcastRisk::Packet2Struct(stBody, pkt);

	//ҵ��ʵ��......
	SendAck(pkt);

	return 0;
};
