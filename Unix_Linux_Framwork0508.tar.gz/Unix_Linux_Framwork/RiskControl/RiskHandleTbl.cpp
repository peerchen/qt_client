#include "RiskHandleTbl.h"

CRiskHandleTbl::CRiskHandleTbl()
{

}

CRiskHandleTbl::~CRiskHandleTbl()
{
	Finish();
}

//##ModelId=491AF50A02AF
int CRiskHandleTbl::GetHandle(unsigned short usHandleID, RISK_HANDLE_DEFINE& stRiskHandle)
{
	for(vector<RISK_HANDLE_DEFINE>::iterator iter = m_vecRiskHandleDef.begin(); iter != m_vecRiskHandleDef.end(); ++iter){
		if((iter->usHandleID)==usHandleID){
			stRiskHandle = *iter;
			return 0;
		}
	}
	return -1;
}

//##ModelId=491B042E035B
int CRiskHandleTbl::Init(otl_connect& dbConnection)
{
	return 0;
}

//��������
void CRiskHandleTbl::Finish()
{
	m_vecRiskHandleDef.clear();
}

