// ArbMain.cpp: implementation of the CArbMain class.
//
//////////////////////////////////////////////////////////////////////

#include "ArbMain.h"
#include "TradePacket.h"
#ifdef _VER_DREB
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CArbMain::CArbMain()
	:m_pRiskCpMgr(NULL)
	,m_ulKey(0)
{
	m_pLog = NULL;
	m_bIsInit = false;
}

CArbMain::~CArbMain()
{

}

bool CArbMain::Init(const char *confile)
{
	m_bIsInit = false;

	//���ó�ʼ
	if (!m_pRes.Init(confile))
	{
		printf("��ʼ������  %s\n",m_pRes.m_errMsg.c_str());
		return false;
	}

	//api��ʼ��
	if (!m_pDrebApi.Init(&m_pRes))
	{
		printf("�������߳�ʼ������! \n");
		return false;
	}

	m_pLog = m_pDrebApi.GetLogPoint();

	//��ʼ�߳�
	if (!m_pDrebMsgThread.Init(&m_pDrebApi,&m_pRes))
	{
		printf("��Ϣ�����̳߳�ʼ������! \n");
		return false;
	}

	m_bIsInit = true;

	return true;
}

int CArbMain::Init( CConfig* pConfig )
{
	return 0;
}

int CArbMain::Start()
{
	if (!m_bIsInit)
	{
		printf("CArbMainδ��ʼ�� \n");
		return false;
	}
	//����api�߳�
	m_pDrebApi.Start();

	//������Ϣ�����߳�
	m_pDrebMsgThread.SetOwner(this);
	m_pDrebMsgThread.Start();
	m_pLog->LogMp(LOG_INFO,__FILE__,__LINE__,"�����ٲû����!");
	return true;
}

void CArbMain::Stop()
{
	m_pDrebApi.Stop();
	m_pDrebMsgThread.SetOwner(NULL);
	m_pDrebMsgThread.Stop();
}

void CArbMain::Monitor()
{
	m_pDrebApi.MonitorThread();
	if (m_pDrebMsgThread.IsStoped())
	{
		m_pDrebMsgThread.SetOwner(this);
		m_pDrebMsgThread.Start();
	}
}

int CArbMain::OnRecvPacket( CPacket &GessPacket )
{
	if (m_pRiskCpMgr)
	{
		int nRet = m_pRiskCpMgr->Forward(GessPacket, m_ulKey);
		//CRLog(E_DEBUG, "Forward result %d", nRet);
	}
	return 0;
}

int CArbMain::SendPacket( CPacket &GessPacket )
{
	int nRet = m_pDrebMsgThread.SendPacket(GessPacket);
	return nRet;
	//CTradePacket& tradePkt = dynamic_cast<CTradePacket&>(GessPacket);
	//HEADER_RSP stHeaderRsp;
	//tradePkt.GetHeader(stHeaderRsp);
	//PBPCCOMMSTRU pMsg = GetReqMsg(stHeaderRsp.seq_no);
	//if (pMsg)//����rsp����
	//{
	//	S_BPC_RSMSG rcvdata;

	//	string sOrg = tradePkt.Print();
	//	pMsg->sDBHead.nLen = sOrg.length()-MSGLEN;
	//	memcpy(pMsg->sBuffer, sOrg.substr(MSGLEN).c_str(), pMsg->sDBHead.nLen);
	//	CRLog(E_PROINFO,"Send Rsp %s", pMsg->sBuffer);
	//	pMsg->sDBHead.a_Ainfo.a_nRetCode = SUCCESS;
	//	pMsg->sDBHead.cRaflag = 1;
	//	pMsg->sDBHead.cZip = 0;
	//	rcvdata.sMsgBuf = pMsg;
	//	m_pDrebApi.SendMsg(rcvdata);
	//	CRLog(E_PROINFO,"Send Rsp m_vReqMsg.size=%d", m_mapReqMsg.size());

	//} 
	//else//�������ͱ���
	//{
	//}
	//return 0;
}

void CArbMain::Bind( CConnectPointManager* pCpMgr,const unsigned long& ulKey )
{
	m_ulKey = ulKey; 
	m_pRiskCpMgr = pCpMgr;
}

void CArbMain::SetSvrTxList( vector<int> v )
{
	//v.push_back(3056);//����֪ͨ����ʱ����2016-03-31
	v.push_back(3061);
	v.push_back(3062);
	printf("ע�ύ�������%d \n", v.size());
	m_vTxList = v;
}

vector<int> CArbMain::GetSvrTxList()
{
	return m_vTxList;
}

void CArbMain::AddReqMsgStru( const string& sSeqNo, PBPCCOMMSTRU pMsg )
{
	if (sSeqNo.empty())
	{
		CRLog(E_ERROR, "AddReqMsgStru û��sSeqNo");
		return;
	}
	CBF_PMutex patuo(&m_bfMutex);
	m_mapReqMsg[sSeqNo] = pMsg;
}

PBPCCOMMSTRU CArbMain::GetReqMsg( const char* szSeqNo )
{
	CBF_PMutex patuo(&m_bfMutex);
	map<string, PBPCCOMMSTRU>::iterator it = m_mapReqMsg.find(szSeqNo);
	if (it != m_mapReqMsg.end())
	{
		return it->second;
	}
	else
		return NULL;
}
#endif