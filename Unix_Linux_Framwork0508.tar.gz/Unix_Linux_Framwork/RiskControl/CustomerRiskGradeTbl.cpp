#include "CustomerRiskGradeTbl.h"

CCustomerRiskGradeTbl::CCustomerRiskGradeTbl()
{

}

CCustomerRiskGradeTbl::~CCustomerRiskGradeTbl()
{
	Finish();
}

//##ModelId=491AF5CA003E
int CCustomerRiskGradeTbl::GetRiskGrade(const string& sCustID, const string& sAgentID, const string& sAcctType, unsigned short usGradeID, CRiskGrade& RiskGrade)
{
	return 0;
}

//##ModelId=491AFB6A032C
int CCustomerRiskGradeTbl::AddCustomerGrade(const string& sCustID,const string& sAgentID, const string& sAcctType,unsigned short usGradeID, double dlGradeValueDown,double dlGradeValueUp)
{
	return 0;
}

//##ModelId=491AFC15003E
int CCustomerRiskGradeTbl::UpdateCustomerGrade(const string& sCustID,const string& sAgentID, const string& sAcctType,unsigned short usGradeID, double dlGradeValueDown,double dlGradeValueUp)
{
	return 0;
}

//##ModelId=491B0442034B
int CCustomerRiskGradeTbl::Init(otl_connect& dbConnection)
{
	return 0;
}

//��������
void CCustomerRiskGradeTbl::Finish()
{
	m_vecRiskGrade.clear();
}