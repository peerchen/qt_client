#include "RiskCpMgr.h"

// A1 �ӿ� [onRecvRtnForwardInstStateUpdate]ForwardInstState ��ҵ��ʵ��
int CRiskCpMgr::OnForwardInstState(CBroadcastPacket& pkt)
{
	ForwardInstState stBody;
	CPacketStructBroadcastRisk::Packet2Struct(stBody, pkt);

	//ҵ��ʵ��......
	SendAck(pkt);

	return 0;
};
