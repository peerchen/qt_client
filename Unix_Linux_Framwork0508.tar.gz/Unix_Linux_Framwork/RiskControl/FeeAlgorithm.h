#ifndef CFEEALGORITHM_H_HEADER_INCLUDED_B6E391AB
#define CFEEALGORITHM_H_HEADER_INCLUDED_B6E391AB

class CFeeAlgorithm
{
  public:
    //##ModelId=4915B8CE005D
    virtual double Fee(double dlMatchCapital, double dlWeight, int nVolume) = 0;
};

#endif /* CFEEALGORITHM_H_HEADER_INCLUDED_B6E391AB */
