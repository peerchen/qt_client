#ifndef _ETFMATCHDETAILTBL_H_
#define _ETFMATCHDETAILTBL_H_
#include <string>
#include <map>
#include <vector>
#include "Gess.h"
using namespace std;

class otl_connect;
class CBasicParaTbl;
class CEtfMatchDetailTbl
{
public:    
	CEtfMatchDetailTbl();
	~CEtfMatchDetailTbl();

    //
	bool IsHandled(const string& sKey,const string& sAcctNo = "");

    //���������ݿ��ʼ��
    int Init(otl_connect& dbConnection,CBasicParaTbl& BasicParaTbl);
	//��������
	void Finish();

	string ToString();
  private:
    //�ɽ���ʶ key = Match_no+Order_no, value = Acct_no
    map<string,string> m_mapPosi;

    //����
    CGessMutex m_mutexTbl;
};

#endif /* CBASICPARATBL_H_HEADER_INCLUDED_B6E3BA86 */