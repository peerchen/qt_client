#include "MainServiceHandler.h"

// F1 �ӿ� [3070]ǿƽ���������� ��ҵ��ʵ��
int CMainServiceHandler::OnFCOrderCancelReq(CTradePacket& pkt)
{
	HEADER_REQ stHeaderReq;
	FCOrderCancelReq stBodyReq;

	HEADER_RSP stHeaderRsp;
	FCOrderCancelRsp stBodyRsp;

	pkt.GetHeader(stHeaderReq);
	CPacketStructTradeRisk::Packet2Struct(stBodyReq, pkt);

	//ҵ��ʵ��......
	// ����ǿƽ������3053
	CTradePacket pktRsp;
	CPacketStructTradeRisk::HeadReq2Rsp(stHeaderReq,stHeaderRsp);

	if (0 == stBodyReq.order_no.size())
	{
		strcpy(stHeaderRsp.rsp_code, RSP_EMPTY_ORDER.c_str()); 
		pktRsp.AddParameter("rsp_msg", "�����Ų���Ϊ��");
		stBodyRsp.oper_flag = 1;
		pktRsp.SetHeader(stHeaderRsp);
		CPacketStructTradeRisk::Struct2Packet(stBodyRsp, pktRsp);

		// ����3070���ͻ���
		m_pRiskCpMgr->ToInterfaceF1(pktRsp,m_ulKey);
		return -1;
	}

	CTradePacket pktReq3053;
	HEADER_REQ stHeaderReq3053;
	
	pkt.GetHeader(stHeaderReq3053); 
	strcpy(stHeaderReq3053.term_type, RiskConst::gc_sTermTypeRsk.c_str());
	strcpy(stHeaderReq3053.exch_code, "4061");
	pktReq3053.SetHeader(stHeaderReq3053);
	
	ForceCovOderCancel stBodyReq3053;
	stBodyReq3053.oper_flag = 1;
	//stBodyReq3053.cancel_order_no = sTraderOrderNo;
	stBodyReq3053.cancel_order_no = stBodyReq.order_no;
	CPacketStructTradeRisk::Struct2Packet(stBodyReq3053, pktReq3053);

	// ����3052�����׷�����
	m_pRiskCpMgr->ToInterfaceA2(pktReq3053,m_ulKey);
		
	string sSerialNo;
	sSerialNo.assign(stHeaderReq.seq_no, 9);
	SetSerialNo( sSerialNo, stBodyReq.order_no );

    string stat="d";
	m_pMemDb->GetEntrFlowTbl().UpdateEntrFlowByOrderNo(stBodyReq.order_no,stat);
	return 0;
}