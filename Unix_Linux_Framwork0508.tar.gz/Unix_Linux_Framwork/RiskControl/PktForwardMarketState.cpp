#include "RiskCpMgr.h"

// A1 �ӿ� [onRecvRtnForwardMarketStateUpdate]ForwardMarketState ��ҵ��ʵ��
int CRiskCpMgr::OnForwardMarketState(CBroadcastPacket& pkt)
{
	ForwardMarketState stBody;
	CPacketStructBroadcastRisk::Packet2Struct(stBody, pkt);

	//ҵ��ʵ��......
	SendAck(pkt);

	return 0;
};
