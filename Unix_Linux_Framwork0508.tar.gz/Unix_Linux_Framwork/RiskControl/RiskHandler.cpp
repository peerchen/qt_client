
#include "RiskHandler.h"
#include "RiskConstant.h"
#include "RiskCpMgr.h"
#include "GessTimerMgrPosix.h"
//#include "omp.h"

using namespace RiskConst;

CRiskHandler::Cmd2Api CRiskHandler::m_Cmd2Api[] =
{
	//����ApiName					����������ָ��
	{"OnNotifyFeeInfo",				&CRiskHandler::OnNotifyFeeInfo},

	{"onRecvRtnSpotMatch", &CRiskHandler::OnSpotMatch},
	{"onRecvRtnForwardMatch", &CRiskHandler::OnForwardMatch},
	{"onRecvRtnDeferMatch", &CRiskHandler::OnDeferMatch},
	{"onRecvRtnDeferDeliveryAppMatch", &CRiskHandler::OnDeferDeliveryAppMatch},
	{"onRecvRtnEtfMatch",&CRiskHandler::OnETFMatch},				//add by luobaolin 2013-3-18
	{"onRecvSpotQuotation", &CRiskHandler::OnSpotQuotation},
	{"onRecvForwardQuotation", &CRiskHandler::OnForwardQuotation},
	{"onRecvDeferQuotation", &CRiskHandler::OnDeferQuotation},
	{"onAcctCapitalAccess", &CRiskHandler::OnAcctCapitalAccess},
	{"onCustInfoChange", &CRiskHandler::OnCustInfoChange},
	{"onCustCancelNotify", &CRiskHandler::onCustCancelNotify},  //�ͻ���������

	{"onRecvRtnFpMatch", &CRiskHandler::OnFpMatch},
	{"onRecvRtnFpRoundQuotation", &CRiskHandler::OnFpRoundQutation}

};

int CRiskHandler::RunPacketHandleApi(CBroadcastPacket& pkt)
{
	try
	{
		std::string sCmdID = pkt.GetCmdID();
	
		int nSize = sizeof(m_Cmd2Api)/sizeof(Cmd2Api);
		for ( int i = 0 ; i < nSize ; i++ )
		{
			if ( strcmp(m_Cmd2Api[i].pcApiName,sCmdID.c_str()) == 0 )
			{
				if (m_Cmd2Api[i].pMemberFunc == 0)
					break;

				return (this->*(m_Cmd2Api[i].pMemberFunc))(pkt);				
			}
		}

		//CRLog(E_ERROR,"%s","Unknown packet!");
		return -1;
	}
	catch(std::exception e)
	{
		CRLog(E_CRITICAL,"exception:%s", e.what());
		return -1;
	}
	catch(...)
	{
		CRLog(E_CRITICAL,"%s","Unknown exception");
		return -1;
	}
}

CRiskHandler::CRiskHandler(CRiskNotify* pRiskNotify,CMemDb* pMemDb)
:m_pMemDb(pMemDb)
,m_pRiskNotify(pRiskNotify)
,m_pRiskCpMgr(0)
,m_ulKey(EnumKeyRiskHandler)
,m_pCfg(0)
,m_nWorkerNum(2)
,m_paWorker(0)
,m_msMin(0)
,m_msMax(0)
,m_msAve(0)
,m_uiCustMin(0)
,m_uiQuotationCount(0)
,m_uiCustMax(0)
,m_msTotal(0)
,m_uiCustAve(0)
,m_uiCount(0)
,m_uiQuoPktFlag(QUO_PKT_NO)
,m_dlSpotSellFrozenRatio(0.00)
{}

CRiskHandler::~CRiskHandler(void)
{
	FinishWorker();
}

//��ʼ�����ã������̳߳�
int CRiskHandler::Init(CConfig* pCfg)
{
	assert(0 != pCfg);
	if (0 == pCfg)
		return -1;

	m_pCfg = pCfg;
	//CConfig* pConfig = m_pCfg->GetCfgGlobal();

	std::string sWorkers("");
	if (0 == m_pCfg->GetProperty("workers",sWorkers))
		m_nWorkerNum = FromString<int>(sWorkers);

	if (m_nWorkerNum <= 0)
		m_nWorkerNum = 2;

	std::string sSellRatio("");
	if (0 == m_pCfg->GetCfgGlobal()->GetProperty("spot_sell_frozen",sSellRatio))
	{
		int nTmp = FromString<int>(sSellRatio);
		if (nTmp >= 0 && nTmp <= 100)
			m_dlSpotSellFrozenRatio = static_cast<double>(nTmp) / 100.00;
	}

	

	m_pQuotationTimer.BindRiskHandler(this);
	string sSpanTime="";
	long nSpanTime=30; //Ĭ��30��
	m_pCfg->GetCfgGlobal()->GetProperty("SpanTime",sSpanTime,"");
	if(""!=sSpanTime)
	{
		m_unSpanTime=FromString<long>(sSpanTime);
	}
	return InitWorker();
}

//���������̼߳������̳߳�
int CRiskHandler::Start()
{
	if (0 != StartWorker())
		return -1;

	CRLog(E_APPINFO,"%s","Register GessTimer");
	CGessTimerMgrImp::Instance()->CreateTimer(&m_pQuotationTimer,m_unSpanTime,"QuotationTimer");
	//���������߳�
	BeginThread();
	return 0;
}

//ֹͣ�����̳߳ؼ������߳�
void CRiskHandler::Stop()
{
	StopWorker();
	//ע����ʱ��
	CRLog(E_APPINFO,"%s","UnRegister GessTimer");
	CGessTimerMgrImp::Instance()->DestroyTimer(&m_pQuotationTimer,"QuotationTimer");

	//ֹͣ�����߳�
	CRLog(E_APPINFO,"%s","Stop RiskHandler Thread");
	EndThread();
}

//������Դ
void CRiskHandler::Finish()
{
	m_deqService.clear();
}

int CRiskHandler::InitWorker()
{
	m_paWorker = new CWorker*[m_nWorkerNum];
	if (0 == m_paWorker)
	{
		CRLog(E_CRITICAL,"%s","No mem!");
		return -1;
	}

	for (int i = 0; i < m_nWorkerNum; i++)
	{
		m_paWorker[i] = new CWorker(this,i);
		if (0 == m_paWorker[i])
		{
			for (int j = 0; j < i; j++)
			{
				delete m_paWorker[j];
			}
			delete []m_paWorker;

			CRLog(E_CRITICAL,"%s","No mem!");
			return -1;
		}
	}

	return 0;
}

void CRiskHandler::FinishWorker()
{
	for (int i = 0; i < m_nWorkerNum; i++)
	{
		delete m_paWorker[i];
	}
	delete []m_paWorker;
}

void CRiskHandler::StopWorker()
{
	assert(0 != m_paWorker);
	if (0 == m_paWorker)
		return;

	//ֹͣ�����̳߳�
	for (int i = 0; i < m_nWorkerNum; i++)
	{
		CRLog(E_APPINFO,"stop RiskHandler worker thread %d",i);
		assert(0 != m_paWorker[i]);
		if (0 != m_paWorker[i])
			m_paWorker[i]->Stop();
	}
}

int CRiskHandler::StartWorker()
{
	assert(0 != m_paWorker);
	if (0 == m_paWorker)
		return -1;

	//���������̳߳�
	for (int i = 0; i < m_nWorkerNum; i++)
	{
		assert(0 != m_paWorker[i]);
		if (0 != m_paWorker[i])
			m_paWorker[i]->Start();
	}

	return 0;
}

void CRiskHandler::Bind(CConnectPointManager* pCpMgr,const unsigned long& ulKey)
{
	m_ulKey = ulKey; 
	m_pRiskCpMgr = dynamic_cast<CRiskCpMgr*>(pCpMgr);
}
CGessTimer * CRiskHandler::GetQuotationTimer()
{
	return &m_pQuotationTimer;
}

int CRiskHandler::SendPacket(CPacket &pkt)
{
	try
	{
		CBroadcastPacket & pktBroadcast = dynamic_cast<CBroadcastPacket&>(pkt);
		std::string sCmdID = pktBroadcast.GetCmdID();

		if (sCmdID == "onRecvDeferQuotation" 
		     || sCmdID == "onRecvSpotQuotation" 
			 || sCmdID == "onRecvForwardQuotation"
			 || sCmdID == "onRecvDeferDeliveryQuotation")
		{//���ں�Լ����
			HandleQuotation(pktBroadcast);
		}
		else
		{
			Enque(pktBroadcast);
		}

		return 0;
	}
	catch(std::bad_cast)
	{
		CRLog(E_ERROR,"%s","packet error!");
		return -1;
	}
	catch(std::exception e)
	{
		CRLog(E_ERROR,"exception:%s!",e.what());
		return -1;
	}
	catch(...)
	{
		CRLog(E_ERROR,"%s","Unknown exception!");
		return -1;
	}
}

//����ӿں�������Ҫ��A1�ӿڱ��������
int CRiskHandler::Enque(CBroadcastPacket& pkt)
{
	m_deqCondMutex.Lock();
	m_deqService.push_back(pkt);
	m_deqCondMutex.Signal();
	m_deqCondMutex.Unlock();

	return 0;
}

//����ӿں���,�������鱨�ģ���ֹ�������鱨�ģ����鱨�Ĳ�ֱ�������
int CRiskHandler::HandleQuotation(CBroadcastPacket& pkt)
{
	return OnNotifyQuotation(pkt);
}

//�����̺߳���
int CRiskHandler::ThreadEntry()
{
	try
	{
		while(!m_bEndThread)
		{
			m_deqCondMutex.Lock();
			while(m_deqService.empty() && !m_bEndThread)
				m_deqCondMutex.Wait();

			if (m_bEndThread)
			{
				m_deqCondMutex.Unlock();
				break;
			}

			CBroadcastPacket pkt = m_deqService.front();
			m_deqService.pop_front();
			m_deqCondMutex.Unlock();

			try
			{
				RunPacketHandleApi(pkt);
			}
			catch(...)
			{
				CRLog(E_CRITICAL,"%s","Unknown exception");
			}
		}
		CRLog(E_APPINFO,"%s","RiskHandler Thread exit!");
		return 0;
	}
	catch(std::exception e)
	{
		CRLog(E_ERROR,"exception:%s!",e.what());
		return -1;
	}
	catch(...)
	{
		CRLog(E_ERROR,"%s","Unknown exception!");
		return -1;
	}
}

//�̻߳���ص�����,����������߳��˳�
int CRiskHandler::End()
{
	m_deqCondMutex.Lock();
	m_deqCondMutex.Signal();
	m_deqCondMutex.Unlock();

	CRLog(E_APPINFO,"%s","RiskHanlder thread wait end");
	Wait();
	return 0;
}

bool CRiskHandler::IsNetManaged(string& sKeyName)
{
	sKeyName = "���ռ�������߳�";
	return true;
}

//ͳһA1�ӿڱ���Ӧ��
int CRiskHandler::SendAck(CBroadcastPacket& pkt)
{
	//CBroadcastPacket pktAck("Ack");
	return 0;//m_pRiskCpMgr->ToInterfaceA1(pktAck,m_ulKey);
}

//DbSyncģ�鷢�͵ķ�����Ϣ�������
int CRiskHandler::OnNotifyFeeInfo(CBroadcastPacket& pkt)
{
	CCustomerTbl& tblCust = m_pMemDb->GetCustTble();
	const vector<CCustomer*>& Recorsets = tblCust.GetRecordSet();

	vector<CCustomer*>::const_iterator it;
	for (it = Recorsets.begin(); it != Recorsets.end(); ++it)
	{
		if (0 != (*it))
			(*it)->CalculateMargin();
	}

	return TraversalRisk();
}

//���ҿͻ�����
CCustomer* CRiskHandler::FindCustomer(const std::string& sCustID)
{
	CCustomerTbl& tblCust = m_pMemDb->GetCustTble();
	return tblCust.GetCustomer(sCustID);
}

//���ݺ�ԼID���Һ�Լÿ������
double CRiskHandler::GetMeasureUnit(const std::string& sInstID)
{
	CProdCodeTbl& tblProd = m_pMemDb->GetProdCodeTbl();
	double dlUnit = 0.0;
	tblProd.GetMeasureUnit(sInstID,dlUnit);
	return dlUnit;
}

//�����̳߳ر����������
int CRiskHandler::TraversalRisk()
{
	//���ȼ����̳߳ؿ�ʼ�����������
	clock_t ctStart = clock();
	for (int i = 0; i < m_nWorkerNum; i++)
	{
		if (0 != m_paWorker[i])
			m_paWorker[i]->Signal();
	}
	
	//�ȴ��̳߳������̼߳������
	for (int i = 0; i < m_nWorkerNum; i++)
	{
		P();
	}
	clock_t ctEnd = clock();

	//ͳ��
	clock_t ctDiff = (ctEnd - ctStart) * 1000 / CLOCKS_PER_SEC;
	if (1 >= m_uiCount)
	{
		m_msMin = ctDiff;
		m_msAve = ctDiff;
		m_msMax = ctDiff;
		m_msTotal = ctDiff;
	}
	else
	{
		m_msMin = min(m_msMin,ctDiff);
		m_msMax = max(m_msMax,ctDiff);
		m_msTotal += ctDiff;
		m_msAve = m_msTotal / m_uiCount;
	}	
	m_uiCount++;	

	cout << endl;
	cout << m_nWorkerNum << " spend " << ctDiff << "(" << ctStart << "-" << ctEnd << ") ms total" << endl;
	for (int i = 0; i < m_nWorkerNum; i++)
	{
		if (0 != m_paWorker[i])
			cout << i << " spend " << m_paWorker[i]->SpendTime() << " ms(" << m_paWorker[i]->BeginTime() << "-" << m_paWorker[i]->EndTime()<< ") for " <<  m_paWorker[i]->NumOfHandle() << "(" << m_paWorker[i]->IndexBegin() << "-" << m_paWorker[i]->IndexEnd() << ") and need notify " << m_paWorker[i]->NumOfNotify() << endl;
	}

	//��ֹ��������,�̳߳ؼ�����Ϻ��֪ͨ����֪ͨ�̴߳��������еķ���֪ͨ��Ϣ
	m_pRiskNotify->Signal();
	
	//CRLog(E_APPINFO,"%s","���´�����������ӯ��");
	UpdateAgentBalanceStat();
	UpdateAgentDebtStat();

	//֪ͨ����֪ͨ�߳� ����һ�μ۸񲨶��ʼ���
	CTradePacket pktQuo;
	HEADER_REQ stHeaderReq;
	memset(&stHeaderReq,0x00,sizeof(HEADER_REQ));
	strcpy(stHeaderReq.exch_code,"QUOT");
	pktQuo.SetHeader(stHeaderReq);
	m_pRiskNotify->EnquePkt(pktQuo);
		

	return 0;
}

//�̳߳ص��ü���
//�������:nIndex,�߳����
int CRiskHandler::Run(int nIndex,WORKER_STATICS& stStatics)
{
	try
	{
		CCustomerTbl& tblCust = m_pMemDb->GetCustTble();
		const vector<CCustomer*>& Recorsets = tblCust.GetRecordSet();
		CQuotationTbl& tblQuotation = m_pMemDb->GetQuotationTbl();
		//double dlPrice[gc_nProdNum];
		//tblQuotation.GetPriceArray(dlPrice,gc_nProdNum);

		vector<double> dlPrice=tblQuotation.GetPriceArray();
		double dlup,dldown,dlup1,dldown1;
		tblQuotation.UpLimitPrice("Ag(T+D)", dlup);
		tblQuotation.DownLimitPrice("Ag(T+D)", dldown);
		tblQuotation.UpLimitPrice1("Ag(T+D)", dlup1);
		tblQuotation.UpLimitPrice1("Ag(T+D)", dldown1);
		double dlup2,dldown2,dlup21,dldown21;
		tblQuotation.UpLimitPrice("Au(T+D)", dlup2);
		tblQuotation.DownLimitPrice("Au(T+D)", dldown2);
		tblQuotation.UpLimitPrice1("Au(T+D)", dlup21);
		tblQuotation.UpLimitPrice1("Au(T+D)", dldown21);

		size_t nSize = Recorsets.size();
		size_t nAve = nSize / m_nWorkerNum;
		size_t nStart = nAve * nIndex;
		size_t nEnd = (nIndex+1)<m_nWorkerNum?nAve * (nIndex + 1):nSize;
		
		//��Ҫ֪ͨ������
		int nNotify = 0;

		CustRiskInfo oCustRiskInfo;
		int nRtn = 0;
		for (size_t i = nStart; i < nEnd; i++)
		{
			CCustomer * pCust = Recorsets[i];
			if (0 == pCust)
				continue;

			nRtn = pCust->OnQuotation(dlPrice,oCustRiskInfo);

			// ����仯��Ӱ����һ�����յ��ǵ�ֵͣ�����¼��㱬����Ϣ add by liuwei 2012-3-28
			pCust->CalculateOutStockInfo(dlup, dldown, dlup1, dldown1, dlup2, dldown2, dlup21, dldown21);

			/// ����״̬ת�ƺ�֪ͨ
			if (nRtn == gc_cStateRiskTransfer)
			{
				nNotify++;

				//��ֹ�̲߳��о��� ����е���֪ͨ
				m_pRiskNotify->Enque(oCustRiskInfo,false);
			}
			///ֵ�仯��֪ͨ
			else if(nRtn == gc_cStateValueChange)
			{
				nNotify++;
				//��ֹ�̲߳��о��� ����е���֪ͨ
				m_pRiskNotify->Enque(oCustRiskInfo,false);
			}
     		else
			{
				
			}

			// �ʴ��汾���ж���Ӫ�ͻ���������仯
#ifdef _VER_25_PSBC
			if( 0 == m_pMemDb->GetRiskAlarmParaTbl().CheckSelfAcctNoIsExists(pCust->CustAcctNo()))
			{
				m_pRiskNotify->EnqueSelf(pCust);
			}		
#endif	
		}

		stStatics.nStart = nStart;
		stStatics.nEnd = nEnd -1;
		return nNotify;
	}
	catch(...)
	{
		CRLog(E_ERROR,"%s","Unknown exception!");
		return -1;
	}
}

//���¿ͻ����������̸���ӯ��ͳ��
void CRiskHandler::UpdateAgentBalanceStat()
{
	CCustomerTbl& tblCust = m_pMemDb->GetCustTble();
	const vector<CCustomer*>& Recorsets = tblCust.GetRecordSet();
	
	size_t nSize = Recorsets.size();
	for (size_t i = 0; i < nSize; i++)
	{
		CCustomer * pCust = Recorsets[i];
		if (0 == pCust)
			continue;

		pCust->UpdateAgentBalanceStat();
	}
}

//�������������
void CRiskHandler::ResetQuotationCount()
{
	//m_deqCondMutex.Lock();
	m_uiQuotationCount=0;
	//m_deqCondMutex.Unlock();

}
//��ȡ���������
unsigned int CRiskHandler::GetQuotationCount()
{
	
	//m_deqCondMutex.Lock();
	unsigned int temp=m_uiQuotationCount;
	//m_deqCondMutex.Unlock();
	return temp;
}
//���¿ͻ����������̸���ӯ��ͳ��
void CRiskHandler::UpdateAgentDebtStat()
{
	CCustomerTbl& tblCust = m_pMemDb->GetCustTble();
	const vector<CCustomer*>& Recorsets = tblCust.GetRecordSet();
	
	size_t nSize = Recorsets.size();
	for (size_t i = 0; i < nSize; i++)
	{
		CCustomer * pCust = Recorsets[i];
		if (0 == pCust)
			continue;

		pCust->UpdateAgentDebtStat();
	}
}
