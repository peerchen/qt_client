#include "MainServiceHandler.h"

// F1 �ӿ� [3302]�޸���С�䶯��λ������


int CMainServiceHandler::OnAlterMinUnitReq(CTradePacket& pkt)
{

    HEADER_REQ stHeaderReq;
	AlterMinUnitReq stBodyReq;

	HEADER_RSP stHeaderRsp;
	AlterMinUnitRsp stBodyRsp;
	CTradePacket pktRsp;
	pkt.GetHeader(stHeaderReq);
	CPacketStructTradeRisk::Packet2Struct(stBodyReq, pkt);

	CPacketStructTradeRisk::HeadReq2Rsp(stHeaderReq,stHeaderRsp);

	ArrayListMsg msg;
	char cPro_code[10];				 //��Լ����
	int  iAter_minunit=0;		     //��С�ı���
	double iQuote_dot=0;
	int		  iMincatchtime;		    //���ҵ���Ӧ����Ʒ�ֵĳ���ʱ��
	int		  iMaxcatchtime;			//δ�ҵ���Ӧ����Ʒ�ֵĳ���ʱ��
	string	  sVarietyCode;			//��Լ��Ӧ�Ľ���Ʒ���б�����","�ָ�

    memset(cPro_code, 0, sizeof(cPro_code));

    //ҵ��ʵ��......
    stBodyRsp.oper_flag = stBodyReq.oper_flag;
	string sSql = "";
   try
	{  //���Ĵ���	0 ��ѯ 1 �޸�	
        if(stBodyReq.oper_flag == 0)
		{
		     sSql="select PROD_CODE,MININUM_UNIT,QUOTE_DOT,minCatchTime,maxCatchTime,VarietyCode  from  MIN_ALTER_UNIT";
			 otl_stream o(1, sSql.c_str(), GetOtlConn());
			 // o<<atoi(stBodyReq.obj_type.c_str());
			   while (!o.eof())
			  {
				o>>cPro_code>>iAter_minunit>>iQuote_dot >> iMincatchtime >> iMaxcatchtime >> sVarietyCode;
				msg.clear();
				msg.AddValue(cPro_code);
				msg.AddValue(iAter_minunit);
				msg.AddValue(iQuote_dot);
				msg.AddValue(iMincatchtime);
				msg.AddValue(iMaxcatchtime);
				msg.AddValue(sVarietyCode);
				stBodyRsp.alm_result.AddValue(msg);
			  }
		}	
		else if (stBodyReq.oper_flag == 1)//�޸�
		{
		
			sSql="select * from MIN_ALTER_UNIT where MININUM_UNIT=:f1<int> and QUOTE_DOT=:f2<double> and MINCATCHTIME =:f3<int> and MAXCATCHTIME =:f4<int> and VARIETYCODE =:f5<char[100]>  and PROD_CODE=:f6<char[10]>";
			otl_stream o(1, sSql.c_str(), GetOtlConn());
			o<<atoi(stBodyReq.min_unit.c_str())<<atof(stBodyReq.quote_dot.c_str()) << stBodyReq.mincatchtime <<stBodyReq.maxcatchtime <<stBodyReq.varietyCode.c_str() <<stBodyReq.prod_code.c_str();
			
			if (!o.eof())
			{
			 	/*sSql="update MIN_ALTER_UNIT set MININUM_UNIT=:f1<int>  where PROD_CODE=:f2<char[10]> ";
				otl_stream update(1, sSql.c_str(), GetOtlConn());
				update<<atoi(stBodyReq.min_unit.c_str())<<stBodyReq.prod_code.c_str();
				m_OtlConn.commit();*/

				strcpy(stHeaderRsp.rsp_code, "00000001");
				pktRsp.AddParameter("rsp_msg", "����ǿƽ�����Ѿ����ù�");
			}
			else
			{
				/*sSql="insert into MIN_ALTER_UNIT values(:f1<int>,:f2<char[10]>)";
				otl_stream insert(1, sSql.c_str(), GetOtlConn());
				insert<<atoi(stBodyReq.min_unit.c_str())<<stBodyReq.prod_code.c_str();
				m_OtlConn.commit();*/
				CRLog(E_ERROR, "min_unit:%d ,quote_dot:%lf, mincatchtime:%d, maxcatchtime:%d,varietyCode:%s,prod_code:%s", stBodyReq.min_unit.c_str(),atof(stBodyReq.quote_dot.c_str()),stBodyReq.mincatchtime ,stBodyReq.maxcatchtime, stBodyReq.varietyCode.c_str(),stBodyReq.prod_code.c_str());
				sSql="update MIN_ALTER_UNIT set MININUM_UNIT=:f1<int>,QUOTE_DOT=:f2<double>,MINCATCHTIME =:f3<int>,MAXCATCHTIME =:f4<int>,VARIETYCODE =:f5<char[100]>  where PROD_CODE=:f6<char[10]>";
				otl_stream update(1, sSql.c_str(), GetOtlConn());
			 	update<<atoi(stBodyReq.min_unit.c_str())<<atof(stBodyReq.quote_dot.c_str()) << stBodyReq.mincatchtime <<stBodyReq.maxcatchtime << stBodyReq.varietyCode.c_str() <<stBodyReq.prod_code.c_str();
				m_OtlConn.commit();

				//�����ڴ����
				AlterMinUnit stuAlterMinUnit;
				vector<string> vecVarietyID = explodeQuoted(",",stBodyReq.varietyCode);
				stuAlterMinUnit.vecVarietyID = vecVarietyID;
				stuAlterMinUnit.min_unit = atoi(stBodyReq.min_unit.c_str());
				stuAlterMinUnit.quote_dot = atof(stBodyReq.quote_dot.c_str());
				stuAlterMinUnit.minCatchTime =  stBodyReq.mincatchtime;
				stuAlterMinUnit.maxCatchTime = stBodyReq.maxcatchtime;

				m_pMemDb->GetBasicParaTbl().SetQuoteAutoForcePara(stBodyReq.prod_code,stuAlterMinUnit);
				strcpy(stHeaderRsp.rsp_code, "00000000");
				pktRsp.AddParameter("rsp_msg", "����ǿƽ�������óɹ�");

			}
		}

    }
    catch(otl_exception& p)
	{
		CRLog(E_ERROR, "DB:MSG:%s\nTEXT:%s\nVARINFO:%s", p.msg, p.stm_text, p.var_info); 
		Rollback();
		strcpy(stHeaderRsp.rsp_code, RSP_EXCEPTION.c_str());
		pktRsp.AddParameter("rsp_msg", (const char *)p.msg);
		
	}

    //������Ӧ����
	
	

	
	pktRsp.SetHeader(stHeaderRsp);
	CPacketStructTradeRisk::Struct2Packet(stBodyRsp,pktRsp);

	//ת������
	m_pRiskCpMgr->ToInterfaceF1(pktRsp,m_ulKey);

	 if (stBodyReq.oper_flag == 1)
		 m_pMemDb->ReLoadMinUnitTal();
  	return 0;
}