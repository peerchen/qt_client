#include "MainServiceHandler.h"
#include "Logger.h"

// F1 �ӿ� [3094]�ʽ𶳽�ⶳ���������� ��ҵ��ʵ��
/*
����˵�������տͻ�һ��
*/
int CMainServiceHandler::OnRiskCustAllReq(CTradePacket& pkt)
{
	HEADER_REQ stHeaderReq;
	RiskCustAllReq stBodyReq;

	HEADER_RSP stHeaderRsp;
	RiskCustAllRsp stBodyRsp;

	pkt.GetHeader(stHeaderReq);
	CPacketStructTradeRisk::Packet2Struct(stBodyReq, pkt);

	//ҵ��ʵ��......
	CTradePacket pktRsp;
	CPacketStructTradeRisk::HeadReq2Rsp(stHeaderReq,stHeaderRsp);
	
	char cExchDate[9];
	char cAcctNo[16];				//�ͻ���
	char cCustId[16];				//�ƽ��ױ���
	char cAcctAbbr[32];				//�ͻ����
	char cAcctType[3];				//�˻�����
	char cGradeId[5];				//���յȼ�
	char cMarginExch[20];      	//��������֤��
	char cMarginMem[20];		//��Ա��֤��
	char cMarginTotal[20];		//�ܱ�֤��
	char cBranchId[13];				//��������ID
	char cBranchName[51];			//������������
	double cRiskIdx1;			//���ն�1
	double cRiskIdx2;			//���ն�2
	char cCanUseBal[20];		//��ǰ�����ʽ�
	char cMarginCall[20];		//׷���ʽ�
	char cMarkSurplus[20];		//����ӯ��
	char cInOutBal[20];			//���ճ����
	char cAcctGradeId[9];				//�ͻ�����         
	char cRiskDays[10];              //���ճ�������
	char cBkAccountNo[30];		//�����˺�
	char cCustMobile[20];       //�ͻ��ֻ���
	string sSql = "";
	ArrayListMsg alm_resulttemp;

	memset(cExchDate, 0, sizeof(cExchDate));
	memset(cAcctNo, 0, sizeof(cAcctNo));
	memset(cCustId, 0, sizeof(cCustId));
	memset(cAcctType, 0, sizeof(cAcctType));
	memset(cAcctAbbr, 0, sizeof(cAcctAbbr));
	memset(cGradeId, 0, sizeof(cGradeId));
	memset(cMarginTotal, 0, sizeof(cMarginTotal));
	memset(cMarginExch, 0, sizeof(cMarginExch));
	memset(cMarginMem, 0, sizeof(cMarginMem));
	memset(cBranchId, 0, sizeof(cBranchId));
	memset(cBranchName, 0, sizeof(cBranchName));
	//memset(cRiskIdx, 0, sizeof(cRiskIdx));
	memset(cCanUseBal, 0, sizeof(cCanUseBal));
	memset(cMarginCall, 0, sizeof(cMarginCall));
	memset(cMarkSurplus, 0, sizeof(cMarkSurplus));
	memset(cInOutBal, 0, sizeof(cInOutBal));
	memset(cAcctGradeId, 0, sizeof(cAcctGradeId));
	memset(cBkAccountNo, 0, sizeof(cBkAccountNo)); //�����˺�
	memset(cCustMobile, 0, sizeof(cCustMobile)); //�ͻ��ֻ���


#if defined(_VER_25_DB2)
	sSql = "select a.exch_date, a.acct_no, b.cust_abbr, b.acct_type, b.branch_id,  a.risk_degree1,FG_CovToChar(a.grade_id), FG_CovToChar(a.margin_mem), FG_CovToChar(a.can_use_bal), FG_CovToChar(a.mark_surplus), FG_CovToChar(a.margin_call), FG_CovToChar(a.in_out_bal) ,a.risk_degree2 ,FG_CovToChar(a.margin_exch) ,b.grade_id from his_End_day_risk_detail a left join cust_info b on a.acct_no = b.acct_no where  exch_date between '";
#else
    #if defined(_VER_25_PSBC)
	sSql = "select a.exch_date, a.acct_no, b.cust_abbr, b.acct_type, b.branch_id,  a.risk_degree1, to_char(a.grade_id), to_char(a.margin_mem), to_char(a.can_use_bal), to_char(a.mark_surplus), to_char(a.margin_call),"
		"to_char(a.in_out_bal) ,a.risk_degree2 ,to_char(a.margin_exch) ,to_char(b.grade_id) ,to_char(a.risk_days),b.account_no,nvl(c.mobile_phone,'') as mobile,b.cust_id "
		"from his_End_day_risk_detail a left join cust_info b on a.acct_no = b.acct_no  "
		"left join cust_append_info c on b.acct_no = c.acct_no where  exch_date between '";
    #else
	sSql = "select a.exch_date, a.acct_no, b.cust_abbr, b.acct_type, b.branch_id,  a.risk_degree1, to_char(a.grade_id), to_char(a.margin_mem), to_char(a.can_use_bal), to_char(a.mark_surplus), to_char(a.margin_call)," 
		"to_char(a.in_out_bal) ,a.risk_degree2 ,to_char(a.margin_exch) ,to_char(b.grade_id) "
		"from his_End_day_risk_detail a "
		"left join cust_info b on a.acct_no = b.acct_no where  exch_date between '";
    #endif
#endif

	sSql += stBodyReq.begin_date;
	sSql += "' and '";
	sSql += stBodyReq.end_date;
	sSql += "' ";
	//������������
	if (stBodyReq.branch_id == "")
	{
		sSql += GetBranchSql(stHeaderReq.BranchID(), 1);
	}
	else if (stBodyReq.branch_id != stHeaderReq.BranchID())
	{
		sSql += GetBranchSql(stBodyReq.branch_id, 1);
	}
	else
	{
		sSql += "and b.branch_id = '";
		sSql += stBodyReq.branch_id;
		sSql += "' ";
	}
	//���յȼ�����
	if (stBodyReq.risk_grade_id != "")
	{
#ifdef _VER_25_DB2
		sSql += "and a.grade_id = ";
		sSql += stBodyReq.risk_grade_id;
		sSql += " ";
#else
		sSql += "and a.grade_id = '";
		sSql += stBodyReq.risk_grade_id;
		sSql += "' ";
#endif
	}
	//�˻���������
	if (stBodyReq.acct_type != "")
	{
		sSql += "and b.acct_type = '";
		sSql += stBodyReq.acct_type;
		sSql += "'";
	}else
	{
		sSql += "and b.acct_type <> '1' ";
	}
	//�ͻ�����
	if (stBodyReq.cust_type != "")
	{
		sSql += " and b.GRADE_ID = '";
		sSql += stBodyReq.cust_type;
		sSql += "' ";
	}
	sSql+= " order by exch_date desc";
	try
	{
		//ִ��sql
		otl_stream o(1, sSql.c_str(), GetOtlConn());
		while (!o.eof())
		{
#if defined(_VER_25_PSBC)
			o >> cExchDate >> cAcctNo >> cAcctAbbr >> cAcctType >> cBranchId >> cRiskIdx1 >> cGradeId >> cMarginMem >> cCanUseBal >> cMarkSurplus >> cMarginCall >> cInOutBal>>cRiskIdx2>>cMarginExch>>cAcctGradeId >> cRiskDays >> cBkAccountNo >> cCustMobile >> cCustId;
#else
			o >> cExchDate >> cAcctNo >> cAcctAbbr >> cAcctType >> cBranchId >> cRiskIdx1 >> cGradeId >> cMarginMem >> cCanUseBal >> cMarkSurplus >> cMarginCall >> cInOutBal>>cRiskIdx2>>cMarginExch>>cAcctGradeId;
#endif


			
			//���������alm_result
			alm_resulttemp.clear();
			alm_resulttemp.AddValue(cExchDate);//����
			alm_resulttemp.AddValue(cAcctNo);//�ͻ���
#if defined(_VER_25_PSBC)
			alm_resulttemp.AddValue(cBkAccountNo);//�����˺�
#endif
			alm_resulttemp.AddValue(cAcctAbbr);//�ͻ����
		    alm_resulttemp.AddValue(cAcctGradeId);//�ͻ�����
			alm_resulttemp.AddValue(cAcctType);//�˻�����
			alm_resulttemp.AddValue(cBranchId);//�����̺�
			string sAgentName = "";
			CAgent* pAgent = m_pMemDb->GetAgentTble().GetAgent(cBranchId);
			if (0 != pAgent)
			{
				sAgentName = pAgent->GetName();
			}
			alm_resulttemp.AddValue(sAgentName);//����
			alm_resulttemp.AddValue(cRiskIdx1);//���ն�1
			alm_resulttemp.AddValue(cRiskIdx2);//���ն�2
			alm_resulttemp.AddValue(cGradeId);//���յȼ�
			alm_resulttemp.AddValue(cMarginMem);//��Ա��֤��
			alm_resulttemp.AddValue(cMarginExch);//��������֤��
			alm_resulttemp.AddValue(atoi(cMarginMem)+atoi(cMarginExch));//�ܱ�֤��
			alm_resulttemp.AddValue(cCanUseBal);//�����ʽ�
			alm_resulttemp.AddValue(cMarkSurplus);//����ӯ����
			alm_resulttemp.AddValue(cMarginCall);//׷����
			alm_resulttemp.AddValue(cInOutBal);//���ճ����
#if defined(_VER_25_PSBC)
			alm_resulttemp.AddValue(cRiskDays);   //���ճ�������
			alm_resulttemp.AddValue(cCustMobile);//�ͻ��ֻ���
#endif

			stBodyRsp.risk_cust.AddValue(alm_resulttemp);
		}
	}
	catch(otl_exception& p)
	{
		CRLog(E_ERROR, "DB:MSG:%s\nTEXT:%s\nVARINFO:%s", p.msg, p.stm_text, p.var_info); 
		strcpy(stHeaderRsp.rsp_code, RSP_EXCEPTION.c_str());
		pktRsp.AddParameter("rsp_msg", (const char *)p.msg);
	}

	//������Ӧ����
	stBodyRsp.oper_flag = stBodyReq.oper_flag;

	pktRsp.SetHeader(stHeaderRsp);
	CPacketStructTradeRisk::Struct2Packet(stBodyRsp,pktRsp);

	//ת������
	m_pRiskCpMgr->ToInterfaceF1(pktRsp,m_ulKey);

	return 0;
};
