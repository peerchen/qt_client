#include "RiskCpMgr.h"

// A1 �ӿ� [onRecvRtnDeferInstStateUpdate]DeferInstState ��ҵ��ʵ��
int CRiskCpMgr::OnDeferInstState(CBroadcastPacket& pkt)
{
	DeferInstState stBody;
	CPacketStructBroadcastRisk::Packet2Struct(stBody, pkt);

	//ҵ��ʵ��......
	SendAck(pkt);

	return 0;
};
