#include "CustFeeDetailTbl.h"
#include "Logger.h"
#include "FeeAlgorithmCapital.h"
#include "FeeAlgorithmVolume.h"
#include "FeeAlgorithmWeight.h"
#include "VersionMacro.h"

CCustFeeDetailTbl::CCustFeeDetailTbl()
{

}

CCustFeeDetailTbl::~CCustFeeDetailTbl()
{
	Finish();
}

//##ModelId=4913CDCE001F
CFeeAlgorithm* CCustFeeDetailTbl::GetFeeAlgorithm(const string& sCustID, const string& sProdID, const string& sFeeType)
{
	CFeeAlgorithm* p = 0;
	CGessGuard guard(m_mutexTbl);
	map<string, CUST_FEE_DETAIL>::iterator it = m_mapCustFeeDetail.find(sCustID + sProdID + sFeeType);
	if (it != m_mapCustFeeDetail.end())
	{
		p = it->second.pFeeAlgorithm;
	}
	return p;
}

int CCustFeeDetailTbl::GetFeeVal(const string& sCustID, const string& sProdID, const string& sFeeType,double& dlFeeVal)
{
	int nRtn = -1;
	CGessGuard guard(m_mutexTbl);
	map<string, CUST_FEE_DETAIL>::iterator it = m_mapCustFeeDetail.find(sCustID + sProdID + sFeeType);
	if (it != m_mapCustFeeDetail.end())
	{
		dlFeeVal =  it->second.dlValue;
		nRtn = 0;
	}
	return nRtn;
}

int CCustFeeDetailTbl::ReInit(otl_connect& dbConnection)
{
	CGessGuard guard(m_mutexTbl);
	//��ռ���
	Finish();

	//��ʼ��
	Init(dbConnection);

	return 0;
}

//##ModelId=4916CB3B03B9
int CCustFeeDetailTbl::Init(otl_connect& dbConnection)
{
	char cAcctNo[16];			//�ͻ���
	char cProdCode[11];			//��Լ����
	char cFareType[4];			//��������
	char cFareMode[3];			//�շ�ģʽ
	char cFareValue[25];		//����ֵ
	CUST_FEE_DETAIL stCustFeeDetail;
	string sSql = "";

	memset(cAcctNo, 0, sizeof(cAcctNo));
	memset(cProdCode, 0, sizeof(cProdCode));
	memset(cFareType, 0, sizeof(cFareType));
	memset(cFareMode, 0, sizeof(cFareMode));

	try
	{
#ifdef _VER_25_DB2
		sSql = "select acct_no, prod_code, fare_type_id, fare_mode, FG_CovToChar(fare_value) from acct_fare_detail";
#else
		sSql = "select acct_no, prod_code, fare_type_id, fare_mode, to_char(fare_value) from acct_fare_detail";
#endif
		
		otl_stream o(1, sSql.c_str(), dbConnection);

		CGessGuard guard(m_mutexTbl);
		while (!o.eof())
		{
			o >> cAcctNo >> cProdCode >> cFareType >> cFareMode >> cFareValue;

			stCustFeeDetail.sCustID = cAcctNo;
			stCustFeeDetail.sProdCode = cProdCode;
			stCustFeeDetail.sFeeTypeID = cFareType;
			stCustFeeDetail.dlValue = atof(cFareValue);
			stCustFeeDetail.sFeeMode=cFareMode;

			if (strcmp(cFareMode, "1") == 0)
			{
				stCustFeeDetail.pFeeAlgorithm = new CFeeAlgorithmCapital(atof(cFareValue));
			}
			else if (strcmp(cFareMode, "2") == 0)
			{
				stCustFeeDetail.pFeeAlgorithm = new CFeeAlgorithmWeight(atof(cFareValue));
			}
			else if (strcmp(cFareMode, "3") == 0)
			{
				stCustFeeDetail.pFeeAlgorithm = new CFeeAlgorithmVolume(atof(cFareValue));
			}

			m_mapCustFeeDetail[stCustFeeDetail.sCustID + stCustFeeDetail.sProdCode + stCustFeeDetail.sFeeTypeID] = stCustFeeDetail;			
		}
	}
	catch(otl_exception& p)
	{
		CRLog(E_ERROR,"otl exception:%s,%s,%s,%s",p.msg,p.stm_text,p.sqlstate,p.var_info);
	}

	return 0;
}

//��������
void CCustFeeDetailTbl::Finish()
{
	try
	{
		CGessGuard guard(m_mutexTbl);
		map<string, CUST_FEE_DETAIL>::iterator it = m_mapCustFeeDetail.begin();
		for ( ; it != m_mapCustFeeDetail.end(); ++it)
		{
			if (0 != it->second.pFeeAlgorithm)
			{
				delete it->second.pFeeAlgorithm;
				it->second.pFeeAlgorithm = 0;
			}
		}
		m_mapCustFeeDetail.clear();
	}
	catch(...)
	{
		CRLog(E_ERROR,"%s","CCustFeeDetailTbl Error!");
	}
}

