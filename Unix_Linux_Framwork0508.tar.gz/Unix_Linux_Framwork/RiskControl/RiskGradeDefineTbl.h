#ifndef CRISKGRADEDEFINETBL_H_HEADER_INCLUDED_B6E39A14
#define CRISKGRADEDEFINETBL_H_HEADER_INCLUDED_B6E39A14
#include <string>
#include <map>
#include <vector>
#include "Gess.h"
using namespace std;

typedef struct tagRiskGradeDefine
{
	unsigned short usGradeID;
	string sName;
	string sColor;
} RISK_GRADE_DEFINE,*PRISK_GRADE_DEFINE;

class otl_connect;
class CRiskGradeDefineTbl
{
public:
	CRiskGradeDefineTbl();
	~CRiskGradeDefineTbl();

    //���ݷ��ռ����ȡ��Ӧ��ϸ��Ϣ
    int GetRiskGrade(unsigned short usGradeID, RISK_GRADE_DEFINE& stRiskGrade);

    //������ռ�����ϸ��Ϣ
    int UpdateRiskGrade(unsigned short usGradeID, RISK_GRADE_DEFINE& stRiskGrade);

    //���������ݿ��ʼ��
    int Init(otl_connect& dbConnection);
	//��������
	void Finish();
  private:
    //##ModelId=491AF55C03B9
    vector<RISK_GRADE_DEFINE> m_vecRiskGradeDef;
    //##ModelId=491AFABD005D
    CGessMutex m_mutexTbl;
};

#endif /* CRISKGRADEDEFINETBL_H_HEADER_INCLUDED_B6E39A14 */
