#include "FpOrderFlowTbl.h"
#include "strutils.h"
#include "Logger.h"
//#include "otlv4.h"
#include "DB_Version.h" 
#include "RiskConstant.h"

using namespace RiskConst;

CFpOrderFlowTbl::CFpOrderFlowTbl(){}



void CFpOrderFlowTbl::Finish()
{
	CGessGuard guard(m_mutexTbl);
	
	m_vecFpOrderFlow.clear();
	m_vecFpOrderFlowStatistics.clear();
	m_mapFpOrderFlowTbl.clear();
}

CFpOrderFlowTbl::~CFpOrderFlowTbl()
{
	Finish();
}

//���������ݿ��ʼ��
int CFpOrderFlowTbl::Init(otl_connect& dbConnection)
{
	
	char cOrderNo[19];
	char cCustID[16];
	char cMemberId[7];
	char cProdCode[21];
	char cEntrPhase[3];
	char cOrderType[3];
	char cEntrStat[3];
	char cGameId[11];
	char cRoundId[11];
	char cBs;
	int nNum;
	double dlPrice;
	double dlForzMargin;
	double dlFrozFare;
	
	string sSql = "";

	memset(cOrderNo,0x00,sizeof(cOrderNo));
	memset(cCustID,0x00,sizeof(cCustID));
	memset(cMemberId,0x00,sizeof(cMemberId));
	memset(cProdCode,0x00,sizeof(cProdCode));
	memset(cEntrPhase,0x00,sizeof(cEntrPhase));
	memset(cOrderType,0x00,sizeof(cOrderType));
	memset(cEntrStat,0x00,sizeof(cEntrStat));
	memset(cGameId,0x00,sizeof(cGameId));
	memset(cRoundId,0x00,sizeof(cRoundId));

	try
	{
		//���������̶���
		CRLog(E_DEBUG, "loading fp_entr_flow info[%s]"," ......");
		

		//��ʼ���������ر�	
		sSql = "select acct_no,order_no from fp_entr_flow";
		otl_stream i(1,sSql.c_str(),dbConnection);

		while (!i.eof())
		{
			i >> cCustID >> cOrderNo;

			m_mapFpOrderFlowTbl[cOrderNo] = string(cCustID);
		}

		//�����걨��ˮ
		sSql = "select a.order_no,\
					a.acct_no,\
					a.member_id,\
					a.prod_code,\
					a.bs,\
					a.entr_amount,\
					a.entr_price,\
					a.froz_margin,\
					a.froz_exch_fare,\
					a.entr_phase,\
					a.order_type,\
					a.entr_stat,\
					a.game_id,\
					a.round_id\
				from fp_entr_flow a, fp_prod_code_def b\
				where a.entr_stat = 'o'\
					and a.prod_code = b.prod_code\
					and a.game_id = b.curr_game_id\
					and b.inst_exch_stat not in ( 'a', 'b' )";

		otl_stream oflow(1,sSql.c_str(),dbConnection);

		while (!oflow.eof())
		{
			oflow >> cOrderNo >> cCustID >> cMemberId >> cProdCode >> cBs >> nNum >> dlPrice >>dlForzMargin >> dlFrozFare >> cEntrPhase >> cOrderType >> cEntrStat >> cGameId >> cRoundId;

			CFpOrderFlow FpOrder = CFpOrderFlow(cOrderNo,cCustID,cMemberId,cProdCode,cBs,nNum,dlPrice,dlForzMargin,dlFrozFare,cEntrPhase,cOrderType,cEntrStat,cGameId,cRoundId);
			m_vecFpOrderFlow.push_back(FpOrder);
		}

		AddUpFpOrderFlow();
	}
	catch(otl_exception& p)
	{
		CRLog(E_ERROR, "otl exception:%s,%s,%s,%s", p.msg, p.stm_text, p.sqlstate, p.var_info);
	}

	return 0;
}

//����
bool CFpOrderFlowTbl::IsHandle(const string& sKey,const string& sAcctNo)
{	
	CGessGuard guard(m_mutexTbl);

	bool blRtn = false;
	map<string,string> ::iterator it = m_mapFpOrderFlowTbl.find(sKey);
	if (it != m_mapFpOrderFlowTbl.end())
	{
		blRtn = true;
	}
	else
	{
		m_mapFpOrderFlowTbl[sKey] = sAcctNo;
		blRtn = false;
	}

	return blRtn;
}	

//�ж��Ƿ����ָ���ͻ���ָ����Լ�ı���
int CFpOrderFlowTbl::IsExit( string sGameId, string sRoundId, string sCustNo,string sProdCode)
{
	CGessGuard guard(m_mutexTbl);

	vector<CFpOrderFlowStatistics>::iterator it;
	for (it = m_vecFpOrderFlowStatistics.begin(); it != m_vecFpOrderFlowStatistics.end(); ++it)
	{
		if( 0==it->GetAcctNo().compare(sCustNo) && it->GetProdCode().compare(sProdCode) == 0 && it->GetGameId() == sGameId && it->GetRoundId() == sRoundId )  
		{
			return 1;
		}
	}

	return 0;
}

//��ȡָ���ͻ���ָ����Լ�ı���
int CFpOrderFlowTbl::GetFpOrderFlow( string sGameId, string sRoundId, string sCustNo,string sProdCode,CFpOrderFlowStatistics & FpOrderFlow)
{
	CGessGuard guard(m_mutexTbl);

	vector<CFpOrderFlowStatistics>::iterator it;
	for (it = m_vecFpOrderFlowStatistics.begin(); it != m_vecFpOrderFlowStatistics.end(); ++it)
	{
		if( 0==it->GetAcctNo().compare(sCustNo) && it->GetProdCode().compare(sProdCode) == 0 && it->GetGameId() == sGameId && it->GetRoundId() == sRoundId )  
		{
			FpOrderFlow = *it;
			break;
		}	
	}

	if(it == m_vecFpOrderFlowStatistics.end())
	{
		return -1;
	}

	return 0;
}	


void CFpOrderFlowTbl::AddFpOrderFlow( string sGameId, string sRoundId, string sAcctNo,string sMemberId,string sProdCode,double dlPrice,int nNumBuy,int nNumSell,double dlMarignBuy,double dlMarginSell,double dlFareBuy,double dlFareSell)
{
	CGessGuard guard(m_mutexTbl);

	CFpOrderFlowStatistics FpOrder = CFpOrderFlowStatistics( sGameId, sRoundId, sAcctNo,sMemberId,sProdCode,dlPrice,nNumBuy,nNumSell,dlMarignBuy,dlMarginSell,dlFareBuy,dlFareSell);

	CRLog(E_DEBUG,"���Ӷ��ۺ�Լ�걨��ˮ��GameId=%s,sRoundId=%s AcctNo=%s,ProdCode=%s,Price=%.2f,NumBuy=%d,NumSell=%d,MarginBuy=%.2f,MarginSell=%.2f,FareBuy=%.2f,FareSell=%.2f",
		sGameId.c_str(), sRoundId.c_str(),sAcctNo.c_str(),sProdCode.c_str(),dlPrice,nNumBuy,nNumSell,dlMarignBuy,dlMarginSell,dlFareBuy,dlFareSell);

	m_vecFpOrderFlowStatistics.push_back(FpOrder);
}



int CFpOrderFlowTbl::UpdateFpOrderFlow( string sGameId, string sRoundId, string sAcctNo,string sProdCode,double dlPrice,int nNumBuy,int nNumSell,double dlMarignBuy,double dlMarginSell,double dlFareBuy,double dlFareSell)
{
	CGessGuard guard(m_mutexTbl);

	vector<CFpOrderFlowStatistics>::iterator it;
	for (it = m_vecFpOrderFlowStatistics.begin(); it != m_vecFpOrderFlowStatistics.end(); ++it)
	{
		if( 0==it->GetAcctNo().compare(sAcctNo) && it->GetProdCode().compare(sProdCode) == 0 && it->GetGameId() == sGameId && it->GetRoundId() == sRoundId )  
		{
			CRLog( E_DEBUG, "UpdateFpOrderFlow:GameId=%s,RoundId=%s,AcctNo=%s,ProdCode=%s,Price=%lf",sGameId.c_str(),sRoundId.c_str(),sAcctNo.c_str(),sProdCode.c_str(),dlPrice);
			it->UpdateNumBuy(nNumBuy);
			it->UpdateNumSell(nNumSell);
			it->UpdateMarginBuy(dlMarignBuy);
			it->UpdateMarginSell(dlMarginSell);
			it->UpdateFareBuy(dlFareBuy);
			it->UpdateFareSell(dlFareSell);
			it->UpdateEntrPrice(dlPrice);
			break;
		}	
	}

	if(it == m_vecFpOrderFlowStatistics.end())
	{
		return -1;
	}

	return 0;
}


//ɾ��ָ���ͻ���ָ����Լ�ı���
int CFpOrderFlowTbl::DeleteFpOrderFlow( string sGameId, string sRoundId, string sCustNo,string sProdCode)
{
	CGessGuard guard(m_mutexTbl);

	vector<CFpOrderFlowStatistics>::iterator it;
	for (it = m_vecFpOrderFlowStatistics.begin(); it != m_vecFpOrderFlowStatistics.end(); ++it)
	{
		if( 0==it->GetAcctNo().compare(sCustNo) && it->GetProdCode().compare(sProdCode) == 0  && it->GetGameId() == sGameId && it->GetRoundId() == sRoundId )  
		{
			CRLog( E_DEBUG, "DeleteFpOrderFlow:GameId=%s,RoundId=%s,AcctNo=%s,ProdCode=%s",sGameId.c_str(),sRoundId.c_str(),sCustNo.c_str(),sProdCode.c_str());
			m_vecFpOrderFlowStatistics.erase(it);
			return 0;
		}	
	}

	return -1;
}

vector<CFpOrderFlowStatistics>& CFpOrderFlowTbl::GetFpOrderRecord()
{
	return m_vecFpOrderFlowStatistics;
}

//��ʼ���׶Σ��Զ����걨��ˮ����ͳ��
void CFpOrderFlowTbl::AddUpFpOrderFlow()
{
	CGessGuard guard(m_mutexTbl);

	int    nNumBuy      = 0;
	int    nNumSell     = 0;
	double dlMarginBuy  = 0.0;
	double dlMarginSell = 0.0;
	double dlFareBuy    = 0.0;
	double dlFareSell   = 0.0;

	string sAcctNo   = "";
	string sMemberId = "";
	string sProdCode = "";
	double dlPrice   = 0.0; 
	string sGameId   = "";
	string sRoundId  = "";

	vector<CFpOrderFlow>::iterator it;
	//����������ˮ����
	for (it = m_vecFpOrderFlow.begin(); it != m_vecFpOrderFlow.end(); ++it)
	{
		sAcctNo   = it->GetAcctNo();
		sMemberId = it->GetMemberId();
		sProdCode = it->GetProdCode();
		dlPrice   = it->GetPrice();
		sGameId   = it->GetGameId();
		sRoundId  = it->GetRoundId();

		if(it->GetBuyorSell() == gc_cProdBuy)
		{
			//��������Ϊ����
			if(it->GetOrderType()== gc_sFpEntrTypeSub)
			{
				nNumBuy = -it->GetNum();
				dlMarginBuy = -it->GetFrozMargin();
				dlFareBuy = -it->GetFrozFare();
			}
			else if(it->GetOrderType()== gc_sFpEntrTypeAdd)
			{
				nNumBuy = it->GetNum();
				dlMarginBuy = it->GetFrozMargin();
				dlFareBuy = it->GetFrozFare();
			}	
			else
			{
				continue;
			}
		}
		else
		{
			//��������Ϊ����
			if(it->GetOrderType() == gc_sFpEntrTypeSub)
			{
				nNumSell = -it->GetNum();
				dlMarginSell = -it->GetFrozMargin();
				dlFareSell = -it->GetFrozFare();
			}
			else if(it->GetOrderType()== gc_sFpEntrTypeAdd)
			{
				nNumSell = it->GetNum();
				dlMarginSell = it->GetFrozMargin();
				dlFareSell = it->GetFrozFare();
			}
			else
			{
				continue;
			}

		}

		vector<CFpOrderFlowStatistics>::iterator itStat;
		for (itStat = m_vecFpOrderFlowStatistics.begin(); itStat != m_vecFpOrderFlowStatistics.end(); ++itStat)
		{
			if(sAcctNo == itStat->GetAcctNo() && sProdCode == itStat->GetProdCode() && sGameId == itStat->GetGameId() && sRoundId == itStat->GetRoundId() )
			{
				itStat->UpdateNumBuy(nNumBuy);
				itStat->UpdateNumSell(nNumSell);
				itStat->UpdateMarginBuy(dlMarginBuy);
				itStat->UpdateMarginSell(dlMarginSell);
				itStat->UpdateFareBuy(dlFareBuy);
				itStat->UpdateFareSell(dlFareSell);
				itStat->UpdateEntrPrice(dlPrice);
				break;
			}
		}


		if(itStat == m_vecFpOrderFlowStatistics.end())
		{
			CFpOrderFlowStatistics FpOrderStat = CFpOrderFlowStatistics( sGameId, sRoundId, sAcctNo,sMemberId,sProdCode,dlPrice,nNumBuy,nNumSell,dlMarginBuy,dlMarginSell,dlFareBuy,dlFareSell);
			m_vecFpOrderFlowStatistics.push_back(FpOrderStat);
		}
	}

	//CRLog
	CRLog(E_DEBUG,"AddUpFpOrderFlow : ");
	for( vector<CFpOrderFlowStatistics>::iterator it = m_vecFpOrderFlowStatistics.begin(); it != m_vecFpOrderFlowStatistics.end(); it++ )
	{
		CRLog(E_DEBUG,"CFpOrderFlowStatistics: \
GameID:%s \
RoundId:%s \
AcctNo:%s \
MemberId:%s \
ProdCode:%s \
FpEntrPrice:%lf \
NumBuy:%d \
MarginBuy:%lf \
FareBuy:%lf \
NumSell:%d \
MarginSell:%lf \
FareSell:%lf"
			,it->GetGameId()
			,it->GetRoundId()
			,it->GetAcctNo()
			,it->GetMemberId()
			,it->GetProdCode()
			,it->GetFpEntrPrice()
			,it->GetNumBuy()
			,it->GetMarginBuy()
			,it->GetFareBuy()
			,it->GetNumSell()
			,it->GetMarginSell()
			,it->GetFareSell());
	}
	//CRLog end
}

