#include "Logger.h"
#include "RiskConstant.h"
#include "EntrFlow.h"
using namespace RiskConst;
using namespace std;


CEntrFlow::CEntrFlow():
m_sLocalOderNo(""),
m_sOderNo(""),
m_sCustId(""),
m_sProdCode(""),
m_sEntrStat(""),
m_sOffsetFlag(""),
m_sForceOrderNo(""),
m_lEntrAmount(0),
m_lRemainAmount(0),
m_sTellId("")
{}
CEntrFlow::CEntrFlow(string sLocalOderNo,string sOderNo,string sCustId,string sProdCode,string sEntrStat,
					 string sOffsetFlag,string sForceOrderNo,long lEntrAmount,long lRemainAmount,double dEntrPrice,char m_cDir,string sTellId)
{
	m_sLocalOderNo=sLocalOderNo;
	m_sOderNo=sOderNo;
	m_sCustId=sCustId;
	m_sProdCode=sProdCode;
	m_sEntrStat=sEntrStat;
	m_sOffsetFlag=sOffsetFlag;
	m_sForceOrderNo=sForceOrderNo;
	m_lEntrAmount=lEntrAmount;
	m_lRemainAmount=lRemainAmount;
	m_dlEntrPrice=dEntrPrice;
	m_cDir=m_cDir;
	m_sTellId=sTellId;
}	

CEntrFlow::~CEntrFlow()
{
}
