#ifndef FPMATCHDFOLWTBL_H_HEADER_INCLUDED_
#define FPMATCHDFOLWTBL_H_HEADER_INCLUDED_
#include <string>
#include <map>
#include <vector>
#include "Gess.h"
using namespace std;

class otl_connect;
class CBasicParaTbl;
class CFpMatchFlowTbl
{
public:    
	CFpMatchFlowTbl();
	~CFpMatchFlowTbl();

	//����
	bool IsHandled(const string& sKey,const string& sAcctNo = "");

	//���������ݿ��ʼ��
	int Init(otl_connect& dbConnection,CBasicParaTbl& BasicParaTbl);
	//��������
	void Finish();

private:
	//�ɽ���ʶ key = Match_no+Order_no, value = Acct_no
	map<string,string> m_mapPosi;

	//����
	CGessMutex m_mutexTbl;
};

#endif /* FPMATCHDFOLWTBL_H_HEADER_INCLUDED_ */