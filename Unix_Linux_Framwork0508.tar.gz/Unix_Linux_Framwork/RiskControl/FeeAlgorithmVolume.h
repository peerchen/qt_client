#ifndef CFEEALGORITHMVOLUME_H_HEADER_INCLUDED_B6E3E6CE
#define CFEEALGORITHMVOLUME_H_HEADER_INCLUDED_B6E3E6CE
#include "FeeAlgorithm.h"

class CFeeAlgorithmVolume : public CFeeAlgorithm
{
  public:
    //##ModelId=4916D65A00FA
	CFeeAlgorithmVolume(double dlUnit):m_dlUnit(dlUnit){}

    //##ModelId=4915BACC0177
    double Fee(double dlMatchCapital, double dlWeight, int nVolume){return nVolume*m_dlUnit;}

  private:
    //##ModelId=4915BA9D0157
    double m_dlUnit;
};

#endif /* CFEEALGORITHMVOLUME_H_HEADER_INCLUDED_B6E3E6CE */
