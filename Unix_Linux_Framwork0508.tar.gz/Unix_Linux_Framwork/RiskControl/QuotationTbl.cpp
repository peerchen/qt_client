#include <sstream>
#include <iomanip>
#include "Logger.h"
#include "QuotationTbl.h"
#include "ProdCodeTbl.h"
#include "BasicParaTbl.h"
#include "RiskConstant.h"
#include "DB_Version.h" 
using namespace RiskConst;

CQuotationTbl::CQuotationTbl()
{
	m_mapProdTime.clear();
}

CQuotationTbl::~CQuotationTbl()
{
	Finish();
}

string CQuotationTbl::ToString() 
{
	std::stringstream ss;

	vector<PROD_QUOTATION>::iterator iter;
	CGessGuard guard(m_mutexTbl);
	for( iter = m_vecQuoation.begin(); iter != m_vecQuoation.end(); ++iter)
	{
		
		ss << (*iter).nIndex << " " ;
		ss << (*iter).sProdCode << " " ;
		ss << (*iter).dlNowPrice << " " ;
		ss << (*iter).dlUpLimit << " " ;
		ss << (*iter).dlDownLimit << "\r\n";
	}

	return ss.str();
}

//##ModelId=4913F49E00DA
int CQuotationTbl::NowPrice(const string& sProdID,double& dlPrice)
{
	int nRtn = -1;
	vector<PROD_QUOTATION>::iterator iter;
	CGessGuard guard(m_mutexTbl);
	for( iter = m_vecQuoation.begin(); iter != m_vecQuoation.end(); ++iter)
	{
		if((*iter).sProdCode == sProdID)
		{
			dlPrice =  (*iter).dlNowPrice;
			nRtn = 0;
			break;
		}		
	}
	return nRtn;
}

//##ModelId=4913F4C602DE
int CQuotationTbl::NowPrice(int nIndex,double& dlPrice)
{
	int nRtn = -1;
	vector<PROD_QUOTATION>::iterator iter;
	CGessGuard guard(m_mutexTbl);
	for( iter = m_vecQuoation.begin(); iter != m_vecQuoation.end(); ++iter)
	{
		if((*iter).nIndex == nIndex)
		{
			dlPrice =  (*iter).dlNowPrice;
			nRtn = 0;
			break;
		}		
	}
	return nRtn;
}

 /***
   *  ��ȡָ���������ڵĵ�ǰ�۸�
   * author: yfy   2010/09/10  
   * param: 
   * 
   * return  -1��ʾδȡ��ȡ���۸�
   */

int CQuotationTbl::NowPrice(const string& sProdID,string& sExchDate,double& dlPrice)
{
	int nRtn = -1;
	vector<PROD_QUOTATION>::iterator iter;
	CGessGuard guard(m_mutexTbl);
	for( iter = m_vecQuoation.begin(); iter != m_vecQuoation.end(); ++iter)
	{
		if((*iter).sProdCode == sProdID)
		{
			if((*iter).sExch_date != sExchDate)
			{
				dlPrice = (*iter).dlNowPrice;
				return -1;
			}
			dlPrice =  (*iter).dlNowPrice;
			nRtn = 0;
			break;
		}		
	}
	return nRtn;
}

//##ModelId=4913F50100FA
int CQuotationTbl::UpLimitPrice(const string& sProdID,double& dlUpLimit)
{
	int nRtn = -1;
	vector<PROD_QUOTATION>::iterator iter;
	CGessGuard guard(m_mutexTbl);
	for( iter = m_vecQuoation.begin(); iter != m_vecQuoation.end(); ++iter)
	{
		if((*iter).sProdCode == sProdID)
		{
			dlUpLimit =  (*iter).dlUpLimit;
			nRtn = 0;
			break;
		}		
	}
	return nRtn;
}

//##ModelId=4913F5290167
int CQuotationTbl::UpLimitPrice(int nIndex,double& dlUpLimit)
{
	int nRtn = -1;
	vector<PROD_QUOTATION>::iterator iter;
	CGessGuard guard(m_mutexTbl);
	for( iter = m_vecQuoation.begin(); iter != m_vecQuoation.end(); ++iter)
	{
		if((*iter).nIndex == nIndex)
		{
			dlUpLimit =  (*iter).dlUpLimit;
			nRtn = 0;
			break;
		}		
	}
	return nRtn;
}

// 
int CQuotationTbl::UpLimitPrice1(const string& sProdID,double& dlUpLimit)
{
	int nRtn = -1;
	vector<PROD_QUOTATION>::iterator iter;
	CGessGuard guard(m_mutexTbl);
	for( iter = m_vecQuoation.begin(); iter != m_vecQuoation.end(); ++iter)
	{
		if((*iter).sProdCode == sProdID)
		{
			dlUpLimit =  (*iter).dlUpLimit1;
			nRtn = 0;
			break;
		}		
	}
	return nRtn;
}

//
int CQuotationTbl::UpLimitPrice1(int nIndex,double& dlUpLimit)
{
	int nRtn = -1;
	vector<PROD_QUOTATION>::iterator iter;
	CGessGuard guard(m_mutexTbl);
	for( iter = m_vecQuoation.begin(); iter != m_vecQuoation.end(); ++iter)
	{
		if((*iter).nIndex == nIndex)
		{
			dlUpLimit =  (*iter).dlUpLimit1;
			nRtn = 0;
			break;
		}		
	}
	return nRtn;
}

//##ModelId=491525AF033C
int CQuotationTbl::DownLimitPrice(const string& sProdID,double& dlDownLimit)
{
	int nRtn = -1;
	vector<PROD_QUOTATION>::iterator iter;
	CGessGuard guard(m_mutexTbl);
	for( iter = m_vecQuoation.begin(); iter != m_vecQuoation.end(); ++iter)
	{
		if((*iter).sProdCode == sProdID)
		{
			dlDownLimit =  (*iter).dlDownLimit;
			nRtn = 0;
			break;
		}		
	}
	return nRtn;
}

//##ModelId=491525A4031C
int CQuotationTbl::DownLimitPrice(int nIndex,double& dlDownLimit)
{
	int nRtn = -1;
	vector<PROD_QUOTATION>::iterator iter;
	CGessGuard guard(m_mutexTbl);
	for( iter = m_vecQuoation.begin(); iter != m_vecQuoation.end(); ++iter)
	{
		if((*iter).nIndex == nIndex)
		{
			dlDownLimit =  (*iter).dlDownLimit;
			nRtn = 0;
			break;
		}		
	}
	return nRtn;
}

//
int CQuotationTbl::DownLimitPrice1(const string& sProdID,double& dlDownLimit)
{
	int nRtn = -1;
	vector<PROD_QUOTATION>::iterator iter;
	CGessGuard guard(m_mutexTbl);
	for( iter = m_vecQuoation.begin(); iter != m_vecQuoation.end(); ++iter)
	{
		if((*iter).sProdCode == sProdID)
		{
			dlDownLimit =  (*iter).dlDownLimit1;
			nRtn = 0;
			break;
		}		
	}
	return nRtn;
}

//
int CQuotationTbl::DownLimitPrice1(int nIndex,double& dlDownLimit)
{
	int nRtn = -1;
	vector<PROD_QUOTATION>::iterator iter;
	CGessGuard guard(m_mutexTbl);
	for( iter = m_vecQuoation.begin(); iter != m_vecQuoation.end(); ++iter)
	{
		if((*iter).nIndex == nIndex)
		{
			dlDownLimit =  (*iter).dlDownLimit1;
			nRtn = 0;
			break;
		}		
	}
	return nRtn;
}

//##ModelId=4913F67100CB
int CQuotationTbl::SetNowPrice(const string& sProdID,double dlPrice)
{
	int nRtn = -1;
	vector<PROD_QUOTATION>::iterator iter;
	CGessGuard guard(m_mutexTbl);
	for( iter = m_vecQuoation.begin(); iter != m_vecQuoation.end(); ++iter)
	{
		if((*iter).sProdCode == sProdID)
		{
			(*iter).dlNowPrice = dlPrice;
			nRtn = 0;
			break;
		}		
	}
	return nRtn;
}

//##ModelId=4913F67C037A
int CQuotationTbl::SetNowPrice(int nIndex,double dlPrice)
{
	int nRtn = -1;
	vector<PROD_QUOTATION>::iterator iter;
	CGessGuard guard(m_mutexTbl);
	for( iter = m_vecQuoation.begin(); iter != m_vecQuoation.end(); ++iter)
	{
		if((*iter).nIndex == nIndex)
		{
			(*iter).dlNowPrice = dlPrice;
			nRtn = 0;
			break;
		}
	}
	return nRtn;

}

//##ModelId=4913F6A502FD
int CQuotationTbl::SetUpLimitPrice(const string& sProdID,double dlPrice)
{
	int nRtn = -1;
	vector<PROD_QUOTATION>::iterator iter;
	CGessGuard guard(m_mutexTbl);
	for( iter = m_vecQuoation.begin(); iter != m_vecQuoation.end(); ++iter)
	{
		if((*iter).sProdCode == sProdID)
		{
			(*iter).dlUpLimit = dlPrice;
			nRtn = 0;
			break;
		}		
	}
	return nRtn;
}

//##ModelId=491525E5029F
int CQuotationTbl::SetUpLimitPrice(int nIndex,double dlPrice)
{
	int nRtn = -1;
	vector<PROD_QUOTATION>::iterator iter;
	CGessGuard guard(m_mutexTbl);
	for( iter = m_vecQuoation.begin(); iter != m_vecQuoation.end(); ++iter)
	{
		if((*iter).nIndex == nIndex)
		{
			(*iter).dlUpLimit = dlPrice;
			nRtn = 0;
			break;
		}		
	}
	return nRtn;
}

//##ModelId=491525F901D4
int CQuotationTbl::SetDownLimitPrice(const string& sProdID,double dlPrice)
{
	int nRtn = -1;
	vector<PROD_QUOTATION>::iterator iter;
	CGessGuard guard(m_mutexTbl);
	for( iter = m_vecQuoation.begin(); iter != m_vecQuoation.end(); ++iter)
	{
		if((*iter).sProdCode == sProdID)
		{
			(*iter).dlDownLimit = dlPrice;
			nRtn = 0;
			break;
		}		
	}
	return nRtn;
}

//##ModelId=49152607007D
int CQuotationTbl::SetDownLimitPrice(int nIndex,double dlPrice)
{
	int nRtn = -1;
	vector<PROD_QUOTATION>::iterator iter;
	CGessGuard guard(m_mutexTbl);
	for( iter = m_vecQuoation.begin(); iter != m_vecQuoation.end(); ++iter)
	{
		if((*iter).nIndex == nIndex)
		{
			(*iter).dlDownLimit = dlPrice;
			nRtn = 0;
			break;
		}		
	}
	return nRtn;
}

//##ModelId=49152927003E
int CQuotationTbl::GetPriceArray(vector<double> & dlPrice)
{
	int i=0;
	CGessGuard guard(m_mutexTbl);
	dlPrice.clear();
	for(vector<PROD_QUOTATION>::iterator iter = m_vecQuoation.begin(); iter != m_vecQuoation.end(); ++iter)
	{
		/*if (iter->nIndex >= 0 && iter->nIndex < nSize)
			dlPrice[iter->nIndex] = iter->dlNowPrice;*/
		dlPrice.push_back(iter->dlNowPrice);

	}
	return 0;
}

//##ModelId=49152927003E
vector<double>  CQuotationTbl::GetPriceArray()
{
	int i=0;
	//��Ϊ��ʼ��ʱ m_vecQuoation �Ѿ���nIndex�������Դ˴�ֱ�Ӱ�m_vecQuoation���뵽t_PriceArray
	vector<double> t_PriceArray; 
	CGessGuard guard(m_mutexTbl);
	for(vector<PROD_QUOTATION>::iterator iter = m_vecQuoation.begin(); iter != m_vecQuoation.end(); ++iter)
	{
	//	if (iter->nIndex >= 0 && iter->nIndex < nSize)
			t_PriceArray.push_back(iter->dlNowPrice);
			/*dlPrice[iter->nIndex] = iter->dlNowPrice;*/
	}
	return t_PriceArray;
}

//��ʼʼ����Լ�۸� 
vector<double> CQuotationTbl::GetInitPriceArray()
{	
	CGessGuard guard(m_mutexTbl);

	vector<double> t_PriceArray; 
	for(int i=0;i<(int)m_vecQuoation.size();i++)
	{
		t_PriceArray.push_back(0.0);
	}
	return t_PriceArray;	
}


//���ݺ�Լ�����ȡ��Լ������

int CQuotationTbl::GetIndexValue(const string sProdID,int & nIndex)
{
	int nRtn = -1;
	vector<PROD_QUOTATION>::iterator iter;
	CGessGuard guard(m_mutexTbl);
	for( iter = m_vecQuoation.begin(); iter != m_vecQuoation.end(); ++iter)
	{
		if((*iter).sProdCode == sProdID)
		{
			nIndex=(*iter).nIndex;
			nRtn = 0;
			break;
		}		
	}
	return nRtn;
	
}
//##ModelId=49163867007D
int CQuotationTbl::GetQuotation(const string& sProdID, PROD_QUOTATION& stQuotation)
{
	int nRtn = -1;
	vector<PROD_QUOTATION>::iterator iter;
	CGessGuard guard(m_mutexTbl);
	for( iter = m_vecQuoation.begin(); iter != m_vecQuoation.end(); ++iter)
	{
		if((*iter).sProdCode == sProdID)
		{
			stQuotation = *iter;
			nRtn = 0;
			break;
		}		
	}
	return nRtn;
}

//##ModelId=491B9C1D0232
int CQuotationTbl::GetQuotation(int nIndex, PROD_QUOTATION& stQuotation)
{
	int nRtn = -1;
	vector<PROD_QUOTATION>::iterator iter;
	CGessGuard guard(m_mutexTbl);
	for( iter = m_vecQuoation.begin(); iter != m_vecQuoation.end(); ++iter)
	{
		if((*iter).nIndex == nIndex)
		{
			stQuotation = *iter;
			nRtn = 0;
			break;
		}		
	}
	return nRtn;
}

int CQuotationTbl::GetQuotation(const string& sProdID,double& dlNowprice)
{
	int nRtn = -1;
	vector<PROD_QUOTATION>::iterator iter;
	CGessGuard guard(m_mutexTbl);
	for( iter = m_vecQuoation.begin(); iter != m_vecQuoation.end(); ++iter)
	{
		if((*iter).sProdCode == sProdID)
		{
			dlNowprice = iter->dlNowPrice;
			return 0;
		}			
	}
	return nRtn;
}


//��ȡ��Լ��Ӧ�Ľ����;
int CQuotationTbl::GetSettlePrice(const string& sProdID,double & dlSettlePrice)
{
	CGessGuard guard(m_mutexTbl);
	map<string,double>::iterator it = m_mapSettlePrice.find(sProdID);
	if( it != m_mapSettlePrice.end())
	{
		dlSettlePrice = it->second;
		return 0;
	}
	return -1;
}
//##ModelId=491638A10177
void CQuotationTbl::SetQuotation(const string& sProdID, const PROD_QUOTATION& stQuotation)
{
	int nRtn = -1;
	vector<PROD_QUOTATION>::iterator iter;
	CGessGuard guard(m_mutexTbl);
	for( iter = m_vecQuoation.begin(); iter != m_vecQuoation.end(); ++iter)
	{
		if((*iter).sProdCode == sProdID)
		{
			int nIndex = (*iter).nIndex;
			*iter = stQuotation;
			(*iter).nIndex = nIndex;
			nRtn = 0;
			break;
		}		
	}
}

//##ModelId=491B9C10036B
void CQuotationTbl::SetQuotation(int nIndex, const PROD_QUOTATION& stQuotation)
{
	int nRtn = -1;
	vector<PROD_QUOTATION>::iterator iter;
	CGessGuard guard(m_mutexTbl);
	for( iter = m_vecQuoation.begin(); iter != m_vecQuoation.end(); ++iter)
	{
		if((*iter).nIndex == nIndex)
		{
			*iter = stQuotation;
			(*iter).nIndex = nIndex;
			nRtn = 0;
			break;
		}		
	}
}

//##ModelId=4916CB8F0196
int CQuotationTbl::Init(CProdCodeTbl& ProdCodeTbl, CBasicParaTbl &BasicParaTbl, otl_connect& dbConnection)
{
	PROD_QUOTATION stProdQuotation;		//ʵʱ����ṹ
	string sSql = "";


	char cExchDate[10];
	
	map<string,PROD_CODE> mapProd;
	map<string,PROD_CODE>::iterator it;

	vector<PROD_QUOTATION> t_vecQuoation;

	ProdCodeTbl.GetRecordSet(mapProd);

	double dlSettlePrice;  // �����
	double dlClosePrice;   // ���̼�

	try
	{
		CGessGuard guard(m_mutexTbl);
		sSql = "select settle_price,close_price,exch_date from prod_settle_price where exch_date < :f1<char[9]> and settle_price != 0 and prod_code = :f2<char[11]> order by exch_date desc";
		otl_stream oProdMarket(1, sSql.c_str(), dbConnection);

		for (it = mapProd.begin(); it != mapProd.end(); ++it)
		{
			stProdQuotation.sProdCode = it->second.sProdCode;
			stProdQuotation.nIndex = ProdCodeTbl.Index(stProdQuotation.sProdCode);

			oProdMarket << BasicParaTbl.GetExchDate().c_str() << stProdQuotation.sProdCode.c_str();
			if (!oProdMarket.eof())
			{
				oProdMarket >> dlSettlePrice >> dlClosePrice >>  cExchDate;

				stProdQuotation.dlNowPrice = dlSettlePrice;
				stProdQuotation.sExch_date.assign(cExchDate);
				stProdQuotation.dlUpLimit = stProdQuotation.dlNowPrice + stProdQuotation.dlNowPrice * it->second.dlUpLimitRatio;
				stProdQuotation.dlDownLimit = stProdQuotation.dlNowPrice - stProdQuotation.dlNowPrice * it->second.dlDownLimitRatio;
				stProdQuotation.dlUpLimit1 = stProdQuotation.dlUpLimit;
				stProdQuotation.dlDownLimit1 = stProdQuotation.dlDownLimit;
				m_mapSettlePrice[stProdQuotation.sProdCode] = stProdQuotation.dlNowPrice;
			}
			else
			{
				stProdQuotation.dlNowPrice = 0.00f;
				stProdQuotation.sExch_date = "";
				stProdQuotation.dlUpLimit = 0.0;
				stProdQuotation.dlDownLimit = 0.0;
				stProdQuotation.dlUpLimit1 = 0.0;
				stProdQuotation.dlDownLimit1 = 0.0;
			}
			
			stProdQuotation.dlBid1 = 0.0;
			stProdQuotation.dlAsk1 = 0.0;
			stProdQuotation.dlBid5 = 0.0;
			stProdQuotation.dlAsk5 = 0.0;

			t_vecQuoation.push_back(stProdQuotation);
		}
		InitK(t_vecQuoation, ProdCodeTbl);

		//nIndex ���Դ�0��ʼ
		//��m_vecQuoation����Ʒ��������

		//�˴��ر�˵������ɾ������Ҫ�ǰ��� ��Լ������ ���򣬱�֤������ȡ����ʱҲ�ǰ���Լ����
		vector<PROD_QUOTATION>::iterator itVec;
		for(int i=0;i< (int)t_vecQuoation.size();i++)
		{
			for(itVec=t_vecQuoation.begin();itVec!=t_vecQuoation.end();++itVec)
			{
				if(itVec->nIndex==i)
				{
					m_vecQuoation.push_back(*itVec);
					break;
				}
			}
		}
		t_vecQuoation.clear();

		return 0;
	}
	catch(otl_exception &p)
	{
		CRLog(E_ERROR, "DB:MSG:%s\nTEXT:%s\nVARINFO:%s", p.msg, p.stm_text, p.var_info); 
		return -1;
	}
	catch(...)
	{
		CRLog(E_ERROR,"%s", "Unknown exception");
		return -1;
	}
}

// ��ʼ������ṹ�е�K����Ϊ�Ǹ���������໥��ϵ�����Ա�����Init֮��
// ��Ϊû�б��۵�λ���������Ŀǰֻ����Au(T+D)����Ag(T+D)Ϊ��׼��Au(T+D)�ı��۵�λΪ1�ˣ�Ag(T+D)�ı��۵�λΪ1000��
// add by liuwei 2012-3-22
void CQuotationTbl::InitK(vector<PROD_QUOTATION>& v, CProdCodeTbl& p)
{
	double dlBasePrice;

	vector<PROD_QUOTATION>::iterator it;
	for (it = v.begin(); it != v.end(); ++it)
	{
		if ((*it).sProdCode == "Ag(T+D)")
		{
			dlBasePrice = (*it).dlNowPrice;
			break;
		}
	}

	map<string, PROD_CODE> mapProd;
	p.GetRecordSet(mapProd);
	map<string, PROD_CODE>::iterator itProd;
	for (itProd = mapProd.begin(); itProd != mapProd.end(); ++itProd)
	{
		for (it = v.begin(); it != v.end(); ++it)
		{
			if (it->sProdCode == itProd->first)
			{
				if (itProd->second.nVarietyType == gc_nAg)
				{
					itProd->second.dlK = it->dlNowPrice / dlBasePrice;
				}
				else
				{
					itProd->second.dlK = it->dlNowPrice * 1000 / dlBasePrice;
				}
				FRound(itProd->second.dlK);
				p.SetProdInfo(itProd->first, itProd->second);
				break;
			}
		}
	}
}

//���浱ǰ��ԼƷ�ֵĳ���ʱ��
void CQuotationTbl::AddQuotation(const string& sProdID)
{
	CGessGuard guard(m_mutexTbl);
	map<string,CGessTime>::iterator it = m_mapProdTime.find(sProdID);
	if( it !=m_mapProdTime.end())
	{
		return;
	}
	else
	{
		// ��ȡϵͳ��ǰ����ʱ��
		time_t tmNow;
		time(&tmNow);
		struct tm stTime;
		localtime_r(&tmNow,&stTime);
		CGessTime t_CurTime=CGessTime( stTime.tm_hour,stTime.tm_min,stTime.tm_sec);
		m_mapProdTime[sProdID] = t_CurTime;
		CRLog(E_APPINFO, "����ƥ�䵱ǰʱ���:[%s]",t_CurTime.ToString(":").c_str());
	}
	
}

//��ȡ��ǰ��ԼƷ�ֵĳ���ʱ��
map<string ,CGessTime> CQuotationTbl::GetQuotationTimeMap()
{
	CGessGuard guard(m_mutexTbl);
	return m_mapProdTime;
}

//ɾ��ָ����ԼƷ�ֵĻ���
int CQuotationTbl::DelQuotationTime(const string& sProdID)
{
	CGessGuard guard(m_mutexTbl);
	map<string,CGessTime>::iterator it = m_mapProdTime.find(sProdID);
	if( it != m_mapProdTime.end())
	{
		m_mapProdTime.erase(it);
		return 0;
	}
	return -1;
}


//�ֻ���������������ˢ��ʱ������¼��㻺��ʱ��
void CQuotationTbl::AddSpotQuotation(const string& sProdID)
{
	CGessGuard guard(m_mutexTbl);
	// ��ȡϵͳ��ǰ����ʱ��
	time_t tmNow;
	time(&tmNow);
	struct tm stTime;
	localtime_r(&tmNow,&stTime);
	CGessTime t_CurTime=CGessTime( stTime.tm_hour,stTime.tm_min,stTime.tm_sec);
	m_mapProdTime[sProdID] = t_CurTime;
	CRLog(E_APPINFO, "�ֻ�[%s]�������������ʹ�ϵ��ǰʱ���:[%s]",sProdID.c_str(),t_CurTime.ToString(":").c_str());

}

//��������
void CQuotationTbl::Finish()
{
	CGessGuard guard(m_mutexTbl);
	m_vecQuoation.clear();
	m_mapProdTime.clear();
	m_mapSettlePrice.clear();
}