#include "FpProdCodeTbl.h"
#include "Logger.h"
//#include "otlv4.h"
#include "DB_Version.h" 
#include "strutils.h"

using namespace strutils;
CFpProdCodeTbl::CFpProdCodeTbl()
{

}
CFpProdCodeTbl::~CFpProdCodeTbl()
{
	Finish();
}

//���������ݿ��ʼ��
int CFpProdCodeTbl::Init(otl_connect& dbConnection, const string &sDate )
{
	char cProdCode[21];
	char cGameId[11];
	int nRoundId = 0;
	double dlPrice;
	string sSql = "";

	memset(cProdCode,0x00,sizeof(cProdCode));
	memset(cGameId,0x00,sizeof(cGameId));


	try
	{
		//���������̶���
		CRLog(E_DEBUG, "loading fp_prod_code_def info[%s]"," ......");

		//�����걨��ˮ
		sSql = "select a.prod_code, b.game_id, b.round_id, b.amend_price \
			from fp_prod_code_def a,fp_round b \
			where b.exch_date = '"+sDate+"' \
			and b.prod_code = a.prod_code \
			and a.inst_exch_stat not in ('a', 'b')";
		otl_stream o(1,sSql.c_str(),dbConnection);

		while (!o.eof())
		{
			o >> cProdCode >> cGameId >> nRoundId >> dlPrice;

			FpProdCode stProd;
			stProd.m_sProdCode = cProdCode;
			stProd.m_sGameId = cGameId;
			stProd.m_nRoundId = nRoundId;
			stProd.m_dlPrice = dlPrice;

			m_mapFpProdCode[stProd.m_sProdCode+stProd.m_sGameId+ToString(stProd.m_nRoundId)] = stProd;
		}

		
	}
	catch(otl_exception& p)
	{
		CRLog(E_ERROR, "otl exception:%s,%s,%s,%s", p.msg, p.stm_text, p.sqlstate, p.var_info);
	}

	return 0;
}

//��������
void CFpProdCodeTbl::Finish()
{
	CGessGuard guard(m_mutexTbl);
	m_mapFpProdCode.clear();
}

//ͨ����Լ��ȥ��ȡ��Լ��Ϣ
int CFpProdCodeTbl::GetFpProdCode(string stKey,FpProdCode& stProdInfo)
{
	CGessGuard guard(m_mutexTbl);

	map<string,FpProdCode>::iterator it = m_mapFpProdCode.find(stKey);
	if (it != m_mapFpProdCode.end())
	{
		stProdInfo = it->second;
	}
	else
	{
		return -1;
	}

	return 0;
}

//ͨ����Լ��ȥ��ȡ��Լ�۸�
int CFpProdCodeTbl::GetFpProdPrice(string stKey,double& dlPrice)
{
	CGessGuard guard(m_mutexTbl);

	map<string,FpProdCode>::iterator it = m_mapFpProdCode.find(stKey);
	if (it != m_mapFpProdCode.end())
	{
		dlPrice= it->second.m_dlPrice;
	}
	else
	{
		return -1;
	}

	return 0;
}
//���º�Լ��Ϣ
void CFpProdCodeTbl::UpdateProdCode(string stKey,FpProdCode stProdInfo)
{
	CGessGuard guard(m_mutexTbl);

	map<string,FpProdCode>::iterator it = m_mapFpProdCode.find(stKey);
	if (it != m_mapFpProdCode.end())
	{
		it->second = stProdInfo;
	}
	else
	{
		m_mapFpProdCode[stKey] = stProdInfo;
	}
}

bool CFpProdCodeTbl::IsHandled(const string& sKey,const string& sProdCode)
{
	bool blRtn = false;

	CGessGuard guard(m_mutexTbl);
	if (m_mapFpQutation.find(sKey) != m_mapFpQutation.end())
	{
		blRtn = true;
	}
	else
	{
		m_mapFpQutation[sKey] = sProdCode;
		blRtn = false;
	}

	return blRtn;
}


//��ȫ���Ͳ����걨ʣ�೷�����ĵ�����
bool CFpProdCodeTbl::IsCancle(string sProdCode,string sGameId,int nRoundId)
{
	CGessGuard guard(m_mutexTbl);

	bool blRtn = false;
	string sKey = sProdCode + sGameId + ToString(nRoundId);

	map<string,int>::iterator itCancle = m_mapFpCancle.find(sKey);
	if(itCancle != m_mapFpCancle.end())
	{
		blRtn = true;
	}
	else
	{
		blRtn = false;
		m_mapFpCancle[sKey] = 1;
	}

	return blRtn;
}