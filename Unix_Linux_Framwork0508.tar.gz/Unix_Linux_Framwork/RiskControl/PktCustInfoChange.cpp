#include "RiskHandler.h"
#include "RiskNotify.h"
#include "RiskConstant.h"

#define FLAG_ADD		1
#define FLAG_UPDATE		2
#define FLAG_DEL		3

using namespace RiskConst;

// A1 �ӿ� [onCustInfoChange]CustInfoChange ��ҵ��ʵ��
int CRiskHandler::OnCustInfoChange(CBroadcastPacket& pkt)
{
	CustInfoChange stBody;
	CPacketStructBroadcastRisk::Packet2Struct(stBody, pkt);

	//ҵ��ʵ��......
	SendAck(pkt);
	CRLog(E_APPINFO,"OnCustInfoChange, %d %s %s %s %s %s %s %s\n",stBody.update_flag, stBody.acct_no.c_str(), stBody.cust_abbr.c_str(),stBody.b_Fare_model_id.c_str(),stBody.m_Fare_model_id.c_str(),stBody.acct_stat.c_str(),stBody.acct_type.c_str(),stBody.branch_ID.c_str());
	if (stBody.update_flag == FLAG_ADD)
	{
		
	}
	else if (stBody.update_flag == FLAG_UPDATE)
	{
		CCustomer* p = FindCustomer(stBody.acct_no);
		if (!p)
			return -1;

		int nAcctState = FromString<int>(stBody.acct_stat);
		if (gc_nAcctStateNormal != nAcctState)
		{
			p->UpdateAcctState(nAcctState);
			CRLog(E_APPINFO,"�ʻ�״̬�ı�Ϊ������״̬:%d!",nAcctState);
			return 0;
		}
		else if (gc_nAcctStateNormal == nAcctState && gc_nAcctStateNormal != p->GetAcctState())
		{
			p->UpdateAcctState(nAcctState);
			CRLog(E_APPINFO,"�ʻ�״̬�ָ�����״̬:%d!",nAcctState);
			return 0;
		}

		
		CRLog(E_APPINFO,"����ģ����:%s %s!",stBody.b_Fare_model_id.c_str(),stBody.m_Fare_model_id.c_str());
		CustRiskInfo oCustRiskInfo;
		int nRtn = p->OnCustInfo(stBody.cust_abbr,stBody.b_Fare_model_id,stBody.m_Fare_model_id,oCustRiskInfo);
		if (nRtn == gc_cStateNormal)
		{
		}
		else if (nRtn == gc_cStateValueChange)
		{
			//����е���֪ͨ
			m_pRiskNotify->Enque(oCustRiskInfo);
		}
		else if (nRtn == gc_cStateRiskTransfer)
		{
			//����е���֪ͨ
			m_pRiskNotify->Enque(oCustRiskInfo);
		}
		else
		{

		}

		p->UpdateAgentBalanceStat();
		p->UpdateAgentDebtStat();
	}
	else if (stBody.update_flag == FLAG_DEL)
	{
		
	}
	else
	{

	}

	return 0;
};
// A1 �ӿ� [onCustCancelNotify]�ͻ�������ҵ��ʵ��
int CRiskHandler::onCustCancelNotify(CBroadcastPacket& pkt)
{

	CustCancelNotify stBody;
	CPacketStructBroadcastRisk::Packet2Struct(stBody, pkt);
	
	//ҵ��ʵ��......
	SendAck(pkt);	
	CRLog(E_APPINFO,"onCustCancelNotify, cancel_sys_date=%s,acct_no=%s\n",stBody.cancel_sys_date.c_str(), stBody.acct_no.c_str());

	if(0 != m_pMemDb->GetCustTble().DelRec(stBody.acct_no))
	{
		CRLog(E_APPINFO,"onCustCancelNotify, acct_no=%s  ʧ��!\n",stBody.acct_no.c_str());
		return -1;
	}
	return 0;
}
