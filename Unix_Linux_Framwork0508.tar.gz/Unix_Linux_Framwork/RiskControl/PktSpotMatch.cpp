#include "RiskHandler.h"

// A1 �ӿ� [onRecvRtnSpotMatch]SpotMatch ��ҵ��ʵ��
int CRiskHandler::OnSpotMatch(CBroadcastPacket& pkt)
{
	SpotMatch stBody;
	CPacketStructBroadcastRisk::Packet2Struct(stBody, pkt);	

	//ҵ��ʵ��......
	SendAck(pkt);

	CCustomer* p = FindCustomer(stBody.acctNo);
	if (!p)
		return -1;

	std::string sKey = stBody.matchNo + stBody.orderNo;
	CMatchDetailTbl& tblMatch = m_pMemDb->GetMatchDetailTbl();
	if (tblMatch.IsHandled(sKey,stBody.acctNo))
		return -1;

	CRLog(E_APPINFO,"OnSpotMatch %s %c %s %d %f %s\n",stBody.acctNo.c_str(),stBody.buyOrSell,stBody.instID.c_str(),stBody.volume,stBody.price,sKey.c_str());

	CustRiskInfo oCustRiskInfo;
	int nType = 0;
	m_pMemDb->GetProdCodeTbl().GetVarietyType(stBody.instID,nType);
	double dlUnit = GetMeasureUnit(stBody.instID);

	int nRtn = gc_cStateNormal;
	
	//ĿǰΪ��֤���ͻ����������һ�� �ֻ������ۼ�10%��̱��� ������һ��
	if (gc_nAu == nType)
	{
		CSpotAuMatch pSpotMatch = CSpotAuMatch(m_dlSpotSellFrozenRatio,stBody.instID,nType,stBody.buyOrSell,stBody.price,stBody.volume,dlUnit);
		nRtn = p->OnRtnMatchSpot(pSpotMatch,oCustRiskInfo);
	}
	else if (gc_nAg == nType)
	{
		CSpotAgMatch pSpotMatch = CSpotAgMatch(m_dlSpotSellFrozenRatio,stBody.instID,nType,stBody.buyOrSell,stBody.price,stBody.volume,dlUnit);
		nRtn = p->OnRtnMatchSpot(pSpotMatch,oCustRiskInfo);
	}
	else if (gc_nPt == nType)
	{
		//������̱������ʲ���ʱ� ĿǰΪ0.02
		double dlFeeVal = 0.02;
		//�����ж� �Ƿ����ÿͻ�������ʿ��� add by zengweiwei 2013-11-14
		if (CBasicParaTbl::GetIsUseSpecialControl()&&CBasicParaTbl::GetIsSpecialControlFareTypeId(gc_sPtMargin))
		{
			string sFeeModelEx("");
			string sFeeModelMem("");
			p->FeeModelID(sFeeModelEx,sFeeModelMem);
			m_pMemDb->GetFeeModelDetailTbl().GetFeeVal(sFeeModelEx,stBody.instID,gc_sPtMargin,dlFeeVal);
		}
		else
		{
			if (0 != m_pMemDb->GetCustFeeDetailTbl().GetFeeVal(stBody.acctNo,stBody.instID,gc_sPtMargin,dlFeeVal))
			{
				string sFeeModelEx("");
				string sFeeModelMem("");
				p->FeeModelID(sFeeModelEx,sFeeModelMem);
				m_pMemDb->GetFeeModelDetailTbl().GetFeeVal(sFeeModelEx,stBody.instID,gc_sPtMargin,dlFeeVal);
			}
		}
		CSpotPtMatch pSpotMatch = CSpotPtMatch(dlFeeVal,m_dlSpotSellFrozenRatio,stBody.instID,nType,stBody.buyOrSell,stBody.price,stBody.volume,dlUnit);
		nRtn = p->OnRtnMatchSpot(pSpotMatch,oCustRiskInfo);
	}
	else
	{
		CRLog(E_APPINFO,"Unknkown Spot Type:%d",nType);
		return -1;
	}

	if (nRtn == gc_cStateNormal)
	{
	}
	if (nRtn == gc_cStateValueChange)
	{
		//����� 
		m_pRiskNotify->Enque(oCustRiskInfo);
	}
	if (nRtn == gc_cStateRiskTransfer)
	{
		//����� 
		m_pRiskNotify->Enque(oCustRiskInfo);
	}

	p->UpdateAgentBalanceStat();
	p->UpdateAgentDebtStat();

	return 0;
};
