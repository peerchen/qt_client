#include "VersionMacro.h"
#if defined(_VER_DREB)
#include "DrebMain.h"
#else
#include "RiskMain.h"
#endif

int main(int argc, char* argv[])
{
	int nRet = 0;
#if defined(_VER_DREB)
	CDrebMain funMain;
	nRet = funMain.Run(argc,argv);
#else
	CRiskMain  funMain;
	nRet = funMain.Run(argc,argv);
#endif

	return nRet;
}

