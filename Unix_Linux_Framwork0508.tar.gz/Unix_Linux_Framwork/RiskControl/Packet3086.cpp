#include "MainServiceHandler.h"
#include "Logger.h"

// F1 �ӿ� [3086]�������ñ��� ��ҵ��ʵ��
int CMainServiceHandler::OnBranchAuthParaReq(CTradePacket& pkt)
{
	HEADER_REQ stHeaderReq;
	BranchAuthParaReq stBodyReq;

	HEADER_RSP stHeaderRsp;
	BranchAuthParaRsp stBodyRsp;

	pkt.GetHeader(stHeaderReq);
	CPacketStructTradeRisk::Packet2Struct(stBodyReq, pkt);

	//ҵ��ʵ��......
	CTradePacket pktRsp;
	CPacketStructTradeRisk::HeadReq2Rsp(stHeaderReq,stHeaderRsp);
	
	char cBranchId[7];			//��������ID
	char cBranchName[51];		//������������
	char cForceCovRight[3];		//ǿƽȨ��
	string sSql = "";
	ArrayListMsg almResultTemp;

	memset(cBranchId, 0, sizeof(cBranchId));
	memset(cForceCovRight, 0, sizeof(cForceCovRight));

	try
	{
		//���Ĵ���		0����ѯ		1���޸�
		if (stBodyReq.oper_flag == 0)
		{
			sSql = "select branch_id, branch_name, force_cov_right from branch_info";

			otl_stream o(1, sSql.c_str(), GetOtlConn());
			while (!o.eof())
			{
				o >> cBranchId >> cBranchName >> cForceCovRight;
				cout << cBranchId << "---" << cBranchName << "---" << cForceCovRight;
				almResultTemp.clear();
				almResultTemp.AddValue(cBranchId);
				almResultTemp.AddValue(cBranchName);
				almResultTemp.AddValue(cForceCovRight);

				stBodyRsp.branch_set.AddValue(almResultTemp);
			}
		}
		else if (stBodyReq.oper_flag == 1)
		{
			sSql = "update branch_info set force_cov_right = :f1<char[2]> where branch_id = :f2<char[7]>";

			otl_stream o(1, sSql.c_str(), GetOtlConn());
			for (size_t i=0; i<stBodyReq.branch_set.size(); i++)
			{
				almResultTemp.clear();
				stBodyReq.branch_set.GetValue(i, almResultTemp);
				
				o << almResultTemp.GetValue<string>(1).c_str() << almResultTemp.GetValue<string>(0).c_str();
			}
		}
	}
	catch(otl_exception& p)
	{
		CRLog(E_ERROR, "DB:MSG:%s\nTEXT:%s\nVARINFO:%s", p.msg, p.stm_text, p.var_info); 
		Rollback();
		strcpy(stHeaderRsp.rsp_code, RSP_EXCEPTION.c_str());
		pktRsp.AddParameter("rsp_msg", (const char *)p.msg);
	}

	//������Ӧ����
	stBodyRsp.oper_flag = stBodyReq.oper_flag;

	pktRsp.SetHeader(stHeaderRsp);
	CPacketStructTradeRisk::Struct2Packet(stBodyRsp,pktRsp);

	//ת������
	m_pRiskCpMgr->ToInterfaceF1(pktRsp,m_ulKey);

	return 0;
};
