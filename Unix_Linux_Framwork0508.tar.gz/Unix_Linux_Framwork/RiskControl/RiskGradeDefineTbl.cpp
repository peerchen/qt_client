#include "RiskGradeDefineTbl.h"

CRiskGradeDefineTbl::CRiskGradeDefineTbl()
{

}

CRiskGradeDefineTbl::~CRiskGradeDefineTbl()
{
	Finish();
}

//##ModelId=491AF57C030D
int CRiskGradeDefineTbl::GetRiskGrade(unsigned short usGradeID, RISK_GRADE_DEFINE& stRiskGrade)
{
	CGessGuard guard(m_mutexTbl);
	for(vector<RISK_GRADE_DEFINE>::iterator iter = m_vecRiskGradeDef.begin(); iter != m_vecRiskGradeDef.end(); ++iter){
		if((iter->usGradeID)==usGradeID){
			stRiskGrade = *iter;
			return 0;
		}
	}
	return -1;
}

//##ModelId=491AFA900109
int CRiskGradeDefineTbl::UpdateRiskGrade(unsigned short usGradeID, RISK_GRADE_DEFINE& stRiskGrade)
{
	CGessGuard guard(m_mutexTbl);
	for(vector<RISK_GRADE_DEFINE>::iterator iter = m_vecRiskGradeDef.begin(); iter != m_vecRiskGradeDef.end(); ++iter){
		if((iter->usGradeID)==usGradeID){
			*iter = stRiskGrade;
			return 0;
		}
	}
	return -1;
}

//##ModelId=491B042A007D
int CRiskGradeDefineTbl::Init(otl_connect& dbConnection)
{
	return 0;
}

//��������
void CRiskGradeDefineTbl::Finish()
{
	CGessGuard guard(m_mutexTbl);
	m_vecRiskGradeDef.clear();
}

