#include "RiskHandler.h"

// A1 �ӿ� [onRecvRtnDeferDeliveryAppMatch]DeferDeliveryAppMatch ��ҵ��ʵ��
int CRiskHandler::OnDeferDeliveryAppMatch(CBroadcastPacket& pkt)
{
	DeferDeliveryAppMatch stBody;
	CPacketStructBroadcastRisk::Packet2Struct(stBody, pkt);

	//ҵ��ʵ��......
	SendAck(pkt);

	return 0;
};
