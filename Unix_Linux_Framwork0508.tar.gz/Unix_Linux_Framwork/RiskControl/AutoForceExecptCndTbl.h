#ifndef CTRIGGERTBL_H_HEADER_INCLUDED_B6E3ACAA_WB
#define CTRIGGERTBL_H_HEADER_INCLUDED_B6E3ACAA_WB
#include <string>
#include <map>
#include <vector>
#include "Gess.h"
#include "DB_Version.h" 
#include "GessTime.h"
#include "GessDateTime.h"

using namespace std;
class otl_connect;
class CGessDateTime;

class CAutoForceExecptCndTbl
{//�Զ�ǿƽ�����������ñ�
public:
	CAutoForceExecptCndTbl();
	~CAutoForceExecptCndTbl();

	//���������ݿ��ʼ��
	int Init(otl_connect& dbConnection);
	void Finish();
	int ReInit(otl_connect& dbConnection);

	int GetCustomeridMap(map<std::string,CGessDateTime>& tm_Customer)const;
	int GetCustomerLevelMap(map<std::string,CGessDateTime>& tm_CustomerLevel)const;
	int GetAcountTypeMap(map<std::string,CGessDateTime>& tm_AcountType)const;
	int GetBrandidMap(map<std::string,CGessDateTime>& tm_Brandid)const;

	bool GetCustExceptType(std::string sCustNo,std::string cCustLevel,std::string sBrandid,std::string sAcctType,CGessDate & sTradeDate,std::string & sExceptDateTime) const;
	bool GetCustExceptType(std::string sCustNo,std::string cCustLevel,std::string sBrandid,std::string sAcctType,std::string & sExceptDateTime) const;
private:

	map<std::string,CGessDateTime> m_Customerid;//�ͻ���
	map<std::string,CGessDateTime> m_CustomerLevel;//�ͻ�����
	map<std::string,CGessDateTime> m_AcountType;//�˻�����
	map<std::string,CGessDateTime> m_Brandid;//��������ID

	mutable CGessMutex  m_mutexTbl;
};
#endif /* CTRIGGERTBL_H_HEADER_INCLUDED_B6E3ACAA_WB */
