#include "SmsFormatTbl.h"
#include "DB_Version.h" 
#include "Logger.h"
//#include "VersionMacro.h"

CSmsFormatTbl::CSmsFormatTbl()
{

}

CSmsFormatTbl::~CSmsFormatTbl()
{
	Finish();
}

int CSmsFormatTbl::Init(otl_connect& dbConnection)
{

	char cAcct_Type[3];   //�˻�����
	char cRisk_Type[3];   //��������
	char cContent_fmt[2000+1];   //�������ݸ�ʽ
	string sKey="";
	string sSql = "";

	memset(cAcct_Type, 0, sizeof(cAcct_Type));
	memset(cRisk_Type, 0, sizeof(cRisk_Type));
    memset(cContent_fmt, 0, sizeof(cContent_fmt));

	CRLog(E_DEBUG, "loading RISK_SMS_NOTIFY_PARA info %s"," ......");
	try
	{
#ifdef _VER_25_DB2
		sSql = "SELECT FG_CovToChar(ACCT_TYPE) AS ACCT_TYPE,FG_CovToChar(RISK_TYPE) AS RISK_TYPE,SMS_CONTENT_FMT FROM RISK_SMS_NOTIFY_PARA";
#else
		sSql = "SELECT to_char(ACCT_TYPE) AS ACCT_TYPE,to_char(RISK_TYPE) AS RISK_TYPE,SMS_CONTENT_FMT FROM RISK_SMS_NOTIFY_PARA";
#endif

		otl_stream o(1, sSql.c_str(), dbConnection);

		CGessGuard guard(m_mutexTbl);
		while (!o.eof())
		{

			memset(cAcct_Type, 0, sizeof(cAcct_Type));
			memset(cRisk_Type, 0, sizeof(cRisk_Type));
			memset(cContent_fmt, 0, sizeof(cContent_fmt));

			o >> cAcct_Type >> cRisk_Type >> cContent_fmt;
			sKey = string(cAcct_Type) + string(cRisk_Type);
			m_SmsFormatMap[sKey]=string(cContent_fmt);
		}
	}
	catch(otl_exception& p)
	{
		CRLog(E_ERROR,"otl exception:%s,%s,%s,%s",p.msg,p.stm_text,p.sqlstate,p.var_info);
	}
	catch(std::exception e)
	{
		CRLog(E_CRITICAL,"exception:%s", e.what());
		return -1;
	}
	catch(...)
	{
		CRLog(E_CRITICAL,"%s","Unknown exception");
		return -1;
	}
	return 0;
}


void CSmsFormatTbl::Finish()
{
	CGessGuard guard(m_mutexTbl);
	m_SmsFormatMap.clear();
}

int CSmsFormatTbl::ReInit(otl_connect& dbConnection)
{
	CGessGuard guard(m_mutexTbl);

	//��ռ���
	Finish();

	//��ʼ��
	Init(dbConnection);

	return 0;
}


int CSmsFormatTbl::GetSmsFormatMap(std::string sAcct_Type,std::string sRisk_Type,std::string & sSmsFormat) const
{
	CGessGuard guard(m_mutexTbl);

	std::string sKey="";

	sKey=sAcct_Type+sRisk_Type;

	map<std::string, std::string>::const_iterator it =m_SmsFormatMap.find(sKey);
	if(it != m_SmsFormatMap.end())
	{
		sSmsFormat = it->second;
		return 0;
	}
	return 1;
}
