#ifndef CRISKALGORITHM_H_HEADER_INCLUDED_B6E3BF1D
#define CRISKALGORITHM_H_HEADER_INCLUDED_B6E3BF1D

class CRiskAlgorithm
{
public:
	//���նȼ��㹫ʽ
	virtual double Risk(double dlCapital, double dlMarginMem, double dlBalance,double dlMarginExch) = 0;

};

#endif /* CRISKALGORITHM_H_HEADER_INCLUDED_B6E3BF1D */
