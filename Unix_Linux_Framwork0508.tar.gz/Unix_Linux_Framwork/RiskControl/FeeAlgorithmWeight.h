#ifndef CFEEALGORITHMWEIGHT_H_HEADER_INCLUDED_B6E38CDE
#define CFEEALGORITHMWEIGHT_H_HEADER_INCLUDED_B6E38CDE
#include "FeeAlgorithm.h"

class CFeeAlgorithmWeight : public CFeeAlgorithm
{
  public:
    //##ModelId=4916D64601C5
	  CFeeAlgorithmWeight(double dlUnit):m_dlUnit(dlUnit){}

    //##ModelId=4915BAC701D4
	  double Fee(double dlMatchCapital, double dlWeight, int nVolume){return dlWeight*m_dlUnit;}

  private:
    //##ModelId=4915BA6902CE
    double m_dlUnit;
};

#endif /* CFEEALGORITHMWEIGHT_H_HEADER_INCLUDED_B6E38CDE */
