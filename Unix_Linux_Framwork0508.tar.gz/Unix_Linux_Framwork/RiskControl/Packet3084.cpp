#include "MainServiceHandler.h"
#include "Logger.h"
#include "RiskTipParaTbl.h"

// F1 �ӿ� [3084]�������ñ��� ��ҵ��ʵ��
int CMainServiceHandler::OnRiskNotifyParaReq(CTradePacket& pkt)
{
	HEADER_REQ stHeaderReq;
	RiskNotifyParaReq stBodyReq;

	HEADER_RSP stHeaderRsp;
	RiskNotifyParaRsp stBodyRsp;

	pkt.GetHeader(stHeaderReq);
	CPacketStructTradeRisk::Packet2Struct(stBodyReq, pkt);

	//ҵ��ʵ��......
	CTradePacket pktRsp;
	CPacketStructTradeRisk::HeadReq2Rsp(stHeaderReq,stHeaderRsp);

	char cContent[2001];
	char cTipType[3];
	char cSrcGradeId[9];
	char cDesGradeId[9];
	string sSql = "";
	ArrayListMsg msg;
	memset(cContent, 0, sizeof(cContent));
	memset(cTipType, 0, sizeof(cTipType));
	memset(cSrcGradeId, 0, sizeof(cSrcGradeId));
	memset(cDesGradeId, 0, sizeof(cDesGradeId));
	strcpy(stHeaderRsp.rsp_code,RSP_SUCCESS.c_str());
	try
	{
		//���Ĵ���		0����ѯ		1���޸�
		if (stBodyReq.oper_flag == 0)
		{
			//��ѯ��ʾ����

#ifdef _VER_25_DB2
			sSql = "select  FG_CovToChar(tip_type),  FG_CovToChar(src_grade_id), FG_CovToChar(des_grade_id),tip_content from risk_notify_para ";
#else
			sSql = "select to_char(tip_type), to_char(src_grade_id),to_char(des_grade_id),tip_content from risk_notify_para ";
#endif
			
			otl_stream o(1, sSql.c_str(),  GetOtlConn());
			
			while(!o.eof())
			{
				o >>cTipType>>cSrcGradeId>>cDesGradeId>> cContent;
				msg.clear();
				msg.AddValue(cTipType);
				msg.AddValue(cSrcGradeId);
				msg.AddValue(cDesGradeId);
				msg.AddValue(cContent);
				stBodyRsp.notify_content_set.AddValue(msg);
			}
		}
		else if (stBodyReq.oper_flag == 1)
		{
			//�޸����ݿ���ʾ����
			sSql = "select tip_content from risk_notify_para where src_grade_id = :f1<int> and des_grade_id = :f2<int>";
			otl_stream oQuery(1, sSql.c_str(), GetOtlConn());
			oQuery << atoi(stBodyReq.risk_grade_src.c_str()) << atoi(stBodyReq.risk_grade_des.c_str());
			if (!oQuery.eof())
			{
				sSql = "update risk_notify_para set tip_content = :f1<varchar[2000]> where src_grade_id = :f2<int> and des_grade_id = :f3<int>";
				otl_stream oUpdate(1, sSql.c_str(), GetOtlConn());
				oUpdate << stBodyReq.notify_content << atoi(stBodyReq.risk_grade_src.c_str()) << atoi(stBodyReq.risk_grade_des.c_str());
			}
			else
			{
				sSql = "insert into risk_notify_para values(:f1<int>, :f2<varchar[2000]>, :f3<int>, :f4<int>)";
				otl_stream oInsert(1, sSql.c_str(), GetOtlConn());
				oInsert << atoi(stBodyReq.tip_type.c_str()) << stBodyReq.notify_content << atoi(stBodyReq.risk_grade_src.c_str()) << atoi(stBodyReq.risk_grade_des.c_str());
			}

			//�޸��ڴ��
			m_pMemDb->GetRiskTipParaTbl().SetRiskTip(atoi(stBodyReq.risk_grade_src.c_str()), atoi(stBodyReq.risk_grade_des.c_str()), stBodyReq.notify_content);
		}
	}
	catch(otl_exception& p)
	{
		CRLog(E_ERROR, "DB:MSG:%s\nTEXT:%s\nVARINFO:%s", p.msg, p.stm_text, p.var_info); 
		Rollback();
		strcpy(stHeaderRsp.rsp_code,RSP_EXCEPTION.c_str());
		pktRsp.AddParameter("rsp_msg", (const char *)p.msg);
	}

	//������Ӧ����
	stBodyRsp.oper_flag = stBodyReq.oper_flag;
	

	pktRsp.SetHeader(stHeaderRsp);
	CPacketStructTradeRisk::Struct2Packet(stBodyRsp,pktRsp);

	//ת������
	m_pRiskCpMgr->ToInterfaceF1(pktRsp,m_ulKey);

	return 0;
};
