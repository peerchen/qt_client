#include <sstream>
#include <iomanip>
#include "BasicParaTbl.h"
#include "DB_Version.h" 
#include "Logger.h"
#include "RiskConstant.h"
#include "GessDate.h"
#include "strutils.h"
#include "GessTime.h"
using namespace strutils;
int CBasicParaTbl::m_uiIsUseSpecialControl=0;
vector<string> CBasicParaTbl::m_vsSpecialControlFareTypeId;
CBasicParaTbl::CBasicParaTbl()
:m_dlVolatility(0.01)
,m_dlLimitPriceRatio(0.01)
,m_uiMaxForceOrderNo(0)
,m_uiIsTimerAutoForce(0)
,m_uiIsQuoteAuotForce(0)
{
	m_sExchDate = CGessDate::NowToString("");
}

CBasicParaTbl::~CBasicParaTbl()
{
	Finish();
}

//##ModelId=491A39330213
double CBasicParaTbl::GetVolatility()
{
	CGessGuard guard(m_mutexTbl);

	double dlVal = m_dlVolatility;
	return dlVal;
}

//##ModelId=491A48B402FD
void CBasicParaTbl::SetVolatility(double dlVolatility)
{
	CGessGuard guard(m_mutexTbl);

	m_dlVolatility = dlVolatility;
}

//ȡ�޼۸�������
double CBasicParaTbl::GetLimitPriceRatio()
{
	CGessGuard guard(m_mutexTbl);
	double dlRatio = m_dlLimitPriceRatio;
	return dlRatio;
}

//�����޼۸�������
void CBasicParaTbl::SetLimitPriceRatio(double dlLimitPriceRatio)
{
	CGessGuard guard(m_mutexTbl);
	m_dlLimitPriceRatio = dlLimitPriceRatio;
}

//ȡ��������
string CBasicParaTbl::GetExchDate()
{
	CGessGuard guard(m_mutexTbl);
	string sDate = m_sExchDate;
	return sDate;
}

//�轻������
void CBasicParaTbl::SetExchDate(const string& sDate)
{
	CGessGuard guard(m_mutexTbl);
	m_sExchDate = sDate;
}

//��ʱ����ǿƽ���� 1 ����  0 �ر�
int CBasicParaTbl::GetIsTimerAutoForce()
{
	CGessGuard guard(m_mutexTbl);
	return m_uiIsTimerAutoForce;
}

//���鴥���������� 1 ����  0 �ر�
int CBasicParaTbl::GetIsQuoteAuotForce()
{
	CGessGuard guard(m_mutexTbl);
	return m_uiIsQuoteAuotForce;

}

//�Զ�ǿƽ���ճ�������
int CBasicParaTbl::GetAutoForceRiskDay()
{
	CGessGuard guard(m_mutexTbl);
	return m_uiAutoForceDay;
}
//ȡ���ǿƽ����
string CBasicParaTbl::GetMaxForceOrderNo()
{
	unsigned int uiSeqNo = 0;
	CGessGuard guard(m_mutexTbl);
	m_uiMaxForceOrderNo++;
	uiSeqNo = m_uiMaxForceOrderNo;	

	stringstream ss;
	ss << "RISKM" << setw(10) << setfill('0') << uiSeqNo;

	return ss.str();
}

//##ModelId=491A4DD2002E
int CBasicParaTbl::Init(otl_connect& dbConnection)
{
	char cExchDate[9];		//��������
	char cCoverNo[16];		//���ǿƽ����
	char cCoverNotmp[9];
	string sSql = "";

	memset(cExchDate, 0, sizeof(cExchDate));
	memset(cCoverNo, 0, sizeof(cCoverNo));
	memset(cCoverNotmp, 0, sizeof(cCoverNotmp));

	try
	{
		char szVal[1024];


		//ϵͳ������ ȡ������
		sSql = "select para_value from system_para where para_id = '" + RiskConst::gc_sVolatility + "'";
		otl_stream oVol(1, sSql.c_str(), dbConnection);
		if (!oVol.eof())
		{
			memset(szVal,0x00,sizeof(szVal));
			oVol >> szVal;
			m_dlVolatility = atof(szVal);
		}

		//ϵͳ������ ȡ�޼�ί�и�������
		sSql = "select para_value from system_para where para_id = '" + RiskConst::gc_sLimitPriceRatio + "'";
		otl_stream oLimit(1, sSql.c_str(), dbConnection);
		if (!oLimit.eof())
		{
			memset(szVal,0x00,sizeof(szVal));
			oLimit >> szVal;
			m_dlLimitPriceRatio = atof(szVal);
		}
		//�Զ�ǿƽ���ճ�������
		sSql = "select para_value from system_para where para_id = '" + RiskConst::gc_sAutoForceDay + "'";
		otl_stream oForceDay(1, sSql.c_str(), dbConnection);
		if (!oForceDay.eof())
		{
			memset(szVal,0x00,sizeof(szVal));
			oForceDay >> szVal;
			m_uiAutoForceDay = atoi(szVal);
		}else
			m_uiAutoForceDay = 0;
		
		////����ƽ���������Ƿ���ݵ��ղֺ���ʷ�ַֿ����㣨1-ʹ�ã�0-��ʹ�ã�
		sSql = "select para_value from system_para where para_id = '" + RiskConst::gc_sIsDiffCovFareByCurrOrHis + "'";
		otl_stream oDiffCovFare(1, sSql.c_str(), dbConnection);
		if (!oDiffCovFare.eof())
		{
			memset(szVal,0x00,sizeof(szVal));
			oDiffCovFare >> szVal;
			m_uiDiffCovFareByCurrOrHis = atoi(szVal);
		}else
			m_uiDiffCovFareByCurrOrHis = 0;

		//�Ƿ����ÿͻ�������ʿ��� add by zengweiwei 2013-11-13
		sSql="select para_value from system_para where para_id='"+RiskConst::gc_sIsUseSpecialControl+"'";
		otl_stream oSpeControl(1, sSql.c_str(), dbConnection);
		if (!oSpeControl.eof())
		{
			memset(szVal,0x00,sizeof(szVal));
			oSpeControl >> szVal;
			m_uiIsUseSpecialControl = atoi(szVal);
		}else
			m_uiIsUseSpecialControl = 0;
		//���ÿͻ�������ʿ��Ƶķ�������ID
		if (m_uiIsUseSpecialControl==1)
		{
			m_vsSpecialControlFareTypeId.clear();
			sSql="select para_value from system_para where para_id='"+RiskConst::gc_sSpecialControlFareTypeId+"'";
			otl_stream oFareTypeId(1, sSql.c_str(), dbConnection);
			if (!oFareTypeId.eof())
			{
				memset(szVal,0x00,sizeof(szVal));
				oFareTypeId >> szVal;
				//���ݶ��Ž����ַ����ָ�
				const char *d = ",";
				char *p;
				p = strtok(szVal,d);
				while(p)
				{
					string s=p;
					m_vsSpecialControlFareTypeId.push_back(s);
					p=strtok(NULL,d);
				}
			}
		}

		//ϵͳ״̬�� ȡ��������
		sSql = "select exch_date from system_stat order by exch_date desc";
		otl_stream oSysStat(1, sSql.c_str(), dbConnection);
		if (!oSysStat.eof())
		{
			oSysStat >> cExchDate;
			m_sExchDate = cExchDate;
		}

		//��ʼ��ǿƽ����
		if(0 != InitAutoForcePara(dbConnection))
		{
			CRLog(E_ERROR,"InitAutoForcePara ʧ��,%s ", "Unknown exception");
			return -1;
		}

		//ǿƽ���� ȡ���ǿƽ����
		sSql = "select cover_no from force_cov_order order by cover_no desc";
		otl_stream oForceCover(1, sSql.c_str(), dbConnection);
		if (!oForceCover.eof())
		{
			oForceCover >> cCoverNo;
			string sTmp = cCoverNo;
			string sNo = sTmp.substr(5,10);
			try
			{		
				stringstream ssNo(sNo);
				ssNo >> m_uiMaxForceOrderNo;
			}
			catch (std::exception e)
			{
				CRLog(E_ERROR, "CBasicParaTbl::Init exception:%s",e.what()); 
				m_uiMaxForceOrderNo = 0;
			}
			catch(...)
			{
				CRLog(E_CRITICAL,"%s","CBasicParaTbl::Init Unknown exception");
				m_uiMaxForceOrderNo = 0;
			}
		}
		else
		{
			m_uiMaxForceOrderNo = 0;
		}
	}
	catch(otl_exception &p)
	{
		CRLog(E_ERROR, "olt exception:%s,%s,%s,%s", p.msg, p.stm_text, p.sqlstate, p.var_info);
	}
	catch(...)
	{
		CRLog(E_ERROR,"%s", "Unknown exception");
	}
	return 0;
}

//��ʼ���Զ�ǿƽ����
int CBasicParaTbl::InitAutoForcePara(otl_connect& dbConnection)
{

	string sSql = "";
	char szVal[1024];
	try
	{

		//ȡ�������Զ�ǿƽ���ܵĿ��� 
		sSql = "select para_value from system_para where para_id = '" + RiskConst::gc_sQuoteAuotForce + "'";
		otl_stream oQuoteAutoForceFlag(1, sSql.c_str(), dbConnection);
		if(!oQuoteAutoForceFlag.eof())
		{
			memset(szVal,0x00,sizeof(szVal));
			oQuoteAutoForceFlag>>szVal;
			m_uiIsQuoteAuotForce = atoi(szVal);
		} 

		//ȡ�Ƕ�ʱ���Զ�ǿƽ���ܵĿ��� 
		sSql = "select para_value from system_para where para_id = '" + RiskConst::gc_sTimerAuotForce + "'";
		otl_stream oTimerAutoForce(1, sSql.c_str(), dbConnection);
		if(!oTimerAutoForce.eof())
		{
			memset(szVal,0x00,sizeof(szVal));
			oTimerAutoForce>>szVal;
			m_uiIsTimerAutoForce = atoi(szVal);
		} 

		// ÿ��Э����� ��Ӧ�� ��С�䶯�� 
		if(0 != MinUnitInit(dbConnection))
		{
			CRLog(E_APPINFO, "δȡ������ǿƽ����%s����ʧ��","");
		}
		
		//�Զ�ǿƽί�еı���ģʽ // 1 ͣ���,2 �޼�,3 �м�
		sSql = "select para_value from system_para where para_id = '" + RiskConst::gc_sAutoForcePriceMode + "'";
		otl_stream oAutoForcePriceMode(1, sSql.c_str(), dbConnection);
		if(!oAutoForcePriceMode.eof())
		{
			memset(szVal,0x00,sizeof(szVal));
			oAutoForcePriceMode>>szVal;
			m_uiAutoForcePriceMode = szVal;
		}
		else
		{
			m_uiAutoForcePriceMode = RiskConst::gc_sLimitPriceFcMode;
			CRLog(E_APPINFO, "δȡ��ǿƽί�еı���ģʽ����,Ĭ��%s �޼�", m_uiAutoForcePriceMode.c_str());

		}
		
		//ȡϵͳ�Զ�ǿƽʱ��㣬�����ж���� ��ʽ20:00;23:33 ʱ����ԷֺŸ���
		m_vForceDateTime.clear();
		sSql = "select para_value from system_para where para_id = '" + RiskConst::gc_sAutoForceTime + "'";
		otl_stream oAutoForceTime(1, sSql.c_str(), dbConnection);
		if(!oAutoForceTime.eof())
		{ 
			memset(szVal,0x00,sizeof(szVal));
			oAutoForceTime>>szVal;
			vector<string> vecForceTime = explodeQuoted(";",szVal);
			int nsize=vecForceTime.size();
			for(int i=0 ; i<nsize ;i++ )
			{
				string s_time = vecForceTime[i];
				int h = FromString<int>(s_time.substr(0,2));//Сʱ
				int m = FromString<int>(s_time.substr(3,2));//����
				int s = FromString<int>(s_time.substr(6,2));//��
				if (h < 0 || h > 24 || m < 0 || m >60 || s < 0 || s > 60 )
				{
					CRLog(E_ERROR,"��ʱ�Զ�ǿƽʱ������ó��� [%s]", s_time.c_str());
					continue;
				} 
				CGessTime t_GessTime=CGessTime(h,m,s);
				//m_vForceDateTime.push_back(CGessDateTime(t_GessDate,t_GessTime));
				m_vForceDateTime.push_back(t_GessTime);
			}
		} 	

		return 0;
	}
	catch(otl_exception &p)
	{
		CRLog(E_ERROR, "olt exception:%s,%s,%s,%s", p.msg, p.stm_text, p.sqlstate, p.var_info);
		return -1;
	}
	catch(...)
	{
		CRLog(E_ERROR,"%s", "Unknown exception");
		return -1;
	}
	
}

int  CBasicParaTbl::MinUnitInit(otl_connect& dbConnection)
{

	char cProdcode[11];		//Э�����
	double dlMin_unit;
	double dlQuote_dot;
	int iMinCatchTime;
	int iMaxCatchTime;
	char cVarietyIDs[101];		//����Ʒ�ֵļ���

    string sSql = "";
	string sProdCode="";
	AlterMinUnit stuAlterMinUnit;
	try
	{
		sSql = "select a.PROD_CODE,(MININUM_UNIT* TICK) as tt,QUOTE_DOT,minCatchTime,maxCatchTime,VarietyCode from MIN_ALTER_UNIT a left join prod_code_def b on a.PROD_CODE=b.PROD_CODE";
	   
		otl_stream oMinUnit(1, sSql.c_str(), dbConnection);
		while(!oMinUnit.eof())
		{  
		   memset(cProdcode,0x00,sizeof(cProdcode));	
		  // memset(stuAlterMinUnit,0x00,sizeof(stuAlterMinUnit));
			
		   oMinUnit>>cProdcode>>dlMin_unit>>dlQuote_dot>>iMinCatchTime>>iMaxCatchTime>>cVarietyIDs;		
		   vector<string> vecVarietyID = explodeQuoted(",",cVarietyIDs);
		   stuAlterMinUnit.vecVarietyID = vecVarietyID;
		   stuAlterMinUnit.min_unit = dlMin_unit;
		   stuAlterMinUnit.quote_dot = dlQuote_dot;
		   stuAlterMinUnit.minCatchTime = iMinCatchTime;
		   stuAlterMinUnit.maxCatchTime = iMaxCatchTime;
		   sProdCode.assign(cProdcode);
		   m_mAlterUnit[sProdCode] = stuAlterMinUnit;
		} 
		return 0;
	}
	catch(otl_exception &p)
	{
		CRLog(E_ERROR, "MinUnitInit olt exception:%s,%s,%s,%s", p.msg, p.stm_text, p.sqlstate, p.var_info);
		return -1;
	}
	catch(...)
	{
		CRLog(E_ERROR," MinUnitInit %s", "Unknown exception");
		return -1;
	}
}


int CBasicParaTbl::GetForcetime(vector<CGessTime> & t_gessdateTime) const
{
	CGessGuard guard(m_mutexTbl);
	t_gessdateTime=m_vForceDateTime;
	return 0;
}

//��ȡ����ʱ��������Ϣ
int CBasicParaTbl::GetMaxForcetime(CGessTime & t_maxFocetime)
{

	CGessGuard guard(m_mutexTbl);
	t_maxFocetime = CGessTime(0,0,1);
	vector<CGessTime>::iterator it = m_vForceDateTime.begin();
	for( ; it != m_vForceDateTime.end() ; it++)
	{
		if((*it)-t_maxFocetime >=0)
		{
			t_maxFocetime = (*it);
		}
	}	
	return 0;
}



int CBasicParaTbl::GetAlterUnit(std::string prodCode, double &price)
{
	CGessGuard guard(m_mutexTbl);
	map<string,AlterMinUnit>::iterator it = m_mAlterUnit.find(prodCode);
	if (it != m_mAlterUnit.end())
	{
		price=(*it).second.min_unit;
		return 0;
	}else
		return 1;

}

//��ȡ����ǿƽ��������
int CBasicParaTbl::GetQuoteAutoForcePara(std::string prodCode,AlterMinUnit& stuAlterMinUnit)
{
	CGessGuard guard(m_mutexTbl);
	map<string,AlterMinUnit>::iterator it = m_mAlterUnit.find(prodCode);
	if (it != m_mAlterUnit.end())
	{
		stuAlterMinUnit=(AlterMinUnit)(*it).second;
		return 0;
	}else
		return 1;

}

//�޸�ָ����Լ����ǿƽ����
int CBasicParaTbl::SetQuoteAutoForcePara(std::string prodCode,AlterMinUnit& stuAlterMinUnit)
{
	CGessGuard guard(m_mutexTbl);
	map<string,AlterMinUnit>::iterator it = m_mAlterUnit.find(prodCode);
	if (it != m_mAlterUnit.end())
	{
		(*it).second = stuAlterMinUnit;
		return 0;
	}else
		return 1;

}

//��ȡ�����뽻��Ʒ�ֵĺ������
int CBasicParaTbl::GetQuoteDot(std::string prodCode, double &price)
{
	CGessGuard guard(m_mutexTbl);

	map<string,AlterMinUnit>::iterator it = m_mAlterUnit.find(prodCode);
	if (it != m_mAlterUnit.end())
	{
		price=(*it).second.quote_dot;
		return 0;
	}else
		return 1;

}


//��ȡ�Զ�ǿƽί�еı���ģʽ 1 ͣ���,2 �޼�,3 �м�
string CBasicParaTbl::GetAutoForcePriceMode()
{
	CGessGuard guard(m_mutexTbl);
	return m_uiAutoForcePriceMode;
}

//����ƽ���������Ƿ���ݵ��ղֺ���ʷ�ַֿ����㣨1-ʹ�ã�0-��ʹ�ã�
int CBasicParaTbl::GetDiffCovFareByCurrOrHisFlag()
{
	return m_uiDiffCovFareByCurrOrHis;
}
//��ȡ�Ƿ����ÿͻ�������ʿ���(1����.0����)
int CBasicParaTbl::GetIsUseSpecialControl()
{
//	CGessGuard guard(m_mutexTbl);
	return m_uiIsUseSpecialControl;
}

//�ж�����ķ��������ǲ������õĿͻ�������ʿ��Ƶķ�������(1����.0����)
int CBasicParaTbl::GetIsSpecialControlFareTypeId(string fareid)
{
//	CGessGuard guard(m_mutexTbl);
	vector<string>::iterator it=m_vsSpecialControlFareTypeId.begin();
	for (;it!=m_vsSpecialControlFareTypeId.end();it++)
	{
		if (fareid==(*it))
		{
			return 1;
		}
	}
	return 0;
}


//��������
void CBasicParaTbl::Finish()
{
	CGessGuard guard(m_mutexTbl);

    m_mAlterUnit.clear();
	m_vForceDateTime.clear();

}


int CBasicParaTbl::ReMinUnitInit(otl_connect& dbConnection)
{
	CGessGuard guard(m_mutexTbl);
	 
	m_mAlterUnit.clear();
	MinUnitInit(dbConnection); 

	return 0;

}
