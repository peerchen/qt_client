#include "RiskTransferHandleTbl.h"

CRiskTransferHandleTbl::CRiskTransferHandleTbl()
{

}

CRiskTransferHandleTbl::~CRiskTransferHandleTbl()
{
	Finish();
}

//##ModelId=491AF46200BB
int CRiskTransferHandleTbl::GetHandle(unsigned short usGradeFrom, unsigned short usGradeTo, vector<RISK_TRANSFER_HANDLE>& vec)
{
	for(vector<RISK_TRANSFER_HANDLE>::iterator iter = m_vecRiskTransferHandle.begin(); iter != m_vecRiskTransferHandle.end(); ++iter){
		if((iter->usGradeFrom)==usGradeFrom&&(iter->usGradeTo)==usGradeTo){
			vec.push_back(*iter);
		}
	}
	if(vec.size()>0)
		return 0;
	return -1;
}

//##ModelId=491B044E007D
int CRiskTransferHandleTbl::Init(otl_connect& dbConnection)
{
	return 0;
}

//��������
void CRiskTransferHandleTbl::Finish()
{
	m_vecRiskTransferHandle.clear();
}
