#include <sstream>
#include <iomanip>
#include "FpMatchFlowTbl.h"
#include "BasicParaTbl.h"
//#include "otlv4.h"
#include "DB_Version.h" 
#include "Logger.h"

CFpMatchFlowTbl::CFpMatchFlowTbl()
{

}

CFpMatchFlowTbl::~CFpMatchFlowTbl()
{
	Finish();
}

//##ModelId=491A39330213
bool CFpMatchFlowTbl::IsHandled(const string& sKey,const string& sAcctNo)
{
	bool blRtn = false;

	CGessGuard guard(m_mutexTbl);
	if (m_mapPosi.find(sKey) != m_mapPosi.end())
	{
		blRtn = true;
	}
	else
	{
		m_mapPosi[sKey] = sAcctNo;
		blRtn = false;
	}

	return blRtn;
}

//���������ݿ��ʼ��
int CFpMatchFlowTbl::Init(otl_connect& dbConnection,CBasicParaTbl& BasicParaTbl)
{
	char cMatchNo[19];			//�ɽ����
	char cAcctNo[16];			//�ʽ��ʺ�/�ͻ���
	string sSql = "";

	memset(cMatchNo, 0, sizeof(cMatchNo));
	memset(cAcctNo, 0, sizeof(cAcctNo));

	try
	{
		//���ճɽ���ˮ��
		sSql = "select match_no, acct_no from fp_match_flow where exch_date >= :f1<char[9]>";
		otl_stream oMatchDetail(1, sSql.c_str(), dbConnection);
		oMatchDetail << BasicParaTbl.GetExchDate().c_str();

		while (!oMatchDetail.eof())
		{
			oMatchDetail >> cMatchNo >> cAcctNo;
			string sKey = cMatchNo;
			m_mapPosi[sKey] = cAcctNo;			
		}
	}
	catch(otl_exception &p)
	{
		CRLog(E_ERROR, "otl exception:%s,%s,%s,%s", p.msg, p.stm_text, p.sqlstate, p.var_info);
	}

	return 0;
}

//��������
void CFpMatchFlowTbl::Finish()
{
	CGessGuard guard(m_mutexTbl);
	m_mapPosi.clear();
}


