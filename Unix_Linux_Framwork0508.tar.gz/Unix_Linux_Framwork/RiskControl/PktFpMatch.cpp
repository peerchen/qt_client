#include "RiskHandler.h"

// A1 �ӿ� [onRecvRtnFpMatch] ��ҵ��ʵ��
int CRiskHandler::OnFpMatch(CBroadcastPacket& pkt)
{
	FpMatch stBody;
	CPacketStructBroadcastRisk::Packet2Struct(stBody, pkt);	

	//ҵ��ʵ��......
	SendAck(pkt);

	CCustomer* p = FindCustomer(stBody.AcctNo);
	if (!p)
		return -1;

	std::string sKey = stBody.MatchNo;
	CFpMatchFlowTbl& tblMatch = m_pMemDb->GetFpMatchFlowTbl();
	if (tblMatch.IsHandled(sKey,stBody.AcctNo))
		return -1;

	CRLog(E_APPINFO,"OnFpMatch %s %c %s %d %s\n",stBody.AcctNo.c_str(),stBody.Bs,stBody.ProdCode.c_str(),stBody.MatchAmount,sKey.c_str());

	//�ⶳ�ÿͻ��ú�Լ�����ж����ʽ�
	CFpOrderFlowStatistics FpOrder;
	int nRtn;
	for( int i = stBody.MatchRound; i>0; i-- )
	{
		nRtn = m_pMemDb->GetFpOrderFlowTbl().GetFpOrderFlow( stBody.MatchGame, ToString(i), stBody.AcctNo,stBody.ProdCode,FpOrder);
		if(nRtn == 0)
		{
			double dlFpFrozenCapital = FpOrder.GetMarginBuy() + FpOrder.GetMarginSell() + FpOrder.GetFareBuy() + FpOrder.GetFareSell();

			//�ⶳ�ʽ�
			p->OnCapitalHandle(dlFpFrozenCapital,gc_sUnFrozenFlag,"");

			//ɾ����¼
			m_pMemDb->GetFpOrderFlowTbl().DeleteFpOrderFlow( stBody.MatchGame, ToString(i), stBody.AcctNo,stBody.ProdCode);
		}
	}

	CustRiskInfo oCustRiskInfo;
	int nType = 0;
	m_pMemDb->GetProdCodeTbl().GetVarietyType(stBody.ProdCode,nType);
	double dlUnit = GetMeasureUnit(stBody.ProdCode);

	nRtn = gc_cStateNormal;
	
	CFpMatch pFpMatch = CFpMatch(stBody.ProdCode,nType,stBody.Bs,stBody.MatchPrice,stBody.MatchAmount,dlUnit,stBody.EntrPhase,stBody.IsAllocate);
 	nRtn = p->OnRtnMatchFp(pFpMatch,oCustRiskInfo);


	if (nRtn == gc_cStateNormal)
	{
	}
	if (nRtn == gc_cStateValueChange)
	{
		//����� 
		m_pRiskNotify->Enque(oCustRiskInfo);
	}
	if (nRtn == gc_cStateRiskTransfer)
	{
		//����� 
		m_pRiskNotify->Enque(oCustRiskInfo);
	}

	p->UpdateAgentBalanceStat();
	p->UpdateAgentDebtStat();

	//�ж��ʽ�澯״̬�Ƿ�ı�	--add by lbl 2014-02-24 modify by wct 2015-07-30
	//m_pRiskCpMgr->GetMainServiceHandler()->FundAlarmNotify(p);
	//���»�Ա̨�ʱ�
	//UpdateMmeberFundByCust(p);

	//���¼��㱬����Ϣ
	//p->CalculateOutStockInfo();

	return 0;
};
