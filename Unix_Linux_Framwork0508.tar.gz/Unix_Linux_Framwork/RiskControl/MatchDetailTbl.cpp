#include <sstream>
#include <iomanip>
#include "MatchDetailTbl.h"
#include "BasicParaTbl.h"
#include "DB_Version.h" 
#include "Logger.h"

CMatchDetailTbl::CMatchDetailTbl()
{

}

CMatchDetailTbl::~CMatchDetailTbl()
{
	Finish();
}

//##ModelId=491A39330213
bool CMatchDetailTbl::IsHandled(const string& sKey,const string& sAcctNo)
{
	bool blRtn = false;

	CGessGuard guard(m_mutexTbl);
	if (m_mapPosi.find(sKey) != m_mapPosi.end())
	{
		blRtn = true;
	}
	else
	{
		m_mapPosi[sKey] = sAcctNo;
		blRtn = false;
	}

	return blRtn;
}

//���������ݿ��ʼ��
int CMatchDetailTbl::Init(otl_connect& dbConnection,CBasicParaTbl& BasicParaTbl)
{
	char cMatchNo[17];			//�ɽ����
	char cOrderNo[17];			//������
	char cAcctNo[16];			//�ʽ��ʺ�/�ͻ���
	string sSql = "";

	memset(cMatchNo, 0, sizeof(cMatchNo));
	memset(cOrderNo, 0, sizeof(cOrderNo));
	memset(cAcctNo, 0, sizeof(cAcctNo));

	try
	{
		//���ճɽ���ˮ��
		sSql = "select match_no, order_no, acct_no from busi_back_flow where exch_date >= :f1<char[9]>";
		otl_stream oMatchDetail(1, sSql.c_str(), dbConnection);
		oMatchDetail << BasicParaTbl.GetExchDate().c_str();

		while (!oMatchDetail.eof())
		{
			oMatchDetail >> cMatchNo >> cOrderNo >> cAcctNo;
			string sKey = cMatchNo;
			sKey = sKey + cOrderNo;
			m_mapPosi[sKey] = cAcctNo;			
		}

	}
	catch(otl_exception &p)
	{
		CRLog(E_ERROR, "otl exception:%s,%s,%s,%s", p.msg, p.stm_text, p.sqlstate, p.var_info);
	}

	return 0;
}

//��������
void CMatchDetailTbl::Finish()
{
	CGessGuard guard(m_mutexTbl);
	m_mapPosi.clear();
}


string CMatchDetailTbl::ToString()
{
	std::stringstream ss;

	map<string,string>::iterator iter;

	CGessGuard guard(m_mutexTbl);
	for( iter =  m_mapPosi.begin(); iter != m_mapPosi.end(); ++iter)
	{
		ss << (*iter).first << " " << (*iter).second;
		ss << "\r\n";
	}

	return ss.str();
}