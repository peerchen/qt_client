#include "BrokerInfoTbl.h"
#include "Logger.h"
#include "DB_Version.h" 
#include <algorithm>
#include <sstream>
int CBrokerInfoTbl::Init(otl_connect& dbConnection)
{
		
	CRLog(E_DEBUG, "loading BrokerInfo info[%s]"," ......");
	string sSql="select abi.acct_no,b.broker_id,b.broker_name,b.tel ,b.branch_id,b.mp from acct_broker_info abi left join broker_info b on abi.broker_id =b.broker_id order by abi.acct_no";

	//CGessGuard guard(m_mutexTbl);
	otl_stream broker_info(1, sSql.c_str(), dbConnection);    //����������Ϣ����
	otl_stream_read_iterator<otl_stream,otl_exception,otl_lob_stream> rs;//���������
	rs.attach(broker_info); 

	while(rs.next_row())
	{
		string sCustNo;			//�ͻ���
		BrokerInfo bi;
		rs.get("acct_no",sCustNo);
		
		rs.get("broker_id",bi.sBrokerId);
		rs.get("broker_name",bi.sBrokerName);
		rs.get("tel",bi.sTel);
		rs.get("branch_id",bi.sBranchId);
		rs.get("mp",bi.sMobile);
		
		map<string,vector<BrokerInfo> >::iterator iter= custBrokerMap.find(sCustNo);
		if (iter==custBrokerMap.end())
		{
			vector<BrokerInfo> temp;
			temp.push_back(bi);
			custBrokerMap[sCustNo]=temp;
		}
		else
		{
			iter->second.push_back(bi);
		}
	}

	return 0;
}

int CBrokerInfoTbl::GetCustBrokerInfo(const string& custNo, vector<BrokerInfo>& vBroker)
{
	map<string,vector<BrokerInfo> >::iterator iter= custBrokerMap.find(custNo);
	if (iter!=custBrokerMap.end())
	{
		vBroker=iter->second;
	}
	return 0;
}

void CBrokerInfoTbl::Finish()
{
	custBrokerMap.clear();
}
CBrokerInfoTbl::CBrokerInfoTbl(){

}
CBrokerInfoTbl::~CBrokerInfoTbl()
{

}