#include "Logger.h"
#include <assert.h>
#include "strutils.h"
#include "MemDb.h"
#include "Customer.h"
#include "Global.h"

using namespace strutils;

//##ModelId=4913EE350290
CCustomerTbl& CMemDb::GetCustTble()
{
	CGessGuard guard(m_mutexDb);
	return m_CustomerTbl;
}

//##ModelId=4913EE5F004E
CAgentTbl& CMemDb::GetAgentTble()
{
	CGessGuard guard(m_mutexDb);
	return m_AgentTbl;
}

//##ModelId=4913EE6D00EA
CFeeModelDetailTbl& CMemDb::GetFeeModelDetailTbl()
{
	CGessGuard guard(m_mutexDb);
	return m_FeeModelDetailTbl;
}

//##ModelId=4913EEB9000F
CCustFeeDetailTbl& CMemDb::GetCustFeeDetailTbl()
{
	CGessGuard guard(m_mutexDb);
	return m_CustFeeDetailTbl;
}

CExchFeeDetailTbl& CMemDb::GetExchFeeDetailTbl()
{
	CGessGuard guard(m_mutexDb);
	return m_ExchFeeDetailTbl;
}

CEtfFeeDetailTbl& CMemDb::GetEtfFeeDetailTbl()		//add by luobaolin 2013-3-26
{
	CGessGuard guard(m_mutexDb);
	return m_EtfFeeDetailTbl;
}

//##ModelId=4913F70B0119
CTriggerTbl& CMemDb::GetTriggerTbl()
{
	CGessGuard guard(m_mutexDb);
	return m_TriggerTbl;
}

//##ModelId=4913F71F0203
CQuotationTbl& CMemDb::GetQuotationTbl()
{
	CGessGuard guard(m_mutexDb);
	return m_QuotationTbl;
}

CBasicParaTbl& CMemDb::GetBasicParaTbl()
{
	CGessGuard guard(m_mutexDb);
	return m_BasicParaTbl;
}

//##ModelId=491531160232
CParameterTbl& CMemDb::GetParameterTbl()
{
	CGessGuard guard(m_mutexDb);
	return m_ParameterTbl;
}

//##ModelId=491537130000
CRealTimeRiskTbl& CMemDb::GetRealTimeRiskTbl()
{
	CGessGuard guard(m_mutexDb);
	return m_RealTimeRiskTbl;
}

//##ModelId=4916C85F02DE
CProdCodeTbl& CMemDb::GetProdCodeTbl()
{
	CGessGuard guard(m_mutexDb);
	return m_ProdCodeTbl;
}

//ǿƽ��˳���
CForceCloseParaTbl& CMemDb::GetForceCloseParaTbl()
{
	CGessGuard guard(m_mutexDb);
	return m_ForceCloseParaTbl;
}

//�ʽ��
CCapitalTbl& CMemDb::GetCapitalTbl()
{
	CGessGuard guard(m_mutexDb);
	return m_CapitalTbl;
}

//�ɽ���
CMatchDetailTbl& CMemDb::GetMatchDetailTbl()
{
	CGessGuard guard(m_mutexDb);
	return m_MatchDetailTbl;
}

// ETF�ɽ���
CEtfMatchDetailTbl& CMemDb::GetETFMatchDetailTbl()
{
	CGessGuard guard(m_mutexDb);
	return m_ETFMatchDetailTbl;
}

//���յȼ������
CRiskGradeDefineTbl& CMemDb::GetRiskGradeDefineTbl()
{
	CGessGuard guard(m_mutexDb);
	return m_RiskGradeDefineTbl;
}

//����֪ͨ�������ñ�
CRiskTipParaTbl& CMemDb::GetRiskTipParaTbl()
{
	CGessGuard guard(m_mutexDb);
	return m_RiskTipParaTbl;
}
//����֪ͨ��Ϣ��
CRiskNotifyTbl& CMemDb::GetRiskNotifyTbl()
{
	CGessGuard guard(m_mutexDb);                           
	return m_RiskNotifyTbl;
}

//ί����ˮ
CEntrFlowTbl & CMemDb::GetEntrFlowTbl()
{
	CGessGuard guard(m_mutexDb);
	return m_EntrFlowTbl;
}

CAutoForceExecptCndTbl & CMemDb::GetForceExecptCndTbl()
{
	CGessGuard guard(m_mutexDb);
	return m_AutoForceExecptCndTbl; 
}

CSmsFormatTbl& CMemDb::GetSmsFormatTbl()
{
	CGessGuard guard(m_mutexDb);
	return m_SmsFormatTbl;
}

CRiskAlarmParaTbl& CMemDb::GetRiskAlarmParaTbl()
{
	CGessGuard guard(m_mutexDb);
	return m_RiskAlarmParaTbl;
}


CBrokerInfoTbl & CMemDb::GetBrokerInfoTbl()
{
	CGessGuard guard(m_mutexDb);
	return m_BrokerInfoTbl;
}
CInOutCustTbl & CMemDb::GetInOutCustTbl()
{
	CGessGuard guard(m_mutexDb);
	return m_InOutCustTbl;
}

//���۳ɽ���ˮ��
CFpMatchFlowTbl& CMemDb::GetFpMatchFlowTbl()
{
	CGessGuard guard(m_mutexDb);
	return m_FpMatchFlowTbl;
}

//�����걨��ˮ��
CFpOrderFlowTbl& CMemDb::GetFpOrderFlowTbl()
{
	CGessGuard guard(m_mutexDb);
	return m_FpOrderFlowTbl;
}

//���ۺ�Լ��Ϣ��
CFpProdCodeTbl& CMemDb::GetFpProdCodeTbl()
{
	CGessGuard guard(m_mutexDb);
	return m_FpProdCodeTbl;
}

////��ȡǿƽί�е���Ϣ
//CForceCovOrderTbl& CMemDb::GeetForceCovOrderTbl()
//{
//	return m_ForceCovOrderTbl;
//}

//���¼�����С������λ
int CMemDb::ReLoadMinUnitTal()
{
	CGessGuard guard(m_mutexDb);

	string sConnStr = CGlobal::Instance()->GetDbConnectStr(m_pConfig->GetCfgGlobal());

    otl_connect::otl_initialize(); // ��ʼ�� ODBC ����
	try
	{	
		otl_connect m_OtlConn;
		m_OtlConn.set_timeout(50);
		m_OtlConn.rlogon(sConnStr.c_str());

		m_BasicParaTbl.ReMinUnitInit(m_OtlConn);
		m_OtlConn.logoff();
		return 0;
	}
	catch(otl_exception& p)
	{
		CRLog(E_ERROR,"otl exception:%s,%s,%s,%s",p.msg,p.stm_text,p.sqlstate,p.var_info);
		return -1;
	}
}


//���¼����Զ�ǿƽ���������������ñ�
int CMemDb::ReLoadAutoForceExecptCndTbl()
{
	CGessGuard guard(m_mutexDb);
    assert(m_pConfig != 0);

	string sConnStr = CGlobal::Instance()->GetDbConnectStr(m_pConfig->GetCfgGlobal());

    otl_connect::otl_initialize(); // ��ʼ�� ODBC ����
	try
	{	
		otl_connect m_OtlConn;
		m_OtlConn.set_timeout(50);
		m_OtlConn.rlogon(sConnStr.c_str());

		m_AutoForceExecptCndTbl.ReInit(m_OtlConn);
		m_OtlConn.logoff();
		return 0;
	}
	catch(otl_exception& p)
	{
		CRLog(E_ERROR,"otl exception:%s,%s,%s,%s",p.msg,p.stm_text,p.sqlstate,p.var_info);
		return -1;
	}

}

//���¼��ؿͻ�����ģ���
int CMemDb::ReLoadCustFeeTbl()
{
	CGessGuard guard(m_mutexDb);
	assert(m_pConfig != 0);

	string sConnStr = CGlobal::Instance()->GetDbConnectStr(m_pConfig->GetCfgGlobal());

	otl_connect::otl_initialize(); // ��ʼ�� ODBC ����
	try
	{	
		otl_connect m_OtlConn;
		m_OtlConn.rlogon(sConnStr.c_str());

		m_CustFeeDetailTbl.ReInit(m_OtlConn);
		m_OtlConn.logoff();
		return 0;
	}
	catch(otl_exception& p)
	{
		CRLog(E_ERROR,"otl exception:%s,%s,%s,%s",p.msg,p.stm_text,p.sqlstate,p.var_info);
		return -1;
	}
}


//���¼��ؽ���������ģ���
int CMemDb::ReLoadExchFeeTbl()
{
	CGessGuard guard(m_mutexDb);
	assert(m_pConfig != 0);

	string sConnStr = CGlobal::Instance()->GetDbConnectStr(m_pConfig->GetCfgGlobal());
	otl_connect::otl_initialize(); // ��ʼ�� ODBC ����
	try
	{	
		otl_connect m_OtlConn;
		m_OtlConn.set_timeout(50);
		m_OtlConn.rlogon(sConnStr.c_str());

		m_ExchFeeDetailTbl.ReInit(m_OtlConn);
		m_OtlConn.logoff();
		return 0;
	}
	catch(otl_exception& p)
	{
		CRLog(E_ERROR,"otl exception:%s,%s,%s,%s",p.msg,p.stm_text,p.sqlstate,p.var_info);
		return -1;
	}
}


//���¼��ط���ģ���
int CMemDb::ReLoadModelFeeTbl()
{
	CGessGuard guard(m_mutexDb);
	assert(m_pConfig != 0);

	string sConnStr = CGlobal::Instance()->GetDbConnectStr(m_pConfig->GetCfgGlobal());
	otl_connect::otl_initialize(); // ��ʼ�� ODBC ����
	try
	{	
		otl_connect m_OtlConn;
		m_OtlConn.set_timeout(50);
		m_OtlConn.rlogon(sConnStr.c_str());

		m_FeeModelDetailTbl.ReInit(m_OtlConn);

		m_OtlConn.logoff();
		return 0;
	}
	catch(otl_exception& p)
	{
		CRLog(E_ERROR,"otl exception:%s,%s,%s,%s",p.msg,p.stm_text,p.sqlstate,p.var_info);
		return -1;
	}
}


//���¼����Զ�ǿƽ���ò���
int CMemDb::ReLoadBasicParaTbl()
{
	CGessGuard guard(m_mutexDb);
	assert(m_pConfig != 0);

	string sConnStr = CGlobal::Instance()->GetDbConnectStr(m_pConfig->GetCfgGlobal());

	otl_connect::otl_initialize(); // ��ʼ�� ODBC ����
	try
	{	
		otl_connect m_OtlConn;
		m_OtlConn.rlogon(sConnStr.c_str());

		CRLog(E_APPINFO,"%s", "���³�ʼ��ϵͳ����������ʼ..");

		//���������ڴ����ʼ��
#ifdef _VER_25_DB2
		m_BasicParaTbl.InitAutoForcePara(m_OtlConn);
#else
		m_BasicParaTbl.Init(m_OtlConn);
#endif	

		CRLog(E_APPINFO,"%s", "���³�ʼ��ϵͳ��������������");
		m_OtlConn.logoff();
		return 0;
	}
	catch(otl_exception& p)
	{
		CRLog(E_ERROR,"otl exception:%s,%s,%s,%s",p.msg,p.stm_text,p.sqlstate,p.var_info);
		return -1;
	}	

}

//��ʼ���ڴ����ݿ�
int CMemDb::Init(CConfig* pCfg,const string& sDate)
{
	CGessGuard guard(m_mutexDb);
	assert(pCfg != 0);
	if (0 == pCfg)
		return -1;

	m_pConfig = pCfg;
	CConfig* pConfig = m_pConfig->GetCfgGlobal();
	if (0 == pConfig)
		return -1;

	string sConnStr = CGlobal::Instance()->GetDbConnectStr(pConfig);

	otl_connect::otl_initialize(); // ��ʼ�� ODBC ����
	try
	{	
		otl_connect m_OtlConn;
		m_OtlConn.set_timeout(50);
		m_OtlConn.rlogon(sConnStr.c_str());

		//cout << "MemDb �ڴ����ݿ��ʼ����ʼ.." << endl << endl;
		CRLog(E_APPINFO,"%s", "MemDb �ڴ����ݿ��ʼ����ʼ..");
		

		//���������ڴ����ʼ��
		CRLog(E_APPINFO,"%s", "m_BasicParaTbl �ڴ����ݿ��ʼ����ʼ..");
		m_BasicParaTbl.Init(m_OtlConn);
		if (sDate != "")
		{
			m_BasicParaTbl.SetExchDate(sDate);
		}
		CRLog(E_APPINFO,"%s", "��ʼ��ϵͳ�������ñ�....");

		//������Ϣ��ʾ���ó�ʼ��
		m_RiskTipParaTbl.Init(m_OtlConn);
		CRLog(E_APPINFO,"%s", "������Ϣ��ʾ���ó�ʼ��....");

		//��Լ�����ڴ����ʼ��
		m_ProdCodeTbl.Init(m_OtlConn);
		CRLog(E_APPINFO,"%s", "��Լ�����ڴ����ʼ��....");

		//ʵʱ�����ڴ����ʼ��
		m_QuotationTbl.Init(m_ProdCodeTbl, m_BasicParaTbl, m_OtlConn);

		CRLog(E_APPINFO,"%s", "ʵʱ�����ڴ����ʼ��....");
		//�����ʼ�����ʷ�۸��ڴ����ʼ��
		m_TriggerTbl.Init(m_ProdCodeTbl);

		CRLog(E_APPINFO,"%s", "�����ʼ�����ʷ�۸��ڴ����ʼ��....");
		//�������ڴ����ʼ��
		m_AgentTbl.Init(m_OtlConn);

		CRLog(E_APPINFO,"%s", "�������ڴ����ʼ��....");
		//����ģ����ϸ�ڴ����ʼ��
		m_FeeModelDetailTbl.Init(m_OtlConn);
		CRLog(E_APPINFO,"%s", "����ģ����ϸ�ڴ����ʼ��....");

		//���˷�����ϸ�ڴ����ʼ��
		m_CustFeeDetailTbl.Init(m_OtlConn);
		CRLog(E_APPINFO,"%s", "���˷�����ϸ�ڴ����ʼ��....");

		
		//ETF������ϸ�ڴ����ʼ��						add by luobaolin 2013-3-26
// 		m_EtfFeeDetailTbl.Init(m_OtlConn);
// 		CRLog(E_APPINFO,"%s", "ETF������ϸ�ڴ����ʼ��....");

		//��ʼ��ί����ˮ��

		CRLog(E_APPINFO,"%s", "��ʼ��ί����ˮ����ʼ��....");
		 m_EntrFlowTbl.Init(m_OtlConn);
	 
		//�Զ�ǿƽ���������ڴ����ʼ��
		CRLog(E_APPINFO,"%s", "�Զ�ǿƽ���������ڴ����ʼ��....");
		m_AutoForceExecptCndTbl.Init(m_OtlConn);
		 
		//��ʼ�����Ÿ�ʽ�ڴ����Ϣ
		CRLog(E_APPINFO,"%s", "��ʼ�����Ÿ�ʽ�ڴ����Ϣ....");
	    m_SmsFormatTbl.Init(m_OtlConn);


		//�ͻ�������Ϣ
		CRLog(E_APPINFO,"%s", "��ʼ���ͻ�������Ϣ....");
		m_BrokerInfoTbl.Init(m_OtlConn);
#ifdef _VER_25_PSBC
		m_RiskAlarmParaTbl.Init(m_OtlConn);
#endif
		////��ʼ��ǿ��ί�е���Ϣ
		//m_ForceCovOrderTbl.Init(m_OtlConn);

		//�ͻ��ڴ����ʼ��
		if(0 != InitCustRltTbl(m_OtlConn))
		{
			CRLog(E_APPINFO,"%s", "MemDb �ͻ��ڴ����ʼ��ʧ��!");
			return -1;
		}
		CRLog(E_DEBUG,"%s", "MemDb �ͻ��ڴ����ʼ���ɹ�!");
		
		string sSimPara("");
		if (0 == m_pConfig->GetProperty("simulate_cust", sSimPara))
		{
			int nSim = FromString<int>(sSimPara);
			if (nSim > 500000)
				nSim = 500000;

			if (nSim > 0)
				m_CustomerTbl.SimInit(nSim, m_AgentTbl, m_CustFeeDetailTbl, m_ExchFeeDetailTbl, m_FeeModelDetailTbl,m_EtfFeeDetailTbl, m_ProdCodeTbl, m_BasicParaTbl);
		}

		m_ForceCloseParaTbl.Init(m_OtlConn);
		//�����ڴ����ʼ��
		//m_ParameterTbl.Init(m_OtlConn);
	
		//��ʼ�����յȼ�����ӳ���
		InitRiskGradeMap(m_OtlConn);
		CRLog(E_APPINFO,"%s", "MemDb �ڴ����ݿ��ʼ��������");
		m_OtlConn.logoff();
		return 0;
	}
	catch(otl_exception& p)
	{
		CRLog(E_ERROR,"otl exception:%s,%s,%s,%s",p.msg,p.stm_text,p.sqlstate,p.var_info);
		return -1;
	}	
}

int CMemDb::InitCustRltTbl(otl_connect& dbConnection)
{
	char cAcctNo[16];					//�ͻ���
	char cProdCode[11];					//��Լ����
	char cDir[2];						//��������
	unsigned int nNum = 0;					//����
	int nIndex = 0;						//��Լ������
	int nType = 0;						//��Լ����
	double dMeasureUnit = 0.0;			//��λ����
	double dMatchPrice = 0.0;			//�ɽ��۸� / ���ս����
	int nRowNum = 0;					//��¼��
	char cLastAcctNo[16];
	string sSql = "";
	string sTempKey = "";
	char szVal[1024];

	memset(cAcctNo, 0, sizeof(cAcctNo));
	memset(cProdCode, 0, sizeof(cProdCode));
	memset(cLastAcctNo, 0, sizeof(cLastAcctNo));
	memset(cDir, 0, sizeof(cDir));
	
	//�ʽ��
	map<string, FUND> mapFund;
	FUND stFund;
	//�ͻ���Լ�ֲܳ���Ϣ
	map<string,map<string,CCustSymbolDeferPosi> > mapCustSymbolDeferPosi;
	map<string,CCustSymbolDeferPosi> mapSymbolDeferPosi;

	//���ճֱֲ�
	map<string, vector<CPosi*> > mapDeferPosiToday;
	vector<CPosi*> vecDeferPosiToday;

	//��ʷ�ֱֲ�
	map<string, vector<CPosi*> > mapDeferPosiHis;
	vector<CPosi*>  vecDeferPosiHis;

	//��Լ�����
	map<string, double> mapProdMarket;

   CRLog(E_DEBUG, "%s","loading InitCustinfo");

	try
	{
		//ȡ��Լ����
		CRLog(E_DEBUG, "%s","loading prod_settle_price");
		sSql = "select prod_code, settle_price from prod_settle_price where exch_date < :f1<char[9]> and settle_price != 0 and prod_code = :f2<char[11]> order by exch_date desc";
		otl_stream oProdMarket(1, sSql.c_str(), dbConnection);
		map<string, PROD_CODE> mapProdcode;
		m_ProdCodeTbl.GetRecordSet(mapProdcode);
		for (map<string, PROD_CODE>::iterator itmProdCode = mapProdcode.begin(); itmProdCode != mapProdcode.end(); itmProdCode++)
		{
			oProdMarket << m_BasicParaTbl.GetExchDate().c_str() << itmProdCode->first.c_str();
			if (!oProdMarket.eof())
			{
				oProdMarket >> cProdCode >> dMatchPrice;

				mapProdMarket[cProdCode] = dMatchPrice;
			}
		}
		//�ֻ�������̱��������
		double dlTmp=0.0;
		double dlSpotSellFrozenRatio = 0.10;  //Ĭ��ֵ
		sSql = "select para_value from system_para where para_id = '" + RiskConst::gc_sSpotSellFrozen + "'";
		otl_stream oLimit(1, sSql.c_str(), dbConnection);
		if (!oLimit.eof())
		{
			memset(szVal,0x00,sizeof(szVal));
			oLimit >> szVal;
			int nTmp = atoi(szVal);
			if (nTmp >= 0 && nTmp <= 100)
				dlSpotSellFrozenRatio = static_cast<double>(nTmp) / 100.00;

		}else
		{
			 CRLog(E_DEBUG, "δ�ҵ��ֻ���������̱�����������ò���,ȡĬ��ֵ %lf",dlSpotSellFrozenRatio);
		}
		dlTmp = 1 - dlSpotSellFrozenRatio;

		int iTmp = 0;
		//��ǰ������֤���Ƿ�����ڷ��ռ����� 1-�ǣ�0-��
		sSql = "select para_value from system_para where para_id = '" + RiskConst::gc_sIsBase_Magin + "'";
		otl_stream oBaseMagin(1, sSql.c_str(), dbConnection);
		if (!oBaseMagin.eof())
		{
			memset(szVal,0x00,sizeof(szVal));
			oBaseMagin >> szVal;
			iTmp = atoi(szVal);
		}
		else
			 CRLog(E_DEBUG, "δ��ȡ����ǰ������֤���Ƿ�����ڷ��ռ��������ò�����,ȡĬ��ֵ %d 0(������)1(����)",iTmp);
		if(iTmp == 1)
			iTmp=-1; //��Ϊ���л�����֤��Ϊ��ֵ������-1��ʾ��������
		else
			iTmp = 1;

		//��ʼ����
		//ȡ�ʽ���ر�
		
		CRLog(E_DEBUG, "%s","loading fund");
		sSql = "select fund.acct_no, (last_bal + in_bal + out_bal + real_buy + real_sell * ";
		sSql += ToString<double>(dlTmp);
		sSql += " + real_b_exch_fare + real_m_exch_fare + other_fare + cov_surplus + last_b_margin + last_m_margin + real_b_margin + real_m_margin+ ";
		sSql += " BASE_MARGIN * " + ToString<double>(iTmp);
		sSql += " + LAST_RESERVE + REAL_RESERVE + LAST_DELI_PREPARE+ DELI_PREPARE + LAST_DELI_MARGIN + DELI_MARGIN + DAY_LONG_FROZ +LAST_FORWARD_FROZ + DAY_FORWARD_FROZ ";
		sSql += " + coalesce(today_avaliable_offset_quota,0.00) ";
#if defined(_VER_25_ORA)  || defined(_VER_25_PSBC)
		sSql += " + LAST_LONG_FROZ ";
#endif	
		sSql += ") as capital, in_bal, out_bal,LAST_M_MARGIN,LAST_B_MARGIN, real_b_margin + last_b_margin ,real_m_margin + last_m_margin from fund left outer join offset_fund on fund.acct_no=offset_fund.acct_no";

		// ����ԭ���Ĵ��룬�Ժ������
#ifndef _VER_25_DB2
		sSql += " for update";
#endif	
		
		otl_stream oFund(100, sSql.c_str(), dbConnection);
		string sSqlTmp="";
		char cSerialNoTmp[20];
		memset(cSerialNoTmp,0,sizeof(cSerialNoTmp));
		while (!oFund.eof())
		{
			oFund >> cAcctNo >> stFund.dCapital >> stFund.dInCapital >> stFund.dOutCapital >> stFund.dlMarginMemLastDay 
				>> stFund.dlMarginExchLastDay >>stFund.dlCurrMarginExch >>stFund.dlCurrMarginMem;
			mapFund[cAcctNo] = stFund;

			// �����ͻ��б���ʼ�� add by zengweiwei 2013-11-21 
			if (fabs(stFund.dInCapital)>=0.0001||fabs(stFund.dOutCapital)>=0.0001)
			{
				m_InOutCustTbl.InsertByDb(cAcctNo,stFund.dInCapital,stFund.dOutCapital);
				sSqlTmp="Select serial_no From bank_capital_flow Where in_account_flag='1' And acct_no='";
				sSqlTmp+=cAcctNo;
				sSqlTmp+="'";
				CRLog(E_DEBUG, "%s",sSqlTmp.c_str());
				otl_stream oSerialNoTmp(1,sSqlTmp.c_str(),dbConnection);
				while (!oSerialNoTmp.eof())
				{
					oSerialNoTmp>>cSerialNoTmp;
					m_InOutCustTbl.InitSerialNo(cAcctNo,cSerialNoTmp);
				}
				
			}
		}
		CRLog(E_DEBUG, "��ʼ���ͻ�:%d ",mapFund.size());
		m_CapitalTbl.Init(dbConnection,m_BasicParaTbl);
		m_MatchDetailTbl.Init(dbConnection,m_BasicParaTbl);
		m_ETFMatchDetailTbl.Init(dbConnection, m_BasicParaTbl);

#ifdef _VER_25_PSBC
		CRLog(E_DEBUG, "��ʼ����Ӫӯ����Ϣ");
		// ��ʼ����Ӫӯ����Ϣ
		IniSelfSurplus(dbConnection);
#endif
		//��ʼ���ͻ��ֲܳ���Ϣ
		int flag = 0;
		flag = m_BasicParaTbl.GetDiffCovFareByCurrOrHisFlag();
		if(flag == 1)
		{
			sSql = "SELECT ACCT_NO,PROD_CODE,LAST_LONG_AMT,LAST_SHORT_AMT,CURR_LONG_AMT,CURR_SHORT_AMT,CURR_LONG_CAN_USE,CURR_SHORT_CAN_USE,";
			sSql += "OPEN_LONG_AMT,OPEN_SHORT_AMT,COV_LONG_FROZ_AMT,COV_LONG_AMT,COV_SHORT_FROZ_AMT,COV_SHORT_AMT,DELI_LONG_FROZ_AMT,DELI_LONG_AMT,";
			sSql += "DELI_SHORT_FROZ_AMT,DELI_SHORT_AMT,MIDD_OPEN_LONG_AMT,MIDD_OPEN_SHORT_AMT,LONG_LIMIT,SHORT_LIMIT,";
			sSql += "LONG_OPEN_AVG_PRICE,SHORT_OPEN_AVG_PRICE,LONG_POSI_AVG_PRICE,SHORT_POSI_AVG_PRICE,LONG_MARGIN,SHORT_MARGIN,LONG_SURPLUS,SHORT_SURPLUS,";
			sSql += "LAST_SETTLE_PRICE,DAY_SETTLE_PRICE";
			sSql += " FROM DEFER_POSI ORDER BY ACCT_NO,PROD_CODE ";
			otl_stream oTotalDeferPosi(1, sSql.c_str(), dbConnection);
			nRowNum = 0;
	
			while (!oTotalDeferPosi.eof())
			{
				CCustSymbolDeferPosi oCustDeferPosi;
				oTotalDeferPosi >>cAcctNo >> cProdCode
					>> oCustDeferPosi.dlLast_long_amt >> oCustDeferPosi.dlLast_short_amt >> oCustDeferPosi.dlCurr_long_amt >> oCustDeferPosi.dlCurr_short_amt >> oCustDeferPosi.dlCurr_long_can_use
					>> oCustDeferPosi.dlCurr_short_can_use >> oCustDeferPosi.dlOpen_long_amt >> oCustDeferPosi.dlOpen_short_amt >> oCustDeferPosi.dlCov_long_froz_amt
					>> oCustDeferPosi.dlCov_long_amt >> oCustDeferPosi.dlCov_short_froz_amt >> oCustDeferPosi.dlCov_short_amt >> oCustDeferPosi.dlDeli_long_froz_amt 
					>> oCustDeferPosi.dlDeli_long_amt >> oCustDeferPosi.dlDeli_short_froz_amt >> oCustDeferPosi.dlDeli_short_amt >> oCustDeferPosi.dlMidd_open_long_amt
					>> oCustDeferPosi.dlMidd_open_short_amt >> oCustDeferPosi.dlLong_limit >> oCustDeferPosi.dlShort_limit >> oCustDeferPosi.dlLong_open_avg_price
					>> oCustDeferPosi.dlShort_open_avg_price >> oCustDeferPosi.dlLong_posi_avg_price >> oCustDeferPosi.dlShort_posi_avg_price >> oCustDeferPosi.dlLong_margin
					>> oCustDeferPosi.dlShort_margin >> oCustDeferPosi.dlLong_surplus >> oCustDeferPosi.dlShort_surplus >> oCustDeferPosi.dlLast_settle_price >> oCustDeferPosi.dlDay_settle_price;
				oCustDeferPosi.sAcct_no.assign(cAcctNo);
				oCustDeferPosi.sProd_code.assign(cProdCode);
				if (nRowNum == 0)
				{
					strcpy(cLastAcctNo, cAcctNo);
					nRowNum++;
				}
				if (strcmp(cLastAcctNo, cAcctNo) != 0)
				{
					//CRLog(E_DEBUG, "id=%d, cLastAcctNo= %s",nRowNum,cLastAcctNo);
					mapCustSymbolDeferPosi[cLastAcctNo] = mapSymbolDeferPosi;
					mapSymbolDeferPosi.clear();				
				}
				mapSymbolDeferPosi[oCustDeferPosi.sProd_code] = oCustDeferPosi;

				//���ļ�¼
				strcpy(cLastAcctNo, cAcctNo);
			}
			if(mapSymbolDeferPosi.size() > 0)
				mapCustSymbolDeferPosi[cLastAcctNo] = mapSymbolDeferPosi;
			CRLog(E_DEBUG, "�ͻ��ֲܳ���Ϣ:%d ",mapSymbolDeferPosi.size());
		}
		
		CRLog(E_DEBUG, "%s","loading posi");

		//ȡ���ճֲ�
		sSql = "select a.acct_no, a.prod_code, a.long_short, a.remain, b.match_price from defer_posi_detail a, busi_back_flow b where a.match_no = b.match_no and a.order_no = b.order_no and stor_date = :f1<char[9]> and remain > 0 order by a.acct_no,a.order_no";
		otl_stream oDeferPosi(1, sSql.c_str(), dbConnection);
		oDeferPosi << m_BasicParaTbl.GetExchDate().c_str();
		nRowNum = 0;
		while (!oDeferPosi.eof())
		{
			oDeferPosi >> cAcctNo >> cProdCode >> cDir >> nNum >> dMatchPrice;
			m_ProdCodeTbl.GetMeasureUnit(cProdCode, dMeasureUnit);
			nIndex = m_ProdCodeTbl.Index(cProdCode);
			m_ProdCodeTbl.GetVarietyType(cProdCode, nType);

			if (nRowNum == 0)
			{
				strcpy(cLastAcctNo, cAcctNo);
				nRowNum++;
			}
			if (strcmp(cLastAcctNo, cAcctNo) != 0)
			{
			
				mapDeferPosiToday[cLastAcctNo] = vecDeferPosiToday;
				vecDeferPosiToday.clear();
			}

			CPosiToday* p = new CPosiToday(cProdCode, nType, cDir[0], nNum, dMeasureUnit, dMatchPrice, nIndex);
			vecDeferPosiToday.push_back(p);

			//���ļ�¼
			strcpy(cLastAcctNo, cAcctNo);
		}
		if (0 < vecDeferPosiToday.size())
			mapDeferPosiToday[cAcctNo] = vecDeferPosiToday;

		CRLog(E_DEBUG, "ȡ���ճֲ�:%d ",vecDeferPosiToday.size());


		//ȡ��ʷ�ֲ�
		sSql = "select acct_no, prod_code, long_short, sum(remain) sremain from defer_posi_detail where stor_date < :f1<char[9]> group by rownum, acct_no, prod_code, long_short having sum(remain) > 0 order by acct_no";
		otl_stream oDeferPosiHis(1, sSql.c_str(), dbConnection);
		oDeferPosiHis << m_BasicParaTbl.GetExchDate().c_str();
		nRowNum = 0;
		while (!oDeferPosiHis.eof())
		{
			oDeferPosiHis >> cAcctNo >> cProdCode >> cDir >> nNum;
			m_ProdCodeTbl.GetMeasureUnit(cProdCode, dMeasureUnit);
			nIndex = m_ProdCodeTbl.Index(cProdCode);
			m_ProdCodeTbl.GetVarietyType(cProdCode, nType);
			map<string, double>::iterator itProdMarket = mapProdMarket.find(cProdCode);
			if (itProdMarket != mapProdMarket.end())
			{
				dMatchPrice = itProdMarket->second;
			}

			if (nRowNum == 0)
			{
				strcpy(cLastAcctNo, cAcctNo);
				nRowNum++;
			}
			if (strcmp(cLastAcctNo, cAcctNo) != 0)
			{
				mapDeferPosiHis[cLastAcctNo] = vecDeferPosiHis;
				vecDeferPosiHis.clear();
			}

			CPosiHis* p = new CPosiHis(cProdCode, nType, cDir[0], nNum, dMeasureUnit, dMatchPrice, nIndex);
			vecDeferPosiHis.push_back(p);

			//���ļ�¼
			strcpy(cLastAcctNo, cAcctNo);
		}
		if (0 < vecDeferPosiHis.size())
			mapDeferPosiHis[cAcctNo] = vecDeferPosiHis;

		CRLog(E_DEBUG, "ȡ��ʷ�ֲ�:%d ",vecDeferPosiHis.size());

		//�������
		dbConnection.commit();
	
		nIndex=m_CustomerTbl.Init(dbConnection, m_AgentTbl, m_CustFeeDetailTbl, m_ExchFeeDetailTbl,m_FeeModelDetailTbl,m_EtfFeeDetailTbl, m_ProdCodeTbl, m_BasicParaTbl, mapFund, mapDeferPosiToday, mapDeferPosiHis,mapCustSymbolDeferPosi);
		if(nIndex != 0)
		{
			CRLog(E_CRITICAL,"%s","init m_CustomerTbl info fail!");
			return -1;
		}
		return 0;		
	}
	catch(otl_exception &p)
	{
		//�������
		dbConnection.commit();
		CRLog(E_ERROR, "otl exception:%s,%s,%s,%s", p.msg, p.stm_text, p.sqlstate, p.var_info);
		return 0;
	}
	catch(std::exception e)
	{
		CRLog(E_CRITICAL,"exception:%s", e.what());
		return -1;
	}
	catch(...)
	{
		CRLog(E_CRITICAL,"%s","Unknown exception");
		return -1;
	}
	return 0;
}

//��ȡ��Ӫ�ͻ�ָ����Լӯ��ֵ��Ϣ
int CMemDb::GetSelfProdCodeSurplus(const string sAcct_no,const string sProd_code,double& dlSurplusMoths,double& dlSurplusYear)
{
	CGessGuard guard(m_mutexDb);
	map<string,vector<TSelfSurplus> >::iterator itIter = m_mapSelfSurplus.find(sAcct_no);
	vector<TSelfSurplus>::iterator it;
	if( itIter != m_mapSelfSurplus.end())
	{
		vector<TSelfSurplus> vecSurplus = itIter->second;
		for(it =vecSurplus.begin();it != vecSurplus.end(); ++it)
		{
			if(it->sProd_Code == sProd_code)
			{
				dlSurplusMoths = it->dlSurplus_month; //��ǰӯ��
				dlSurplusYear = it->dlSurplus_year; //��ǰӯ��
				return 0;
			}
		}
	}
	return -1;
}

//��ȡ��Ӫ�ͻ�ָ����Լӯ��ֵ��Ϣ
int CMemDb::GetSelfTotalSurplus(const string sAcct_no,double& dlTotalMoths,double& dlTotalYear)
{
	dlTotalMoths = 0.0;
	dlTotalYear = 0.0;

	CGessGuard guard(m_mutexDb);
	map<string,vector<TSelfSurplus> >::iterator itIter = m_mapSelfSurplus.find(sAcct_no);
	vector<TSelfSurplus>::iterator it;
	if( itIter != m_mapSelfSurplus.end())
	{
		vector<TSelfSurplus> vecSurplus = itIter->second;
		for(it =vecSurplus.begin();it != vecSurplus.end(); ++it)
		{
			dlTotalMoths += it->dlSurplus_month; //��ǰӯ��
			dlTotalYear += it->dlSurplus_year; //��ǰӯ��
		}
		return 0;
	}
	return -1;
}

void CMemDb::InitRiskGradeMap(otl_connect& dbConnection)
{
	char cGradeName[128];
	short usGradeID;
	string sSql;
	sSql = "select grade_id, grade_name from risk_grade";
	otl_stream oRiskGrade(1,sSql.c_str(), dbConnection);
	while (!oRiskGrade.eof())
	{
		memset(cGradeName, 0, sizeof(cGradeName));
		oRiskGrade >> usGradeID >> cGradeName;
		m_mRiskGradeName[usGradeID] = cGradeName;
	}

	//ȡ�ͻ����չ�ϵ
	CRLog(E_DEBUG, "CMemDb::InitRiskGradeMap ȡ���յȼ�:%d ",m_mRiskGradeName.size());
}
string CMemDb::GetRiskGradeName(unsigned short uRiskGrade)
{
	string result("");
	map<unsigned short,string>::iterator itRiskGrade;
	itRiskGrade = m_mRiskGradeName.find(uRiskGrade);
	if(itRiskGrade != m_mRiskGradeName.end())
	{
		result = itRiskGrade->second;
	}
	else
		CRLog(E_ERROR,"���ռ���[%d]�Ҳ�����Ӧ�ķ��ռ�������",uRiskGrade);
	return result;
}
void CMemDb::Finish()
{
	CGessGuard guard(m_mutexDb);
	m_ForceCloseParaTbl.Finish();
	m_MatchDetailTbl.Finish();
	m_ETFMatchDetailTbl.Finish();
	m_CapitalTbl.Finish();
	m_CustomerTbl.Finish();
	m_CustFeeDetailTbl.Finish();
	m_FeeModelDetailTbl.Finish();
	m_AgentTbl.Finish();
	m_TriggerTbl.Finish();
	m_QuotationTbl.Finish();
	m_ProdCodeTbl.Finish();
	m_RiskNotifyTbl.Finish();
	m_RiskTipParaTbl.Finish();
	m_BasicParaTbl.Finish();	
	m_RealTimeRiskTbl.Finish();
	m_RiskGradeDefineTbl.Finish();
	m_ParameterTbl.Finish();
	m_EntrFlowTbl.Finish();
	m_AutoForceExecptCndTbl.Finish();
	m_SmsFormatTbl.Finish();
	m_InOutCustTbl.Finish();
	m_mRiskGradeName.clear();

	m_RiskAlarmParaTbl.Finish();
	m_mapSelfSurplus.clear();
}

int CMemDb::ReInit()
{
	CGessGuard guard(m_mutexDb);

	Finish();
	return Init(m_pConfig);
}

int CMemDb::IniSelfSurplus( otl_connect& dbConnection )
{
	//��ȡ��Ӫ�ͻ�����ӯ��
	string sCurExchDate = m_BasicParaTbl.GetExchDate();

	string sSql = "select r.acct_no, r.variety as prod_code, r.month_profit as monthSurplus,r.year_profit as yearSurplus "
		" from report_self_variety_risk r "
		" where r.exch_date =  (select max(exch_date) from system_stat where exch_date < '"+sCurExchDate+"') "
		" order by r.acct_no, r.variety	";

	//CRLog(E_DEBUG, "��Ӫӯ�� sql=:%s ",sSql.c_str());
	int nRowNum =0;
	vector<TSelfSurplus> vecSelfSurplus;

	double dlSurplusMoths =0.0;         //��ǰӯ��ֵ
	double dlSurplusYear = 0.0;			//����ӯ��ֵ

	char cLastAcctNo[16];               // ��һ���ͻ���
	char cAcctNo[16];					//�ͻ���
	char cProdCode[11];					//��Լ����
	memset(cAcctNo, 0, sizeof(cAcctNo));
	memset(cProdCode, 0, sizeof(cProdCode));
	memset(cLastAcctNo, 0, sizeof(cLastAcctNo));

	this->m_mapSelfSurplus.clear();
	vecSelfSurplus.clear();
	otl_stream oCustSelfStream(10, sSql.c_str(), dbConnection);
	while(!oCustSelfStream.eof())
	{
		oCustSelfStream >> cAcctNo >> cProdCode >> dlSurplusMoths >> dlSurplusYear;
		if (nRowNum == 0)
		{
			strcpy(cLastAcctNo, cAcctNo);
			nRowNum++;
		}
		if (strcmp(cLastAcctNo, cAcctNo) != 0)
		{
			m_mapSelfSurplus[cLastAcctNo] = vecSelfSurplus;
			vecSelfSurplus.clear();
		}

		TSelfSurplus selfSurplus;
		selfSurplus.sProd_Code = string(cProdCode);
		selfSurplus.dlSurplus_month = dlSurplusMoths;		//����ӯ��ֵ
		selfSurplus.dlSurplus_year = dlSurplusYear;		//����ӯ��ֵ

		vecSelfSurplus.push_back(selfSurplus);

		//���ļ�¼
		strcpy(cLastAcctNo, cAcctNo);
	}
	if (0 < vecSelfSurplus.size())
		m_mapSelfSurplus[cAcctNo] = vecSelfSurplus;

	return 0;
}



