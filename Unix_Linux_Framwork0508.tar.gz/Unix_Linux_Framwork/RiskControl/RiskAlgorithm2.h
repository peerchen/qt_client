#ifndef CRISKALGORITHM2_H_HEADER_INCLUDED
#define CRISKALGORITHM2_H_HEADER_INCLUDED
#include <cmath>
#include <limits>
#include "RiskAlgorithm.h"
#include "strutils.h"
#include "Constant.h"

using namespace strutils;
using namespace Const;

class CRiskAlgorithm2: public CRiskAlgorithm
{
public:
	CRiskAlgorithm2(){}
	~CRiskAlgorithm2(){}

	//���ն�2 ���㹫ʽ
	inline double Risk(double dlCapital, double dlMarginMenber, double dlBalance,double dlMarginExch) 
	{
		double dlRiskDegree = 0.00;
		if (dlMarginMenber<= numeric_limits<double>::epsilon())
		{
			dlRiskDegree=-10000.00;
		} 
		//else if ((dlCapital+dlBalance)<= numeric_limits<double>::epsilon())
		//{
		//	dlRiskDegree=0.00;
		//}
		else
		{
			dlRiskDegree=-(dlCapital+dlBalance)/dlMarginMenber;
			if (dlRiskDegree>100)
				dlRiskDegree=100.00;
			else if(dlRiskDegree<-10000)
				dlRiskDegree=-10000.00;
		}
		return dlRiskDegree;
	}
};

#endif 
