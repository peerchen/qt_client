#include "DbSync.h"
#include "MemDb.h"
#include "RiskHandler.h"

// A1 �ӿ� [onBaseTableUpdate]BaseTableUpdate ��ҵ��ʵ��
int CDbSync::OnBaseTableUpdate(CBroadcastPacket& pkt)
{
	BaseTableUpdate stBody;
	CPacketStructBroadcastRisk::Packet2Struct(stBody, pkt);

	//ҵ��ʵ��......
	SendAck(pkt);

	//bank_info
	//bank_mer_code_info
	//branch_info
	//broker_info
	//code_table
	//fare_model_def
	//acct_fare_detail
	//fare_model_detail
	//instID_def
	//system_para
	//teller_info
	//variety
	if ("acct_fare_detail" == stBody.table_name)
	{
		m_pMemDb->ReLoadCustFeeTbl();

		CBroadcastPacket ntfPkt("OnNotifyFeeInfo");
		m_pRiskHandler->Enque(ntfPkt);
	}
	else if ("gess_acct_fare_detail" == stBody.table_name)
	{
		m_pMemDb->ReLoadExchFeeTbl();
		CBroadcastPacket ntfPkt("OnNotifyFeeInfo");
		m_pRiskHandler->Enque(ntfPkt);
	}
	else if ("fare_model_detail" == stBody.table_name)
	{
		m_pMemDb->ReLoadModelFeeTbl();

		CBroadcastPacket ntfPkt("OnNotifyFeeInfo");
		m_pRiskHandler->Enque(ntfPkt);
	}
	else if ("system_para" == stBody.table_name)
	{
		m_pMemDb->ReLoadBasicParaTbl();
	}
	else
	{

	}

	return 0;
};

