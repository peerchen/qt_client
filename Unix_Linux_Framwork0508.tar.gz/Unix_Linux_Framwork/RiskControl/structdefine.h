#ifndef _STRUCT_DEFINE_H
#define _STRUCT_DEFINE_H

//���
typedef struct tagOffsetFund
{
	double dlOffsetTotal;
	double dlOffsetTotalLast;
	double dlOffsetCanUse;
	double dlOffsetCanUseLast;
	double dlOffsetMarginMem;
	double dlOffsetMarginMemLast;
	double dlOffsetMarginExch;
	double dlOffsetMarginExchLast;
	double dlOffsetFrozen;

	tagOffsetFund()
	{
		dlOffsetTotal = 0.0;
		dlOffsetTotalLast = 0.0;
		dlOffsetCanUse = 0.0;
		dlOffsetCanUseLast = 0.0;
		dlOffsetMarginMem = 0.0;
		dlOffsetMarginMemLast = 0.0;
		dlOffsetMarginExch = 0.0;
		dlOffsetMarginExchLast = 0.0;
		dlOffsetFrozen = 0.0;
	}
}OffsetFund,*POffsetFund;

#endif