#include "RiskCpMgr.h"
#include "RiskConstant.h"
#include "RiskHandler.h"
#include "GessDate.h"

using namespace RiskConst;

// A1 �ӿ� [onSysStatChange]SysStat ��ҵ��ʵ��
int CRiskCpMgr::OnSysStat(CBroadcastPacket& pkt)
{
	SysStat stBody;
	CPacketStructBroadcastRisk::Packet2Struct(stBody, pkt);

	//ҵ��ʵ��......
	SendAck(pkt);

	CRLog(E_APPINFO,"%s",pkt.Print().c_str());

	int nState = FromString<int>(stBody.m_sys_stat);

	//
	if (nState >= gc_nSysStateDataInit)
	{
		m_nSysState = nState;
	}
	else
	{
		m_nSysState = gc_nSysStateReady;
	}

	if (gc_nSysStateAcctFinish == nState)
	{
		//CGessDate oDate(stBody.exch_date);
		//oDate++;

		//CRLog(E_APPINFO,"simulate exch date :%s",oDate.ToString().c_str());
		//msleep(5);
		//SysInit(oDate.ToString());

		////ģ�����鴥��һ�η��նȱ�������
		//vector<string> v;
		////OnCmd("test", v);
		//msleep(1);
		//CBroadcastPacket pkt("onRecvDeferQuotation");
		//m_pRiskHandler->Enque(pkt);

		//m_nSysState = gc_nSysStateReady;
		//NotifyClientInit();
	}

	
	return 0;
}