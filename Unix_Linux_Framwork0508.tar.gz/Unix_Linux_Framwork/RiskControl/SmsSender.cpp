#include "SmsSender.h"
#include <otlv4.h> 
#include "Logger.h"
#include "ProcessInterfaceSmsc.h"
#include "GessTime.h"
#include "GessDate.h"
#include "TcpShortCp.h"
#include "Customer.h"
#include "Encode.h"

CSmsSender::CSmsSender(CMemDb* pMemDb):
m_sExchDate(""),
m_pCfg(0),
m_pCpInterfaceSms(0),
m_bIsFirstSend(true),
m_pMemDb(pMemDb)
{

}

CSmsSender::~CSmsSender()
{
	for (size_t i=0;i<m_SmsSendInfo.size();i++)
	{
		delete m_SmsSendInfo[i];
	}
	m_SmsSendInfo.clear();

	if(0!=m_pCpInterfaceSms)
	{
		delete m_pCpInterfaceSms;
		m_pCpInterfaceSms=0;
	}
	
}

int CSmsSender::Start()
{
	
	BeginThread();
	return 0;
}
void CSmsSender::Stop()
{
	m_bEndThread= true;
}
int CSmsSender::Init(CConfig *pConfig)
{
	char cExchDate[9];		//��������
	char cMobile[32];		//�ֻ�����
	char cAcctNo[16];		//�ͻ���
	int  iRiskType;		//��������
	double dlDebtCall;			//׷�����
	double dlBalance;			//����ӯ��
	double dlRiskDegree1;		//���ն�1
	double dlMargin;				//��֤��
	double dlCapital;			//�����ʽ�
	memset(cExchDate, 0, sizeof(cExchDate));
	memset(cMobile, 0, sizeof(cMobile));
	memset(cAcctNo, 0, sizeof(cAcctNo));
	m_pCfg=pConfig;
	try
	{	
		//���ض��ŷ�����ip��ַ�����ip��ַΪ�գ����������ŷ���
		string ip="";
		m_pCfg->GetProperty("ip",ip);
		if(ip=="")
		{
			m_bEndThread= true;
			return 0;
		}

		//ȡ��������
		string sSql = "select exch_date from system_stat order by exch_date desc";
		otl_stream oSysStat(1, sSql.c_str(), GetOtlConn());
		if (!oSysStat.eof())
		{
			oSysStat >> cExchDate;
			if(!oSysStat.eof())
			{
				oSysStat >> cExchDate;
			}
			m_sExchDate=cExchDate;
		}
		oSysStat.close();

		//�����ݿ����Ҫ���͵Ķ�����Ϣ
		sSql = "SELECT b.ACCT_NO, c.MOBILE_PHONE,b.RISK_TYPE ,b.RISK_DEGREE1,b.MARK_SURPLUS,b.MARGIN_CALL,b.CAN_USE_BAL  ,b.MARGIN FROM "
			" (SELECT t.ACCT_NO,t.RISK_TYPE ,t.RISK_DEGREE1,t.MARK_SURPLUS,t.MARGIN_CALL ,t.CAN_USE_BAL  ,t.MARGIN_EXCH+t.MARGIN_MEM AS MARGIN FROM HIS_END_DAY_RISK_DETAIL  t WHERE t.EXCH_DATE='"+m_sExchDate+"' AND t.SEND_STATE=0) b "
			"  JOIN CUST_APPEND_INFO c ON b.ACCT_NO=c.ACCT_NO ";
		otl_stream oSmsInfo(1, sSql.c_str(), GetOtlConn());

		CRLog(E_APPINFO,"����֪ͨsql�� %s \n",sSql.c_str());
		int i=1;
		while(!oSmsInfo.eof())
		{
			oSmsInfo>>cAcctNo>>cMobile>>iRiskType>>dlRiskDegree1>>dlBalance>>dlDebtCall>>dlCapital>>dlMargin;
			string acct_no=cAcctNo;
			CCustomer* p=m_pMemDb->GetCustTble().GetCustomer(acct_no);
			if(p==0)
			{
				continue;
			}
			SmsSendInfo * temp= new SmsSendInfo;
			temp->sCustNo=cAcctNo;
			temp->sAgentName=p->AgentName();
			temp->sCustAbbr=p->CustAbbr();
			temp->sAcctType=p->AcctType();
			temp->sMobile=cMobile;
			temp->iRiskType =iRiskType;
			temp->dlRiskDegree1=dlRiskDegree1;
			temp->dlBalance=dlBalance;
			temp->dlDebtCall=dlDebtCall;
			temp->dlCapital=dlCapital;
			temp->dlMargin=dlMargin;
			temp->sContent=ConverToSmsCotent(temp);
			temp->sSeq=ToString(i++);
			m_SmsSendInfo.push_back(temp);

		}
		oSmsInfo.close();
		
		CRLog(E_APPINFO,"�����ݿ�ȡ���ķ��տͻ����� %d \n",m_SmsSendInfo.size());
		//SmsSendInfo * temp= new SmsSendInfo;
		//temp->sMobile="13528485747";
		//temp->sContent="tttt";
		//temp->sCustNo="1";
		//temp->sSeq="000001010";
		//m_SmsSendInfo.push_back(temp);

		m_pCpInterfaceSms = new CTcpShortCpCli<CProcessInterfaceSmsc>;
		m_pCpInterfaceSms->Init(pConfig);
		
		//���ض������ò���
		m_pCfg->GetProperty("PKGTYPE",conInfo.pkg_type);
		m_pCfg->GetProperty("PKGSRC",conInfo.pkg_src);
		m_pCfg->GetProperty("TRANCODE",conInfo.tran_code);
		m_pCfg->GetProperty("SUBPORT",conInfo.sub_port);
		m_pCfg->GetProperty("BUSICODE",conInfo.busi_code);
		m_pCfg->GetProperty("SENDDEPTID",conInfo.send_deptid);
		m_pCfg->GetProperty("SPID",conInfo.spid);
		m_pCfg->GetProperty("CODE",conInfo.code);
		m_pCfg->GetProperty("SRCIDFLAG",conInfo.srcid_flag);
		m_pCfg->GetProperty("FEEFLAG",conInfo.fee_flag);

		return 0;
		//m_OtlConn.logoff();
	}
	catch(otl_exception& p1)
	{
		CRLog(E_ERROR,"otl exception:%s,%s,%s,%s",p1.msg,p1.stm_text,p1.sqlstate,p1.var_info);
		
	}
	return -1;

}


int CSmsSender::ThreadEntry()
{

	while (!m_bEndThread)
	{
		vector<SmsSendInfo *> err;
		vector<SmsSendInfo *> suss;
		if (m_SmsSendInfo.size()==0)
		{
			//�Ƴ�����
			m_bEndThread= true;
			break;
		}
		//ѭ�����Ͷ���
		for (size_t i=0;i<m_SmsSendInfo.size();i++)
		{
			//���Ͷ���
			CSmsPacket  sendPacket,rcvPacket;
			this->GetSendMsg(sendPacket,m_SmsSendInfo[i]);
			m_pCpInterfaceSms->SendPacket(sendPacket,rcvPacket,20);
			SMS_HEADER header;
			rcvPacket.GetHeader(header);
			
			//msg.GetValue()
			string succFlag=header.succ_flag;
			string fid="01";
			CRLog(E_APPINFO,"���ŷ���:�ͻ��ţ�%s,����״̬��%s\n",m_SmsSendInfo[i]->sCustNo.c_str(),rcvPacket.GetFiledByFid(fid).c_str());
			if("1"==succFlag&&"0000"==rcvPacket.GetFiledByFid(fid)) //���ͳɹ�
			{
				suss.push_back(m_SmsSendInfo[i]);
				UpdateSmsState(m_SmsSendInfo[i],"1");

			}
			else //����ʧ��
			{
				err.push_back(m_SmsSendInfo[i]);
				if(m_bIsFirstSend)
					UpdateSmsState(m_SmsSendInfo[i],"2");
			}
		}
	   //���ԭ��������
		m_SmsSendInfo.clear();
		//�ѷ���ʧ�ܵģ��ڷŵ����Ͷ�������
		for(size_t i=0;i<err.size();i++)
		{
			m_SmsSendInfo.push_back(err[i]);
		}
		err.clear();
		//�ͷŷ��ͳɹ��� �ڴ�
		for(size_t i=0;i<suss.size();i++)
		{
			delete suss[i];
		}
		suss.clear();
		m_bIsFirstSend=false;
		msleep(SLEEPTIME); 

	}
	return 0;
}

otl_connect & CSmsSender::GetOtlConn() throw(otl_exception)
{
	try
	{	
		otl_stream o(1, "select 1 from dual", m_OtlConn); 
	}
	catch(otl_exception& p)
	{  
		//�����쳣�������������ݿ�
		string sUser = "";		//���ݿ��û���
		string sPwd = "";		//����
		string sTns = "";		//������
		string sConnStr = "";	//�����ַ���
		m_pCfg->GetCfgGlobal()->GetProperty("user", sUser);
		m_pCfg->GetCfgGlobal()->GetProperty("pwd", sPwd);
		m_pCfg->GetCfgGlobal()->GetProperty("tns", sTns);

		char szPwdEnc[512];
		char szPwdDec[512];
		strcpy(szPwdEnc,sPwd.c_str());
		//CEncode::PwdBase64Dec3Des(szPwdEnc,szPwdDec,sizeof(szPwdDec));

		//sConnStr = sUser + "/" + szPwdDec + "@" + sTns;
		
sConnStr = sUser + "/" + szPwdEnc + "@" + sTns;
		
		try
		{	
			m_OtlConn.logoff();
			m_OtlConn.rlogon(sConnStr.c_str());
			otl_stream o(1, "select 1 from dual", m_OtlConn); 
		}
		catch(otl_exception& p1)
		{
			CRLog(E_ERROR,"otl exception:%s,%s,%s,%s",p1.msg,p1.stm_text,p1.sqlstate,p1.var_info);
			throw p1;
		}

	}
	return m_OtlConn;
}
//�������ݿ���ŷ���״̬ 0Ϊ���� 1 �ѷ��� 2����ʧ��
void CSmsSender::UpdateSmsState(SmsSendInfo *smsInfo,const string & state )
{
	string sSql="UPDATE HIS_END_DAY_RISK_DETAIL SET SMS_CONTENT='"+smsInfo->sContent+"', SEND_STATE="+state+" WHERE EXCH_DATE='"+m_sExchDate+"' AND ACCT_NO='"+smsInfo->sCustNo+"'";
	CRLog(E_APPINFO,"����֪ͨsql :%s \n",sSql.c_str());
	try
	{	
		otl_stream o(1,sSql.c_str(), GetOtlConn()); 	
		m_OtlConn.commit();
	}
	catch(otl_exception& p1)
	{
		CRLog(E_ERROR,"otl exception:%s,%s,%s,%s",p1.msg,p1.stm_text,p1.sqlstate,p1.var_info);
		
	}
		

}

void CSmsSender::GetSendMsg(CSmsPacket & sendPacket ,SmsSendInfo * sendInfo )
{
	SMS_HEADER header;
	
	memset(header.seq,0x00,sizeof(header.seq));
	sprintf(header.seq,"%s",sendInfo->sSeq.c_str());

	memset(header.pkg_type,0x00,sizeof(header.pkg_type));
	sprintf(header.pkg_type,"%s",conInfo.pkg_type.c_str());

	memset(header.pkg_src,0x00,sizeof(header.pkg_src));
	sprintf(header.pkg_src,"%s",conInfo.pkg_src.c_str());

	memset(header.tran_code,0x00,sizeof(header.tran_code));
	sprintf(header.tran_code,"%s",conInfo.tran_code.c_str());

	memset(header.priority,0x00,sizeof(header.priority));
	sprintf(header.priority,"%d",5);
	
	string date=CGessDate::NowToString("").substr(2,6);
	memset(header.tran_date,0x00,sizeof(header.tran_date));
	sprintf(header.tran_date,"%s",date.c_str());

	string time=CGessTime::NowToString("")+"000";
	memset(header.tran_time,0x00,sizeof(header.tran_time));
	sprintf(header.tran_time,"%s",time.c_str());

	memset(header.ra_flag,0x00,sizeof(header.ra_flag));
	sprintf(header.ra_flag,"%c",'R');

	memset(header.enc_flag,0x00,sizeof(header.enc_flag));
	sprintf(header.enc_flag,"%s","N");

	memset(header.totals,0x00,sizeof(header.totals));
	sprintf(header.totals,"%d",1);

	memset(header.rec_no,0x00,sizeof(header.rec_no));
	sprintf(header.rec_no,"%d",1);

	memset(header.succ_flag,0x00,sizeof(header.succ_flag));
	memset(header.reserved,0x00,sizeof(header.reserved));

	sendPacket.SetHeader(header);
	
	SmsField fild;
	memset(fild.fid,0x00,sizeof(fild.fid));
	memset(fild.fdata,0x00,sizeof(fild.fdata));
	memset(fild.flen,0x00,sizeof(fild.flen));

	
	sprintf(fild.fid,"%s","01");
	sprintf(fild.flen,"%d",conInfo.sub_port.length());
	sprintf(fild.fdata,"%s",conInfo.sub_port.c_str());
	sendPacket.AddField(fild);
	

	sprintf(fild.fid,"%s","02");
	sprintf(fild.flen,"%d",conInfo.busi_code.length());
	sprintf(fild.fdata,"%s",conInfo.busi_code.c_str());
	sendPacket.AddField(fild);
	
	sprintf(fild.fid,"%s","03");
	sprintf(fild.flen,"%d",conInfo.send_deptid.length());
	sprintf(fild.fdata,"%s",conInfo.send_deptid.c_str());
	sendPacket.AddField(fild);

	sprintf(fild.fid,"%s","04");
	sprintf(fild.flen,"%d",conInfo.spid.length());
	sprintf(fild.fdata,"%s",conInfo.spid.c_str());
	sendPacket.AddField(fild);

	sprintf(fild.fid,"%s","05");
	sprintf(fild.flen,"%d",sendInfo->sMobile.length());
	sprintf(fild.fdata,"%s",sendInfo->sMobile.c_str());
	sendPacket.AddField(fild);

	sprintf(fild.fid,"%s","06");
	sprintf(fild.flen,"%d",conInfo.code.length());
	sprintf(fild.fdata,"%s",conInfo.code.c_str());
	sendPacket.AddField(fild);

	sprintf(fild.fid,"%s","07");
	sprintf(fild.flen,"%d",ToString(sendInfo->sContent.length()).length());
	sprintf(fild.fdata,"%d",sendInfo->sContent.length());
	sendPacket.AddField(fild);

	sprintf(fild.fid,"%s","08");
	sprintf(fild.flen,"%d",sendInfo->sContent.length());
	sprintf(fild.fdata,"%s",sendInfo->sContent.c_str());
	sendPacket.AddField(fild);

	sprintf(fild.fid,"%s","09");
	sprintf(fild.flen,"%d",1);
	sprintf(fild.fdata,"%d",5);
	sendPacket.AddField(fild);

	sprintf(fild.fid,"%s","10");
	sprintf(fild.flen,"%d",1);
	sprintf(fild.fdata,"%d",1);
	sendPacket.AddField(fild);

	sprintf(fild.fid,"%s","11");
	sprintf(fild.flen,"%d",conInfo.srcid_flag.length());
	sprintf(fild.fdata,"%s",conInfo.srcid_flag.c_str());
	sendPacket.AddField(fild);

	sprintf(fild.fid,"%s","12");
	sprintf(fild.flen,"%d",conInfo.fee_flag.length());
	sprintf(fild.fdata,"%s",conInfo.fee_flag.c_str());
	sendPacket.AddField(fild);



	//memset(header.fields,0x00,sizeof(header.fields));
	//sprintf(header.enc_flag,"%s","12");

	


}
int CSmsSender::End()
{
	return 0;
}
string CSmsSender::ConverToSmsCotent(SmsSendInfo * smsSendInfo)
{	
	char cContent[1000];	    //����ģ��
	string content="";
	memset(cContent,0x00,sizeof(cContent));
	try
	{

		string sSql="select SMS_CONTENT_FMT from RISK_SMS_NOTIFY_PARA where ACCT_TYPE=:f1<int> and RISK_TYPE=:f2<int>";
		otl_stream o(1, sSql.c_str(), GetOtlConn());
		o<<atoi(smsSendInfo->sAcctType.c_str())<<smsSendInfo->iRiskType;
		if(!o.eof())
		{
			o>>cContent;
		}
		content=cContent;
		string aCustRinfo[CONTENT_NUM];
		aCustRinfo[0]=smsSendInfo->sCustNo; 
		aCustRinfo[1]=smsSendInfo->sCustAbbr;
		aCustRinfo[2]=smsSendInfo->sAgentName;
		aCustRinfo[3]=ToString(smsSendInfo->dlRiskDegree1);
		aCustRinfo[4]=ToString(smsSendInfo->dlCapital);
		aCustRinfo[5]=ToString(smsSendInfo->dlMargin);
		aCustRinfo[6]=ToString(smsSendInfo->dlBalance);
		aCustRinfo[7]=ToString(smsSendInfo->dlDebtCall);

		string year= m_pMemDb->GetBasicParaTbl().GetExchDate().substr(0,4);
		string month=m_pMemDb->GetBasicParaTbl().GetExchDate().substr(4,2);
		string day=m_pMemDb->GetBasicParaTbl().GetExchDate().substr(6,2);
		aCustRinfo[8]=year+"��"+month+"��"+day+"��";
		//�滻ָ���ַ�������
		for(int i=0;i<CONTENT_NUM;i++)
		{
	      for(string::size_type pos(0);pos!=string::npos;pos+=aCustRinfo[i].length()) 
			{   
				if((pos=content.find(NOTIFY_CONTENT[i],pos))!=string::npos)  
				{
				  content.replace(pos,NOTIFY_CONTENT[i].length(),aCustRinfo[i]);   
				}
				else  
				{
					break;   
				}
			 }   
		 }
		
	}catch(otl_exception& p)
	{  
		CRLog(E_ERROR, "��ѯ����֪ͨģ�屨��!DB:MSG:%s\nTEXT:%s\nVARINFO:%s", p.msg, p.stm_text, p.var_info); 
	}catch(std::exception e)
	{
		CRLog(E_ERROR,"exception:%s!",e.what());
		
	}
	catch(...)
	{
		CRLog(E_ERROR,"%s","Unknown exception!");
		
	}
	return content;
}
