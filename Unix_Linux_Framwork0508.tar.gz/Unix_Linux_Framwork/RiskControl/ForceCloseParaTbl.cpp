#include "ForceCloseParaTbl.h"
#include "DB_Version.h" 
#include "Logger.h"
//#include "VersionMacro.h"
#include "strutils.h"
using namespace strutils;

CForceCloseParaTbl::CForceCloseParaTbl()
{

}

CForceCloseParaTbl::~CForceCloseParaTbl()
{
	Finish();
}

//##ModelId=491A4970003E
int CForceCloseParaTbl::GetRecordSet(vector<PROD_PRIORITY>& vecProdPri)
{
	vector<PROD_PRIORITY>::iterator it;
	CGessGuard guard(m_mutexTbl);
	for (it = m_vecPriority.begin(); it != m_vecPriority.end(); ++it)
	{
		vecProdPri.push_back(*it);
	}
	return 0;
}

int CForceCloseParaTbl::UpdateRecord(vector<PROD_PRIORITY>& vecProdPri)
{
	vector<PROD_PRIORITY>::iterator it;

	CGessGuard guard(m_mutexTbl);
	m_vecPriority.clear();
	for (it = vecProdPri.begin(); it != vecProdPri.end(); ++it)
	{
		m_vecPriority.push_back(*it);
	}
	return 0;
}

//##ModelId=491A4DD703A9
int CForceCloseParaTbl::Init(otl_connect& dbConnection)
{
	char cProdCode[11];		//��Լ����
	char cBs[3];				//��������
	char cPriority[11];			//����˳��
	PROD_PRIORITY stProdPriority;
	string sSql = "";

	memset(cProdCode, 0, sizeof(cProdCode));
	memset(cBs, 0, sizeof(cBs));
	memset(cPriority, 0, sizeof(cPriority));


	CRLog(E_DEBUG, "loading force_cover_priority info[%s]"," ......");
	try
	{
		//ǿƽ˳�������
#ifdef _VER_25_DB2
		sSql = "select prod_code, bs, FG_CovToChar(priority) from force_cover_priority order by priority";
#else
		sSql = "select prod_code, bs, to_char(priority) from force_cover_priority order by priority";
#endif

		otl_stream oForce(1, sSql.c_str(), dbConnection);

		CGessGuard guard(m_mutexTbl);
		while (!oForce.eof())
		{
			oForce >> cProdCode >> cBs >> cPriority;

			stProdPriority.sProdCode = cProdCode;
			string sDir = cBs;
			stProdPriority.ucDir = trim(sDir).c_str()[0];
			stProdPriority.nPriority = atoi(cPriority);

			m_vecPriority.push_back(stProdPriority);
		}
	}
	catch(otl_exception &p)
	{
		CRLog(E_ERROR, "otl exception:%s,%s,%s,%s", p.msg, p.stm_text, p.sqlstate, p.var_info);
	}

	return 0;
}

//��������
void CForceCloseParaTbl::Finish()
{
	CGessGuard guard(m_mutexTbl);
	m_vecPriority.clear();
}

