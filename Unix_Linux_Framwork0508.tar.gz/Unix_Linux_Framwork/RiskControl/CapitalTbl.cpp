#include <sstream>
#include <iomanip>
#include "CapitalTbl.h"
#include "BasicParaTbl.h"
#include "DB_Version.h" 
#include "Logger.h"
#include "RiskConstant.h"

CCapitalTbl::CCapitalTbl()
{

}

CCapitalTbl::~CCapitalTbl()
{
	Finish();
}

//##ModelId=491A39330213
bool CCapitalTbl::IsHandled(const string& sKey,const string& sAcctNo)
{
	bool blRtn = false;

	CGessGuard guard(m_mutexTbl);
	map<string,string> ::iterator it = m_mapCapital.find(sKey);
	if (it != m_mapCapital.end())
	{
		blRtn = true;
	}
	else
	{
		m_mapCapital[sKey] = sAcctNo;
		blRtn = false;
	}
	
	return blRtn;
}

//���������ݿ��ʼ��
int CCapitalTbl::Init(otl_connect& dbConnection,CBasicParaTbl& BasicParaTbl)
{
	char cSrcTable[51];
	char cSNo[19];					//������ˮ��
	char cAcctNo[16];				//�ͻ���
	string sSql = "";

	memset(cSNo, 0, sizeof(cSNo));
	memset(cAcctNo, 0, sizeof(cAcctNo));

	try
	{
		////�ֹ������
		//sSql = "select serial_no, acct_no from Cash_access_flow where Exch_date >=:f1<char[9]>";
		//otl_stream oAccess(1, sSql.c_str(), dbConnection);
		//oAccess << BasicParaTbl.GetExchDate().c_str();
		//while (!oAccess.eof())
		//{
		//	oAccess >> cSNo >> cAcctNo;

		//	m_mapCapital[RiskConst::gc_sAccess + cSNo] = cAcctNo;
		//}

		////�ֹ�����
		//sSql = "select serial_no, acct_no from fund_adjust_flow where Exch_date >=:f1<char[9]>" ;
		//otl_stream oAdjust(1, sSql.c_str(), dbConnection);
		//oAdjust << BasicParaTbl.GetExchDate().c_str();
		//while (!oAdjust.eof())
		//{
		//	oAdjust >> cSNo >> cAcctNo;

		//	m_mapCapital[RiskConst::gc_sAdjust + cSNo] = cAcctNo;
		//}

		////�Զ������
		//sSql = "select serial_no, acct_no from fund_auto_inout_flow where in_account_flag = 1 and Exch_date >=:f1<char[9]>";
		//otl_stream oAuto(1, sSql.c_str(), dbConnection);
		//oAuto << BasicParaTbl.GetExchDate().c_str();
		//while (!oAuto.eof())
		//{
		//	oAuto >> cSNo >> cAcctNo;

		//	m_mapCapital[RiskConst::gc_sAuto + cSNo] = cAcctNo;
		//}

		sSql = "select src_table, serial_no, acct_no from para_fund_inout";
		otl_stream oAuto(1, sSql.c_str(), dbConnection);

		CGessGuard guard(m_mutexTbl);
		while (!oAuto.eof())
		{
			oAuto >> cSrcTable >> cSNo >> cAcctNo;
	
			string sKey = cSrcTable;
			sKey += cSNo;
			m_mapCapital[sKey] = cAcctNo;
		}
	}
	catch(otl_exception &p)
	{
		CRLog(E_ERROR, "otl excepiton:%s,%s,%s,%s", p.msg, p.stm_text, p.sqlstate, p.var_info);
	}

	return 0;
}

//��������
void CCapitalTbl::Finish()
{
	CGessGuard guard(m_mutexTbl);
	m_mapCapital.clear();
}

string CCapitalTbl::ToString() 
{
	std::stringstream ss;

	map<string,string>::iterator iter;
	
	CGessGuard guard(m_mutexTbl);
	for( iter =  m_mapCapital.begin(); iter != m_mapCapital.end(); ++iter)
	{
		ss << (*iter).first << " " << (*iter).second;
		ss <<  "\r\n";
	}

	return ss.str();
}