#include "MainServiceHandler.h"
#include "Logger.h"

// F1 �ӿ� [3096]���������� ��ҵ��ʵ��
int CMainServiceHandler::OnBranchDistQueryReq(CTradePacket& pkt)
{
	HEADER_REQ stHeaderReq;
	BranchDistQueryReq stBodyReq;

	HEADER_RSP stHeaderRsp;
	BranchDistQueryRsp stBodyRsp;

	pkt.GetHeader(stHeaderReq);
	CPacketStructTradeRisk::Packet2Struct(stBodyReq, pkt);

	//ҵ��ʵ��......
	CTradePacket pktRsp;
	CPacketStructTradeRisk::HeadReq2Rsp(stHeaderReq,stHeaderRsp);
	
	char cBranchId[13];
	char cExchDate[9];
	int iTotalCustNo;
	int iRiskCustNo;
	string sSql = "";
	string sGrade = "";
	ArrayListMsg almResultTemp;

	memset(cBranchId, 0, sizeof(cBranchId));
	memset(cExchDate, 0, sizeof(cExchDate));

	//ȡ���յȼ�����
	if (stBodyReq.risk_level.size() > 0)
	{
		for (unsigned int i=0; i<stBodyReq.risk_level.size(); i++)
		{
			if (i != 0)
			{
				sGrade += ", ";
			}
#ifdef _VER_25_DB2
			sGrade +=  stBodyReq.risk_level.GetValue<string>(i);
#else
			sGrade += "'" + stBodyReq.risk_level.GetValue<string>(i) + "'";
#endif
		}
	}

	//ȡ�¼�����������Ϣ
#ifdef _VER_25_DB2
	sSql = "select "
		"z.exch_date, "
		"z.branch_id, "
		"(select FG_CovNull(sum(num), 0) from end_day_risk_statics where branch_id in (select branch_id from v_rte_branch_info where parent_branch_id = z.branch_id ) and exch_date = z.exch_date) total_num, "
		"(select FG_CovNull(sum(num), 0) from end_day_risk_statics where branch_id in (select branch_id from v_rte_branch_info where parent_branch_id = z.branch_id ) and exch_date = z.exch_date and grade_id in (" + sGrade + ")) risk_num "
		"from "
		"(select * from "
		"(select distinct exch_date from end_day_risk_statics where exch_date between '" + stBodyReq.begin_time + "' and '" + stBodyReq.end_time + "') x ,"
		"(select branch_id from branch_info where parent_branch_id = '" + stHeaderReq.BranchID() + "') y"
		") z";
#else
	
	sSql = "select "
		"z.exch_date, "
		"z.branch_id, "
		"(select nvl(sum(num), 0) from end_day_risk_statics where branch_id in (select branch_id from branch_info start with branch_id = z.branch_id connect by prior branch_id = parent_branch_id) and exch_date = z.exch_date) total_num, "
		"(select nvl(sum(num), 0) from end_day_risk_statics where branch_id in (select branch_id from branch_info start with branch_id = z.branch_id connect by prior branch_id = parent_branch_id) and exch_date = z.exch_date and grade_id in (" + sGrade + ")) risk_num "
		"from "
		"(select * from "
		"(select distinct exch_date from end_day_risk_statics where exch_date between '" + stBodyReq.begin_time + "' and '" + stBodyReq.end_time + "') x "
		"cross join "
		"(select branch_id from branch_info where parent_branch_id = '" + stHeaderReq.BranchID() + "') y"
		") z";
#endif

	try
	{
		//ִ��sql
		otl_stream o(1, sSql.c_str(), GetOtlConn());
		
		while (!o.eof())
		{
			o >> cExchDate >> cBranchId >> iTotalCustNo >> iRiskCustNo;

			almResultTemp.clear();
			almResultTemp.AddValue(cExchDate);
			almResultTemp.AddValue(cBranchId);
			almResultTemp.AddValue(iTotalCustNo);
			almResultTemp.AddValue(iRiskCustNo);

			stBodyRsp.branch_id.AddValue(almResultTemp);
		}

		//ȡ����Ա���ڴ���������Ϣ
#ifdef _VER_25_DB2
		sSql = "select "
			" distinct x.exch_date, "
			"(select FG_CovNull(sum(num), 0) from end_day_risk_statics where exch_date = x.exch_date and branch_id=x.branch_id) total_num, "
			"(select FG_CovNull(sum(num), 0) from end_day_risk_statics where exch_date = x.exch_date and grade_id in (" + sGrade + ") and branch_id=x.branch_id) risk_num "
			"from "
			"end_day_risk_statics x "
			"where "
			"x.branch_id = '" + stHeaderReq.BranchID() + "'"
			"and "
			"x.exch_date between '" + stBodyReq.begin_time + "' and '" + stBodyReq.end_time + "'";
#else
		sSql = "select "
			" distinct x.exch_date, "
			"(select nvl(sum(num), 0) from end_day_risk_statics where branch_id in (select branch_id from branch_info start with branch_id = x.branch_id connect by prior branch_id = parent_branch_id) and exch_date = x.exch_date) total_num, "
			"(select nvl(sum(num), 0) from end_day_risk_statics where branch_id in (select branch_id from branch_info start with branch_id = x.branch_id connect by prior branch_id = parent_branch_id) and exch_date = x.exch_date and grade_id in (" + sGrade + ")) risk_num "
			"from end_day_risk_statics x "
			"where x.branch_id = '" + stHeaderReq.BranchID() + "'"
			"and x.exch_date between '" + stBodyReq.begin_time + "' and '" + stBodyReq.end_time + "'";
#endif

		otl_stream oSelf(1, sSql.c_str(), GetOtlConn());

		while (!oSelf.eof())
		{
			oSelf >> cExchDate >> iTotalCustNo >> iRiskCustNo;

			almResultTemp.clear();
			almResultTemp.AddValue(cExchDate);
			almResultTemp.AddValue(stHeaderRsp.branch_id);
			almResultTemp.AddValue(iTotalCustNo);
			almResultTemp.AddValue(iRiskCustNo);

			stBodyRsp.branch_id.AddValue(almResultTemp);
		}
	}
	catch(otl_exception& p)
	{
		CRLog(E_ERROR, "DB:MSG:%s\nTEXT:%s\nVARINFO:%s", p.msg, p.stm_text, p.var_info); 
		strcpy(stHeaderRsp.rsp_code,RSP_EXCEPTION.c_str());
		pktRsp.AddParameter("rsp_msg", (const char *)p.msg);
	}

	//������Ӧ����
	stBodyRsp.oper_flag = stBodyReq.oper_flag;

	pktRsp.SetHeader(stHeaderRsp);
	CPacketStructTradeRisk::Struct2Packet(stBodyRsp,pktRsp);

	//ת������
	m_pRiskCpMgr->ToInterfaceF1(pktRsp,m_ulKey);

	return 0;
};
