#include <cassert>
#include "DbSync.h"
#include "RiskCpMgr.h"
#include "Logger.h"

CDbSync::CDbSync(CRiskHandler* pRiskHandler,CMemDb* pMemDb)
:m_pRiskHandler(pRiskHandler)
,m_pMemDb(pMemDb)
,m_pRiskCpMgr(0)
{
}

CDbSync::~CDbSync(void)
{
	m_deqSync.clear();
}

int CDbSync::Init(CConfig* pConfig)
{
	assert(pConfig != 0);
	if (0 == pConfig)
		return -1;


	return 0;
}

int CDbSync::Start()
{
	BeginThread();
	return 0;
}

void CDbSync::Stop()
{
	EndThread();
}

void  CDbSync::Finish()
{

}

void CDbSync::Bind(CConnectPointManager* pCpMgr,const unsigned long& ulKey)
{
	m_ulKey = ulKey; 
	m_pRiskCpMgr = dynamic_cast<CRiskCpMgr*>(pCpMgr);
}

int CDbSync::Enque(CPacket& pkt)
{
	try
	{
		CBroadcastPacket& pktBroadcast = dynamic_cast<CBroadcastPacket&>(pkt);		
		m_deqCondMutex.Lock();
		m_deqSync.push_back(pktBroadcast);		
		m_deqCondMutex.Unlock();
		m_deqCondMutex.Signal();

		return 0;
	}
	catch(std::bad_cast)
	{
		CRLog(E_ERROR,"%s","packet error!");
		return -1;
	}
	catch(std::exception e)
	{
		CRLog(E_ERROR,"exception:%s!",e.what());
		return -1;
	}
	catch(...)
	{
		CRLog(E_ERROR,"%s","Unknown exception!");
		return -1;
	}
}

int CDbSync::ThreadEntry()
{
	try
	{		
		while(!m_bEndThread)
		{
			m_deqCondMutex.Lock();
			while(m_deqSync.empty() && !m_bEndThread)
				m_deqCondMutex.Wait();

			if (m_bEndThread)
			{
				m_deqCondMutex.Unlock();
				break;
			}

			CBroadcastPacket pkt = m_deqSync.front();
			m_deqSync.pop_front();
			m_deqCondMutex.Unlock();

			try
			{
				std::string sCmdID = pkt.GetCmdID();
				if (sCmdID == "onBaseTableUpdate")
					OnBaseTableUpdate(pkt);
				else
					;//...
			}
			catch(...)
			{
				CRLog(E_ERROR,"%s","Unknown exception!");
			}
		}

		CRLog(E_APPINFO,"%s","DbSync Thread exit!");
		return 0;
	}
	catch(std::exception e)
	{
		CRLog(E_ERROR,"exception:%s!",e.what());
		return -1;
	}
	catch(...)
	{
		CRLog(E_ERROR,"%s","Unknown exception!");
		return -1;
	}
}

int CDbSync::End()
{
	m_deqCondMutex.Lock();
	m_deqCondMutex.Signal();
	m_deqCondMutex.Unlock();
	Wait();
	return 0;
}

int CDbSync::SendAck(CBroadcastPacket& pkt)
{
	// ע�͵���Ч����
	/*CBroadcastPacket pktAck("Ack");
	return m_pRiskCpMgr->ToInterfaceA1(pktAck,m_ulKey);*/
	return 0;
}

bool CDbSync::IsNetManaged(string& sKeyName)
{
	sKeyName = "���ݿ�ͬ���߳�";
	return true;
}