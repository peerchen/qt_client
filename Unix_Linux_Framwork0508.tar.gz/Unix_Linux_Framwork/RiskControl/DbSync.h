#ifndef _RISK_DBSYNC_H
#define _RISK_DBSYNC_H

#include <deque>
#include <map>
#include "WorkThreadNm.h"
#include "BroadcastPacket.h"
#include "Gess.h"
#include "PacketStructTransferBroadcastRisk.h"

using namespace std;

class CRiskCpMgr;
class CRiskHandler;
class CMemDb;
class CDbSync:virtual public CConnectPointAsyn, virtual	public CWorkThreadNm
{
public:
	//CDbSync(CRiskCpMgr* pMgr, CRiskHandler* pRiskHandler,CMemDb* pMemDb);
	CDbSync(CRiskHandler* pRiskHandler,CMemDb* pMemDb);
	~CDbSync(void);

	int Init(CConfig* pConfig);
	int Start();
	void Stop();
	void Finish();
	int OnRecvPacket(CPacket &GessPacket){return 0;}
	int SendPacket(CPacket &GessPacket){return Enque(GessPacket);}
	void Bind(CConnectPointManager* pCpMgr,const unsigned long& ulKey);

	int Enque(CPacket& pkt);
private:
	int ThreadEntry();
	int End();

	//�������߳�״̬�Ƿ���Ҫ������
	bool IsNetManaged(string& sKeyName);

	CRiskCpMgr* m_pRiskCpMgr;
	unsigned long		m_ulKey;

	CRiskHandler* m_pRiskHandler;
	CMemDb* m_pMemDb;
	CConfig* m_pCfg;

	std::deque<CBroadcastPacket> m_deqSync;
	CCondMutex	m_deqCondMutex;

private:
	int SendAck(CBroadcastPacket& pkt);

	// [onBaseTableUpdate] ҵ����Ӧ�����
	int OnBaseTableUpdate(CBroadcastPacket& pkt);
	
};
#endif