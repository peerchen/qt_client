#ifndef CINOUTCUSTTBL_H
#define CINOUTCUSTTBL_H
#include <string>
#include <map>
#include "Gess.h"
#include "RiskConstant.h"
using namespace std;
class CInOutCust
{
public:
	CInOutCust()
	:m_sAcctNo("")
	,m_sSerialNo("")
	,m_dAmount(0.00)
	,m_iAccessWay(RiskConst::gc_cCapitalIn)
	{}
	~CInOutCust(){}
	string m_sAcctNo;//�ͻ���
	string m_sSerialNo;//����������ˮ��
	double m_dAmount;//ת�˽��
	int    m_iAccessWay;//��ȡ����
};
class CInOutCustTbl
{
public:
	CInOutCustTbl();
	~CInOutCustTbl();
	void InsertByDb(string acctNo,double inCap,double outCap);
	void InitSerialNo(string acctNo,string serialNo);
	int InsertToInOutCustList(CInOutCust& ioCust,double inCap,double outCap);
	int GetRecordSet(map<string,CInOutCust> & mapInOutCust);
	void Finish();
private:
	map<string,CInOutCust> m_mapInOutCust;
	CGessMutex  m_mutexTbl;
};
#endif/*CINOUTCUSTTBL_H*/