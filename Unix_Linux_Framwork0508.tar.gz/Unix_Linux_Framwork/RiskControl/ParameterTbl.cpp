#include "ParameterTbl.h"
#include "Logger.h"

CParameterTbl::CParameterTbl()
{

}

CParameterTbl::~CParameterTbl()
{
	Finish();
}

//##ModelId=4916CB820213
int CParameterTbl::Init(otl_connect& dbConnection)
{
	char cParaId[51];			//����ID
	char cParaDesc[301];		//��������
	char cParaType[3];			//��������
	char cParaValue[501];		//����ֵ
	RISK_PARAMETER stParaMeter;	
	string sSql = "";

	memset(cParaId, 0, sizeof(cParaId));
	memset(cParaDesc, 0, sizeof(cParaDesc));
	memset(cParaType, 0, sizeof(cParaType));
	memset(cParaValue, 0, sizeof(cParaValue));

	try
	{
		//��ϵͳ��������ȡϵͳ����
		sSql = "select para_id, para_desc, para_type, para_value from system_para";
		otl_stream o(1, sSql.c_str(), dbConnection);

		while (!o.eof())
		{
			o >> cParaId >> cParaDesc >> cParaType >> cParaValue;
			
			//���ӵ�������¼��
			stParaMeter.sParameterId = cParaId;
			stParaMeter.sParameterDesc = cParaDesc;
			stParaMeter.sParameterType = cParaType;
			stParaMeter.sParameterValue = cParaValue;

			m_mapParameters[stParaMeter.sParameterId] = stParaMeter;
		}
	}
	catch(otl_exception& p)
	{
		CRLog(E_ERROR, "otl exception:%s,%s,%s,%s", p.msg, p.stm_text, p.sqlstate, p.var_info);
	}

	return 0;

}

//##ModelId=49140C6C02FD
int CParameterTbl::GetParameter(const string& sID, RISK_PARAMETER& stPara)
{
	CGessGuard guard(m_mutexTbl);

	map<string,RISK_PARAMETER>::iterator it = m_mapParameters.find(sID);
	if (it != m_mapParameters.end())
	{
		stPara = it->second;
		return 0;
	}
	return -1;

}

//##ModelId=4916DEA703B9
int CParameterTbl::SetParameter(const string& sID, const RISK_PARAMETER& stPara)
{
	CGessGuard guard(m_mutexTbl);

	map<string,RISK_PARAMETER>::iterator it = m_mapParameters.find(sID);
	if (it != m_mapParameters.end())
	{
		it->second = stPara;
		return 0;
	}
	return -1;
}

//��������
void CParameterTbl::Finish()
{
	CGessGuard guard(m_mutexTbl);
	m_mapParameters.clear();
}

