#include "MainServiceHandler.h"
#include "Logger.h"
#include "NmConstant.h"
#include "GessTime.h"
#include "Global.h"
#include "math.h"

CMainServiceHandler::Cmd2Api CMainServiceHandler::m_Cmd2Api[] =
{
	//����ApiName   ����������ָ��
	{"3063", &CMainServiceHandler::OnCustSpecReq},
	{"3064", &CMainServiceHandler::OnRiskNotifyQueryReq},
	{"3065", &CMainServiceHandler::OnNotDealFCQueryReq},
	{"3066", &CMainServiceHandler::OnFCOrderSubmitReq},
	{"3067", &CMainServiceHandler::OnAutoGenFCOrderReq},
	{"3069", &CMainServiceHandler::OnFCOrderQueryReq},
	{"3070", &CMainServiceHandler::OnFCOrderCancelReq},	
	{"3081", &CMainServiceHandler::OnRiskStateParaReq},
	{"3082", &CMainServiceHandler::OnRiskhandleParaReq},
	{"3084", &CMainServiceHandler::OnRiskNotifyParaReq},
	{"3085", &CMainServiceHandler::OnForceCoverParaReq},
	{"3086", &CMainServiceHandler::OnBranchAuthParaReq},
	{"3088", &CMainServiceHandler::OnRiskGradeQueryReq},
	{"3091", &CMainServiceHandler::OnRiskCustQueryReq},
	{"3093", &CMainServiceHandler::OnRiskTestCalReq},
	{"3094", &CMainServiceHandler::OnRiskCustAllReq},
	{"3095", &CMainServiceHandler::OnRiskDistQueryReq},
	{"3096", &CMainServiceHandler::OnBranchDistQueryReq},
	{"3097", &CMainServiceHandler::OnTryCloseReq},
	{"3098", &CMainServiceHandler::OnProdQuotationReq},
	{"3099", &CMainServiceHandler::OnCustRiskDegreeQueryReq},
	{"3100", &CMainServiceHandler::OnSmsParaReq},
	{"3301", &CMainServiceHandler::OnAutoForceExecptConditionReq},
	{"3302", &CMainServiceHandler::OnAlterMinUnitReq},
    {"3303", &CMainServiceHandler::OnHandlSmsMessageReq},
	{"3304", &CMainServiceHandler::OnCustAlarmParaReq},
#if defined(_VER_25_PSBC)
	{"3306", &CMainServiceHandler::OnCustProfitLossInfoReq},
#else
	{"3306", &CMainServiceHandler::OnBranchRiskStatQryReq},
#endif
	{"4043", &CMainServiceHandler::OnForceCovOderAck},
	{"4044", &CMainServiceHandler::OnForceCovOderAck},
	{"4061", &CMainServiceHandler::OnForceCovOderCancelAck},

	{"3307", &CMainServiceHandler::OnSubAgentRiskIndexQuery},
	{"3308", &CMainServiceHandler::OnSubAgentRiskParaSet},
	{"3309", &CMainServiceHandler::OnAutoGenFCOrderBatchReq},
	{"3310", &CMainServiceHandler::OnFCOrderSubmitBatchReq},
	{"3311", &CMainServiceHandler::OnFCOrderCancelBatchReq},
	{"3312", &CMainServiceHandler::OnInOutCustList},
	{"3321", &CMainServiceHandler::OnRiskCustQueryReqByTrade},
};

CMainServiceHandler::CMainServiceHandler(CRiskNotify *pRiskNotify, CMemDb* pMemDb)
:m_pRiskNotify(pRiskNotify)
,m_pMemDb(pMemDb)
,m_pRiskCpMgr(0)
,m_pCfg(0)
,m_ulKey(EnumKeyMainService)
,m_strConnect("")
{
	m_oTimeTagsLast.ToNow();
}

CMainServiceHandler::~CMainServiceHandler(void)
{
	m_deqService.clear();
}

int CMainServiceHandler::RunPacketHandleApi(CTradePacket& pkt)
{
	try
	{
		std::string sCmdID = pkt.GetCmdID();

    	int nSize = sizeof(m_Cmd2Api)/sizeof(Cmd2Api);
		for ( int i = 0 ; i < nSize ; i++ )
		{
			if ( strcmp(m_Cmd2Api[i].pcApiName,sCmdID.c_str()) == 0 )
			{
				if (m_Cmd2Api[i].pMemberFunc == 0)
					break;

				return (this->*(m_Cmd2Api[i].pMemberFunc))(pkt);				
			}
		}

		//CRLog(E_ERROR,"Unknown packet!");
		return -1;
	}
	catch(std::exception e)
	{
		CRLog(E_CRITICAL,"exception:%s", e.what());
		return -1;
	}
	catch(...)
	{
		CRLog(E_CRITICAL,"%s","Unknown exception");
		return -1;
	}
}

int CMainServiceHandler::Init(CConfig* pCfg)
{
	assert(pCfg != 0);
	if (0 == pCfg)
		return -1;

	CConfig* pConfig = pCfg->GetCfgGlobal();
	if (0 == pConfig)
		return -1;

	m_pCfg = pConfig;

	m_strConnect = CGlobal::Instance()->GetDbConnectStr(pConfig);

	otl_connect::otl_initialize(); 
	try
	{
		m_OtlConn.set_timeout(50);
		m_OtlConn.rlogon(m_strConnect.c_str());
	}
	catch(otl_exception& p)
	{
		CRLog(E_ERROR,"otl exception:%s,%s,%s,%s",p.msg,p.stm_text,p.sqlstate,p.var_info);
	}
	m_oMainServiceHandlerNm.Bind(this);
	m_oQuotationAutoForceThread.Bind(this);
	m_ForceOrder2DBThread.Bind(this);
	m_oAutoForceThread.Bind(this);
	m_oTimeTimer.Bind(this);
    m_oQuoteTimer.Bind(this);

	CNetMgr::Instance()->Register(&m_oMainServiceHandlerNm,mibQueNum,mibQueNum+"."+"ҵ���ѯ�౨�Ķ���");
	CNetMgr::Instance()->Register(&m_oMainServiceHandlerNm,mibQueNum,mibQueNum+"."+"�����ر��౨�Ķ���");

	return 0;
}

int CMainServiceHandler::Start()
{
	BeginThread();
	m_oQuotationAutoForceThread.Start();
	m_oAutoForceThread.Start();
	m_ForceOrder2DBThread.Start();
	CGessTimerMgrImp::Instance()->CreateTimer(&m_oTimeTimer,6,"TimeTimer");
	CGessTimerMgrImp::Instance()->CreateTimer(&m_oQuoteTimer,2,"QuoteTimer");
	srand(static_cast<unsigned int>(time(0)));
	return 0;
}

void CMainServiceHandler::Stop()
{
	CGessTimerMgrImp::Instance()->DestroyTimer(&m_oTimeTimer,"TimeTimer");
	CGessTimerMgrImp::Instance()->DestroyTimer(&m_oQuoteTimer,"QuoteTimer");
	CRLog(E_APPINFO,"%s","stop QuotationAutoForce thread!");
	m_oQuotationAutoForceThread.Stop();
	CRLog(E_APPINFO,"%s","stop AutoForce thread!");
	m_oAutoForceThread.Stop();
	CRLog(E_APPINFO,"%s","stop MainService thread!");
	m_ForceOrder2DBThread.Stop();
	EndThread();
}

void CMainServiceHandler::Finish()
{
	CNetMgr::Instance()->UnRegisterModule(&m_oMainServiceHandlerNm);
	gc_mapSerialNo.clear();
}

void CMainServiceHandler::Bind(CConnectPointManager* pCpMgr,const unsigned long& ulKey)
{
	m_ulKey = ulKey; 
	m_pRiskCpMgr = dynamic_cast<CRiskCpMgr*>(pCpMgr);
}
//��ز�ѯ�����б�������
int CMainServiceHandler::Query(CNMO & oNmo) 
{
	oNmo.m_nQuality=gc_nQuolityGood;
	oNmo.m_sOid=mibQueNum;
	//oNmo.m_sTimeStamp=CGessDateTime::NowToString()+" "+CGessTime::NowToString(":");

	m_deqCondMutex.Lock();
	if(oNmo.m_sOidIns==(mibQueNum+"."+"ҵ���ѯ�౨�Ķ���"))
	{
		oNmo.m_sValue=ToString(m_deqService.size());		
	}
	else if(oNmo.m_sOidIns==(mibQueNum+"."+"�����ر��౨�Ķ���"))
	{
		oNmo.m_sValue=ToString(m_deqBroascast.size());	
	}
	m_deqCondMutex.Unlock();
	return 0;

}

int CMainServiceHandler::Query(vector< CNMO > & vNmo)
{
	CNMO service;
	service.m_nQuality=gc_nQuolityGood;
	service.m_sOid=mibQueNum;
	//service.m_sTimeStamp=CGessDateTime::NowToString()+" "+CGessTime::NowToString(":");
	
	CNMO broascast;
	broascast.m_nQuality=gc_nQuolityGood;
	broascast.m_sOid=mibQueNum;
	//broascast.m_sTimeStamp=CGessDateTime::NowToString()+" "+CGessTime::NowToString(":");


	m_deqCondMutex.Lock();
	service.m_sValue=ToString(m_deqService.size());	
	broascast.m_sValue=ToString(m_deqBroascast.size());	
	m_deqCondMutex.Unlock();

	vNmo.push_back(service);
	vNmo.push_back(broascast);
	return 0;

}
int CMainServiceHandler::Enque(CPacket& pkt)
{
	try
	{
		CTradePacket& pktTrade = dynamic_cast<CTradePacket&>(pkt);		
		m_deqCondMutex.Lock();
		m_deqService.push_back(pktTrade);		
		m_deqCondMutex.Unlock();
		m_deqCondMutex.Signal();

		return 0;
	}
	catch(std::bad_cast)
	{
		CRLog(E_ERROR,"%s","packet error!");
		return -1;
	}
	catch(std::exception e)
	{
		CRLog(E_ERROR,"exception:%s!",e.what());
		return -1;
	}
	catch(...)
	{
		CRLog(E_ERROR,"%s","Unknown exception!");
		return -1;
	}
}

int CMainServiceHandler::Enque(CBroadcastPacket& pkt)
{
	try
	{
		CBroadcastPacket& pktBroadcast = dynamic_cast<CBroadcastPacket&>(pkt);		
		m_deqCondMutex.Lock();
		m_deqBroascast.push_back(pktBroadcast);		
		m_deqCondMutex.Unlock();
		m_deqCondMutex.Signal();

		return 0;
	}
	catch(std::bad_cast)
	{
		CRLog(E_ERROR,"%s","packet error!");
		return -1;
	}
	catch(std::exception e)
	{
		CRLog(E_ERROR,"exception:%s!",e.what());
		return -1;
	}
	catch(...)
	{
		CRLog(E_ERROR,"%s","Unknown exception!");
		return -1;
	}
}

int CMainServiceHandler::SendPacket(CPacket &pkt)
{
	try
	{
		CTradePacket& pktTrade = dynamic_cast<CTradePacket&>(pkt);		
		m_deqCondMutex.Lock();
		m_deqService.push_back(pktTrade);		
		m_deqCondMutex.Unlock();
		m_deqCondMutex.Signal();

		return 0;
	}
	catch(std::bad_cast)
	{
	}
	catch(std::exception e)
	{
		CRLog(E_ERROR,"exception:%s!",e.what());
		return -1;
	}
	catch(...)
	{
		CRLog(E_ERROR,"%s","Unknown exception!");
		return -1;
	}

	try
	{
		CBroadcastPacket& pktBroadcast = dynamic_cast<CBroadcastPacket&>(pkt);		
		m_deqCondMutex.Lock();
		m_deqBroascast.push_back(pktBroadcast);		
		m_deqCondMutex.Unlock();
		m_deqCondMutex.Signal();

		return 0;
	}
	catch(std::bad_cast)
	{
		CRLog(E_ERROR,"%s","packet error!");
		return -1;
	}
	catch(std::exception e)
	{
		CRLog(E_ERROR,"exception:%s!",e.what());
		return -1;
	}
	catch(...)
	{
		CRLog(E_ERROR,"%s","Unknown exception!");
		return -1;
	}
}

int CMainServiceHandler::ThreadEntry()
{
	try
	{
		while(!m_bEndThread)
		{
			m_deqCondMutex.Lock();
			while(m_deqService.empty() && m_deqBroascast.empty() && !m_bEndThread)
				m_deqCondMutex.Wait();

			if (m_bEndThread)
			{
				m_deqCondMutex.Unlock();
				break;
			}

			if (!m_deqService.empty())
			{
				CTradePacket pkt = m_deqService.front();
				m_deqService.pop_front();
				m_deqCondMutex.Unlock();

				try
				{
					RunPacketHandleApi(pkt);	
				}
				catch(...)
				{
					CRLog(E_ERROR,"%s","Unknown exception!");
				}
				continue;
			}
			if (!m_deqBroascast.empty())
			{
				CBroadcastPacket pkt = m_deqBroascast.front();
				m_deqBroascast.pop_front();
				m_deqCondMutex.Unlock();

				try
				{
					std::string sCmdID = pkt.GetCmdID();
					if (sCmdID == "onRecvRtnDeferMatch")
					{
						OnDeferRtnOrderMatch(pkt);
					}
					else if (sCmdID == "onRecvRspDeferOrder")
					{
						OnDeferRspOrder(pkt);
					}
					else if(sCmdID == "onRecvDeferQuotation" || sCmdID =="onRecvSpotQuotation")
					{
						if(m_pMemDb->GetBasicParaTbl().GetIsQuoteAuotForce())//�Ƿ���������ǿƽ�߳�
						{
							m_deqCondQuotionMutex.Lock();
							m_deqQuotation.push_back(pkt);
							m_deqCondQuotionMutex.Signal();
							m_deqCondQuotionMutex.Unlock();
						}
						
					}
					else if(sCmdID== "onRecvRtnDeferOrder" || sCmdID=="onRecvRtnDeferOrderCancel")
					{
						OnDeferRtnOrder(pkt);
					}
					else if(sCmdID == "onRecvRtnFpOrder")
					{
						OnRtnFpOrder(pkt);
					}
					else if(sCmdID == "onRecvRtnFpOrderCancel")
					{
						OnRtnFpOrderCancle(pkt);
					}
					else if(sCmdID == "onRecvRspFpOrderFullCancel")
					{
						OnRtnFpOrderFullCancle(pkt);
					}
					else if(sCmdID == "onRecvRspFpFrCancel")
					{
						OnRtnFpFrCancle(pkt);
					}
				}
				catch(...)
				{
					CRLog(E_ERROR,"%s","Unknown exception!");
				}
				continue;
			}

		}

		CRLog(E_SYSINFO,"%s","MainServiceHandler Thread exit!");
		return 0;
	}
	catch(std::exception e)
	{
		CRLog(E_ERROR,"exception:%s!",e.what());
		return -1;
	}
	catch(...)
	{
		CRLog(E_ERROR,"%s","Unknown exception!");
		return -1;
	}
}

int CMainServiceHandler::End()
{
	m_deqCondMutex.Lock();
	m_deqCondMutex.Signal();
	m_deqCondMutex.Unlock();
	Wait();
	return 0;
}

//
bool CMainServiceHandler::IsNetManaged(string& sKeyName)
{
	sKeyName = "��ؽ��״����߳�";
	return true;
}

otl_connect & CMainServiceHandler::GetOtlConn() throw(otl_exception)
{
	try
	{	
		otl_stream o(1, "select 1 from host_info", m_OtlConn); 
	}
	catch(otl_exception& p)
	{  
		CRLog(E_ERROR, "DB:MSG:%s\nTEXT:%s\nVARINFO:%s", p.msg, p.stm_text, p.var_info);
		//�����쳣�������������ݿ�
	
		if( m_strConnect == "")
		{
			m_strConnect = CGlobal::Instance()->GetDbConnectStr(m_pCfg);
		}
	
		try
		{	
			m_OtlConn.set_timeout(50);
			m_OtlConn.logoff();
			m_OtlConn.rlogon(m_strConnect.c_str());
			otl_stream o(1, "select 1 from host_info", m_OtlConn); 
		}
		catch(otl_exception& p1)
		{
			CRLog(E_ERROR,"otl exception:%s,%s,%s,%s",p1.msg,p1.stm_text,p1.sqlstate,p1.var_info);
			throw p1;
		}

	}
	return m_OtlConn;
}

//����Զ�ǿƽʱ����ǿƽ����
void CMainServiceHandler::TimerCheckAutoForce()
{
	if(!m_pMemDb->GetBasicParaTbl().GetIsTimerAutoForce())//�Ƿ���������ǿƽ�߳�
	{
		//���鿪��δ�򿪲��Զ�ǿ������
		return;
	}

	vector<CGessTime>  temp;
	CGessTime oMaxParaGessTime;

	m_pMemDb->GetBasicParaTbl().GetMaxForcetime(oMaxParaGessTime);
	m_pMemDb->GetBasicParaTbl().GetForcetime(temp);
	
	for( unsigned int i=0;i<temp.size();i++)
	{
		CGessTime otNowTime;
		
		int len=otNowTime-((CGessTime)temp.at(i));
		int mlen = ((CGessTime)temp.at(i)) - m_oTimeTagsLast;
		if( ( m_oTimeTagsLast - oMaxParaGessTime ) >=0 
				&& (otNowTime - oMaxParaGessTime) > 0)
		{
			continue;
		}
		//CRLog(E_DEBUG, "len=%d,m_oTimeTagsLast= %s ,oMaxParaGessTime = %s ",len,m_oTimeTagsLast.ToString("-").c_str(),oMaxParaGessTime.ToString("-").c_str()); 
		if( len >0 && ( mlen >0 || (m_oTimeTagsLast - oMaxParaGessTime ) >=0 ) )
		{
			CRLog(E_DEBUG, "curOnTimes =%s,m_oTimeTagsLast= %s ,oMaxParaGessTime = %s ",
				((CGessTime)temp.at(i)).ToString(":").c_str(),m_oTimeTagsLast.ToString(":").c_str(),oMaxParaGessTime.ToString(":").c_str()); 
			m_deqCondAutoForceMutex.Lock();
			m_deqAutoForce.push_back("Time");
			m_deqCondAutoForceMutex.Signal();
			m_deqCondAutoForceMutex.Unlock();

			m_oTimeTagsLast = (CGessTime)temp.at(i);
			break;
		}

	}	
	return ;
}




//����䶯����ǿƽ���
void CMainServiceHandler::QuoteFlowAutoForce(CBroadcastPacket& pkt)
{	
	if(!m_pMemDb->GetBasicParaTbl().GetIsQuoteAuotForce())//�Ƿ���������ǿƽ�߳�
	{
		//���鿪��δ�򿪲��Զ�ǿ������
		return;
	}
	DeferQuotation stBody;
	CPacketStructBroadcastRisk::Packet2Struct(stBody, pkt);
	if(stBody.last-0<0.001)
	{
		return;
	}
	if(m_pMemDb->GetBasicParaTbl().GetExchDate()!=stBody.quoteDate)
	{
		CRLog(E_APPINFO,"�յ�������Ľ������������ϵͳ���ײ�һ�£����齻������ %s ������ϵͳ�������� %s \n",stBody.quoteDate.c_str(),m_pMemDb->GetBasicParaTbl().GetExchDate().c_str());
		return;
	}
	std::string sCmdID = pkt.GetCmdID();
	if( sCmdID == "onRecvDeferQuotation" )
		CheckDeferQuotationAutoForce(stBody);
	
	return;	
}
 /***
   *  ������������,����Ƿ�ǿƽ��С�����ʷ�Χ֮�ڣ���󲻸��£������ڲ������
   * author: yfy   2010/10/25  
   * param: 
   * 
   * return 
   */
void CMainServiceHandler::CheckDeferQuotationAutoForce(DeferQuotation& stBody)
{
	
	double dlDownLimit=0;
	m_pMemDb->GetQuotationTbl().DownLimitPrice(stBody.instID,dlDownLimit);
	double dlUpLimit=0;
	m_pMemDb->GetQuotationTbl().UpLimitPrice(stBody.instID,dlUpLimit);
	double price=0;
	if(0==m_pMemDb->GetBasicParaTbl().GetAlterUnit(stBody.instID,price))
	{
		if(stBody.last-dlDownLimit<=price||dlUpLimit-stBody.last<=price)//�쵽�ǵ�ͣ��ۣ�����ǿƽ
		{
			 
			m_pMemDb->GetQuotationTbl().AddQuotation(stBody.instID);
			CRLog(E_APPINFO, "��Լ:[%s],��ǰ���¼۸�:[%lf],������С����ֵΪ[%lf],��ͣ���:[%lf],��ͣ���[%lf]",
						stBody.instID.c_str(),stBody.last,price,dlUpLimit,dlDownLimit); 
/*			m_deqCondAutoForceMutex.Lock();
			m_deqAutoForce.push_back(stBody.instID);
			m_deqCondAutoForceMutex.Signal();
			m_deqCondAutoForceMutex.Unlock();*/
		}
		else
		{
			m_pMemDb->GetQuotationTbl().DelQuotationTime(stBody.instID);
		}
	}
	else
	{
		CRLog(E_APPINFO, "δ�ҵ���Լ����Ϊ��%s ����С�䶯�۸�",stBody.instID.c_str()); 
	}	

}

 /***
   *  �ֻ����������������ʹ�ϵ,���������ʹ�ϵ���¼�ʱʱ���
   * author: yfy   2010/10/25  
   * param: 
   * 
   * return 
   */
void CMainServiceHandler::CheckSpotQuotationAutoForce(DeferQuotation& stBody)
{
	
	//��ǰ�ֻ��ĺ�Լ����
	string sSpotID=stBody.instID;
	//�ֻ���ǰ��������
	double sSpotNowPrice = stBody.last;	

	//1.��ѯ�������黺���б�
	string sInstID="";
	AlterMinUnit stuAlterMinUnit;
	double dlInstNowPrice=0.0f;

	map<string ,CGessTime > mapQuoteTimeMap = m_pMemDb->GetQuotationTbl().GetQuotationTimeMap();
	map<string ,CGessTime >::iterator it = mapQuoteTimeMap.begin();
	for( ;it != mapQuoteTimeMap.end();++it)
	{
		sInstID = it->first;

		m_pMemDb->GetBasicParaTbl().GetQuoteAutoForcePara(sInstID,stuAlterMinUnit);
		//��ȡ��Լ��ǰ�۸�
		m_pMemDb->GetQuotationTbl().NowPrice(sInstID,dlInstNowPrice);

		//2.��ѯ��ǰ�ֻ��Ƿ����ڵ�ǰ���ڵ����Ʒ
		vector<string>::iterator itVariety = stuAlterMinUnit.vecVarietyID.begin();
		for( ;itVariety !=stuAlterMinUnit.vecVarietyID.end();++itVariety)
		{
				if((*itVariety) == sSpotID )
				{
					//����������,��������ˢ��ʱ��
					if( abs(dlInstNowPrice-sSpotNowPrice)/sSpotNowPrice *100 < stuAlterMinUnit.quote_dot)
					{
						m_pMemDb->GetQuotationTbl().AddSpotQuotation(stBody.instID);
						CRLog(E_APPINFO, "�ֻ�ˢ�»���ʱ���,����Ʒ��:[%s],���ڵ�ǰ���¼�[%lf],�������Ʒ��:[%s],���Ʒ���¼۸�:[%lf],����������ֵΪ[%lf]",
							sInstID.c_str(),dlInstNowPrice,sSpotID.c_str(),sSpotNowPrice,stuAlterMinUnit.quote_dot);
					}					
				}
		}
	}

}

//�������ʱ�����ǿƽ����
void CMainServiceHandler::QuoteCatchCheckAutoForce()
{
	string sInstID="";
	string sVarietyCode="";

	try
	{
		map<string ,CGessTime > mapQuoteTimeMap = m_pMemDb->GetQuotationTbl().GetQuotationTimeMap();

		map<string ,CGessTime >::iterator it = mapQuoteTimeMap.begin();
		for( ;it != mapQuoteTimeMap.end();++it)
		{
			int len=((CGessTime)(it->second)).IntervalToNow();
			sInstID = it->first;

			AlterMinUnit stuAlterMinUnit;
			m_pMemDb->GetBasicParaTbl().GetQuoteAutoForcePara(sInstID,stuAlterMinUnit);

			//С�ڳ���ʱ�䲻����
			if( len <= stuAlterMinUnit.minCatchTime)
				continue;

			int flag=0;
			double dlVarietyNowPrice =0.0f;
			double dlInstNowPrice= 0.0f;
			string sExchDate = m_pMemDb->GetBasicParaTbl().GetExchDate();
			//��ȡ��ǰ��Լָ������Ʒ�ֵĵ������¼۸�
			for(vector<string>::iterator itVec = stuAlterMinUnit.vecVarietyID.begin();itVec !=stuAlterMinUnit.vecVarietyID.end() ;++itVec )
			{			
				//��ȡ����Ʒ�ּ۸�
				if(0 == m_pMemDb->GetQuotationTbl().NowPrice(*itVec,sExchDate,dlVarietyNowPrice))
				{
					flag=1;
					sVarietyCode = *itVec;
					break;				
				}			
			}
			if(flag !=1)
			{
				//δ�ҵ�����Ʒ�ֵ����¼۸�,���������ʵĳ���ʱ���ж�
				if( len <= stuAlterMinUnit.maxCatchTime)
					continue;
				CRLog(E_APPINFO, "δ�ҵ���Լ����Ϊ:%s �����Ʒ�ֵĺ�Լ�۸�,����ƥ��ʱ���:[%s],�������[%d]��ʱ��ƥ��!",
					sInstID.c_str(),((CGessTime)(it->second)).ToString(":").c_str(),stuAlterMinUnit.maxCatchTime); 
			}
			else  //���ҵ�����Ʒ�ֵ����¼۸�
			{			   
				//��ȡ��Լ��ǰ�۸�
				m_pMemDb->GetQuotationTbl().NowPrice(sInstID,dlInstNowPrice);
				double dlQuoteDot= abs(dlInstNowPrice-dlVarietyNowPrice)/dlVarietyNowPrice *100;
				if( dlQuoteDot > stuAlterMinUnit.quote_dot)
				{
					CRLog(E_DEBUG, "��ǰ�������������[%f],����������[%f]",dlQuoteDot,stuAlterMinUnit.quote_dot);
					//�������õ���������ֵ,�۸��쳣��ǿƽ�ͻ�����
					continue;
				}
				CRLog(E_APPINFO, "���ҵ���Լ����Ϊ��%s ���¼�[%f] ���Ʒ��[%s]�ĺ�Լ�۸�[%f] ��������[%f],����ƥ��ʱ���:[%s],������С[%d]��ʱ��ƥ��!",
					sInstID.c_str(),dlInstNowPrice,sVarietyCode.c_str(),dlVarietyNowPrice,stuAlterMinUnit.quote_dot,((CGessTime)(it->second)).ToString(":").c_str(),stuAlterMinUnit.minCatchTime); 
			}
			CRLog(E_APPINFO, "��Լ���룺%s �Ĵ����Զ�ǿƽ,����ʱ��:[%d]",sInstID.c_str(),((CGessTime)(it->second)).IntervalToNow()); 
			m_deqCondAutoForceMutex.Lock();
			m_deqAutoForce.push_back(sInstID);
			m_deqCondAutoForceMutex.Signal();
			m_deqCondAutoForceMutex.Unlock();
			//ɾ����ǰ��
			m_pMemDb->GetQuotationTbl().DelQuotationTime(sInstID);
		}	
		return;
	
	}
	catch (std::exception e)
	{
		CRLog(E_ERROR, "CMainServiceHandler::QuoteCatchCheckAutoForce exception:%s",e.what()); 
		return ;
	}
	catch(...)
	{
		CRLog(E_CRITICAL,"%s","CMainServiceHandler::QuoteCatchCheckAutoForce Unknown exception");
		return;
	}
}


//��ȡָ���ͻ��ĳɹ�ί�б���
int  CMainServiceHandler::GetCustomerEntrFlow(const string& custNo,vector<CEntrFlow>& vecCustDelegateFlow)
{
	char cLocalOderNo[15];
	char cOderNo[17];
	char cCustID[16];
	char cProdCode[11];
	char cEntrStat[3];
	char cOffsetFlag[3];
	char cForceOrderNo[19];
	long lEntrAmount=0;
	long lRemainAmount=0;
	double dlEntrPrice=0.0;
	char cDir;
	string sTemp="";
	vecCustDelegateFlow.clear();

	memset(cLocalOderNo,0x00,sizeof(cLocalOderNo));
	memset(cOderNo,0x00,sizeof(cOderNo));
	memset(cCustID,0x00,sizeof(cCustID));
	memset(cProdCode,0x00,sizeof(cProdCode));
	memset(cEntrStat,0x00,sizeof(cEntrStat));
	memset(cOffsetFlag,0x00,sizeof(cOffsetFlag));
	memset(cForceOrderNo,0x00,sizeof(cForceOrderNo));
	try
	{
		//���������̶���
		CRLog(E_DEBUG, "loading entr_flow info[%s]"," ......");
		otl_stream o(1, "select local_order_no,order_no,cust_id,prod_code,entr_stat,offset_flag,entr_amount,remain_amount,"
			" CLIENT_SERIAL_NO,Entr_Price,(case when Bs ='b' then '0' else '1' end) as bs "
			" from entr_flow " 
#ifndef _VER_TRUNK_ORA
			" where offset_flag !='2' and acct_no =:f1<char[15]> and (entr_stat in('1','o')) ",GetOtlConn());
#else
			" where offset_flag !='2' and acct_no =:f1<char[15]> and (entr_stat in('1','o','p')) ",GetOtlConn());
#endif
			
		o<<custNo.c_str();
		while (!o.eof())
		{
			o >> cLocalOderNo >> cOderNo>> cCustID>> cProdCode>> cEntrStat>> cOffsetFlag>> lEntrAmount>> lRemainAmount>>cForceOrderNo >>dlEntrPrice >> cDir ;

			CEntrFlow entrFlow;
			sTemp=string(cLocalOderNo);
			entrFlow.SetLocalOderNo(sTemp);
			sTemp=string(cOderNo);
			entrFlow.SetOderNo(sTemp);
			sTemp=string(cCustID);
			entrFlow.SetCustId(sTemp);
			sTemp=string(cProdCode);
			entrFlow.SetProdCode(sTemp);
			sTemp=string(cEntrStat);
			entrFlow.SetEntrStat(sTemp);
			sTemp=string(cOffsetFlag);
			entrFlow.SetOffsetFlag(sTemp);
			entrFlow.SetEntrAmount(lEntrAmount);
			entrFlow.SetRemainAmount(lRemainAmount);
			sTemp=string(cForceOrderNo);
			entrFlow.SetForceOrderNo(sTemp);
			entrFlow.SetEntrPrice(dlEntrPrice);
			entrFlow.SetEntrDir(cDir);
			vecCustDelegateFlow.push_back(entrFlow);
		}

	}
	catch(otl_exception& p)
	{
		CRLog(E_ERROR, "otl exception:%s,%s,%s,%s", p.msg, p.stm_text, p.sqlstate, p.var_info);
		return -1;
	}
	return 0;
}

map<string, string> CMainServiceHandler::GetMapSerialNo()
{
	CGessGuard guard(m_mutex);

	return gc_mapSerialNo;
}

std::string CMainServiceHandler::GetCovNo( const string& sKey )
{
	string sSerialNo = GetSerialNo(sKey);

#ifndef _VER_TRUNK_ORA
	return sSerialNo;
#else
	if( sSerialNo.length() >= 15 )
		return sSerialNo.substr(0, 15);
	else
		return sSerialNo;
#endif
}

std::string CMainServiceHandler::GetSerialNo( const string& sKey )
{
	CGessGuard guard(m_mutex);

	map<string, string>::const_iterator cit = gc_mapSerialNo.find(sKey);
	return 	cit == gc_mapSerialNo.end() ? gc_Empty_Str : cit->second;
}

void CMainServiceHandler::SetSerialNo( const string& sKey, const string& sValue )
{
	CGessGuard guard(m_mutex);

	gc_mapSerialNo[sKey] = sValue;
}

//ͳ������׷�����
double CMainServiceHandler::GetIndirDebtStat(CAgent* pAgent)
{
	try
	{
		double dlIndirDebt=0.00;

		assert(0 != pAgent);
		if (0 != pAgent)
		{
			CRealTimeRiskTbl &RealtimeTbl=m_pMemDb->GetRealTimeRiskTbl();
			map<std::string,CAgent*> mapAgents;
			pAgent->GetAgents(1, mapAgents);
			map<string, CAgent*>::iterator it;
			for(it = mapAgents.begin();it!=mapAgents.end();++it)
			{
				dlIndirDebt+=RealtimeTbl.GetDebtStat((*it).first);
			}
			dlIndirDebt+=RealtimeTbl.GetDebtStat(pAgent->ID());
		}
		return dlIndirDebt;
	}
	catch(std::exception e)
	{
		CRLog(E_ERROR,"exception:%s!",e.what());
		return 0.00;
	}
	catch(...)
	{
		CRLog(E_ERROR,"%s","Unknown exception!");
		return 0.00;
	}
}

//ͳ��ֱ������׷�����
double CMainServiceHandler::GetDirDebtStat(CAgent* pAgent)
{
	try
	{
		double dlIndirDebt=0.00;
		CRealTimeRiskTbl &RealtimeTbl=m_pMemDb->GetRealTimeRiskTbl();
		dlIndirDebt+=RealtimeTbl.GetDebtStat(pAgent->ID());
		return dlIndirDebt;
	}
	catch(std::exception e)
	{
		CRLog(E_ERROR,"exception:%s!",e.what());
		return 0.00;
	}
	catch(...)
	{
		CRLog(E_ERROR,"%s","Unknown exception!");
		return 0.00;
	}
}

vector<int> CMainServiceHandler::GetSvrTxList()
{
	vector<int> vList;
	string sCmdID;
	int nSize = sizeof(m_Cmd2Api)/sizeof(Cmd2Api);
	for ( int i = 0 ; i < nSize ; i++ )
	{
		sCmdID = m_Cmd2Api[i].pcApiName;
		int nCode = FromString<int>(sCmdID);
		if ( 3000 < nCode && 4000 > nCode && 
			3069 != nCode && 3088 != nCode && 3094 != nCode && 3095 != nCode && 3096 != nCode)//���׷������д�����Щ��ѯ,���ǾͲ���
		{
			vList.push_back(nCode);
		}
	}
	return vList;
}