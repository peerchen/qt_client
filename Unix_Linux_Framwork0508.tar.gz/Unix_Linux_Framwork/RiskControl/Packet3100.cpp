#include "MainServiceHandler.h"

// F1 �ӿ� [3100]��ض���ģ������
int CMainServiceHandler::OnSmsParaReq(CTradePacket& pkt)
{
	HEADER_REQ stHeaderReq;
	SmsParaReq stBodyReq;

	HEADER_RSP stHeaderRsp;
	SmsParaRsp stBodyRsp;
	CTradePacket pktRsp;
	pkt.GetHeader(stHeaderReq);
	CPacketStructTradeRisk::Packet2Struct(stBodyReq, pkt);
	//ҵ��ʵ��......
	string sRspCode = RSP_SUCCESS;
	string sRspMsg;
	string sSql="";
	char cAcctType[3];				//�ͻ�����
	char cRiskType[3];				//�ͻ�����
	char cSmsContent[2001];		    //����ģ��

	memset(cAcctType, 0, sizeof(cAcctType));
	memset(cRiskType, 0, sizeof(cRiskType));
	memset(cSmsContent, 0, sizeof(cSmsContent));
	ArrayListMsg msg;
	stBodyRsp.oper_flag=stBodyReq.oper_flag;    
	CPacketStructTradeRisk::HeadReq2Rsp(stHeaderReq,stHeaderRsp);
	strcpy(stHeaderRsp.rsp_code,RSP_SUCCESS.c_str());
	try
	{
		if (stBodyReq.oper_flag==1)//�޸�
		{
			sSql="select * from RISK_SMS_NOTIFY_PARA where ACCT_TYPE=:f1<int> and RISK_TYPE=:f2<int>";
			otl_stream o(1, sSql.c_str(), GetOtlConn());
			o<<atoi(stBodyReq.acct_type.c_str())<<atoi(stBodyReq.risk_type.c_str());
			if (!o.eof())
			{
				sSql="update RISK_SMS_NOTIFY_PARA set SMS_CONTENT_FMT=:f1<char[2001]>  where RISK_TYPE=:f2<int> and ACCT_TYPE= :f3<int>";
				otl_stream update(1, sSql.c_str(), GetOtlConn());
				update<<stBodyReq.sms_content.c_str()<<atoi(stBodyReq.risk_type.c_str())<<atoi(stBodyReq.acct_type.c_str());
				m_OtlConn.commit();
			}
			else
			{
				sSql="insert into RISK_SMS_NOTIFY_PARA values(:f1<int> ,:f2<int> ,:f3<char[2001]>)";
				otl_stream insert(1, sSql.c_str(), GetOtlConn());
				insert<<atoi(stBodyReq.acct_type.c_str())<<atoi(stBodyReq.risk_type.c_str())<<stBodyReq.sms_content;
				m_OtlConn.commit();
			}
		}
		else //��ѯ
		{
#ifdef _VER_25_DB2
			sSql="select FG_CovToChar(ACCT_TYPE),FG_CovToChar(RISK_TYPE),SMS_CONTENT_FMT  from RISK_SMS_NOTIFY_PARA";
#else
			sSql="select to_char(ACCT_TYPE),to_char(RISK_TYPE),SMS_CONTENT_FMT  from RISK_SMS_NOTIFY_PARA WHERE 1=1";

         #if defined(_VER_25_PSBC)
			if(stBodyReq.risk_type == "5")
				sSql += " AND RISK_TYPE='"+stBodyReq.risk_type + "'";
			else
				sSql += " AND RISK_TYPE <> '5'";
         #endif
#endif
			
			otl_stream o(1, sSql.c_str(), GetOtlConn());
			while (!o.eof())
			{
				o>>cAcctType>>cRiskType>>cSmsContent;
				msg.clear();
				msg.AddValue(cAcctType);
				msg.AddValue(cRiskType);
				msg.AddValue(cSmsContent);
				stBodyRsp.sms_content_set.AddValue(msg);
			}
		}
	}
	catch (otl_exception& p)
	{
		CRLog(E_ERROR, "DB:MSG:%s\nTEXT:%s\nVARINFO:%s", p.msg, p.stm_text, p.var_info); 
		Rollback();
		strcpy(stHeaderRsp.rsp_code, RSP_EXCEPTION.c_str());
		pktRsp.AddParameter("rsp_msg", (const char *)p.msg);
		
	}
	
	pktRsp.SetHeader(stHeaderRsp);
	CPacketStructTradeRisk::Struct2Packet(stBodyRsp,pktRsp);

	//ת������
	m_pRiskCpMgr->ToInterfaceF1(pktRsp,m_ulKey);

	return 0;
};
