#include "DB_Version.h" 
#include "Logger.h"
#include "RiskConstant.h"
#include "GessDate.h"
#include "strutils.h"
#include "GessTime.h"
#include "RiskAlarmParaTbl.h"

using namespace RiskConst;


CRiskAlarmParaTbl::CRiskAlarmParaTbl()
{

}

CRiskAlarmParaTbl::~CRiskAlarmParaTbl()
{
	Finish();
}

//���������ݿ��ʼ��
int CRiskAlarmParaTbl::Init(otl_connect& dbConnection)
{

   char cProd_Code[20];		//Ԥ����
   char cNotify_obj[20];		//Ԥ������
   char cAcctNo[30];		//�ͻ�����Ϣ
   char cTerm_value[60];		//Ԥ��ֵ
   char cNotify_way[20];		//Ԥ����ʽ
   int iTimeout;				//���ʱ��
   char cTerm_type[20];		//Ԥ������
   char cBeginTime[20];
   char cEndTime[20];		
   char cTeller_id[20];		//����Ա
   char cLong_short[3];		//��շ����־

   string sAlarmIter ="";	  //��ʱԤ����
   string sAlarmObjIter = ""; //��ʱԤ������
   string sProd_Code,sNotify_obj,sGessTime;	



   CRLog(E_DEBUG, "%s","loading RISK_ALARM_PARA info......");
   string sSql = "SELECT PROD_CODE,NOTIFY_OBJ,TERM_VALUE,NOTIFY_WAY,TIMEOUT,TERM_TYPE,BEGIN_DAY,END_DAY,TELLER_ID FROM RISK_ALARM_PARA ";
			sSql += "ORDER BY PROD_CODE DESC,NOTIFY_OBJ DESC";

   m_mapRiskAlarmPara.clear();
   otl_stream oAlarmPara(50, sSql.c_str(), dbConnection);
   map<string,RiskAlarmPara> mapObjAlarmPara;
   while(!oAlarmPara.eof())
	{
		oAlarmPara >> cProd_Code >> cNotify_obj >> cTerm_value >> cNotify_way >> iTimeout >> cTerm_type >> cBeginTime >> cEndTime >> cTeller_id;

		RiskAlarmPara objAlarmIter;
		sProd_Code.assign(cProd_Code);
		sNotify_obj.assign(cNotify_obj);


		objAlarmIter.term_value.assign(cTerm_value); //Ԥ��ֵ
		objAlarmIter.term_type.assign(cTerm_type);   // Ԥ������
		objAlarmIter.notify_way.assign(cNotify_way);		//Ԥ����ʽ
		objAlarmIter.timeout = iTimeout;   //���ʱ��
		objAlarmIter.oBegin_time = ParseStringTime(sGessTime.assign(cBeginTime));
		objAlarmIter.oEnd_time =  ParseStringTime(sGessTime.assign(cEndTime));
		objAlarmIter.teller_id.assign(cTeller_id);

		objAlarmIter.sAlarm_Iter = sProd_Code;
		objAlarmIter.sAlarm_obj = sNotify_obj;

		if( sProd_Code != gc_sAlarmCapitalALL)
			objAlarmIter.ui_Alarm_type = 0;
		else
			objAlarmIter.ui_Alarm_type = 1;

		//if(sAlarmObjIter != sNotify_obj)
		//{
		//	mapObjAlarmPara[sNotify_obj] = objAlarmIter;
		//}
		if(sAlarmIter == "")
		{
			sAlarmIter = sProd_Code;
		}

		if( sAlarmIter != sProd_Code )
		{
			if(mapObjAlarmPara.size() >0 )
				m_mapRiskAlarmPara[sAlarmIter] = mapObjAlarmPara;

			sAlarmIter = sProd_Code;
			mapObjAlarmPara.clear();
		}

		mapObjAlarmPara[sNotify_obj] = objAlarmIter;
	} 
	if(mapObjAlarmPara.size() >0 )
		m_mapRiskAlarmPara[sAlarmIter] = mapObjAlarmPara;



	//װ����Ӫֹ����ƺ�Լ����Ȩ�ޱ�

	sSql = "select acct_no,prod_code,nvl(long_short,'0') from ACCT_PROD_TRANS";
	m_mapProdOptions.clear();
	otl_stream oProdOption(50, sSql.c_str(), dbConnection);
	while(!oProdOption.eof())
	{
		RiskSelfTranOptionPara oSelfTransOption;
		oProdOption >> cAcctNo >> cProd_Code >> cLong_short;
		string sKey = string(cAcctNo)+ string(cProd_Code);
		oSelfTransOption.sAcctNo = string(cAcctNo);
		oSelfTransOption.sProdCode = string(cProd_Code);
		oSelfTransOption.iLongShort = atoi(cLong_short);
		m_mapProdOptions[sKey] = oSelfTransOption;
	}
	

	//װ����Ӫ�ͻ��ż���
	sSql="select acct_no from cust_info where acct_type='1' order by acct_no";
	m_verSelfAcctNos.clear();
	otl_stream oSelfAcctNos(50, sSql.c_str(), dbConnection);
	while(!oSelfAcctNos.eof())
	{
		oSelfAcctNos >> cAcctNo ;
		m_verSelfAcctNos.push_back(string(cAcctNo));
	}
	return 0;
}


//�ж�ָ���Ŀͻ��Ƿ�Ϊ��Ӫ�ͻ�
int CRiskAlarmParaTbl::CheckSelfAcctNoIsExists(const string& sAcctNo)
{
	vector<string>::iterator it=m_verSelfAcctNos.begin();
	for(;it != m_verSelfAcctNos.end();it++)
	{
		if((*it) ==sAcctNo )
			return 0;
	}	
	return -1;	
}

//�ж�ָ����Ӫ�ͻ�ָ����Լ�Ĳ���Ȩ��
int CRiskAlarmParaTbl::CheckProdOptionsFlag(const string& sAcctNo,const string& sProd_Code)
{
	string sKey = sAcctNo+sProd_Code;
	map<string,RiskSelfTranOptionPara>::iterator it = m_mapProdOptions.find(sKey);
	if(it != m_mapProdOptions.end())
	{
		return it->second.iLongShort;
	}
	return 0;
}

//�ж�ָ����Ӫ�ͻ��Ƿ�������� 0���ڣ�1-������
int CRiskAlarmParaTbl::CheckProdOptionsFlag(const string& sAcctNo)
{
	map<string,RiskSelfTranOptionPara>::iterator it = m_mapProdOptions.begin();

	for( ;it != m_mapProdOptions.end();++it)
	{
		if(it->second.sAcctNo == sAcctNo )
		{
			return 0;
		}
	}
	return -1;
}


//�������ͻ�ȡ��澯��Ϣ
int CRiskAlarmParaTbl::GetRiskAlarmTermType(const string& sProd_Code,map<string,RiskAlarmPara>& mapAlarmQuotation)
{
	CGessGuard guard(m_mutexTbl);
	map<string,map<string,RiskAlarmPara> > ::iterator it;

	it = m_mapRiskAlarmPara.find(sProd_Code);
	if(it != m_mapRiskAlarmPara.end())
	{
		mapAlarmQuotation =(map<string,RiskAlarmPara>)it->second;
		return 0;
	}
	return -1;
}

//��ȡ����Ԥ��������Ϣ
int CRiskAlarmParaTbl::GetRiskAlarmParaRecordSet(map<string,map<string,RiskAlarmPara> > & mapAlarmPara)
{
	mapAlarmPara = m_mapRiskAlarmPara;
	return 0;
}

int CRiskAlarmParaTbl::GetRiskAlarmSlefPara(const string acct_no,RiskAlarmPara& riskAlarm)
{
	map<string,map<string,RiskAlarmPara> >::iterator itCode;
	map<string,RiskAlarmPara>::iterator itIter;

	CGessGuard guard(m_mutexTbl);
	for(itCode = m_mapRiskAlarmPara.begin(); itCode != m_mapRiskAlarmPara.end(); ++itCode )
	{
		if(itCode->first == gc_sAlarmCapitalALL)  // �����ʽ�Ԥ��
		{	
			itIter= itCode->second.find(acct_no);
			if(itIter !=itCode->second.end() )
			{
				riskAlarm = itIter->second;
				return 0;
			}				
		}	
	}
	return -1;
}


//��ȡ��Ӫ���п����ʽ�Ԥ�����
int CRiskAlarmParaTbl::GetRiskAlarmSlefIsExists(const string mapKey)
{
	map<string,map<string,RiskAlarmPara> >::iterator itCode;
	map<string,RiskAlarmPara>::iterator itIter;

	CGessGuard guard(m_mutexTbl);
	for(itCode = m_mapRiskAlarmPara.begin(); itCode != m_mapRiskAlarmPara.end(); ++itCode )
	{
		if(itCode->first == gc_sAlarmCapitalALL)  // �����ʽ�Ԥ��
		{	
			itIter= itCode->second.find(mapKey);
			if(itIter !=itCode->second.end() )
				return 0;
		}	
	}
	return -1;
}


	 /***
	   *  ���¸澯֪ͨ�Ļ�����Ϣ
	   * param: alarmKey =(Ԥ������+Ԥ����+Ԥ������) 
	   *        iTimeout == ʱ��������λ ����)
	   * return 0--��Ҫ������ʾ��Ϣ  -1--������ʾ�澯
	   ***/
int CRiskAlarmParaTbl::UpRiskAlarmNotifyInfo(string& alarmKey,int iTimeout)
{
	CGessTime t_CurTime;
	CGessGuard guard(m_mutexTbl);
	map<string,CGessTime>::iterator it = m_mapAlarmTimes.find(alarmKey);
	if( it != m_mapAlarmTimes.end())
	{
		if(it->second.IntervalToNow() > iTimeout * 60 )
		{
			CRLog(E_DEBUG,"֪ͨ,alarmKey=[%s],ƥ��ʱ�� time= [%s]",alarmKey.c_str(),t_CurTime.ToString(":").c_str());
			m_mapAlarmTimes[alarmKey] = t_CurTime;	
			return 0;
		}
		else
		{
			CRLog(E_DEBUG,"δ֪ͨ,alarmKey=[%s],ƥ��ʱ��Time=[%s],Cur_time= [%s]",alarmKey.c_str(),it->second.ToString(":").c_str(),t_CurTime.ToString(":").c_str());
			return -1;
		}
			
	}
	else
	{
		// ��ȡϵͳ��ǰ����ʱ��
		/*time_t tmNow;
		time(&tmNow);
		struct tm stTime;
		localtime_r(&tmNow,&stTime);
		CGessTime t_CurTime=CGessTime( stTime.tm_hour,stTime.tm_min,stTime.tm_sec);*/
		m_mapAlarmTimes[alarmKey] = t_CurTime;		
		CRLog(E_APPINFO, "alarmKey=[%s],ƥ��ʱ�� time= [%s]",alarmKey.c_str(),t_CurTime.ToString(":").c_str());
	}

	return 0;
}


	 /***
	   * ���������Ƿ�ﵽԤ������ 1���ﵽԤ��, 0��δ�ﵽԤ��
	   * param:  paraValue -- Ԥ��ֵ 
	             termType  -- Ԥ������
				 curCapital  -- �������ʽ�
				 dlBidPrice  -- ��ǰ�����
				 dlAskPrice  -- ��ǰ������
	   */
int CRiskAlarmParaTbl::CheckParaIsFill(const double paraValue,const string termType,double& dlCapital,double dlBidPrice,double dlAskPrice)
{
	string sSymbol[] ={"=",">","<",">=","<=","!=",
						"��>","��<","��=",
						"��>","��<","��="
					  };
	int i= 0;
	for(i=0;i<12;i++)
	{	
		if(sSymbol[i] == termType )
			break;
	}
	CRLog(E_DEBUG,"....i=[%d],paraValue =[%f],termType = [%s],dlCapital = [%f],dlBidPrice = [%f],dlAskPrice =[%f]",
		i,paraValue,termType.c_str(),dlCapital,dlBidPrice,dlAskPrice);

	switch(i)
	{
		case 0:
			return (abs(dlCapital - paraValue) <= 0.00001) ? 1:0;
		case 1:
			return (dlCapital - paraValue) > 0.01 && abs(dlCapital) >0.0001 ? 1:0;
		case 2:
			return (dlCapital - paraValue) < 0.01 && abs(dlCapital) >0.0001 ? 1:0;
		case 3:
			return (dlCapital - paraValue) >= 0.01 && abs(dlCapital) >0.0001 ? 1:0;
		case 4:
			return (dlCapital - paraValue) <= 0.01 && abs(dlCapital) >0.0001 ? 1:0;
		case 5:
			return ((dlCapital != paraValue) ? 1:0);


		case 6:
			dlCapital = dlBidPrice;
			return ((dlBidPrice - paraValue) > 0.01 && dlBidPrice>0.001 ? 1:0);
		case 7:
			dlCapital = dlBidPrice;
			return ((dlBidPrice - paraValue) < 0.01 && dlBidPrice>0.001 ? 1:0);
		case 8:
			dlCapital = dlBidPrice;
			return (abs(dlBidPrice - paraValue) < 0.01 && dlBidPrice>0.001 ? 1:0);

		case 9:
			dlCapital = dlAskPrice;
			return ((dlAskPrice - paraValue) >0.01 && dlAskPrice>0.001 ? 1:0);
		case 10:
			dlCapital = dlAskPrice;
			return ((dlAskPrice - paraValue) <0.01 && dlAskPrice>0.001  ? 1:0);
		case 11:
			dlCapital = dlAskPrice;
			return (abs(dlAskPrice - paraValue) < 0.01 && dlAskPrice>0.001 ? 1:0);
	}
	return 0;
}


CGessTime CRiskAlarmParaTbl::ParseStringTime(string& sGessTime)
{
	CGessTime t_GessTime;
	int h = FromString<int>(sGessTime.substr(0,2));//Сʱ
	int m = FromString<int>(sGessTime.substr(3,2));//����
	int s = FromString<int>(sGessTime.substr(6,2));//��
	if (h < 0 || h > 24 || m < 0 || m >60 || s < 0 || s > 60 )
	{
		CRLog(E_ERROR,"��ʱ�Զ�ǿƽʱ������ó��� [%s],Ĭ��ȡ��ǰʱ��", sGessTime.c_str());	
		return t_GessTime;
	} 
	else
	{
		return CGessTime(h,m,s);
	}
}


void CRiskAlarmParaTbl::Finish()
{
	CGessGuard guard(m_mutexTbl);
	//Ԥ����������
	m_mapRiskAlarmPara.clear();

	//Ԥ��֪ͨ������
	m_mapAlarmTimes.clear();

	m_mapProdOptions.clear();

	m_verSelfAcctNos.clear();
}


