//#pragma once
#ifndef _RISK_MAIN_H
#define _RISK_MAIN_H
#include "RiskCpMgr.h"

class CRiskMain
{
public:
	CRiskMain(void);
public:
	~CRiskMain(void);

	// ִ�к���
	int Run( int argc, char* argv[] );

private:
	CRiskCpMgr theMgr;
};
#endif