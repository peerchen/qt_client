#include "Global.h"
#include <iostream>
#include "BF_DesEncrypt.h"
#include "Logger.h"
#include "RiskConstant.h"
using namespace RiskConst;

CGlobal::CGlobal(void)
{
}

CGlobal::~CGlobal(void)
{
}

//RiskConst::EDBTYPE CGlobal::GetDBType()
//{
//	return e_DB_ORA;
//}

int CGlobal::GetNotifyPeriod()
{
	return gc_nNotifyPeriod;
}

string CGlobal::GetDbConnectStr( CConfig* pConfig )
{
	assert(pConfig != 0);

	string sUser = "";		//���ݿ��û���
	string sPwd = "";		//����
	string sTns = "";		//������
	string sConnStr = "";	//�����ַ���

	pConfig->GetProperty("user", sUser);
	pConfig->GetProperty("pwd", sPwd);
	pConfig->GetProperty("tns", sTns);

	char szPwdEnc[512]={0};
	//char szPwdDec[512];
	strcpy(szPwdEnc,sPwd.c_str());
	CBF_DesEnctypt DesEnctrpt;
	CRLog(E_DEBUG, "in para:%s", szPwdEnc);
//	DesEnctrpt.unencryptchar(szPwdEnc, strlen(szPwdEnc), gc_sBF_DES_KEY.c_str());
	sConnStr = sUser + "/" + szPwdEnc + "@" + sTns;
	CRLog(E_DEBUG, "out para:%s", szPwdEnc);
	return sConnStr;
}

int CGlobal::Get3DesEnc( char *buf,int buflen, string& sErrorMsg )
{
	if( buflen >= 512 )
	{
		sErrorMsg = "����̫���������Ƿ��������!";
		return -1;
	}

	CBF_DesEnctypt DesEnctrpt;
	if( !DesEnctrpt.encryptchar(buf, buflen, gc_sBF_DES_KEY.c_str()) )
	{
		sErrorMsg = "3DES/BASE64���ܴ���";
		return -2;
	}

	return 0;
}

void CGlobal::PassWord( int argc, char* argv[] )
{
	char para1[500];
	memset(para1,0,sizeof(para1));
	strcpy(para1,argv[1]);
	if (strcmp(para1,"en") == 0)
	{
		// ��ȡ����
		char szPwd[512];
		strcpy(szPwd,argv[2]);

		// ��������м���
		string sErrorMsg;
		if( CGlobal::Get3DesEnc(szPwd,strlen(szPwd),sErrorMsg) == 0 )
		{
			cout << "3DES/BASE64���ܺ�ĵ����봮:" << szPwd << endl;
		}
		else
		{
			cout << "3DES/BASE64���ܴ���" << sErrorMsg << endl;
		}
	}
	else if (strcmp(para1,"un") == 0)
	{
		char szPwdEnc[512]={0};

		strcpy(szPwdEnc,argv[2]);
		CBF_DesEnctypt DesEnctrpt;

		if (DesEnctrpt.unencryptchar(szPwdEnc, strlen(szPwdEnc), gc_sBF_DES_KEY.c_str()))
		{
			cout << "3DES/BASE64���ܺ�ĵ����봮:" << szPwdEnc << endl;
		}
		else
		{
			cout << "3DES/BASE64���ܴ���" << endl;
		}
	}
}
