#include "MainServiceHandler.h"

// F1 �ӿ� [3098]��Լ�����ѯ���������� ��ҵ��ʵ��
int CMainServiceHandler::OnProdQuotationReq(CTradePacket& pkt)
{
	CRLog(E_DEBUG, "in OnProdQuotationReq");
	HEADER_REQ stHeaderReq;
	ProdQuotationReq stBodyReq;

	HEADER_RSP stHeaderRsp;
	ProdQuotationRsp stBodyRsp;

	pkt.GetHeader(stHeaderReq);
	CPacketStructTradeRisk::Packet2Struct(stBodyReq, pkt);

	//ҵ��ʵ��......
	string sRspCode = RSP_SUCCESS;
	string sRspMsg;

	PROD_QUOTATION stQuo;
	if (0 == m_pMemDb->GetQuotationTbl().GetQuotation(stBodyReq.prod_code,stQuo))
	{
		ArrayListMsg alMsg;
		alMsg.AddValue(stQuo.sProdCode);
		alMsg.AddValue(stQuo.dlNowPrice);
		alMsg.AddValue(stQuo.dlBid1);
		alMsg.AddValue(stQuo.dlAsk5);
		alMsg.AddValue(stQuo.dlUpLimit);
		alMsg.AddValue(stQuo.dlDownLimit);

		stBodyRsp.quotaion_result.AddValue(alMsg);
	}
	else
	{
		sRspCode = RSP_NO_DATA;
		sRspMsg = "δ�Һ�Լ��Ӧ��������!";		
	}

	stBodyRsp.oper_flag = stBodyReq.oper_flag;

	//������Ӧ����
	CTradePacket pktRsp;
	CPacketStructTradeRisk::HeadReq2Rsp(stHeaderReq,stHeaderRsp);

	strcpy(stHeaderRsp.rsp_code, sRspCode.substr(0,8).c_str());
	if (sRspCode != RSP_SUCCESS)
	{
		pktRsp.AddParameter(RSP_MSG, sRspMsg);
	}

	pktRsp.SetHeader(stHeaderRsp);
	CPacketStructTradeRisk::Struct2Packet(stBodyRsp,pktRsp);

	CRLog(E_DEBUG, " OnProdQuotationReq %s", pktRsp.Print().c_str());
	//ת������
	m_pRiskCpMgr->ToInterfaceF1(pktRsp,m_ulKey);

	return 0;
};
