#include "MainServiceHandler.h"
#include "Logger.h"
#include <sstream>
#include "strutils.h"
using namespace strutils;

//[3308] ���������������ղ�������

int CMainServiceHandler::OnSubAgentRiskParaSet(CTradePacket& pkt)
{
	HEADER_REQ stHeaderReq;
	HEADER_RSP stHeaderRsp;
	SubAgentRiskParaSetReq stBodyReq;
	SubAgentRiskParaSetRsp stBodyRsp;

	pkt.GetHeader(stHeaderReq);
	CPacketStructTradeRisk::HeadReq2Rsp(stHeaderReq, stHeaderRsp);

	CPacketStructTradeRisk::Packet2Struct(stBodyReq, pkt);
	stBodyRsp.oper_flag = stBodyReq.oper_flag;

	CTradePacket pktRsp;

	//ҵ��ʵ��......

	string str;
	ArrayListMsg msg;
	if (stBodyReq.oper_flag == 0) // ��ѯ
	{
		string sSql;
		vector<string> vectCodeID; 
		char cCodeID[11] = "";
		int count = 0;

		sSql = "select code_id from v_ct_threshold_type order by code_id";
		otl_stream o(1, sSql.c_str(), GetOtlConn());
		while(!o.eof())
		{
			o >> cCodeID;
			str = cCodeID;
			vectCodeID.push_back(str);
		}
		count = vectCodeID.size(); // ��ֵ��������


		char threshold_type[11]="";  // ��ֵ����
		double threshold_value = 0.0;  // ��ֵ��ֵ
		char cBranchID[13] = "";  // ��������
		char cBranchName[51] = "";  // ��������
		int index;
		double dldefault = 0.0;

		vector<string> vectBranchID;  // ��������
		vector<string> vectBranchName;  // ����

		vector<CAgent*> vectSubAgent;
		m_pMemDb->GetAgentTble().GetSubAgent(vectSubAgent);
		vector<CAgent*>::iterator iter;

		if (stBodyReq.query_condition.size() > 0)// ��ѯ������Ϊ�գ����ѯָ����������ķ�ֵ���ͺ���ֵ
		{
			for (int i = 0; i < stBodyReq.query_condition.size(); i++)
			{
				msg = stBodyReq.query_condition.GetValue(i);
				vectBranchID.push_back(msg.GetValue<string>(0));
				for (iter = vectSubAgent.begin(); iter != vectSubAgent.end(); ++iter)
				{
					if ((*iter)->GetAgentID() == msg.GetValue<string>(0))
					{
						vectBranchName.push_back((*iter)->GetName());
						break;
					}
				}
			}
		}
		else
		{
			for (iter = vectSubAgent.begin(); iter != vectSubAgent.end(); ++iter)
			{
				vectBranchID.push_back((*iter)->GetAgentID());
				vectBranchName.push_back((*iter)->GetName());
			}
		}
		sSql = "select d.branch_id,d.branch_name,c.threshold_type,c.threshold_value from risk_sub_agent_para c "
			"right join "
			"(select a.branch_id, a.branch_name, b.bank_type,a.branch_level from branch_info a left join bank_info b on a.bank_no=b.bank_no "
			"where b.bank_type='6' and not a.branch_level=2) d on c.branch_id=d.branch_id "
			"where d.branch_id=:f1<char[13]> "
			"order by branch_id,threshold_type";
		//"select threshold_value from sub_agent_risk_para where branch_id=:f1<char[13]> order by threshold_type";
		vector<string>::iterator it;
		vector<string>::iterator it1;
		string str, str1;
		// 			for (int i = 0; i < stBodyReq.query_condition.size(); i++)
		for (it = vectBranchID.begin(), it1 = vectBranchName.begin(); it != vectBranchID.end(); ++it, ++it1)
		{
			otl_stream o(1, sSql.c_str(), GetOtlConn());
			// 				o << stBodyReq.query_condition.GetValue(i).GetValue<string>(0).c_str();
			o << it->c_str();
			index = 0;
			while (!o.eof())
			{
				o >> cBranchID >> cBranchName >> threshold_type >> threshold_value;
				if (strlen(threshold_type) > 0)
				{
					msg.clear();
					msg.AddValue(cBranchID);
					msg.AddValue(cBranchName);
					msg.AddValue(threshold_type);
					msg.AddValue(threshold_value);
					stBodyRsp.alm_result.AddValue(msg);
					index++;
				}
			}
			if (index < count)
			{
				bool bExit;
				str.assign(it->c_str());
				str1.assign(it1->c_str());
				for (int j = 0; j < count; j++)
				{
					bExit = false;

					for (int jj = 0; jj < stBodyRsp.alm_result.size(); jj++)
					{
						msg = stBodyRsp.alm_result.GetValue(jj);
						if ( (vectCodeID[j] == msg.GetValue<string>(2)) && 
							(str == msg.GetValue<string>(0)))
						{
							bExit = true;
							break;;
						}
					}
					if (!bExit)
					{
						msg.clear();
						msg.AddValue(str);
						msg.AddValue(str1);
						msg.AddValue(vectCodeID[j]);
						msg.AddValue(dldefault);
						stBodyRsp.alm_result.AddValue(msg);
					}
				}
			}
		}
		vectSubAgent.clear();
		vectBranchID.clear();
		vectCodeID.clear();
// 		else // ��ѯ����Ϊ�գ����ѯ�����������������ķ�ֵ���ͺ���ֵ
// 		{
// // 			char cBranchIDOld[13] = "";
// 			sSql = "";
// 			otl_stream o(1, sSql.c_str(), GetOtlConn());
// 			while (!o.eof())
// 			{
// 				o >> cBranchID >> cBranchName >> threshold_type >> threshold_value;
// 				msg.clear();
// 				msg.AddValue(cBranchID);
// 				msg.AddValue(cBranchName);
// 				msg.AddValue(threshold_type);
// 				msg.AddValue(threshold_value);
// 				stBodyRsp.alm_result.AddValue(msg);
// // 				o >> cBranchID >> threshold_type >> threshold_value;
// // 				if (strlen(cBranchIDOld) == 0 || (strcmp(cBranchID, cBranchIDOld) == 0)) // ��Ȼ�cBranchIDOldΪ��
// // 				{
// // 					msg.AddValue(threshold_type);
// // 					msg.AddValue(threshold_value);
// // 				}
// // 				else
// // 				{
// // 					msg.AddValue(0, cBranchIDOld);
// // 					stBodyRsp.alm_result.AddValue(msg);
// // 					msg.clear();
// // 				}
// // 				strcpy(cBranchIDOld, cBranchID);
// 			}
// 		}
	}
	else if (stBodyReq.oper_flag == 1) // �޸�
	{
		for (int i = 0; i < stBodyReq.query_condition.size(); i++)
		{
			msg = stBodyReq.query_condition.GetValue(i);
// 			for (int j = 1; j < stBodyReq.query_condition.GetValue(i).size(); j++)
// 			{
				string sSql = "select * from risk_sub_agent_para where branch_id=:f1<char[13]> and threshold_type=:f2<char[11]>";
				otl_stream o(1, sSql.c_str(), GetOtlConn());
				o << msg.GetValue<string>(0).c_str() << msg.GetValue<string>(1).c_str();
				if (!o.eof()) // �����ݣ����¾���
				{
					sSql = "update risk_sub_agent_para set threshold_value=:f1<double> where branch_id=:f2<char[13]> and threshold_type=:f3<char[11]>";
					otl_stream o_update(1, sSql.c_str(), GetOtlConn());
					o_update << msg.GetValue<double>(2) << msg.GetValue<string>(0).c_str() << msg.GetValue<string>(1).c_str();
// 					j++;
					m_OtlConn.commit();
				}
				else // ��¼�����ڣ�����
				{
					sSql = "insert into risk_sub_agent_para values(:f1<char[13]>, :f2<char[11]>, :f3<double>)";
					otl_stream o_insert(1, sSql.c_str(), GetOtlConn());

					o_insert << msg.GetValue<string>(0).c_str() << msg.GetValue<string>(1).c_str() << msg.GetValue<double>(2);
// 					o_insert << str1.c_str() << str2.c_str() << db;
// 					j++;
					m_OtlConn.commit();
// 				}
			}
		}
	}
	else
	{
		strcpy(stHeaderRsp.rsp_code, RSP_PARAM_ERROR.c_str());
		pktRsp.AddParameter("rsp_msg", "�����������");
	}

	pktRsp.SetHeader(stHeaderRsp);
	CPacketStructTradeRisk::Struct2Packet(stBodyRsp, pktRsp);

	// ���ͱ���
	m_pRiskCpMgr->ToInterfaceF1(pktRsp,m_ulKey);

	return 0;
}