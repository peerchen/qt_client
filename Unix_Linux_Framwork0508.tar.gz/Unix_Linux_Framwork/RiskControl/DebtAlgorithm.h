#ifndef CDEBTALGORITHM_H_HEADER_INCLUDED_B6E3CEA7
#define CDEBTALGORITHM_H_HEADER_INCLUDED_B6E3CEA7

//##ModelId=491B04CD0271
class CDebtAlgorithm
{
  public:
    //##ModelId=491B056E037A
    virtual double Debt(double dlRiskDegree,double dlCapital, double dlMargin, double dlBalance, double dlRatio, double dlDebtLineMem) = 0;
};

#endif /* CDEBTALGORITHM_H_HEADER_INCLUDED_B6E3CEA7 */
