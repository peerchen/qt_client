#include <sstream>
#include <iomanip>
#include "EtfMatchDetailTbl.h"
#include "BasicParaTbl.h"
#include "DB_Version.h" 
#include "Logger.h"

CEtfMatchDetailTbl::CEtfMatchDetailTbl()
{

}

CEtfMatchDetailTbl::~CEtfMatchDetailTbl()
{
	Finish();
}



bool CEtfMatchDetailTbl::IsHandled(const string& sKey,const string& sAcctNo)
{
	bool blRtn = false;

	CGessGuard guard(m_mutexTbl);
	if (m_mapPosi.find(sKey) != m_mapPosi.end())
	{
		blRtn = true;
	}
	else
	{
		m_mapPosi[sKey] = sAcctNo;
		blRtn = false;
	}

	return blRtn;
}

//���������ݿ��ʼ��
int CEtfMatchDetailTbl::Init(otl_connect& dbConnection,CBasicParaTbl& BasicParaTbl)
{
	char cMatchNo[17];			//�ɽ����
	char cAcctNo[16];			//�ʽ��ʺ�/�ͻ���
	string sSql = "";

	memset(cMatchNo, 0, sizeof(cMatchNo));
	memset(cAcctNo, 0, sizeof(cAcctNo));

	try
	{
		//���ճɽ���ˮ��
		sSql = "select local_serial_no, acct_no from etf_match_flow where exch_date >= :f1<char[9]>";
		otl_stream oMatchDetail(1, sSql.c_str(), dbConnection);
		oMatchDetail << BasicParaTbl.GetExchDate().c_str();

		while (!oMatchDetail.eof())
		{
			oMatchDetail >> cMatchNo >> cAcctNo;
			string sKey = cMatchNo;
			m_mapPosi[sKey] = cAcctNo;			
		}

	}
	catch(otl_exception &p)
	{
		CRLog(E_ERROR, "otl exception:%s,%s,%s,%s", p.msg, p.stm_text, p.sqlstate, p.var_info);
	}

	return 0;
}

//��������
void CEtfMatchDetailTbl::Finish()
{
	CGessGuard guard(m_mutexTbl);
	m_mapPosi.clear();
}


string CEtfMatchDetailTbl::ToString()
{
	std::stringstream ss;

	map<string,string>::iterator iter;

	CGessGuard guard(m_mutexTbl);
	for( iter =  m_mapPosi.begin(); iter != m_mapPosi.end(); ++iter)
	{
		ss << (*iter).first << " " << (*iter).second;
		ss << "\r\n";
	}

	return ss.str();
}