#ifndef CRISKHANDLETBL_H_HEADER_INCLUDED_B6E3C675
#define CRISKHANDLETBL_H_HEADER_INCLUDED_B6E3C675
#include <string>
#include <map>
#include <vector>
#include "Gess.h"
using namespace std;

typedef struct tagRiskHandleDefine
{
	unsigned short usHandleID;
	string sHandleName;   
	string sHandleClass;
} RISK_HANDLE_DEFINE,*PRISK_HANDLE_DEFINE;

class otl_connect;
class CRiskHandleTbl
{
public:
	CRiskHandleTbl();
	~CRiskHandleTbl();

    //##ModelId=491AF50A02AF
    int GetHandle(unsigned short usHandleID, RISK_HANDLE_DEFINE& stRiskHandle);

    //##ModelId=491B042E035B
    int Init(otl_connect& dbConnection);
	//��������
	void Finish();
  private:
    //##ModelId=491AF4E70222
    vector<RISK_HANDLE_DEFINE> m_vecRiskHandleDef;
};

#endif /* CRISKHANDLETBL_H_HEADER_INCLUDED_B6E3C675 */
