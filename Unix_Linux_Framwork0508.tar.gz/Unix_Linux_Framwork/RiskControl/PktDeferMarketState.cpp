#include "RiskCpMgr.h"

// A1 �ӿ� [onRecvRtnDeferMarketStateUpdate]DeferMarketState ��ҵ��ʵ��
int CRiskCpMgr::OnDeferMarketState(CBroadcastPacket& pkt)
{
	DeferMarketState stBody;
	CPacketStructBroadcastRisk::Packet2Struct(stBody, pkt);

	//ҵ��ʵ��......
	SendAck(pkt);

	return 0;
};
