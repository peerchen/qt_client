#include "AutoForceExecptCndTbl.h"
#include "Logger.h"
#include "DB_Version.h" 
#include "GessDate.h"
#include "strutils.h"
//#include "VersionMacro.h"

//�Զ�ǿƽ�����������ñ�

CAutoForceExecptCndTbl::CAutoForceExecptCndTbl()
{

}

CAutoForceExecptCndTbl::~CAutoForceExecptCndTbl()
{
	Finish();
}


int CAutoForceExecptCndTbl::GetCustomeridMap(map<std::string,CGessDateTime>& tm_Customer) const
{
	CGessGuard guard(m_mutexTbl);

	tm_Customer=m_Customerid;
	return 0;

}
int CAutoForceExecptCndTbl::GetCustomerLevelMap(map<std::string,CGessDateTime>& tm_CustomerLevel) const
{
	CGessGuard guard(m_mutexTbl);

	tm_CustomerLevel= m_CustomerLevel;
	return 0;
}

int CAutoForceExecptCndTbl::GetAcountTypeMap(map<std::string,CGessDateTime>& tm_AcountType)const
{
	CGessGuard guard(m_mutexTbl);

	tm_AcountType= m_AcountType;
	return 0;

}
int CAutoForceExecptCndTbl::GetBrandidMap(map<std::string,CGessDateTime>& tm_Brandid)const
{
	CGessGuard guard(m_mutexTbl);

	tm_Brandid= m_Brandid;
	return 0;
}

//�Խ������ڱȽ�����
bool CAutoForceExecptCndTbl::GetCustExceptType(std::string sCustNo,std::string cCustLevel,std::string sBrandid,std::string sAcctType,
											   CGessDate & sTradeDate,std::string & sExceptDateTime) const
{
	CGessGuard guard(m_mutexTbl);

	CGessDateTime t_DateTime;
	std::string sSepratorDate = "-";
	std::string sSepratorTime = ":";
	std::string sSeprator = " ";


	int flag=0;

	// 1 ���ݿͻ��Ų����Ƿ�����ͻ�

	m_mutexTbl.Lock();
	map<std::string,CGessDateTime>::const_iterator it = m_Customerid.find(sCustNo);
	if(it != m_Customerid.end())
	{
		t_DateTime = it->second;
		flag=1;
	}
	it = m_CustomerLevel.find(cCustLevel);
	if( flag== 0 &&  it != m_CustomerLevel.end() )
	{
		t_DateTime = it->second;
		flag=1;
	}

	it = m_Brandid.find(sBrandid);
	if(  flag== 0 && it  != m_Brandid.end() )
	{
		t_DateTime = it->second;
		flag=1;
	}

	it =m_AcountType.find(sAcctType);
	if(  flag== 0 && it != m_AcountType.end() )
	{
		t_DateTime = it->second;
		flag=1;
	}
	m_mutexTbl.Unlock();

	if( 0== flag)
		return false;
	// ��ȡϵͳ��ǰ����ʱ��
	time_t tmNow;
	time(&tmNow);
	struct tm stTime;
	localtime_r(&tmNow,&stTime);

	CGessTime t_CurTime=CGessTime( stTime.tm_hour,stTime.tm_min,stTime.tm_sec);
	CGessDateTime t_CurDateTime = CGessDateTime(sTradeDate,t_CurTime);

	if(t_DateTime.Compare(t_CurDateTime) >0)
	{
		sExceptDateTime = t_DateTime.ToString(sSepratorDate,sSepratorTime,sSeprator);
		return true;
	}else
	{
		sExceptDateTime="";
		return false;
	}

}

//��ϵͳ���ڱȽ�����
bool CAutoForceExecptCndTbl::GetCustExceptType(std::string sCustNo,std::string cCustLevel,std::string sBrandid,std::string sAcctType,
											   std::string & sExceptDateTime) const
{
	CGessGuard guard(m_mutexTbl);

	CGessDateTime t_DateTime;
	std::string sSepratorDate = "-";
	std::string sSepratorTime = ":";
	std::string sSeprator = " ";


	int flag=0;

	// 1 ���ݿͻ��Ų����Ƿ�����ͻ�

	m_mutexTbl.Lock();
	map<std::string,CGessDateTime>::const_iterator it = m_Customerid.find(sCustNo);
	if(it != m_Customerid.end())
	{
		t_DateTime = it->second;
		flag=1;
	}
	it = m_CustomerLevel.find(cCustLevel);
	if( flag== 0 &&  it != m_CustomerLevel.end() )
	{
		t_DateTime = it->second;
		flag=1;
	}

	it = m_Brandid.find(sBrandid);
	if(  flag== 0 && it  != m_Brandid.end() )
	{
		t_DateTime = it->second;
		flag=1;
	}

	it =m_AcountType.find(sAcctType);
	if(  flag== 0 && it != m_AcountType.end() )
	{
		t_DateTime = it->second;
		flag=1;
	}
	m_mutexTbl.Unlock();

	if( 0== flag)
		return false;
	// ��ȡϵͳ��ǰ����ʱ��

	if(t_DateTime.IntervalToNow() <= 0)
	{
		sExceptDateTime = t_DateTime.ToString(sSepratorDate,sSepratorTime,sSeprator);
		return true;

	}else
	{
		sExceptDateTime="";
		return false;
	}

}





//##ModelId=4916CF61037A
int CAutoForceExecptCndTbl::Init(otl_connect& dbConnection)
{

	char cExceptType[6];				//��������
	char cTypeValue[40];                 //����ֵ �Ǹ����ֵ
	char cExceptDateTime[25];		    //��������ʱ��



	string sSql = "";

	memset(cExceptType, 0, sizeof(cExceptType));
	memset(cExceptDateTime, 0, sizeof(cExceptDateTime));
	CRLog(E_DEBUG, "loading AUTO_FORCE_EXCEPT_COND_PARA info %s"," ......");
	CGessGuard guard(m_mutexTbl);
	try
	{
#ifdef _VER_25_DB2
			sSql="select FG_CovToChar(EXCEPT_TYPE),TYPE_VALUE ,EXCEPT_DATE_TIME from AUTO_FORCE_EXCEPT_COND_PARA";
#else
			sSql="select to_char(EXCEPT_TYPE),TYPE_VALUE ,EXCEPT_DATE_TIME from AUTO_FORCE_EXCEPT_COND_PARA";
#endif

		otl_stream o(1, sSql.c_str(), dbConnection);
		while (!o.eof())
		{

			memset(cTypeValue, 0, sizeof(cTypeValue)); 
			o>>cExceptType>>cTypeValue>>cExceptDateTime;


			CGessDate t_GessDate;
			CGessTime t_GessTime;
			CGessDateTime t_DateTime;
			vector<string> v_DateTime;          //����ʱ��

			v_DateTime = explodeQuoted(" ",cExceptDateTime);
			if(v_DateTime.size()==2)
			{
				t_GessDate = CGessDate(v_DateTime[0]); 
				int h = FromString<int>(v_DateTime[1].substr(0,2));//Сʱ
				int m = FromString<int>(v_DateTime[1].substr(3,2));//����
				int s = FromString<int>(v_DateTime[1].substr(6,2));//��
				t_GessTime=CGessTime(h,m,s);
				t_DateTime=CGessDateTime(t_GessDate,t_GessTime);
			}
			else
			{
				CRLog(E_ERROR,"%s", "����ʱ�����ó���");
				return -1;
			}

			if (strcmp(cExceptType, "1") == 0) //1�ͻ���
			{

				m_Customerid[cTypeValue]=t_DateTime;

			}
			else if (strcmp(cExceptType, "2") == 0)//2�ͻ�����
			{

				m_CustomerLevel[cTypeValue]=t_DateTime;
			}
			else if (strcmp(cExceptType, "3") == 0)//3 ��������
			{  

				m_Brandid[cTypeValue]=t_DateTime;
			}
			else  if (strcmp(cExceptType, "4") == 0)//4�˻�����
			{

				m_AcountType[cTypeValue]=t_DateTime;
			}
		}
	}
	catch(otl_exception& p)
	{
		CRLog(E_ERROR,"otl exception:%s,%s,%s,%s",p.msg,p.stm_text,p.sqlstate,p.var_info);
	}
	return 0;
}

//��������
void CAutoForceExecptCndTbl::Finish()
{
	CGessGuard guard(m_mutexTbl);

	//vecAutoForceEptCnd.clear();
	m_Customerid.clear();//�ͻ���
	m_CustomerLevel.clear();//�ͻ�����
	m_AcountType.clear() ;//�˻�����
	m_Brandid.clear();//��������ID
}


int CAutoForceExecptCndTbl::ReInit(otl_connect& dbConnection)
{
	CGessGuard guard(m_mutexTbl);

	//��ռ���
	Finish();

	//��ʼ��
	Init(dbConnection);

	return 0;
}