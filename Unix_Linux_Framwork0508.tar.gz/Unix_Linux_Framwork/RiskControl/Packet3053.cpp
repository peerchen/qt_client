#include "MainServiceHandler.h"

// A2 �ӿ� [3053]ǿƽ������Ӧ ��ҵ��ʵ��
int CMainServiceHandler::OnForceCovOderCancelAck(CTradePacket& pkt)
{
	HEADER_RSP stHeaderRsp;
	ForceCovOderCancelAck stBodyRsp;

	pkt.GetHeader(stHeaderRsp);
	CPacketStructTradeRisk::Packet2Struct(stBodyRsp, pkt);

	//ҵ��ʵ��......
	string sSerialNo;
	sSerialNo.assign(stHeaderRsp.seq_no, 9);
	string sLocalOrderNo = GetSerialNo(sSerialNo);

	if (sLocalOrderNo.size() <= 0)
	{
		CRLog(E_ERROR, "����3053 �Ҳ���ǿƽ����[%s]��Ӧ�����к�", sSerialNo.c_str());
		return -1;
	}
	  
	CTradePacket pktRsp3070;
	HEADER_RSP stHeaderRsp3070;
	
	pkt.GetHeader(stHeaderRsp3070); 
	strcpy(stHeaderRsp3070.exch_code, "3070");
	pktRsp3070.SetHeader(stHeaderRsp3070);
	
	FCOrderCancelRsp stBodyRsp3070;
	stBodyRsp3070.oper_flag = 1;
	stBodyRsp3070.order_no = sLocalOrderNo;

	CPacketStructTradeRisk::Struct2Packet(stBodyRsp3070, pkt);

	string sRspMsg; 
	pkt.GetParameterVal("rsp_msg"        , sRspMsg);
	pktRsp3070.AddParameter("rsp_msg", sRspMsg);

	// ����3066���ĵ��ͻ���
	m_pRiskCpMgr->ToInterfaceF1(pktRsp3070,m_ulKey);

	return 0;
}
