#include "RealTimeRiskTbl.h"
#include "RiskConstant.h"

using namespace RiskConst;

CRealTimeRiskTbl::CRealTimeRiskTbl()
{

}

CRealTimeRiskTbl::~CRealTimeRiskTbl()
{
	Finish();
}

//##ModelId=491533C300EA
int CRealTimeRiskTbl::GetRisk(const string& sCustID, CRtmRisk& stRisk)
{
	int nRtn = -1;
	CGessGuard guard(m_mutexTbl);
	map<string,CRtmRisk>::iterator it = m_mapRealTimeRisk.find(sCustID);
	if (it != m_mapRealTimeRisk.end())
	{
		stRisk = it->second;
		nRtn = 0;
	}
	return nRtn;
}

//##ModelId=4915340C0232
int CRealTimeRiskTbl::GetRecordSet(map<string,CRtmRisk>& mapRisk)
{
	CGessGuard guard(m_mutexTbl);
	map<string,CRtmRisk>::iterator it = m_mapRealTimeRisk.begin();
	for ( ; it != m_mapRealTimeRisk.end(); ++it)
	{
		mapRisk[it->second.m_sCustomerId] = it->second;
	}
	return 0;
}

//##ModelId=4916E21002EE
int CRealTimeRiskTbl::UpdateRiskState(CRtmRisk& stRisk)
{
	CGessGuard guard(m_mutexTbl);
	map<string,CRtmRisk>::iterator it = m_mapRealTimeRisk.find(stRisk.m_sCustomerId);
	if (it != m_mapRealTimeRisk.end())
	{
		if (stRisk.m_usRiskType == gc_cRiskTypeNormal)
		{
			m_mapRealTimeRisk.erase(it);
		}
		else
		{
			it->second = stRisk;
		}
	}
	else
	{
		if (gc_cRiskTypeNormal != stRisk.m_usRiskType)
			m_mapRealTimeRisk[stRisk.m_sCustomerId] = stRisk;
	}
	return 0;
}

//���ݷ�����ϸ�ȼ����ط��տͻ��Ӽ�
int CRealTimeRiskTbl::GetRecordSetByGrade(unsigned short usGrade,map<string,CRtmRisk>& mapRisk)
{
	CGessGuard guard(m_mutexTbl);
	map<string,CRtmRisk>::iterator it = m_mapRealTimeRisk.begin();
	for ( ; it != m_mapRealTimeRisk.end(); it++)
	{
		if (it->second.m_usRiskGrade == usGrade)
		{
			mapRisk[it->second.m_sCustomerId] = it->second;
		}
	}
	return 0;
}

//���ݷ��ջ����ȼ����ط��տͻ��Ӽ�
int CRealTimeRiskTbl::GetRecordSetByType(unsigned short usType,map<string,CRtmRisk>& mapRisk)
{
	CGessGuard guard(m_mutexTbl);
	map<string,CRtmRisk>::iterator it = m_mapRealTimeRisk.begin();
	for ( ; it != m_mapRealTimeRisk.end(); ++it)
	{
		if (it->second.m_usRiskType == usType)
		{
			mapRisk[it->second.m_sCustomerId] = it->second;
		}
	}
	return 0;
}

//���ݴ�����IDͳ����׷�����
double CRealTimeRiskTbl::GetDebtStat(const string& sBranchID)
{
	double dlDebt = 0.000;
	CGessGuard guard(m_mutexTbl);
	map<string,CRtmRisk>::iterator it = m_mapRealTimeRisk.begin();
	for ( ; it != m_mapRealTimeRisk.end(); ++it)
	{
		if (it->second.m_sBranchId == sBranchID)
		{
			dlDebt += it->second.m_dlCapitalCall;
		}
	}
	return dlDebt;
}

//��������
void CRealTimeRiskTbl::Finish()
{
	CGessGuard guard(m_mutexTbl);
	m_mapRealTimeRisk.clear();
}