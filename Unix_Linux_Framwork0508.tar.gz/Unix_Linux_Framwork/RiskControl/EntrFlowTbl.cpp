#include "EntrFlowTbl.h"
#include "Logger.h"
#include "DB_Version.h" 
#include "RiskConstant.h"
using namespace RiskConst;

CEntrFlowTbl::CEntrFlowTbl(){}



void CEntrFlowTbl::Finish()
{
	CGessGuard guard(m_mutexTbl);

	m_vecEntrFlow.clear();
}

CEntrFlowTbl::~CEntrFlowTbl()
{
	Finish();
}

int CEntrFlowTbl::Init(otl_connect &dbConnection)
{
	char cLocalOderNo[15];
	char cOderNo[17];
	char cCustID[16];
	char cProdCode[11];
	char cEntrStat[3];
	char cOffsetFlag[3];
	char cForceOrderNo[19];
	long lEntrAmount=0;
	long lRemainAmount=0;
	double dlEntrPrice=0.0;
	char cDir;
	char cTellId[50];
	string sTemp="";

	memset(cLocalOderNo,0x00,sizeof(cLocalOderNo));
	memset(cOderNo,0x00,sizeof(cOderNo));
	memset(cCustID,0x00,sizeof(cCustID));
	memset(cProdCode,0x00,sizeof(cProdCode));
	memset(cEntrStat,0x00,sizeof(cEntrStat));
	memset(cOffsetFlag,0x00,sizeof(cOffsetFlag));
	memset(cForceOrderNo,0x00,sizeof(cForceOrderNo));
	memset(cTellId,0x00,sizeof(cTellId));
	try
	{
		//���������̶���
		CRLog(E_DEBUG, "loading entr_flow info[%s]"," ......");

		//modify by liuwei 2012-0918 �������ӱ�����ͨ������ˮ
		otl_stream o(1, "select local_order_no,order_no,cust_id,prod_code,entr_stat,offset_flag,entr_amount,remain_amount,"
			" CLIENT_SERIAL_NO,Entr_Price,(case when Bs ='b' then '0' else '1' end) as bs ,e_teller_id"
#ifndef _VER_TRUNK_ORA
			" from entr_flow where offset_flag='2' and (entr_stat='1'or entr_stat='o')", dbConnection);
#else
		    " from entr_flow where (entr_stat='1'or entr_stat='o'or entr_stat='p')", dbConnection);
#endif

		CGessGuard guard(m_mutexTbl);
		while (!o.eof())
		{
			o >> cLocalOderNo >> cOderNo>> cCustID>> cProdCode>> cEntrStat>> cOffsetFlag>> lEntrAmount>> lRemainAmount>>cForceOrderNo >>dlEntrPrice >> cDir >>cTellId;

			CEntrFlow entrFlow;
				sTemp=string(cLocalOderNo);
			entrFlow.SetLocalOderNo(sTemp);
				sTemp=string(cOderNo);
			entrFlow.SetOderNo(sTemp);
				sTemp=string(cCustID);
			entrFlow.SetCustId(sTemp);
				sTemp=string(cProdCode);
			entrFlow.SetProdCode(sTemp);
				sTemp=string(cEntrStat);
			entrFlow.SetEntrStat(sTemp);
				sTemp=string(cOffsetFlag);
			entrFlow.SetOffsetFlag(sTemp);
			entrFlow.SetEntrAmount(lEntrAmount);
			entrFlow.SetRemainAmount(lRemainAmount);
				sTemp=string(cForceOrderNo);
			entrFlow.SetForceOrderNo(sTemp);
			entrFlow.SetEntrPrice(dlEntrPrice);
			entrFlow.SetEntrDir(cDir);
			sTemp=string(cTellId);
			entrFlow.SetTellId(sTemp);
			m_vecEntrFlow.push_back(entrFlow);
		}
		
	}
	catch(otl_exception& p)
	{
		CRLog(E_ERROR, "otl exception:%s,%s,%s,%s", p.msg, p.stm_text, p.sqlstate, p.var_info);
	}

	return 0;
}
//�ж�һ���ͻ��Ƿ����ǿƽΪ�ɽ���ǿƽί�� ��1 ���ڣ�0 ������
int CEntrFlowTbl::IsExistCustID(std::string custID)
{
	CGessGuard guard(m_mutexTbl);

	int rtn=0; 
	vector<CEntrFlow >::iterator it=m_vecEntrFlow.begin();
	for (it=m_vecEntrFlow.begin(); it!=m_vecEntrFlow.end();it++)
	{
		if(custID==it->GetCustId() && ("o"==it->GetEntrStat()||"1"==it->GetEntrStat()))
		{
			rtn=1;
			break;
		}
	}
	return rtn;
}
//�ж��Ƿ���ڱ��ر�����ΪlocalOrderNo ί����ˮ 1 ���ڣ�0 ������
int CEntrFlowTbl::IsExist(string & localOrderNo)
{
	int rtn=0;
	CGessGuard guard(m_mutexTbl);
	vector<CEntrFlow >::iterator it=m_vecEntrFlow.begin();
	for (it=m_vecEntrFlow.begin(); it!=m_vecEntrFlow.end();it++)
	{
		if(localOrderNo==it->GetLocalOderNo())
		{
			rtn=1;
			break;
		}
	}
	return rtn;
}
void CEntrFlowTbl::UpdateEntrFlow(string & localOrderNo,string & sOderNo,string & sCustId,string & sProdCode,string & sEntrStat,string  sOffsetFlag,long lEntrAmount,long lRemainAmount)
{
	CGessGuard guard(m_mutexTbl);
	vector<CEntrFlow >::iterator it=m_vecEntrFlow.begin();
	for (it=m_vecEntrFlow.begin(); it!=m_vecEntrFlow.end();it++)
	{
		if(localOrderNo==it->GetLocalOderNo())
		{
			it->SetEntrStat(sEntrStat);
			it->SetOderNo(sOderNo);
			it->SetCustId(sCustId);
			it->SetProdCode(sProdCode);
			it->SetEntrStat(sEntrStat);
			it->SetOffsetFlag(sOffsetFlag);
			it->SetEntrAmount(lEntrAmount);
			it->SetRemainAmount(lRemainAmount);

			CRLog(E_DEBUG, "����ǿƽ��1��custid=%s, ForceOrderNo=%s, EntrStat=%s, ProdCode=%s,LocalOderNo=%s,OffsetFlag=%s", 
				it->GetCustId().c_str(), it->GetForceOrderNo().c_str(), it->GetEntrStat().c_str(), it->GetProdCode().c_str(), it->GetLocalOderNo().c_str(), it->GetOffsetFlag().c_str());

			break;
		}	

	}
}
void CEntrFlowTbl::UpdateEntrFlow(string & localOrderNo,string & sOderNo,string & sCustId,string & sProdCode,string & sEntrStat,long lEntrAmount,long lRemainAmount)
{
	CGessGuard guard(m_mutexTbl);
	vector<CEntrFlow >::iterator it=m_vecEntrFlow.begin();
	for (it=m_vecEntrFlow.begin(); it!=m_vecEntrFlow.end();it++)
	{
		if(localOrderNo==it->GetLocalOderNo())
		{
			it->SetEntrStat(sEntrStat);
			it->SetOderNo(sOderNo);
			it->SetCustId(sCustId);
			it->SetProdCode(sProdCode);
			it->SetEntrStat(sEntrStat);
			it->SetEntrAmount(lEntrAmount);
			it->SetRemainAmount(lRemainAmount);
			CRLog(E_DEBUG, "����ǿƽ��2��custid=%s, ForceOrderNo=%s, EntrStat=%s, ProdCode=%s,LocalOderNo=%s,OffsetFlag=%s", 
				it->GetCustId().c_str(), it->GetForceOrderNo().c_str(), it->GetEntrStat().c_str(), it->GetProdCode().c_str(), it->GetLocalOderNo().c_str(), it->GetOffsetFlag().c_str());
			break;
		}	
	}
}
//ɾ��ί����ˮ
void CEntrFlowTbl::DeleteEntrFlow(std::string &localOrderNo)
{  
	
	bool isFind=false;
	CGessGuard guard(m_mutexTbl);
	vector<CEntrFlow >::iterator it=m_vecEntrFlow.begin();
	for (it=m_vecEntrFlow.begin(); it!=m_vecEntrFlow.end();)
	{
		if(localOrderNo==it->GetLocalOderNo() )
		{
			it = m_vecEntrFlow.erase(it);
			isFind=true;
			break;
		}
		else
		{
			it++;
		}

	}

	if(!isFind)
	{
		CRLog(E_APPINFO, "δ�ҵ�ǿƽ����ί����ˮ�����ر����ţ�%s",localOrderNo.c_str()) ; 
	}
}

void CEntrFlowTbl::AddEntrFlow(std::string &sForceOrderNo,string & sEntrStat,string & sCustID,string sProdCode,string sOffsetFlag,long lEntrAmount,string dlEnterPrice,char cDir,string sTellId)
{
	CGessGuard guard(m_mutexTbl);

	CEntrFlow  entrFlow;
	entrFlow.SetForceOrderNo(sForceOrderNo);
	entrFlow.SetEntrStat(sEntrStat);
	entrFlow.SetCustId(sCustID);
	entrFlow.SetProdCode(sProdCode);
	entrFlow.SetOffsetFlag(sOffsetFlag);
	entrFlow.SetEntrAmount(lEntrAmount);
	entrFlow.SetRemainAmount(lEntrAmount);
	double m_dlEntrPrice=atof(dlEnterPrice.c_str());
	entrFlow.SetEntrPrice(m_dlEntrPrice);
	entrFlow.SetEntrDir(cDir);
	entrFlow.SetTellId(sTellId);
	CRLog(E_DEBUG, "���ӱ�����ˮ��custid=%s, ForceOrderNo=%s, EntrStat=%s, ProdCode=%s,LocalOderNo=%s,OffsetFlag=%s", 
		entrFlow.GetCustId().c_str(), entrFlow.GetForceOrderNo().c_str(), entrFlow.GetEntrStat().c_str(), entrFlow.GetProdCode().c_str(), entrFlow.GetLocalOderNo().c_str(), entrFlow.GetOffsetFlag().c_str());
	// 	CRLog(E_DEBUG, "����ǿƽ����custid=%s, ForceOrderNo=%s, EntrStat=%s, ProdCode=%s,LocalOderNo=%s,OffsetFlag=%s", 
	// 		entrFlow.GetCustId().c_str(), entrFlow.GetForceOrderNo().c_str(), entrFlow.GetEntrStat().c_str(), entrFlow.GetProdCode().c_str(), entrFlow.GetLocalOderNo().c_str(), sOffsetFlag.c_str());
	m_vecEntrFlow.push_back(entrFlow);
}
void CEntrFlowTbl::AddEntrFlow(std::string &sForceOrderNo,string & sEntrStat,string & sCustID,string sProdCode,string sOffsetFlag,long lEntrAmount,string dlEnterPrice,char cDir, string sLocalOderNo,string sTellId)
{
	CGessGuard guard(m_mutexTbl);

	CEntrFlow  entrFlow;
	entrFlow.SetForceOrderNo(sForceOrderNo);
	entrFlow.SetEntrStat(sEntrStat);
	entrFlow.SetCustId(sCustID);
	entrFlow.SetProdCode(sProdCode);
	entrFlow.SetOffsetFlag(sOffsetFlag);
	entrFlow.SetEntrAmount(lEntrAmount);
	entrFlow.SetRemainAmount(lEntrAmount);
	double m_dlEntrPrice=atof(dlEnterPrice.c_str());
	entrFlow.SetEntrPrice(m_dlEntrPrice);
	entrFlow.SetEntrDir(cDir);
	entrFlow.SetLocalOderNo(sLocalOderNo);
	entrFlow.SetTellId(sTellId);
	CRLog(E_DEBUG, "���ӱ�����ˮ��custid=%s, ForceOrderNo=%s, EntrStat=%s, ProdCode=%s,LocalOderNo=%s,OffsetFlag=%s", 
		entrFlow.GetCustId().c_str(), entrFlow.GetForceOrderNo().c_str(), entrFlow.GetEntrStat().c_str(), entrFlow.GetProdCode().c_str(), entrFlow.GetLocalOderNo().c_str(), entrFlow.GetOffsetFlag().c_str());
	// 	CRLog(E_DEBUG, "����ǿƽ����custid=%s, ForceOrderNo=%s, EntrStat=%s, ProdCode=%s,LocalOderNo=%s,OffsetFlag=%s", 
	// 		entrFlow.GetCustId().c_str(), entrFlow.GetForceOrderNo().c_str(), entrFlow.GetEntrStat().c_str(), entrFlow.GetProdCode().c_str(), entrFlow.GetLocalOderNo().c_str(), sOffsetFlag.c_str());
	m_vecEntrFlow.push_back(entrFlow);
}

void CEntrFlowTbl::UpdateEntrFlowLocalOrderNo(std::string &forceOrderNo, std::string &localOrderNo)
{
	CGessGuard guard(m_mutexTbl);

	vector<CEntrFlow >::iterator it=m_vecEntrFlow.begin();
	for (it=m_vecEntrFlow.begin(); it!=m_vecEntrFlow.end();it++)
	{
		if(forceOrderNo==it->GetForceOrderNo() )
		{
			it->SetLocalOderNo(localOrderNo);
			break;
		}	
	}
}

void CEntrFlowTbl::UpdateEntrFlow(string & localOrderNo,string & sEntrStat)
{
	CGessGuard guard(m_mutexTbl);

	vector<CEntrFlow >::iterator it=m_vecEntrFlow.begin();
	for (it=m_vecEntrFlow.begin(); it!=m_vecEntrFlow.end();it++)
	{
		if(localOrderNo==it->GetLocalOderNo())
		{
			it->SetEntrStat(sEntrStat);
			break;
		}	
	}
}

void CEntrFlowTbl::UpdateEntrFlowByOrderNo(string & orderNo,string & sEntrStat)
{
	CGessGuard guard(m_mutexTbl);

	vector<CEntrFlow >::iterator it=m_vecEntrFlow.begin();
	for (it=m_vecEntrFlow.begin(); it!=m_vecEntrFlow.end();it++)
	{
		if(orderNo==it->GetOderNo())
		{
			it->SetEntrStat(sEntrStat);
			break;
		}	
	}
}

void CEntrFlowTbl::UpdateEntrFlowByForceOrderNo(string & sForceOrderNo,string & sEntrStat)
{
	CGessGuard guard(m_mutexTbl);

	vector<CEntrFlow >::iterator it=m_vecEntrFlow.begin();
	for (it=m_vecEntrFlow.begin(); it!=m_vecEntrFlow.end();it++)
	{
		if(sForceOrderNo==it->GetForceOrderNo())
		{
			it->SetEntrStat(sEntrStat);
			break;
		}	
	}
}
int CEntrFlowTbl::GetForceEntrFlowOrder(string sCustNo,vector<CEntrFlow> & m_vecForceEntrFlowOrder)
{
	CGessGuard guard(m_mutexTbl);

	vector<CEntrFlow >::iterator it=m_vecEntrFlow.begin();
	for (it=m_vecEntrFlow.begin(); it!=m_vecEntrFlow.end();it++)
	{
		if( 0==it->GetCustId().compare(sCustNo) 
#ifdef _VER_TRUNK_ORA  // _VER_TRUNK_ORA��Ҫ�ж��Ƿ���ǿƽ��
			&& IsValidForceCovOrder(*it)
#else
			&& IsValidOrder(*it)
#endif	 
			)
		{
			m_vecForceEntrFlowOrder.push_back((*it));			
			CRLog(E_DEBUG, "�ڴ�������ǿƽ����custid=%s, ForceOrderNo=%s, EntrStat=%s, ProdCode=%s,LocalOderNo=%s,OffsetFlag=%s", 
				it->GetCustId().c_str(), it->GetForceOrderNo().c_str(), it->GetEntrStat().c_str(), it->GetProdCode().c_str(), it->GetLocalOderNo().c_str(), it->GetOffsetFlag().c_str());
		}	
	}
	return 0;
}

/*
�߶����� xrs 
�Ӻ����߼�����Ӧ��ȡ����ָ���ͻ�����ͨƽ�ֵ���Ϊ�κ����������ô��Ť��
*/
int CEntrFlowTbl::GetEntrFlowOrder(string sCustNo,vector<CEntrFlow> & m_vecEntrFlowOrder)
{
	CGessGuard guard(m_mutexTbl);

	vector<CEntrFlow>::iterator it;
	for (it = m_vecEntrFlow.begin(); it != m_vecEntrFlow.end(); ++it)
	{
		if( 0==it->GetCustId().compare(sCustNo)
			&& it->GetOffsetFlag() == gc_OffsetFlag_CovPosi
			&& IsValidOrder(*it) )
		{
			m_vecEntrFlowOrder.push_back((*it));
			CRLog(E_DEBUG, "�ڴ������пͻ�������custid=%s, ForceOrderNo=%s, EntrStat=%s, ProdCode=%s,LocalOderNo=%s,OffsetFlag=%s", 
				it->GetCustId().c_str(), it->GetForceOrderNo().c_str(), it->GetEntrStat().c_str(), it->GetProdCode().c_str(), it->GetLocalOderNo().c_str(), it->GetOffsetFlag().c_str());
		}	
	}

	return 0;
}
int CEntrFlowTbl::GetAllEntrFlowOrder(string sCustNo,vector<CEntrFlow> & m_vecEntrFlowOrder)
{
	CGessGuard guard(m_mutexTbl);

	vector<CEntrFlow>::iterator it;
	for (it = m_vecEntrFlow.begin(); it != m_vecEntrFlow.end(); ++it)
	{
		if( 0==it->GetCustId().compare(sCustNo) 
			&& it->GetOffsetFlag() != gc_OffsetFlag_OpenPosi 
			&& IsValidOrder(*it) )   //o --
		{
			m_vecEntrFlowOrder.push_back((*it));
			CRLog(E_DEBUG, "�ڴ������пͻ����б�����custid=%s, ForceOrderNo=%s, EntrStat=%s, ProdCode=%s,LocalOderNo=%s,OffsetFlag=%s", 
				it->GetCustId().c_str(), it->GetForceOrderNo().c_str(), it->GetEntrStat().c_str(), it->GetProdCode().c_str(), it->GetLocalOderNo().c_str(), it->GetOffsetFlag().c_str());
		}	
	}

	return 0;
}
int CEntrFlowTbl::IsExistForceOrder(const string &acct_no, const string &f_order_no)
{
	CGessGuard guard(m_mutexTbl);

	vector<CEntrFlow>::iterator it;
	for (it = m_vecEntrFlow.begin(); it != m_vecEntrFlow.end(); ++it)
	{
		if( it->GetCustId() == acct_no && it->GetForceOrderNo() == f_order_no)
		{
			CRLog(E_DEBUG, "ǿƽ���Ѵ����ڴ��У�custid=%s, ForceOrderNo=%s, EntrStat=%s, ProdCode=%s,LocalOderNo=%s,OffsetFlag=%s", 
				it->GetCustId().c_str(), it->GetForceOrderNo().c_str(), it->GetEntrStat().c_str(), it->GetProdCode().c_str(), it->GetLocalOderNo().c_str(), it->GetOffsetFlag().c_str());
			return 1;	
		}
	}

	return 0;
}

string CEntrFlowTbl::GetAcctnoByForceOrder(const string &f_order_no)
{
	CGessGuard guard(m_mutexTbl);
	string str="";

	vector<CEntrFlow>::iterator it;
	for (it = m_vecEntrFlow.begin(); it != m_vecEntrFlow.end(); ++it)
	{
		if (it->GetForceOrderNo() == f_order_no)
		{
			return it->GetCustId();
		}
	}

	CRLog(E_DEBUG, "ǿƽ����Ϊ%s��ǿƽ�����ڴ���ˮ���в�����", f_order_no.c_str());

	return str;
}

bool CEntrFlowTbl::IsValidForceCovOrder( const CEntrFlow& stOrder ) const
{
	if( stOrder.GetOffsetFlag() == gc_OffsetFlag_ForceCov && IsValidOrder(stOrder) )
		return true;
	else
		return false;
}

bool CEntrFlowTbl::IsValidOrder( const CEntrFlow& stOrder ) const
{
	if( stOrder.GetRemainAmount() > 0 )
	{
		string sEntrStat = stOrder.GetEntrStat();
		if( sEntrStat == gc_EntrStat_Reported 
			|| sEntrStat == gc_EntrStat_PartMatch 
		// _VER_TRUNK_ORA���������걨�ı���
#ifdef _VER_TRUNK_ORA
			|| sEntrStat == gc_EntrStat_Declaring
#endif
			 )
			return true;
	}
	
	return false;
}
