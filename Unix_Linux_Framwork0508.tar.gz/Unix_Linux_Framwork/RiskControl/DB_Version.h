#ifndef _VERSION_DB_H
#define _VERSION_DB_H
#include "VersionMacro.h"

#ifdef _VER_25_DB2
#include "otlv4_db2.h"
//win�����ݿ�lib����
#ifdef _WINDOWS
#pragma comment(lib, "../lib/db2_lib/db2cli.lib") 
#endif
#else
#include "otlv4.h"
#ifdef _WINDOWS
#pragma comment(lib, "../lib/orc_lib/oci.lib") 
#endif
#endif

#endif