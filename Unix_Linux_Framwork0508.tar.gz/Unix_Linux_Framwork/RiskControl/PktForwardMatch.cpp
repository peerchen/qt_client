#include "RiskHandler.h"

// A1 �ӿ� [onRecvRtnForwardMatch]ForwardMatch ��ҵ��ʵ��
int CRiskHandler::OnForwardMatch(CBroadcastPacket& pkt)
{
	ForwardMatch stBody;
	CPacketStructBroadcastRisk::Packet2Struct(stBody, pkt);

	//ҵ��ʵ��......
	SendAck(pkt);

	CCustomer* p = FindCustomer(stBody.acctNo);
	if (!p)
		return -1;

	std::string sKey = stBody.matchNo + stBody.orderNo;
	CMatchDetailTbl& tblMatch = m_pMemDb->GetMatchDetailTbl();
	if (tblMatch.IsHandled(sKey,stBody.acctNo))
		return -1;

	CRLog(E_APPINFO,"OnForwardMatch %s %c %s %d %f %c %f %s\n",stBody.acctNo.c_str(),stBody.buyOrSell,stBody.instID.c_str(),stBody.volume,stBody.price,stBody.rateType,stBody.marginRate,sKey.c_str());

	CustRiskInfo oCustRiskInfo;
	int nType = 0;
	m_pMemDb->GetProdCodeTbl().GetVarietyType(stBody.instID,nType);
	double dlUnit = GetMeasureUnit(stBody.instID);

	int nRtn = gc_cStateNormal;
	if (gc_nAu == nType)
	{
		CForwardAuMatch pFwdMatch = CForwardAuMatch(stBody.rateType,stBody.marginRate,stBody.instID,nType,stBody.buyOrSell,stBody.price,stBody.volume,dlUnit);
		nRtn = p->OnRtnMatchForward(pFwdMatch,oCustRiskInfo);
	}
	else if (gc_nAg == nType)
	{
		CForwardAgMatch pFwdMatch = CForwardAgMatch(stBody.rateType,stBody.marginRate,stBody.instID,nType,stBody.buyOrSell,stBody.price,stBody.volume,dlUnit);
		nRtn = p->OnRtnMatchForward(pFwdMatch,oCustRiskInfo);
	}
	else
	{
		CRLog(E_APPINFO,"Unknkown Spot Type:%d",nType);
		return -1;
	}

	
	if (nRtn == gc_cStateNormal)
	{
	}
	if (nRtn == gc_cStateValueChange)
	{
		//����� 
		m_pRiskNotify->Enque(oCustRiskInfo);
	}
	if (nRtn == gc_cStateRiskTransfer)
	{
		//����� 
		m_pRiskNotify->Enque(oCustRiskInfo);
	}

	p->UpdateAgentBalanceStat();
	p->UpdateAgentDebtStat();

	return 0;
};
