cp ./DbSync/*  ./
cp ./Main/*  ./
cp ./MainServiceHandle/* ./
cp ./MemDb/* ./
cp ./RiskHandle/* ./
cp ./RiskNotify/* ./
