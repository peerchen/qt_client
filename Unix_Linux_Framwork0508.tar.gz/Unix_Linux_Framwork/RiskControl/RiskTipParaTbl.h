#ifndef RISKTIPPARATBL_H
#define RISKTIPPARATBL_H
#include <string>
#include <map>
#include <vector>
#include "Gess.h"
using namespace std;

class otl_connect;
class CRiskTipParaTbl
{
public:
	CRiskTipParaTbl();
	~CRiskTipParaTbl();

	int GetRiskTip(unsigned short usTipType,string& sTip);

	int GetRiskTip(unsigned short usSrcGrade ,unsigned short usDesGrade, string& sTip);

	//##ModelId=491A48FC0167
	void SetRiskTip(unsigned short usTipType,const string& sTip);

	void SetRiskTip(unsigned short usSrcGrade ,unsigned short usDesGrade, string& sTip);

	//##ModelId=491A4DD2002E
	int Init(otl_connect& dbConnection);
	//��������
	void Finish();
private:
	map<unsigned short,string> m_mapTips;
	map<string, string> m_mapNotifyPara;
	CGessMutex  m_mutexTbl;
};

#endif