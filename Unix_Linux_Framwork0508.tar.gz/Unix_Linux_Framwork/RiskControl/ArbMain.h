// ArbMain.h: interface for the CArbMain class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ARBMAIN_H__D1862398_E67A_4017_AC64_51E13AE7BEF3__INCLUDED_)
#define AFX_ARBMAIN_H__D1862398_E67A_4017_AC64_51E13AE7BEF3__INCLUDED_
#include "VersionMacro.h"
#ifdef _VER_DREB
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
//#include "CommApRisk.h"
#include "ArbResource.h"
#include "DrebMsgThread.h"
#include "BF_DrebServer.h"


class  CArbMain  : public CConnectPointAsyn
{
public:
	void Monitor();
	void Stop();
	int Start();
	bool Init(const char *confile);
	int Init(CConfig* pConfig);
	CArbMain();
	virtual ~CArbMain();
	int OnRecvPacket(CPacket &GessPacket);
	int SendPacket(CPacket &GessPacket);
	void Bind(CConnectPointManager* pCpMgr,const unsigned long& ulKey);
	void Finish(){}

	void SetSvrTxList(vector<int> v);
	//��ȡ������Ľ������б�
	vector<int> GetSvrTxList();
	//����������ڴ�ָ��
	void AddReqMsgStru(const string& sSeqNo, PBPCCOMMSTRU pMsg);

	CArbResource     m_pRes;   //����
	CBF_DrebServer   m_pDrebApi;//api
	CIErrlog         *m_pLog;
private:
	PBPCCOMMSTRU GetReqMsg(const char* szSeqNo);
private:
	CDrebMsgThread   m_pDrebMsgThread;//��Ϣ�߳�
	bool              m_bIsInit;
	CConnectPointManager*     m_pRiskCpMgr;
	unsigned long	m_ulKey;
	vector<int> m_vTxList;
	map<string, PBPCCOMMSTRU> m_mapReqMsg;
	CBF_Mutex m_bfMutex;
};
#endif
#endif // !defined(AFX_ARBMAIN_H__D1862398_E67A_4017_AC64_51E13AE7BEF3__INCLUDED_)
