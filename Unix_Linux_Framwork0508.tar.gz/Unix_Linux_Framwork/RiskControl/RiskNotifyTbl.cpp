#include "RiskNotifyTbl.h"

CRiskNotifyTbl::CRiskNotifyTbl()
{

}

CRiskNotifyTbl::~CRiskNotifyTbl()
{
	Finish();
}

//##ModelId=491BA01E006D
int CRiskNotifyTbl::GetRecordSet(vector<RISK_NOTIFY>& vecNtf)
{
	CGessGuard guard(m_mutexTbl);
	for(vector<RISK_NOTIFY>::iterator iter = m_vecRiskNotify.begin(); iter != m_vecRiskNotify.end(); ++iter){
		vecNtf.push_back(*iter);
	}
	return 0;
}

//##ModelId=491BA05C03A9
void CRiskNotifyTbl::InsertRec(RISK_NOTIFY& stRiskNotify)
{
	CGessGuard guard(m_mutexTbl);
	m_vecRiskNotify.push_back(stRiskNotify);
}

int CRiskNotifyTbl::GetAgentRecordSet(const string& sAgentID,vector<RISK_NOTIFY>& vecRec)
{
	CGessGuard guard(m_mutexTbl);
	for(vector<RISK_NOTIFY>::iterator iter = m_vecRiskNotify.begin(); iter != m_vecRiskNotify.end(); ++iter){
		if((iter->m_sBranchId).compare(sAgentID)==0){
			vecRec.push_back(*iter);
		}
	}
	if(vecRec.size()>0)
		return 0;
	return -1;
}

int CRiskNotifyTbl::GetCustRecordSet(const string& sCustID,vector<RISK_NOTIFY>& vecRec)
{
	CGessGuard guard(m_mutexTbl);
	for(vector<RISK_NOTIFY>::iterator iter = m_vecRiskNotify.begin(); iter != m_vecRiskNotify.end(); ++iter){
		if((iter->m_sCustomerId)==sCustID){
			vecRec.push_back(*iter);
		}
	}
	if(vecRec.size()>0)
		return 0;
	return -1;
}

//��������
void CRiskNotifyTbl::Finish()
{
	CGessGuard guard(m_mutexTbl);
	m_vecRiskNotify.clear();
}