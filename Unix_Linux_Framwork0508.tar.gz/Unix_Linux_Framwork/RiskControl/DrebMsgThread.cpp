// DrebMsgThread.cpp: implementation of the CDrebMsgThread class.
//
//////////////////////////////////////////////////////////////////////

#include "DrebMsgThread.h"
#ifdef _VER_DREB
#include "ArbResource.h"
#include "ArbMain.h"
#include "BroadcastPacket.h"
#include "TradePacket.h"
#include "PacketStructTransferTradeRisk.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDrebMsgThread::CDrebMsgThread()
{
	m_pLog = NULL;
	m_pOwner = NULL;
	m_nSvrHostStatus = 1001;
}

CDrebMsgThread::~CDrebMsgThread()
{

}
bool CDrebMsgThread::Init(CBF_DrebServer   *bus,CBF_DrebResource *res)
{
	m_pDrebApi = bus;
	m_pRes = res;
	m_pLog = m_pDrebApi->GetLogPoint();

	m_pTime.Init(100,true);
	m_pTime.SetTimer(0,((CArbResource *)m_pRes)->m_nArbReportTime*1000,&CDrebMsgThread::OnTimer,this);
	m_pTime.SetTimer(1,5000,&CDrebMsgThread::OnTimer,this);
	m_pTime.SetTimer(2,5000,&CDrebMsgThread::OnTimer,this);
	
#ifdef _XDP_ARB
	char errmsg[200];
	bzero(errmsg,sizeof(errmsg));
	if (!m_pXdp.InitXdp(((CArbResource *)m_pRes)->m_sXdpDefineXml.c_str(),errmsg))
	{
		m_pLog->LogMp(LOG_ERROR,__FILE__,__LINE__,"XDP���ĳ�ʼ������ %s",errmsg);
		return false;
	}
	if (!m_pSendXdp.XdpCopy(&m_pXdp))
	{
		m_pLog->LogMp(LOG_ERROR,__FILE__,__LINE__,"XDP���ĳ�ʼ��XdpCopy���� %s",errmsg);
		return false;
	}
#endif
	return true;
}
int CDrebMsgThread::OnTimer(unsigned int event, void *p)
{
	CDrebMsgThread *pp = (CDrebMsgThread *)p;
#ifdef _XDP_ARB
	if (event == 0)
	{
		//��������״̬���ٲ�
		pp->Send2Arb();
	}
	else if (event == 2)
	{
		pp->PrintHostStatus();
	}
	else if (event == 1)
	{
		pp->SendQueryHostStatus();
	}
#endif
	return 0;
}
int CDrebMsgThread::Run()
{
	while (m_bIsRunning)
	{
		if (m_pDrebApi->GetMsgData(m_rMsgData) && 0 != m_rMsgData.sMsgBuf)
		{
			ProcessDrebData(m_rMsgData);
		}
	}
	return 0;
}


// ������: OnMsgConnectBack
// ���  : ������ 2015-4-23 15:55:29
// ����  : virtual void 
// ����  : S_BPC_RSMSG &rcvdata
// ����  : �����������߳ɹ�����Ӧ
void CDrebMsgThread::OnMsgConnectBack(S_BPC_RSMSG &rcvdata)
{
	//����ע���
	m_pDrebApi->GetLogPoint()->LogMp(LOG_DEBUG,__FILE__,__LINE__,"�յ�DREB���ӳɹ�����Ӧ");
#ifdef _XDP_ARB
	//�����ѯ���������ٲõ�״̬������״̬��ע��
	char errmsg[4096];
	bzero(errmsg,sizeof(errmsg));

	m_pXdp.ResetData();
	if (!m_pXdp.SetFieldValue("uint3",m_pRes->g_nSvrMainId,errmsg))
	{
		m_pLog->LogMp(LOG_ERROR,__FILE__,__LINE__,"xdp��������״̬���� %s",errmsg);
		m_pDrebApi->PoolFree(rcvdata.sMsgBuf);
		rcvdata.sMsgBuf = NULL;
		return;
	}
	if (!m_pXdp.SetFieldValue("uint4",(unsigned int)(m_pRes->g_nSvrPrivateId),errmsg))
	{
		m_pLog->LogMp(LOG_ERROR,__FILE__,__LINE__,"xdp���÷�������� %s",errmsg);
		m_pDrebApi->PoolFree(rcvdata.sMsgBuf);
		rcvdata.sMsgBuf = NULL;
		return;
	}
	if (m_pLog->isWrite(LOG_DEBUG+1))
	{
		m_pXdp.PrintXdp(errmsg);
		m_pLog->LogMp(LOG_DEBUG,__FILE__,__LINE__,"Ӧ�ò�ѯ����״̬���� %s",errmsg);
	}
	unsigned int datalen = BPUDATASIZE;
	if (!m_pXdp.ToBuffer(rcvdata.sMsgBuf->sBuffer,datalen,errmsg))
	{
		m_pLog->LogMp(LOG_ERROR,__FILE__,__LINE__,"xdp ToBuffer���� %s",errmsg);
		m_pDrebApi->PoolFree(rcvdata.sMsgBuf);
		rcvdata.sMsgBuf = NULL;
		return;
	}

	rcvdata.sMsgBuf->sDBHead.nLen = datalen;
	
	rcvdata.sMsgBuf->sDBHead.a_Ainfo.a_nRetCode = SUCCESS;
	rcvdata.sMsgBuf->sDBHead.cRaflag = 0;
	rcvdata.sMsgBuf->sDBHead.cCmd = CMD_DPCALL;
	rcvdata.sMsgBuf->sDBHead.cZip = 0;
	rcvdata.sMsgBuf->sDBHead.d_Dinfo.d_nServiceNo = APP_QUERY_HOST;
	m_bIsQueryAns = false;//��ѯӦ��Ϊfalse����һֱΪfalseʱҪ���·����ѯ����ֹ�ٲ����⵼�·���������
	m_pDrebApi->SendMsg(rcvdata);
#endif
	printf("�������߳ɹ� \n");
	RegisterDreb(0);
}

// ������: OnMsgDrebAns
// ���  : ������ 2015-4-23 15:55:58
// ����  : virtual void 
// ����  : S_BPC_RSMSG &rcvdata
// ����  : ��Ӧ���߹�����Ӧ������
void CDrebMsgThread::OnMsgDrebAns(S_BPC_RSMSG &rcvdata)
{
	//Ӧ������
	m_pDrebApi->GetLogPoint()->LogMp(LOG_DEBUG,__FILE__,__LINE__,"�յ�DREB��Ӧ����Ӧ");
	switch (rcvdata.sMsgBuf->sDBHead.d_Dinfo.d_nServiceNo)
	{
	case APP_QUERY_HOST:
		{
			if (rcvdata.sMsgBuf->sDBHead.a_Ainfo.a_nRetCode!=SUCCESS)
			{
				m_pDrebApi->GetLogPoint()->LogMp(LOG_DEBUG,__FILE__,__LINE__, "�ٲ�δ����");
			}
#ifdef _XDP_ARB
			else if (rcvdata.sMsgBuf->sDBHead.d_Dinfo.d_nServiceNo == APP_QUERY_HOST)
			{
				OnQueryArbAns(rcvdata);
			}
#endif				
		}
		break;
	case 4043:
	case 4044:
	case 4061:
	case 3052:
	case 3056:
		{
			CRLog(E_PROINFO, "��������������Ӧ����:d_nServiceNo=%d", rcvdata.sMsgBuf->sDBHead.d_Dinfo.d_nServiceNo);
			OnSvrRequest(rcvdata);
		}
		break;
	}

	m_pDrebApi->PoolFree(rcvdata.sMsgBuf);
	rcvdata.sMsgBuf = NULL;
}

// ������: OnMsgRequest
// ���  : ������ 2015-4-23 15:54:38
// ����  : virtual void 
// ����  : S_BPC_RSMSG &rcvdata
// ����  : �������߹�������������
void CDrebMsgThread::OnMsgRequest(S_BPC_RSMSG &rcvdata)
{
	if (rcvdata.sMsgBuf->sDBHead.cRaflag !=0) //��Ϊ����
	{
		m_pDrebApi->GetLogPoint()->LogMp(LOG_ERROR,__FILE__,__LINE__,"�޴˹��� ��Ϣ[%s]  DREB����[%s] ����[%d] RA��־[%d] ������[%d]  ��ʶ[%d %d %d] Դ[%d %d] cZip[%d] ҵ�����ݳ���[%d]",\
			GetBpcMsgType(rcvdata.sMsgBuf->sBpcHead.cMsgType).c_str(),\
			GetDrebCmdType(rcvdata.sMsgBuf->sDBHead.cCmd).c_str(),rcvdata.sMsgBuf->sDBHead.cNextFlag,\
			rcvdata.sMsgBuf->sDBHead.cRaflag,rcvdata.sMsgBuf->sDBHead.d_Dinfo.d_nServiceNo,rcvdata.sMsgBuf->sDBHead.s_Sinfo.s_nNodeId,\
			rcvdata.sMsgBuf->sDBHead.s_Sinfo.s_cNodePrivateId,rcvdata.sMsgBuf->sDBHead.s_Sinfo.s_nDrebSerial,\
			rcvdata.sMsgBuf->sDBHead.s_Sinfo.s_nSerial,rcvdata.sMsgBuf->sDBHead.s_Sinfo.s_nHook,\
			rcvdata.sMsgBuf->sDBHead.cZip,rcvdata.sMsgBuf->sDBHead.nLen);
		m_pDrebApi->PoolFree(rcvdata.sMsgBuf);
		rcvdata.sMsgBuf = NULL;
		return;
	}
	int nRet = 0;
	switch (rcvdata.sMsgBuf->sDBHead.d_Dinfo.d_nServiceNo)
	{
#ifdef _XDP_ARB
		case  ARB_SEND_CONTROL:
			nRet = OnArbControl(rcvdata);//ָ������
			break;
		case  ARB_SEND_QUERY://��ѯ״̬
			nRet = OnArbQuery(rcvdata);
			break;
#endif
		default:
			//�����������������
			{
				nRet = -1;//��������ҵ����� lqh 2016-11-17
				if (rcvdata.sMsgBuf->sDBHead.s_Sinfo.s_nSvrMainId != m_pRes->g_nSvrMainId)//�������Զ˷�ط������Ĺ㲥 
				{
					m_pDrebApi->GetLogPoint()->LogMp(LOG_DEBUG,__FILE__,__LINE__, "�����������ݣ�%s",rcvdata.sMsgBuf->sBuffer);
					CRLog(E_PROINFO, "���������㲥����:d_nServiceNo=%d", rcvdata.sMsgBuf->sDBHead.d_Dinfo.d_nServiceNo);

					if (CMD_DPBC == rcvdata.sMsgBuf->sDBHead.cCmd || CMD_DPABC == rcvdata.sMsgBuf->sDBHead.cCmd)
					{
						OnRecvBroardcast(rcvdata);
					}
					else 
						OnSvrRequest(rcvdata);
				}
			}

			break;
	}

	if (-1 == nRet) //rcvdataû�������߷���ȥ������Ҫ�ͷ��ڴ� 
	{
		m_pDrebApi->PoolFree(rcvdata.sMsgBuf);
		rcvdata.sMsgBuf = NULL;
	}

	return;
}
// ������: Start
// ���  : ������ 2015-4-23 15:52:29
// ����  : virtual bool 
// ����  : ���������߳�
bool CDrebMsgThread::Start()
{
	if (NULL == m_pDrebApi || NULL == m_pRes)
	{
		return false;
	}
	if (m_pTime.IsStoped())
	{
		m_pTime.Start();
	}
	m_bIsRunning = true;
	CreateThread();
	return true;
}

// ������: Stop
// ���  : ������ 2015-4-23 15:52:43
// ����  : virtual void 
// ����  : ֹͣ�����߳�
void CDrebMsgThread::Stop()
{
	if (!m_pTime.IsStoped())
	{
		m_pTime.Stop();
	}
	m_bIsRunning = false;
	Join();
}
#ifdef _XDP_ARB
void CDrebMsgThread::Send2Arb()
{
	CArbResource *arbconf = (CArbResource *)m_pRes;
	if (arbconf->m_nSvrHostStatus == ARBSTATUS_UNKNOW)
	{
		//δ֪״̬����ȥ����
		return;
	}
	S_BPC_RSMSG data;
	data.sMsgBuf = (PBPCCOMMSTRU)m_pDrebApi->PoolMalloc();
	if (data.sMsgBuf == NULL)
	{
		m_pLog->LogMp(LOG_ERROR,__FILE__,__LINE__,"��������״̬֪ͨʧ��[%d %d] PoolMalloc error",m_pRes->g_nSvrMainId,m_pRes->g_nSvrPrivateId);
		return;
	}
	char errmsg[250];
	bzero(errmsg,sizeof(errmsg));
	bzero(data.sMsgBuf,sizeof(BPCCOMMSTRU));
	data.sMsgBuf->sBpcHead.nIndex = 100;
	data.sMsgBuf->sDBHead.cCmd = CMD_DPPUSH;
	data.sMsgBuf->sDBHead.d_Dinfo.d_nServiceNo = APP_PUSH_STATUS;
	data.sMsgBuf->sDBHead.d_Dinfo.d_nSvrMainId = 0;
	data.sMsgBuf->sDBHead.d_Dinfo.d_cSvrPrivateId = 0;
	
	if (!m_pSendXdp.SetFieldValue("uint3",m_pRes->g_nSvrMainId,errmsg))
	{
		m_pLog->LogMp(LOG_ERROR,__FILE__,__LINE__,"XDP SetFieldValue uint3 error: %s",errmsg);
		m_pDrebApi->PoolFree(data.sMsgBuf);
		return;
	}
	if (!m_pSendXdp.SetFieldValue("uint4",(unsigned int)m_pRes->g_nSvrPrivateId,errmsg))
	{
		m_pLog->LogMp(LOG_ERROR,__FILE__,__LINE__,"XDP SetFieldValue uint4 error: %s",errmsg);
		m_pDrebApi->PoolFree(data.sMsgBuf);
		return;
	}
	if (!m_pSendXdp.SetFieldValue("uint9",((CArbResource *)m_pRes)->m_nSvrHostStatus,errmsg))
	{
		m_pLog->LogMp(LOG_ERROR,__FILE__,__LINE__,"XDP SetFieldValue uint9 error: %s",errmsg);
		m_pDrebApi->PoolFree(data.sMsgBuf);
		return;
	}
	unsigned int len = BPUDATASIZE;
	if (!m_pSendXdp.ToBuffer(data.sMsgBuf->sBuffer,len,errmsg))
	{
		m_pLog->LogMp(LOG_ERROR,__FILE__,__LINE__,"XDP ToBuffer error: %s",errmsg);
		m_pDrebApi->PoolFree(data.sMsgBuf);
		return;
	}
	data.sMsgBuf->sDBHead.nLen = len;
	m_pDrebApi->SendMsg(data); //�����ٲ�֪ͨ
}

void CDrebMsgThread::OnQueryArbAns(S_BPC_RSMSG &rcvdata)
{
	//��ѯ����״̬�ı���
	char errmsg[4096];
	bzero(errmsg,sizeof(errmsg));
	CRLog(E_PROINFO,"OnQueryArbAns %s", rcvdata.sMsgBuf->sBuffer);
	if (!m_pXdp.FromBuffer(rcvdata.sMsgBuf->sBuffer,rcvdata.sMsgBuf->sDBHead.nLen,errmsg))
	{
		m_pLog->LogMp(LOG_ERROR,__FILE__,__LINE__,"arb���صı��Ĳ�������XDP���� %s",errmsg);
		return;
	}
	if (m_pLog->isWrite(LOG_DEBUG+1))
	{
		m_pXdp.PrintXdp(errmsg);
		m_pLog->LogMp(LOG_DEBUG,__FILE__,__LINE__,"arb����Ӧ�ò�ѯ���� %s",errmsg);
	}
	unsigned int status=0;
	unsigned int retcode=0;

	if (!m_pXdp.GetFieldValue("uint9",status,errmsg))
	{
		m_pLog->LogMp(LOG_ERROR,__FILE__,__LINE__,"arb����Ӧ�ò�ѯ���Ĳ�������uint9�ֶ� %s",errmsg);
		return;
	}
	if (!m_pXdp.GetFieldValue("uint10",retcode,errmsg))
	{
		m_pLog->LogMp(LOG_ERROR,__FILE__,__LINE__,"arb����Ӧ�ò�ѯ���Ĳ�������uint10�ֶ� %s",errmsg);
		return;
	}	
	if (retcode != SUCCESS)
	{
		m_pLog->LogMp(LOG_ERROR,__FILE__,__LINE__,"arb����Ӧ�ò�ѯ �ķ�����[%d]Ϊ���ɹ�",retcode);
		return;
	}
	m_pLog->LogMp(LOG_DEBUG,__FILE__,__LINE__,"arb����Ӧ�ò�ѯ ��Ӧ��״̬[%d]",status);
	if (status == ARBSTATUS_MASTER || status == ARBSTATUS_MASTER_AYN )
	{
		//Ϊ����
		OnChangeHostStatus(status);
	}
	else if (status == ARBSTATUS_BACKUP || status == ARBSTATUS_BACKUP_AYN)
	{
		OnChangeHostStatus(status);
	}
	else
	{
		m_pLog->LogMp(LOG_ERROR,__FILE__,__LINE__,"arb����Ӧ�ò�ѯ ��Ӧ��״̬[%d]����",status);
	}

	m_bIsQueryAns = true;
	return;
	
}

void CDrebMsgThread::OnChangeHostStatus(unsigned int status)
{
	CArbResource *arbconf = (CArbResource *)m_pRes;
	if (status == ARBSTATUS_MASTER || status == ARBSTATUS_MASTER_AYN )
	{
		if (m_pOwner)
		{
			CBroadcastPacket GessPacket("HostStatus");
			GessPacket.AddParameter("IsMaster", 1);
			m_pOwner->OnRecvPacket(GessPacket);
		}

		//Ϊ����
		if (arbconf->m_nSvrHostStatus != ARBSTATUS_MASTER && arbconf->m_nSvrHostStatus != ARBSTATUS_MASTER_AYN)
		{
			//תΪ����
			arbconf->m_nSvrHostStatus = ARBSTATUS_MASTER;
			m_pLog->LogMp(LOG_PROMPT,__FILE__,__LINE__,"������Ϊ����");
			printf("������Ϊ����");
			//ע�ύ��
			for (size_t i=0; i< m_pRes->g_vDrebLinkInfo.size(); i++)
			{
				m_pDrebApi->RegisterDreb(i,&((CArbResource *)m_pRes)->g_lSvrTxList);
				//LogSvrTxList(((CArbResource*)m_pRes)->g_lSvrTxList);
			}
		}
	}
	else if (status == ARBSTATUS_BACKUP || status == ARBSTATUS_BACKUP_AYN)
	{
		if (m_pOwner)
		{
			CBroadcastPacket GessPacket("HostStatus");
			GessPacket.AddParameter("IsMaster", 0);
			m_pOwner->OnRecvPacket(GessPacket);
		}
		if (arbconf->m_nSvrHostStatus != ARBSTATUS_BACKUP && arbconf->m_nSvrHostStatus != ARBSTATUS_BACKUP_AYN)
		{
			//תΪ����
			arbconf->m_nSvrHostStatus = ARBSTATUS_BACKUP;
			m_pLog->LogMp(LOG_PROMPT,__FILE__,__LINE__,"������Ϊ����");
		}
	}
}

int CDrebMsgThread::OnArbControl(S_BPC_RSMSG &rcvdata)
{
	char errmsg[4096];
	bzero(errmsg,sizeof(errmsg));
	if (!m_pXdp.FromBuffer(rcvdata.sMsgBuf->sBuffer,rcvdata.sMsgBuf->sDBHead.nLen,errmsg))
	{
		m_pLog->LogMp(LOG_ERROR,__FILE__,__LINE__,"�ٲ�ָ�����Ĳ�������XDP���� %s",errmsg);
		return -1;
	}
	if (m_pLog->isWrite(LOG_DEBUG+1))
	{
		m_pXdp.PrintXdp(errmsg);
		m_pLog->LogMp(LOG_DEBUG,__FILE__,__LINE__,"�ٲ�ָ������ %s",errmsg);
	}
	unsigned int id=0;
	unsigned int pid=0;
	unsigned int status=0;
	
	if (!m_pXdp.GetFieldValue("uint3",id,errmsg))
	{
		m_pLog->LogMp(LOG_ERROR,__FILE__,__LINE__,"�ٲ�ָ�����Ĳ��� ��uint3�ֶ� %s",errmsg);
		return -1;
	}
	
	if (!m_pXdp.GetFieldValue("uint4",pid,errmsg))
	{
		m_pLog->LogMp(LOG_ERROR,__FILE__,__LINE__,"�ٲ�ָ�����Ĳ��� ��uint4�ֶ� %s",errmsg);
		return -1;
	}
	
	if (!m_pXdp.GetFieldValue("uint9",status,errmsg))
	{
		m_pLog->LogMp(LOG_ERROR,__FILE__,__LINE__,"�ٲ�ָ�����Ĳ��� ��uint9�ֶ� %s",errmsg);
		return -1;
	}
	if (id != m_pRes->g_nSvrMainId || pid != m_pRes->g_nSvrPrivateId)
	{
		m_pLog->LogMp(LOG_ERROR,__FILE__,__LINE__,"�ٲ�ָ�����Ĳ��� ����[%d %d] ���Ǳ�����",id,pid);
		return -1;
	}
	m_pLog->LogMp(LOG_PROMPT,__FILE__,__LINE__,"����ָ����״̬Ϊ[%d]",status);
	//�ı�״̬
	OnChangeHostStatus(status);
	CArbResource *arbconf = (CArbResource *)m_pRes;
	if (!m_pXdp.SetFieldValue("uint9",arbconf->m_nSvrHostStatus,errmsg))
	{
		m_pLog->LogMp(LOG_ERROR,__FILE__,__LINE__,"XDP  SetFieldValue ����");
		return -1;
	}
	if (!m_pXdp.SetFieldValue("uint10",(unsigned int)SUCCESS,errmsg))
	{
		m_pLog->LogMp(LOG_ERROR,__FILE__,__LINE__,"XDP  SetFieldValue ����");
		return -1;
	}
	if (m_pLog->isWrite(LOG_DEBUG+1))
	{
		m_pXdp.PrintXdp(errmsg);
		m_pLog->LogMp(LOG_DEBUG,__FILE__,__LINE__,"�ٲ�ָ������Ӧ���� %s",errmsg);
	}
	unsigned int datalen = BPUDATASIZE;
	if (!m_pXdp.ToBuffer(rcvdata.sMsgBuf->sBuffer,datalen,errmsg))
	{
		m_pLog->LogMp(LOG_ERROR,__FILE__,__LINE__,"xdp ToBuffer���� %s",errmsg);
		return -1;
	}
	rcvdata.sMsgBuf->sDBHead.nLen = datalen;
	
	rcvdata.sMsgBuf->sDBHead.a_Ainfo.a_nRetCode = SUCCESS;
	rcvdata.sMsgBuf->sDBHead.cRaflag = 1;
	rcvdata.sMsgBuf->sDBHead.cZip = 0;
	m_pDrebApi->SendMsg(rcvdata);
	
	return 0;
}

int CDrebMsgThread::OnArbQuery(S_BPC_RSMSG &rcvdata)
{
	char errmsg[4096];
	bzero(errmsg,sizeof(errmsg));
	if (!m_pXdp.FromBuffer(rcvdata.sMsgBuf->sBuffer,rcvdata.sMsgBuf->sDBHead.nLen,errmsg))
	{
		m_pLog->LogMp(LOG_ERROR,__FILE__,__LINE__,"�ٲò�ѯ���Ĳ�������XDP���� %s",errmsg);
		return -1;
	}
	if (m_pLog->isWrite(LOG_DEBUG+1))
	{
		m_pXdp.PrintXdp(errmsg);
		m_pLog->LogMp(LOG_DEBUG,__FILE__,__LINE__,"�ٲò�ѯ���� %s",errmsg);
	}
	unsigned int id=0;
	unsigned int pid=0;
	
	if (!m_pXdp.GetFieldValue("uint3",id,errmsg))
	{
		m_pLog->LogMp(LOG_ERROR,__FILE__,__LINE__,"�ٲò�ѯ���Ĳ��� ��uint3�ֶ� %s",errmsg);
		return -1;
	}
	
	if (!m_pXdp.GetFieldValue("uint4",pid,errmsg))
	{
		m_pLog->LogMp(LOG_ERROR,__FILE__,__LINE__,"�ٲò�ѯ���Ĳ��� ��uint4�ֶ� %s",errmsg);
		return -1;
	}
	
	
	if (id != m_pRes->g_nSvrMainId || pid != m_pRes->g_nSvrPrivateId)
	{
		m_pLog->LogMp(LOG_ERROR,__FILE__,__LINE__,"�ٲò�ѯ���Ĳ��� ����[%d %d] ���Ǳ�����",id,pid);
		return -1;
	}
	
	CArbResource *arbconf = (CArbResource *)m_pRes;
	if (!m_pXdp.SetFieldValue("uint9",arbconf->m_nSvrHostStatus,errmsg))
	{
		m_pLog->LogMp(LOG_ERROR,__FILE__,__LINE__,"XDP  SetFieldValue ����");
		return -1;
	}
	if (!m_pXdp.SetFieldValue("uint10",(unsigned int)SUCCESS,errmsg))
	{
		m_pLog->LogMp(LOG_ERROR,__FILE__,__LINE__,"XDP  SetFieldValue ����");
		return -1;
	}
	if (m_pLog->isWrite(LOG_DEBUG+1))
	{
		m_pXdp.PrintXdp(errmsg);
		m_pLog->LogMp(LOG_DEBUG,__FILE__,__LINE__,"�ٲò�ѯӦ���� %s",errmsg);
	}
	unsigned int datalen = BPUDATASIZE;
	if (!m_pXdp.ToBuffer(rcvdata.sMsgBuf->sBuffer,datalen,errmsg))
	{
		m_pLog->LogMp(LOG_ERROR,__FILE__,__LINE__,"xdp ToBuffer���� %s",errmsg);
		return -1;
	}
	rcvdata.sMsgBuf->sDBHead.nLen = datalen;
	
	rcvdata.sMsgBuf->sDBHead.a_Ainfo.a_nRetCode = SUCCESS;
	rcvdata.sMsgBuf->sDBHead.cRaflag = 1;
	rcvdata.sMsgBuf->sDBHead.cZip = 0;
	m_pDrebApi->SendMsg(rcvdata);	
	return 0;
}

void CDrebMsgThread::PrintHostStatus()
{
	static int nPrint = 0;
	unsigned int nSvrHostStatus = ((CArbResource *)m_pRes)->m_nSvrHostStatus;
	if (nSvrHostStatus == m_nSvrHostStatus && ++nPrint%17 != 0)
	{
		return;
	}
	else
		m_nSvrHostStatus = nSvrHostStatus;
	switch (m_nSvrHostStatus)
	{
		case ARBSTATUS_UNKNOW:
			CRLog(E_DEBUG,"������״̬Ϊ [δ֪]\n");

			break;
		case ARBSTATUS_MASTER:
			CRLog(E_DEBUG,"������״̬Ϊ [����]\n");
			break;
		case ARBSTATUS_MASTER_AYN:
			CRLog(E_DEBUG,"������״̬Ϊ [����ͬ��]\n");
			break;
		case ARBSTATUS_BACKUP:
			CRLog(E_DEBUG,"������״̬Ϊ [����]\n");
			break;
		case ARBSTATUS_BACKUP_AYN:
			CRLog(E_DEBUG,"������״̬Ϊ [����ͬ��]\n");
			break;
		default: 
			CRLog(E_DEBUG,"������״̬Ϊ����״̬ %d\n",((CArbResource *)m_pRes)->m_nSvrHostStatus);
			break;

	}
	
}

void CDrebMsgThread::SendQueryHostStatus()
{
	if (!m_bIsQueryAns)
	{
		S_BPC_RSMSG rcvdata;
		rcvdata.sMsgBuf = (PBPCCOMMSTRU) m_pDrebApi->PoolMalloc();
		if (rcvdata.sMsgBuf== NULL)
		{
			m_pLog->LogMp(LOG_ERROR,__FILE__,__LINE__,"PoolMalloc���� ");
			return;
		}
		//�����ѯ���������ٲõ�״̬������״̬��ע��
		char errmsg[4096];
		bzero(errmsg,sizeof(errmsg));
		m_pSendXdp.ResetData();
		if (!m_pSendXdp.SetFieldValue("uint3",m_pRes->g_nSvrMainId,errmsg))
		{
			m_pLog->LogMp(LOG_ERROR,__FILE__,__LINE__,"xdp��������״̬���� %s",errmsg);
			m_pDrebApi->PoolFree(rcvdata.sMsgBuf);
			rcvdata.sMsgBuf = NULL;
			return;
		}
		if (!m_pSendXdp.SetFieldValue("uint4",(unsigned int)(m_pRes->g_nSvrPrivateId),errmsg))
		{
			m_pLog->LogMp(LOG_ERROR,__FILE__,__LINE__,"xdp���÷�������� %s",errmsg);
			m_pDrebApi->PoolFree(rcvdata.sMsgBuf);
			rcvdata.sMsgBuf = NULL;
			return;
		}
		if (m_pLog->isWrite(LOG_DEBUG+1))
		{
			m_pSendXdp.PrintXdp(errmsg);
			m_pLog->LogMp(LOG_DEBUG,__FILE__,__LINE__,"Ӧ�ò�ѯ����״̬���� %s",errmsg);
		}
		unsigned int datalen = BPUDATASIZE;
		if (!m_pSendXdp.ToBuffer(rcvdata.sMsgBuf->sBuffer,datalen,errmsg))
		{
			m_pLog->LogMp(LOG_ERROR,__FILE__,__LINE__,"xdp ToBuffer���� %s",errmsg);
			m_pDrebApi->PoolFree(rcvdata.sMsgBuf);
			rcvdata.sMsgBuf = NULL;
			return;
		}
		rcvdata.sMsgBuf->sDBHead.nLen = datalen;
		
		rcvdata.sMsgBuf->sDBHead.a_Ainfo.a_nRetCode = SUCCESS;
		rcvdata.sMsgBuf->sDBHead.cRaflag = 0;
		rcvdata.sMsgBuf->sDBHead.cCmd = CMD_DPCALL;
		rcvdata.sMsgBuf->sDBHead.cZip = 0;
		rcvdata.sMsgBuf->sDBHead.d_Dinfo.d_nServiceNo = APP_QUERY_HOST;
		m_bIsQueryAns = false;//��ѯӦ��Ϊfalse����һֱΪfalseʱҪ���·����ѯ����ֹ�ٲ����⵼�·���������
		m_pDrebApi->SendMsg(rcvdata);

	}
}
#endif
void CDrebMsgThread::SetOwner( CArbMain* pOwner )
{
	m_pOwner = pOwner;
}

void CDrebMsgThread::RegisterDreb(unsigned int index)
{
	//printf("RegisterDreb %s %d m_pOwner->GetSvrTxList() ����%d \n", __FILE__,__LINE__, m_pOwner->GetSvrTxList().size());
	if (m_pOwner)
	{
		//LogSvrTxList(m_pOwner->GetSvrTxList());

		//ע�ύ��
		for (size_t i=0; i< m_pRes->g_vDrebLinkInfo.size(); i++)
		{
			m_pDrebApi->RegisterDreb(i, &m_pOwner->GetSvrTxList());
		}
	}
}

void CDrebMsgThread::LogSvrTxList( vector<int> v )
{
	string sCodes,sCode;
	//printf("LogSvrTxList size %d \n", v.size());
	for (size_t i = 0; i < v.size(); i++)
	{
		char buf[10] = {0};
		sprintf(buf, "%d,", v[i]);
		//printf("LogSvrTxList %d %s \n", i, buf);
		//CRLog(E_DEBUG, "LogSvrTxList %d %s", i, buf);
		sCode = buf;
		sCodes += sCode;
	}
	m_pLog->LogMp(LOG_PROMPT,__FILE__,__LINE__,"ע�ύ������:%s ", sCodes.c_str());
	//printf("ע�ύ������ %s\n", sCodes.c_str());
}
//���߹���������
int CDrebMsgThread::OnSvrRequest(S_BPC_RSMSG &rcvdata)
{
	CRLog(E_DEBUG, "OnSvrRequest");
	if (m_pOwner && rcvdata.sMsgBuf->sDBHead.nLen > 0)
	{
		CRLog(E_PROINFO, "�������߱���:%s, nLen=%d", rcvdata.sMsgBuf->sBuffer, rcvdata.sMsgBuf->sDBHead.nLen);
		string sOrg;
		sOrg.assign(rcvdata.sMsgBuf->sBuffer, rcvdata.sMsgBuf->sDBHead.nLen);

		if (0 == OnRecvTradePacket(sOrg))
		{
			if (0 == rcvdata.sMsgBuf->sDBHead.cRaflag)
			{
				string sSeqNo = sOrg.substr(0, SEQNO);
				//sSeqNo.assign(rcvdata.sMsgBuf->sBuffer, SEQNO);
				m_msgHead.Insert(sSeqNo.c_str(), *(rcvdata.sMsgBuf));
			}
		}
		else
		{
			CRLog(E_DEBUG,"��Ч����: nLen=%d", rcvdata.sMsgBuf->sDBHead.nLen);
		} 

		return 0;
	}

	return -1;
}

int CDrebMsgThread::OnRecvTradePacket( const string sPkt )
{
	CRLog(E_DEBUG, "OnRecvTradePacket");
	CTradePacket GessPacket;
	//CRLog(E_PROINFO,"OnSvrRequest Decode %s",sOrg.c_str());
	char buf[9] = {0};
	int nPktLen = sPkt.length();
	sprintf(buf, "%08d", nPktLen);
	string sNew = buf ;
	sNew += sPkt;
	//CRLog(E_DEBUG, "sNew=%s len=%d  \n", sNew.c_str(), nPktLen+8);
	GessPacket.Decode(sNew.c_str(), nPktLen+8);
	string sCmd = GessPacket.GetCmdID();
	CRLog(E_PROINFO,"OnSvrRequest cmd=%s drebbuf=%s ", sCmd.c_str(), sNew.c_str() );
	if (sCmd.length() > 3)
	{
		//printf("OnRecvPacket %s \n", sCmd.c_str());
		m_pOwner->OnRecvPacket(GessPacket);
		return 0;
	}
	return -1;
}
int CDrebMsgThread::OnRecvBroardcast( S_BPC_RSMSG &rcvdata )
{
	CRLog(E_DEBUG, "OnRecvBroardcast");
	if (m_pOwner)
	{
		string sOrg;
		sOrg.assign(rcvdata.sMsgBuf->sBuffer, rcvdata.sMsgBuf->sDBHead.nLen);

		CBroadcastPacket GessPacket;
		GessPacket.Decode(rcvdata.sMsgBuf->sBuffer, rcvdata.sMsgBuf->sDBHead.nLen);

		string sCmdApiName = GessPacket.GetCmdID();
		if (sCmdApiName.length() < 4)
		{
			CRLog(E_PROINFO,"���ܵ���Ч�㲥 %s",	sCmdApiName.c_str());
			return -1;
		}

		if (sCmdApiName.find("Quotation") == string::npos && 
			sCmdApiName.find("InstStateUpdate") == string::npos)
		{
			CRLog(E_PROINFO,"OnRecvBroardcast %s",	sOrg.c_str());
		}
		else
		{
			// ��ȡϵͳ��ǰ����ʱ��,1���Ӵ�һ��������־,
			time_t tmNow;
			time(&tmNow);
			struct tm stTime;
			localtime_r(&tmNow,&stTime);
			static int nHour = stTime.tm_hour;
			static int nMin = stTime.tm_min;
			if (nHour != stTime.tm_hour || nMin != stTime.tm_min)
			{
				nHour = stTime.tm_hour;
				nMin = stTime.tm_min;
				CRLog(E_PROINFO,"OnRecvBroardcast %s",	sCmdApiName.c_str());
			}
		}

		m_pOwner->OnRecvPacket(GessPacket);

		return 0;
	}
	return -1;
}


int CDrebMsgThread::SendPacket( CPacket &GessPacket )
{
	CRLog(E_DEBUG, "SendPacket");
	string sCmd = GessPacket.GetCmdID();
	int nRet = -1;
	if (4 == sCmd.length())//�����붼��4λ
	{
		try 
		{
			CTradePacket& tradeRsp = dynamic_cast<CTradePacket&>(GessPacket);
			if (HEAD_REQ == tradeRsp.PktType())
			{
				nRet = SendTradePacketReq(tradeRsp);
			}
			else
			{
				nRet = SendTradePacketRsp(tradeRsp);//����rsp����
			}
		}
		catch(std::bad_cast)
		{
			CRLog(E_ERROR,"%s","packet error!");
			return -1;
		}
		catch(std::exception e)
		{
			CRLog(E_ERROR,"exception:%s!",e.what());
			return -1;
		}
		catch(...)
		{
			CRLog(E_ERROR,"%s","Unknown exception!");
			return -1;
		}
	}
	else//���ķ����Ʊ���
	{
		nRet = SendBroadcastPacket(GessPacket);
	}
	return nRet;
}

int CDrebMsgThread::SendTradePacketRsp( CTradePacket& tradeRsp )
{
	CRLog(E_DEBUG, "SendTradePacketRsp");
	S_BPC_RSMSG snddata;
	snddata.sMsgBuf = (PBPCCOMMSTRU)m_pDrebApi->PoolMalloc();
	if (snddata.sMsgBuf == NULL)
	{
		m_pLog->LogMp(LOG_ERROR,__FILE__,__LINE__,"PoolMalloc error",m_pRes->g_nSvrMainId,m_pRes->g_nSvrPrivateId);
		return -1;
	}

	bzero(snddata.sMsgBuf,sizeof(BPCCOMMSTRU));
	unsigned int nLen = 0;
	string sOrg = tradeRsp.Encode(nLen);
	sOrg = sOrg.substr(8, sOrg.length() - 8);
	HEADER_RSP stHeaderRsp;
	tradeRsp.GetHeader(stHeaderRsp);
	//CRLog(E_DEBUG,"ready to SendTradePacketRsp sSeqNo=%s ", sOrg.c_str());
	int nSend = -1;
	if (m_msgHead.GetHead(stHeaderRsp.seq_no, *(snddata.sMsgBuf)))
	{
		snddata.sMsgBuf->sDBHead.a_Ainfo.a_nRetCode = SUCCESS;
		snddata.sMsgBuf->sDBHead.cRaflag = 1;
		snddata.sMsgBuf->sDBHead.cZip = 0;
		DealSubscribeRsp(tradeRsp, snddata.sMsgBuf->sDBHead.s_Sinfo);
		nSend = Send2Dreb(snddata, sOrg);
	}
	else
	{
		CRLog(E_PROINFO,"SendTradePacketRsp %sδ�ҵ�����ͷ", stHeaderRsp.seq_no);
	}

	if (0 != nSend)
	{
		m_pDrebApi->PoolFree(snddata.sMsgBuf);
		snddata.sMsgBuf = NULL;
	}

	return nSend;
}
int CDrebMsgThread::SendTradePacketReq( CTradePacket& tradeRsp )
{
	CRLog(E_DEBUG, "SendTradePacketReq");
	S_BPC_RSMSG data;
	data.sMsgBuf = (PBPCCOMMSTRU)m_pDrebApi->PoolMalloc();
	if (data.sMsgBuf == NULL)
	{
		m_pLog->LogMp(LOG_ERROR,__FILE__,__LINE__,"PoolMalloc error",m_pRes->g_nSvrMainId,m_pRes->g_nSvrPrivateId);
		return -1;
	}

	bzero(data.sMsgBuf,sizeof(BPCCOMMSTRU));
	data.sMsgBuf->sDBHead.cRaflag = 0;
	data.sMsgBuf->sDBHead.cCmd = CMD_DPCALL;
	data.sMsgBuf->sDBHead.a_Ainfo.a_nRetCode = SUCCESS;
	data.sMsgBuf->sDBHead.d_Dinfo.d_nServiceNo = FromString<int>(tradeRsp.GetCmdID());
	//ȥ��ǰ��λ����
	unsigned int nLen = 0;
	string sOrg = tradeRsp.Encode(nLen);
	string sNew = sOrg.substr(8, sOrg.length() - 8);
	return Send2Dreb(data, sNew);
}

int CDrebMsgThread::SendBroadcastPacket( CPacket& pktRsp )
{
	CRLog(E_DEBUG, "SendBroadcastPacket");
	try
	{
		CBroadcastPacket& tradeRsp = dynamic_cast<CBroadcastPacket&>(pktRsp);
		S_BPC_RSMSG data;
		data.sMsgBuf = (PBPCCOMMSTRU)m_pDrebApi->PoolMalloc();
		if (data.sMsgBuf == NULL)
		{
			m_pLog->LogMp(LOG_ERROR,__FILE__,__LINE__,"PoolMalloc error",m_pRes->g_nSvrMainId,m_pRes->g_nSvrPrivateId);
			return -1;
		}

		bzero(data.sMsgBuf,sizeof(BPCCOMMSTRU));
		SetBrcDrebHead(tradeRsp, data.sMsgBuf->sDBHead);
		
		unsigned int nLen = 0;
		string sOrg = tradeRsp.Encode(nLen);

		//CRLog(E_PROINFO,"Ready to SendBroadcastPacket %s", sNew.c_str());
		return Send2Dreb(data, sOrg);
	}
	catch(std::bad_cast)
	{
		CRLog(E_ERROR,"%s","packet error!");
		return -1;
	}
	catch(std::exception e)
	{
		CRLog(E_ERROR,"exception:%s!",e.what());
		return -1;
	}
	catch(...)
	{
		CRLog(E_ERROR,"%s","Unknown exception!");
		return -1;
	}

	return -2;
}

int CDrebMsgThread::Send2Dreb( S_BPC_RSMSG &data, const string& sOrg )
{
	CRLog(E_DEBUG, "Send2Dreb");
	data.sMsgBuf->sDBHead.nLen = sOrg.length();

	if (data.sMsgBuf->sDBHead.nLen > 0 && data.sMsgBuf->sDBHead.nLen < BPUDATASIZE)
	{
		memcpy(data.sMsgBuf->sBuffer, sOrg.c_str(), data.sMsgBuf->sDBHead.nLen);
		CRLog(E_PROINFO,"SendOut %s", data.sMsgBuf->sBuffer);
		m_pDrebApi->SendMsg(data);
		return 0;
	}
	return -1;
}

int CDrebMsgThread::DealSubscribeRsp( CTradePacket& pktRsp, DREB_S_NODEINFO s_Sinfo )
{
	CRLog(E_DEBUG, "DealSubscribeRsp");
	if ("3061" == pktRsp.GetCmdID()) // ���տͻ�����
	{
		// ��ȡ���Ľṹ
		SubscriberRsp stBodyRsp;
		CPacketStructTradeRisk::Packet2Struct(stBodyRsp, pktRsp);

		// ��ȡ����ԱID
		string sTeller_id;
		pktRsp.GetParameterVal("teller_id", sTeller_id);
		if (sTeller_id.empty())
		{
			return -2;
		}

		// �������ĺ�ȡ������
		m_bfMutexSubscribe.Lock();
		CRLog(E_DEBUG,"1 add 2 remove sTeller_id=%s oper_flag=%d", sTeller_id.c_str(), stBodyRsp.oper_flag);
		if (1 == stBodyRsp.oper_flag)//����
		{
			m_mapSubscriberNodeInfo[sTeller_id] = s_Sinfo;
		} 
		else if (2 == stBodyRsp.oper_flag)//ȡ������
		{
			map<string, DREB_S_NODEINFO>::iterator it = m_mapSubscriberNodeInfo.find(sTeller_id);
			if (it != m_mapSubscriberNodeInfo.end())
			{
				m_mapSubscriberNodeInfo.erase(it);
			}
		}
		else
		{
			CRLog(E_ERROR,"%s","Unknown 3061 oper_flag!");
		}
		m_bfMutexSubscribe.UnLock();

		return 0;
	}
	return -1;
}

int CDrebMsgThread::SetBrcDrebHead( CBroadcastPacket& pktRsp, DREB_HEAD& sDBHead )
{
	CRLog(E_DEBUG, "SetBrcDrebHead");
	if ("onBranchRiskStat" == pktRsp.GetCmdID())
	{
		string sTellerId;
		pktRsp.GetParameterVal("TellerIDs", sTellerId);

		map<string, DREB_S_NODEINFO>::iterator it = m_mapSubscriberNodeInfo.find(sTellerId);
		if (it != m_mapSubscriberNodeInfo.end())
		{
			sDBHead.cCmd = CMD_DPPUSH;
			sDBHead.s_Sinfo.s_nNodeId = it->second.s_nNodeId;
			sDBHead.s_Sinfo.s_nSvrMainId = it->second.s_nSvrMainId;
			sDBHead.s_Sinfo.s_nHook = it->second.s_nHook;
			sDBHead.s_Sinfo.s_nSerial = it->second.s_nSerial;
			CRLog(E_DEBUG,"%s ","onBranchRiskStat point to point !");
		}
		else
		{
			CRLog(E_ERROR,"onBranchRiskStat not find sTellerId  %s", sTellerId.c_str());
			return -1;
		}
	}
	else
	{
		sDBHead.cCmd = CMD_DPBC;
	}
	sDBHead.a_Ainfo.a_nRetCode = SUCCESS;
	return 0;
}

#endif