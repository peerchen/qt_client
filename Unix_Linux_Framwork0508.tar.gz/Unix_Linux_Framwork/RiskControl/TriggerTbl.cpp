#include "TriggerTbl.h"
#include "ProdCodeTbl.h"

CTriggerTbl::CTriggerTbl()
{

}

CTriggerTbl::~CTriggerTbl()
{
	Finish();
}

//##ModelId=4913F5B20290
int CTriggerTbl::GetTriggerPrice(int nIndex,double& dlPrice)
{
	int nRtn = -1;
	vector<TRIGGER_PRICE>::iterator iter;
	CGessGuard guard(m_mutexTbl);
	for(iter = vecTrigger.begin(); iter != vecTrigger.end(); ++iter)
	{
		if((*iter).nIndex == nIndex)
		{
			dlPrice = (*iter).dlTriggerPrice;
			nRtn = 0;
			break;
		}
	}
	return nRtn;
	
}

//##ModelId=4913F5D4036B
int CTriggerTbl::GetTriggerPrice(const string& sProdID,double& dlPrice)
{
	int nRtn = -1;
	vector<TRIGGER_PRICE>::iterator iter;
	CGessGuard guard(m_mutexTbl);
	for(iter = vecTrigger.begin(); iter != vecTrigger.end(); ++iter)
	{
		if((*iter).sProdCode == sProdID)
		{
			dlPrice = (*iter).dlTriggerPrice;
			nRtn = 0;
			break;
		}
	}
	return nRtn;
}

//##ModelId=4913F61D00DA
int CTriggerTbl::SetTriggerPrice(int nIndex,double dlPrice)
{
	int nRtn = -1;
	vector<TRIGGER_PRICE>::iterator iter;
	CGessGuard guard(m_mutexTbl);
	for(iter = vecTrigger.begin(); iter != vecTrigger.end(); ++iter)
	{
		if((*iter).nIndex == nIndex)
		{
			(*iter).dlTriggerPrice = dlPrice;
			nRtn = 0;
			break;
		}
	}
	return nRtn;
}

//##ModelId=4913F63901A5
int CTriggerTbl::SetTriggerPrice(string sProdID,double dlPrice)
{
	int nRtn = -1;
	vector<TRIGGER_PRICE>::iterator iter;
	CGessGuard guard(m_mutexTbl);
	for(iter = vecTrigger.begin(); iter != vecTrigger.end(); ++iter)
	{
		if((*iter).sProdCode == sProdID)
		{
			(*iter).dlTriggerPrice = dlPrice;
			nRtn = 0;
			break;
		}
	}
	return nRtn;
}

//##ModelId=491529F900EA
int CTriggerTbl::GetPriceArray(vector <double> & dlPrice)
{
	int i = 0;
	CGessGuard guard(m_mutexTbl);
	dlPrice.clear();
	for(vector<TRIGGER_PRICE>::iterator iter = vecTrigger.begin(); iter != vecTrigger.end(); ++iter){
		//dlPrice[i] = iter->dlTriggerPrice;

		dlPrice.push_back(iter->dlTriggerPrice);
		/*i++;

		if (i >= nSize)
			break;*/
	}
	return 0;
}

//##ModelId=4916CF61037A
int CTriggerTbl::Init(CProdCodeTbl& ProdCodeTbl)
{
	TRIGGER_PRICE stTriggerPrice;		//�����ʽṹ

	vector<TRIGGER_PRICE> t_vecTrigger;

	map<string,PROD_CODE> mapProd;
	map<string,PROD_CODE>::iterator it;
	ProdCodeTbl.GetRecordSet(mapProd);
	
	CGessGuard guard(m_mutexTbl);

	for (it = mapProd.begin(); it != mapProd.end(); ++it)
	{
		stTriggerPrice.sProdCode = it->second.sProdCode;
		stTriggerPrice.nIndex = ProdCodeTbl.Index(stTriggerPrice.sProdCode);
		stTriggerPrice.dlTriggerPrice = 0.0;

	
		t_vecTrigger.push_back(stTriggerPrice);
		
	}
	//nIndex ���Դ�0��ʼ
	//��m_vecQuoation����Ʒ��������

	//�˴��ر�˵������ɾ������Ҫ�ǰ��� ��Լ������ ���򣬱�֤������ȡ����ʱҲ�ǰ���Լ����

	vector<TRIGGER_PRICE>::iterator itVec;
	for(int i=0;i<(int)t_vecTrigger.size();i++)
	{
		for(itVec=t_vecTrigger.begin();itVec!=t_vecTrigger.end();++itVec)
		{
			if(itVec->nIndex == i)
			{				
				vecTrigger.push_back(*itVec);
				break;
			}
		}
	}

	return 0;
}

//��������
void CTriggerTbl::Finish()
{
	CGessGuard guard(m_mutexTbl);
	vecTrigger.clear();
}