#ifndef CFORCECLOSEPARATBL_H_HEADER_INCLUDED_SMSFORMAT
#define CFORCECLOSEPARATBL_H_HEADER_INCLUDED_SMSFORMAT


#include <string>
#include <map>
#include <vector>
//#include "Customer.h"
#include "Gess.h"
#include "DB_Version.h" 

using namespace std;

class otl_connect;
//class CustRiskInfo;
class CSmsFormatTbl
{

public:
	CSmsFormatTbl();
	~CSmsFormatTbl();

	//���������ݿ��ʼ��
	int Init(otl_connect& dbConnection);
	void Finish();
	int ReInit(otl_connect& dbConnection);

	int GetSmsFormatMap(std::string sAcct_Type,std::string sRisk_Type,std::string &sSmsFormat)  const;
	
	////���ݿͻ������Ϣ��ȡ���Ÿ�ʽ
	//int GetSmsCotent(CustRiskInfo CustRinfo,std::string & content) const;

private:

	map<std::string,std::string> m_SmsFormatMap;   //���Ÿ�ʽMapkey rist_type+acct_type
	
	mutable CGessMutex  m_mutexTbl;
};

#endif
