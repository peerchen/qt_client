#include "MainServiceHandler.h"

// F1 �ӿ� [3301]�Զ�ǿƽ��������������������



int CMainServiceHandler::OnAutoForceExecptConditionReq(CTradePacket& pkt)
{
    HEADER_REQ stHeaderReq;
	AutoForceExecptConditionReq stBodyReq;

	HEADER_RSP stHeaderRsp;
	AutoForceExecptConditionRsp stBodyRsp;
	CTradePacket pktRsp;
	pkt.GetHeader(stHeaderReq);
	CPacketStructTradeRisk::Packet2Struct(stBodyReq, pkt);
    //ҵ��ʵ��......

	CPacketStructTradeRisk::HeadReq2Rsp(stHeaderReq,stHeaderRsp);

    string sSql = "";
	char cExceptType[3];				//��������
	char cTypeValue[20];				 //����ֵ
	char cExceptDateTime[25];		    //��������ʱ��
    ArrayListMsg msg;


	memset(cExceptType, 0, sizeof(cExceptType));
	memset(cTypeValue, 0, sizeof(cTypeValue));
	memset(cExceptDateTime, 0, sizeof(cExceptDateTime));


   
   stBodyRsp.oper_flag = stBodyReq.oper_flag;
   try
	{
		//���Ĵ���	0����ѯ		1������	  2���޸�		3��ɾ��
		if (stBodyReq.oper_flag == 0)//��ѯ
		{
			
			if(stBodyReq.type_value.size() == 0 )// ����ֵΪ��
			{
#ifdef _VER_25_DB2
				sSql="select FG_CovToChar(EXCEPT_TYPE),TYPE_VALUE ,EXCEPT_DATE_TIME from AUTO_FORCE_EXCEPT_COND_PARA where EXCEPT_TYPE=:f1<int>";
#else
				sSql="select to_char(EXCEPT_TYPE),TYPE_VALUE ,EXCEPT_DATE_TIME from AUTO_FORCE_EXCEPT_COND_PARA where EXCEPT_TYPE=:f1<int>";
#endif
			 
			 otl_stream o(1, sSql.c_str(), GetOtlConn());
			 o<<atoi(stBodyReq.obj_type.c_str());

			   while (!o.eof())
			  {
				o>>cExceptType>>cTypeValue>>cExceptDateTime;
				msg.clear();
				msg.AddValue(cExceptType);
				msg.AddValue(cTypeValue);
				msg.AddValue(cExceptDateTime);
				stBodyRsp.value_list.AddValue(msg);
			  }
			
			}
			else 
			{
#ifdef _VER_25_DB2
				sSql="select FG_CovToChar(EXCEPT_TYPE),TYPE_VALUE ,EXCEPT_DATE_TIME from AUTO_FORCE_EXCEPT_COND_PARA where EXCEPT_TYPE=:f1<int> and TYPE_VALUE=:f2<char[20]>";
#else
				sSql="select to_char(EXCEPT_TYPE),TYPE_VALUE ,EXCEPT_DATE_TIME from AUTO_FORCE_EXCEPT_COND_PARA where EXCEPT_TYPE=:f1<int> and TYPE_VALUE=:f2<char[20]>";
#endif
			 
			 otl_stream o(1, sSql.c_str(), GetOtlConn());
			 o<<atoi(stBodyReq.obj_type.c_str())<<stBodyReq.type_value.GetValue<string>(0).c_str();
			   
			  while (!o.eof())
			  {
				o>>cExceptType>>cTypeValue>>cExceptDateTime;
				msg.clear();
				msg.AddValue(cExceptType);
				msg.AddValue(cTypeValue);
				msg.AddValue(cExceptDateTime);
				stBodyRsp.value_list.AddValue(msg);
			  }
			 
			}
		}
		
		else if (stBodyReq.oper_flag == 2||stBodyReq.oper_flag == 1)//�޸ĺ�����
		{
			
             sSql="select * from AUTO_FORCE_EXCEPT_COND_PARA where EXCEPT_TYPE=:f1<int> and TYPE_VALUE=:f2<char[20]>";
             otl_stream o(1, sSql.c_str(), GetOtlConn());
			 for(size_t i=0; i<stBodyReq.type_value.size(); i++)
			 {
				 o<<atoi(stBodyReq.obj_type.c_str())<<stBodyReq.type_value.GetValue<string>(i).c_str();
			 
			    if (!o.eof())
				{
					sSql="update AUTO_FORCE_EXCEPT_COND_PARA set EXCEPT_DATE_TIME=:f1<char[25]>  where EXCEPT_TYPE=:f2<int> and TYPE_VALUE= :f3<char[20]>";
					otl_stream update(1, sSql.c_str(), GetOtlConn());
					update<<stBodyReq.except_date_time.c_str()<<atoi(stBodyReq.obj_type.c_str())<<stBodyReq.type_value.GetValue<string>(i).c_str();
					m_OtlConn.commit();
				}
				else
				{
					sSql="insert into AUTO_FORCE_EXCEPT_COND_PARA values(:f1<int> ,:f2<char[20]>,:f3<char[25]>)";
					otl_stream insert(1, sSql.c_str(), GetOtlConn());
					insert<<atoi(stBodyReq.obj_type.c_str())<<stBodyReq.type_value.GetValue<string>(i).c_str()<<stBodyReq.except_date_time.c_str();
					m_OtlConn.commit();
				}
			 } 


		}
		else if (stBodyReq.oper_flag == 3)//ɾȥ
		{
			
		  
		    string sDelete="(";
		    for(size_t i=0; i<stBodyReq.type_value.size(); i++)
			{
				 sDelete+="'";
				 sDelete+=stBodyReq.type_value.GetValue<string>(i);
				 sDelete+="'";
				 if(i!=stBodyReq.type_value.size()-1)
					sDelete+=",";
			}   
           sDelete+=")";

		   sSql="delete from AUTO_FORCE_EXCEPT_COND_PARA where EXCEPT_TYPE=:f1<int> and TYPE_VALUE IN "+sDelete; 
		   otl_stream deleteone(1, sSql.c_str(), GetOtlConn()); 
		   deleteone<<atoi(stBodyReq.obj_type.c_str());	   
		   m_OtlConn.commit(); 

		}

	}
	catch(otl_exception& p)
	{
		CRLog(E_ERROR, "DB:MSG:%s\nTEXT:%s\nVARINFO:%s", p.msg, p.stm_text, p.var_info); 
		Rollback();
		strcpy(stHeaderRsp.rsp_code, RSP_EXCEPTION.c_str());
		pktRsp.AddParameter("rsp_msg", (const char *)p.msg);
		
	}

	//������Ӧ����
	
	pktRsp.SetHeader(stHeaderRsp);
	CPacketStructTradeRisk::Struct2Packet(stBodyRsp,pktRsp);

	//ת������
	m_pRiskCpMgr->ToInterfaceF1(pktRsp,m_ulKey);
	
	// �����ڴ��
	if (stBodyReq.oper_flag != 0)
    m_pMemDb->ReLoadAutoForceExecptCndTbl();
	return 0;

}



