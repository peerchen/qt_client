#include "RiskMain.h"
#include "BF_DesEncrypt.h"
#include "Global.h"
#include "RiskConstant.h"
using namespace RiskConst;


CRiskMain::CRiskMain(void)
{
}

CRiskMain::~CRiskMain(void)
{
}

int CRiskMain::Run( int argc, char* argv[] )
{
	try
	{
		if (argc == 3 ) //����Ƿ�Ϊstop������֮ǰ�����
		{
			CGlobal::PassWord(argc, argv);
			return 0;
		}


#ifdef WIN32
		char szFileName[_MAX_PATH], szFilePath[_MAX_PATH];
		char * pcName;
		::GetModuleFileName(0,szFileName, _MAX_PATH);
		::GetFullPathName(szFileName, _MAX_PATH, szFilePath, &pcName);
		char szBuf[_MAX_PATH];
		strcpy(szBuf, pcName);
		*pcName = '\0';
		SetCurrentDirectory(szFilePath);

		//winsock��ʼ��
		WSADATA wsaData;
		int nRtn = WSAStartup(MAKEWORD(2,2), &wsaData);
		if (nRtn != NO_ERROR)
		{
			CRLog(E_ERROR,"%s", "Error at WSAStartup()");
			return -1;
		}
#else
		signal(SIGPIPE, SIG_IGN);
		signal(SIGHUP, SIG_IGN);
		signal(SIGINT, SIG_IGN);
		//	signal(SIGTERM, sig_term);
		signal(SIGUSR1, SIG_IGN);
		signal(SIGUSR2, SIG_IGN);
		signal(SIGALRM, SIG_IGN);

		signal(SIGCHLD,SIG_IGN);
#endif

		if (0 == theMgr.Init())
		{
			if (0 == theMgr.Start())
			{
				theMgr.StartMe();
				theMgr.Run();
				// 				theMgr.StopMe();
				// 				theMgr.Stop();
				// 				theMgr.Finish();
			}
			else
			{
				theMgr.Stop();
				theMgr.Finish();
			}

			//�˳�ʱδ���߳�ͬ������sleep
			msleep(2);
		}
#ifdef WIN32
		WSACleanup();
#endif
		return 0;

	}
	catch(std::exception e)
	{
		CRLog(E_CRITICAL,"exception:%s", e.what());
		return -1;
	}
	catch(...)
	{
		CRLog(E_CRITICAL,"%s","Unknown exception");
		return -1;
	}
}
