#ifndef _RISKCPMGR_H
#define _RISKCPMGR_H

#include "NetLogDev.h"
#include <bitset>
#include <deque>
#include <iostream>
#include <signal.h>
#include "WorkThreadNm.h"
#include "Gess.h"
#include "BroadcastPacket.h"
#include "IpcPacket.h"
#include "Logger.h"
#include "PacketStructTransferBroadcastRisk.h"
#include "PacketStructTransferIpcNm.h"
using namespace std;
using namespace nmagent;

//���ӵ�key����
typedef enum tagEnumKey
{
	EnumKeyIfA1,             
	EnumKeyIfA2,             
	EnumKeyIfF1,             
	EnumKeyIfF2,
	EnumKeyIfH1,             
	EnumKeyIfH2, 
	EnumKeyIfK,
	EnumNetMagModule,
	EnumKeyRiskHandler,     
	EnumKeyRiskNotify,
	EnumKeyDbSync,     
	EnumKeyMainService,
	EnumKeyIfCmd,
	EnumKeyCmdHandler,
	EnumKeySelfBroadcast,
	EnumKeySelfIpc,
	EnumKeySmsService,
	EnumKeyDREB,
	EnumKeyUnknown
} EnumKeyIf;

//�������ӵ���������
const string gc_sCfgIfA1 = "IFA1";             
const string gc_sCfgIfA2 = "IFA2";
const string gc_sCfgIfSmscService="IFSMS";
const string gc_sCfgIfF1 = "IFF1";                 
const string gc_sCfgIfF2 = "IFF2";
const string gc_sCfgIfK = "IFK";
const string gc_sCfgIfH1 = "IFH1";
const string gc_sCfgIfH2 = "IFH2";
const string gc_sCfgIfCmd = "IFCMD";
const string gc_sCfgRiskHandler = "riskhandler";         
const string gc_sCfgRiskNotify = "risknotify";         
const string gc_sCfgDbSync = "dbsync";            
const string gc_sCfgMainService = "mainservice";
const string gc_sCfgMemDb = "memdb";
const string gc_sCfgNetMagModule = "NetMagModule";
const string gc_sCfgSMS = "SMS";

//ȱʡ������ƥ��
const string gc_sDefaultCmdID = "#";

class CGessTimerMgr;
class CNetMgrModule;
class CMemDb;
class CMainServiceHandler;
class CRiskHandler;
class CDbSync;
class CRiskNotify;
class CConfigImpl;
class CArbMain;
class CRiskCpMgr:public CProtocolCpMgr
{
private:
	//�첽�˳��߳�
	class CAsynQuitThread :public CWorkThread
	{
	public:
		CAsynQuitThread():m_pParent(0){}
		virtual ~CAsynQuitThread(){}
		void Bind(CRiskCpMgr* p){m_pParent = p;}
	private:
		int ThreadEntry()
		{
			try
			{
				if (0 != m_pParent)
				{
					m_pParent->StopMe();
					m_pParent->Stop();
					m_pParent->Finish();
					m_pParent->ReadyToQuit();
				}
				CRLog(E_SYSINFO,"%s","CAsynQuitThread exit!");
				return 0;
			}
			catch(std::exception e)
			{
				CRLog(E_ERROR,"exception:%s!",e.what());
				return -1;
			}
			catch(...)
			{
				CRLog(E_ERROR,"%s","Unknown exception!");
				return -1;
			}
		}
		int End()
		{
			return 0;
		}
	private:
		CRiskCpMgr* m_pParent;
	};

	//�����д����߳�
	class CCommandLineThread :public CWorkThreadNm
	{
	public:
		CCommandLineThread():m_pParent(0){}
		virtual ~CCommandLineThread(){}
		void Bind(CRiskCpMgr* p){m_pParent = p;}
	private:
		int ThreadEntry()
		{
			try
			{
				string sIn("");	
				cout << "RiskMgr->";
				while(!m_bEndThread)
				{
					if (0 != m_pParent)
						m_pParent->HandleCmdLine(sIn);
					else
						msleep(2);
				}

				CRLog(E_SYSINFO,"%s","RiskCpMgr_CmdThread exit!");
				return 0;
			}
			catch(std::exception e)
			{
				CRLog(E_ERROR,"exception:%s!",e.what());
				return -1;
			}
			catch(...)
			{
				CRLog(E_ERROR,"%s","Unknown exception!");
				return -1;
			}
		}
		int End()
		{
			return 0;
		}
		//�������߳�״̬�Ƿ���Ҫ������
		bool IsNetManaged(string& sKeyName)
		{
			sKeyName = "����������߳�";
			return true;
		}
	private:
		CRiskCpMgr* m_pParent;
	};

	//telnet�����߳�
	class CIpcThread :public CWorkThreadNm
	{
	public:
		CIpcThread():m_pParent(0){}
		virtual ~CIpcThread(){}
		void Bind(CRiskCpMgr* p){m_pParent = p;}
	private:
		int ThreadEntry()
		{
			return m_pParent->Run();
		}
		int End()
		{
			return 0;
		}
		//�������߳�״̬�Ƿ���Ҫ������
		bool IsNetManaged(string& sKeyName)
		{
			sKeyName = "���Telnet�߳�";
			return true;
		}
	private:
		CRiskCpMgr* m_pParent;
	};

	//�㲥�౨�Ĵ����߳�
	class CBroadcastPktThread :public CWorkThreadNm
	{
	public:
		CBroadcastPktThread():m_pParent(0){}
		virtual ~CBroadcastPktThread(){}
		void Bind(CRiskCpMgr* p){m_pParent = p;}
		int Enque(CBroadcastPacket& pkt)
		{
			m_deqCondMutex.Lock();
			m_deqPacket.push_back(pkt);	
			m_deqCondMutex.Unlock();
			m_deqCondMutex.Signal();
			return 0;
		}
	private:
		int ThreadEntry()
		{
			try
			{
				while(!m_bEndThread)
				{
					m_deqCondMutex.Lock();
					while(m_deqPacket.empty()&& !m_bEndThread)
						m_deqCondMutex.Wait();
					
					if (m_bEndThread)
					{
						m_deqPacket.clear();
						m_deqCondMutex.Unlock();
						break;
					}

					if ( !m_deqPacket.empty())
					{
						CBroadcastPacket pkt = m_deqPacket.front();
						m_deqPacket.pop_front();
						m_deqCondMutex.Unlock();

						if (0 != m_pParent)
							m_pParent->RunBroadcastPacketHandleApi(pkt);
					}
				}

				CRLog(E_SYSINFO,"%s","RiskCpMgr_BroadcastThread exit!");
				return 0;
			}
			catch(std::exception e)
			{
				CRLog(E_ERROR,"exception:%s!",e.what());
				return -1;
			}
			catch(...)
			{
				CRLog(E_ERROR,"%s","Unknown exception!");
				return -1;
			}
		}
		int End()
		{
			m_deqCondMutex.Lock();
			m_deqCondMutex.Signal();
			m_deqCondMutex.Unlock();
			Wait();
			return 0;
		}
		//�������߳�״̬�Ƿ���Ҫ������
		bool IsNetManaged(string& sKeyName)
		{
			sKeyName = "��ع㲥�߳�";
			return true;
		}
	private:
		CRiskCpMgr* m_pParent;
		//A1�ӿ�ϵͳ��㲥����
		std::deque<CBroadcastPacket> m_deqPacket;
		CCondMutex	m_deqCondMutex;
	};

	//������־����Ϣ�����߳�
	class CNetLogThread :public CWorkThreadNm
	{
	public:
		CNetLogThread():m_pParent(0){}
		virtual ~CNetLogThread(){}
		void Bind(CRiskCpMgr* p){m_pParent = p;}
		int Enque(const string& sMsg)
		{
			m_deqCondMutex.Lock();
			m_deqLog.push_back(sMsg);
			m_deqCondMutex.Unlock();
			m_deqCondMutex.Signal();
			return 0;
		}
	private:
		int ThreadEntry()
		{
			try
			{
				while(!m_bEndThread)
				{
					m_deqCondMutex.Lock();
					while(m_deqLog.empty() && !m_bEndThread)
						m_deqCondMutex.Wait();
					
					if (m_bEndThread)
					{
						m_deqLog.clear();
						m_deqCondMutex.Unlock();
						break;
					}

					if ( !m_deqLog.empty())
					{
						string sMsg = m_deqLog.front();
						m_deqLog.pop_front();
						m_deqCondMutex.Unlock();
						
						if (0 != m_pParent)
							m_pParent->HandleNetLogMsg(sMsg);
					}
				}

				CRLog(E_SYSINFO,"%s","RiskCpMgr_NetLog Thread exit!");
				return 0;
			}
			catch(std::exception e)
			{
				CRLog(E_ERROR,"exception:%s!",e.what());
				return -1;
			}
			catch(...)
			{
				CRLog(E_ERROR,"%s","Unknown exception!");
				return -1;
			}
		}
		int End()
		{
			m_deqCondMutex.Lock();
			m_deqCondMutex.Signal();
			m_deqCondMutex.Unlock();
			Wait();
			return 0;
		}
		//�������߳�״̬�Ƿ���Ҫ������
		bool IsNetManaged(string& sKeyName)
		{
			sKeyName = "�����־�߳�";
			return true;
		}
	private:
		CRiskCpMgr* m_pParent;
		//��־��Ϣ����
		std::deque<string> m_deqLog;
		CCondMutex	m_deqCondMutex;
	};

	//��������IPC�౨�Ĵ��������ӵ�
	class CConnectPointSelfIpc: public CConnectPointAsyn
	{
	public:
		CConnectPointSelfIpc():m_pMgr(0),m_ulKey(EnumKeyUnknown){}
		virtual ~CConnectPointSelfIpc(){}
		int Init(CConfig* pConfig){return 0;}
		int Start(){return 0;}
		void Stop(){}
		void Finish(){}
		int OnRecvPacket(CPacket &GessPacket){return 0;}
		void Bind(CConnectPointManager* pCpMgr,const unsigned long& ulKey){m_pMgr=dynamic_cast<CRiskCpMgr*>(pCpMgr); m_ulKey=ulKey;}
		
		int SendPacket(CPacket &GessPacket)
		{
			if (0==m_pMgr)
				return -1;
			return m_pMgr->OnPacketSelfIpc(GessPacket);
		}
	private:
		CRiskCpMgr* m_pMgr;
		unsigned long m_ulKey;
	};

	//���������㲥�౨�Ĵ��������ӵ�
	class CConnectPointSelfBroadcast:public CConnectPointAsyn
	{
	public:
		CConnectPointSelfBroadcast():m_pMgr(0),m_ulKey(EnumKeyUnknown){}
		virtual ~CConnectPointSelfBroadcast(){}
		int Init(CConfig* pConfig){return 0;}
		int Start(){return 0;}
		void Stop(){}
		void Finish(){}
		int OnRecvPacket(CPacket &GessPacket){return 0;}
		void Bind(CConnectPointManager* pCpMgr,const unsigned long& ulKey){m_pMgr=dynamic_cast<CRiskCpMgr*>(pCpMgr); m_ulKey=ulKey;}
		int SendPacket(CPacket &GessPacket)
		{
			if (0==m_pMgr)
				return -1;
			return m_pMgr->OnPacketSelfBroadcast(GessPacket);
		}
	private:
		CRiskCpMgr* m_pMgr;
		unsigned long m_ulKey;
	};

	//telnet �����д������ӵ�
	class CConnectPointCmd:public CConnectPointAsyn
	{
	public:
		CConnectPointCmd():m_pMgr(0),m_ulKey(EnumKeyUnknown){}
		~CConnectPointCmd(){}
		int Init(CConfig* pConfig){return 0;}
		int Start(){return 0;}
		void Stop(){}
		void Finish(){}
		int OnRecvPacket(CPacket &GessPacket){return 0;}
		void Bind(CConnectPointManager* pCpMgr,const unsigned long& ulKey)
		{
			m_pMgr=dynamic_cast<CRiskCpMgr*>(pCpMgr); 
			m_ulKey=ulKey;
		}
		int SendPacket(CPacket &GessPacket)
		{
			if (0==m_pMgr)
				return -1;
			return m_pMgr->OnPacketCmd(GessPacket);
		}
	private:
		CRiskCpMgr* m_pMgr;
		unsigned long m_ulKey;
	};

	//��־����
	class CNetLogHost:public CSubscriber
	{
	public:
		CNetLogHost():m_pMgr(0){}
		virtual ~CNetLogHost(){}
		void Bind(CRiskCpMgr* p){m_pMgr = p;}
		void OnNotify(const string& sMsg)
		{
			if (0 != m_pMgr)
				m_pMgr->OnNetLogMsg(sMsg);
		}
	private:
		CRiskCpMgr* m_pMgr;
	};

	class CIfkTimer : public CGessTimer
	{
	public:
		CIfkTimer(){}
		virtual ~CIfkTimer(){}
		void Bind(CRiskCpMgr* p)
		{
			m_pParent=p;
		}
		int TimeOut(const string& ulKey,unsigned long& ulTmSpan)
		{
			if (0 != m_pParent)
				return m_pParent->OnIfkTimeout();
			return -1;
		}
		void TimerCanceled(const string& ulKey)
		{
		}
	private:
		CRiskCpMgr* m_pParent;
	};
public:
	CRiskCpMgr(void);
	~CRiskCpMgr(void);

	int OnConnect(const unsigned long& ulKey,const string& sLocalIp, int nLocalPort, const string& sPeerIp, int nPeerPort,int nFlag);
	int OnAccept(const unsigned long& ulKey,const string& sLocalIp, int nLocalPort, const string& sPeerIp, int nPeerPort);
	int OnLogin( const unsigned long& ulKey,const string& sLocalIp, int nLocalPort, const string& sPeerIp, int nPeerPort,int nFlag);
	int OnClose(const unsigned long& ulKey,const string& sLocalIp, int nLocalPort, const string& sPeerIp, int nPeerPort);
	int Forward(CPacket &GessPacket,const unsigned long& ulKey);

	int ToInterfaceA1(CPacket& pkt,const unsigned long& ulKey = EnumKeyUnknown);
	int ToInterfaceA2(CPacket& pkt,const unsigned long& ulKey = EnumKeyUnknown);
	int ToInterfaceF1(CPacket& pkt,const unsigned long& ulKey = EnumKeyUnknown);
	int ToInterfaceF2(CPacket& pkt,const unsigned long& ulKey = EnumKeyUnknown);
	int ToInterfaceK(CPacket& pkt,const unsigned long& ulKey = EnumKeyUnknown);
	int ToInterfaceSms(CPacket& pkt,const unsigned long& ulKey = EnumKeyUnknown);


	int Init();
	void Finish();
	int Start();
	int StartMe();
	void Stop();
	void StopMe();
	int Run();

	void AsynQuit() { m_oAsynQuitThread.Bind(this); m_oAsynQuitThread.BeginThread(); }
	void ReadyToQuit() { m_nReadyQuit = 1; }
	bool IsReadyToQuit() { return 1 == m_nReadyQuit;}

	CMainServiceHandler * GetMainServiceHandler(){return m_pMainService;};


#ifdef _VER_DREB
	CArbMain* GetArbMain(){
		//if (NULL == m_arbMain)
		//{
		//	m_arbMain = new CArbMain;
		//}
		return m_arbMain;
	}
	void SetArbMain(CArbMain* arb)
	{
		m_arbMain = arb;
	}
#endif
	//��ȡ�����������
	int GetHostStatus(){
		return m_nIsMaster;
	}
	bool IsDrebMode(){
		return m_bUseDreb;
	}
	bool IsStopApp(){
		return m_bStop;
	}

private:
	//�����Ա����ָ��
	typedef int (CRiskCpMgr::*MFP_PacketHandleApi)(CBroadcastPacket& pkt);
	//�����������뱨�Ĵ�����Ա����ӳ��ṹ
	typedef struct tagCmd2Api
	{
		string sApiName;						//����ApiName���״���
		MFP_PacketHandleApi pMemberFunc;		//���Ĵ�������ָ��
	} Cmd2Api;
	//�����������뱨�Ĵ�����Ա����ӳ���
	static Cmd2Api m_Cmd2Api[];

	//�����Ա����ָ��
	typedef int (CRiskCpMgr::*MFP_IpcHandleApi)(CIpcPacket& pkt);
	//�����������뱨�Ĵ�����Ա����ӳ��ṹ
	typedef struct tagIpcCmd2Api
	{
		string sApiName;						//����ApiName���״���
		MFP_IpcHandleApi pMemberFunc;			//���Ĵ�������ָ��
	} IpcCmd2Api;
	//�����������뱨�Ĵ�����Ա����ӳ���
	static IpcCmd2Api m_IpcCmd2Api[];

	//�����Ա����ָ��
	typedef string (CRiskCpMgr::*MFP_CmdHandleApi)(const string& sCmd, const vector<string>& vecPara);
	//�����������뱨�Ĵ�����Ա����ӳ��ṹ
	typedef struct tagCmdLine2Api
	{
		string sCmdName;					//CmdName
		string sCmdAbbr;					//������д
		MFP_CmdHandleApi pMemberFunc;		//���Ĵ�������ָ��
		string sHelp;						//����˵��
	} CmdLine2Api;
	//���������������������Ա����ӳ���
	static CmdLine2Api m_CmdLine2Api[];


	//Դ�ӿ�+�������������Ӧ·�ɽӿ�ӳ��ṹ
	typedef struct tagIfRouterCfg
	{
		CConnectPointAsyn* pCp;
		unsigned long ulIfTo;
		unsigned long ulIfFrom;
		string sCmdID;
	} IfRouterCfg;
	//Դ�ӿ�+�������������Ӧ·�ɽӿ�ӳ���ϵ���ñ�
	static IfRouterCfg m_tblIfRouterCfg[];

	//·�ɵ�
	typedef multimap<string,CConnectPointAsyn*> MMAP_CP;
	typedef MMAP_CP::iterator MMAP_IT;
	typedef pair<MMAP_IT,MMAP_IT> RANGE_CP;
	typedef struct tagIfRouterPoint
	{
		unsigned long ulIfFrom;
		MMAP_CP  mmapCmds;
	} IfRouterPoint;
	//�ڴ�·�ɱ�
	IfRouterPoint m_tblIfRouter[EnumKeyUnknown];

	int InitRouterTbl();
private:
	int RunBroadcastPacketHandleApi(CBroadcastPacket& pkt);
	int HandleNetLogMsg(const string & sNetLogMsg);
	int HandleCmdLine(string& sIn);
	int RunIpcPacketHandleApi(CIpcPacket& pkt);

	//�������ӵ�ص��ӿ�
	int OnPacketSelfBroadcast(CPacket& GessPacket);
	int OnPacketSelfIpc(CPacket& GessPacket);

	//telnet ���������ӵ�ص��ӿ�
	int OnPacketCmd(CPacket& GessPacket);
		
	//��־�ص��ӿ�
	void OnNetLogMsg(const string& sMsg);

	//��ʱ���ص��ӿ�
	int OnIfkTimeout();

	//�������ó�ʼ��
	int BasicCfgInit();
	//ҵ��ģ���ʼ��
	int RiskModuleInit(const string& sDate = "");
	//��������ӿ����ӵ��ʼ��
	int IfCpsInit();

	int IfCpsStart();
	int RiskModuleStart();
	void RiskModuleStop();
	void IfCpsStop();
	void RiskModuleFinish();
	void IfCpsFinish();
	void RouterTblFinish();

	//���д���
	void SysInit(const string& = "");
	int NotifyClientInit();

	int NotifySmsDayend(std::string curDate);

	//Զ���ն˶����б�
	map<string,string>  m_deqTelnets;
	CGessMutex			m_csTelnets;

	//��־����
	CNetLogHost m_oNetLogHost;
	CIpcThread m_oIpcThread;
	//
	CAsynQuitThread m_oAsynQuitThread;
	CNetLogThread	m_oNetLogThread;
	CCommandLineThread m_oCmdLineThread;
	CBroadcastPktThread	m_oBroadcastPktThread;

	//K�ӿ�IPC�౨��
	std::deque<CIpcPacket> m_deqIpcPacket;
	CCondMutex	m_deqCondMutex;

	//��ʱ��������
	CGessTimerMgr * m_pGessTimerMgr;
	CIfkTimer m_oIfkTimer;

	CMemDb*					m_pMemDb;
	CMainServiceHandler*	m_pMainService;
	CRiskHandler*			m_pRiskHandler;
	CDbSync*				m_pDbSync;
	CRiskNotify*			m_pRiskNotify;
#ifdef _VER_DREB
	CArbMain*				m_arbMain;
#endif
	//CSmsSender *            m_pSmsSender;

	CConnectPointCmd		m_oCpCmdHandler;
	CConnectPointSelfBroadcast		m_oCpSelfBroadcast;
	CConnectPointSelfIpc	m_oCpSelfIpc;

	//���ӿ����ӵ㼰��ʶ
	CConnectPointAsyn*	m_pCpInterfaceA1;
	CConnectPointAsyn*	m_pCpInterfaceA2;
	CConnectPointAsyn*	m_pCpInterfaceF1;
	CConnectPointAsyn*	m_pCpInterfaceF2;
	CConnectPointAsyn*	m_pCpInterfaceCmd;
	CConnectPointAsyn*	m_pCpInterfaceK;
	CConnectPointAsyn*	m_pCpInterfaceH1;
	CConnectPointAsyn*	m_pCpInterfaceH2;
	CConnectPointAsyn*  m_pCpInterfaceSmscService;

	CNetMgrModule*	m_pNetMagModule;

	CConfigImpl*		m_pConfig;

	int		m_nSysState;
	CGessMutex	m_csSysState;

	volatile bool m_bStop;
	int			  m_nReadyQuit;

	bitset<EnumKeyUnknown> m_bsCps;
	CGessMutex			   m_csBitsetCps;
	int  m_nIsMaster;
	bool m_bUseDreb;//�Ƿ�ʹ������ģʽ
private:
	//����������ַ�
	string OnCmd(const string& sCmdLine, const vector<string>& vecPara);

	string OnCmdLineQuit(const string& sCmd, const vector<string>& vecPara);
	string OnCmdLineSimQuotation(const string& sCmd, const vector<string>& vecPara);
	string OnCmdLineSimInit(const string& sCmd, const vector<string>& vecPara);     
	string OnCmdLineSimSysState(const string& sCmd, const vector<string>& vecPara);
	string OnCmdLineState(const string& sCmd, const vector<string>& vecPara);
	string OnCmdLineCustInfo(const string& sCmd, const vector<string>& vecPara);
	string OnCmdLineBranchInfo(const string& sCmd, const vector<string>& vecPara);
	string OnCmdLineQotationInfo(const string& sCmd, const vector<string>& vecPara);
	string OnCmdLineHelp(const string& sCmd, const vector<string>& vecPara);
	string OnCmdLineMatchInfo(const string& sCmdLine, const vector<string>& vecPara);
	string OnCmdLineSysInfo(const string& sCmdLine, const vector<string>& vecPara);
	string OnCmdLine3DesEnc(const string& sCmdLine, const vector<string>& vecPara);
private:
	//ͳһA1�ӿڱ���Ӧ��
	int SendAck(CBroadcastPacket& pkt);

	// [onSysInit] ҵ����Ӧ�����
	int OnSysInit(CBroadcastPacket& pkt);

	// [onSysStatChange] ҵ����Ӧ�����
	int OnSysStat(CBroadcastPacket& pkt);

		// [onRecvRtnSpotInstStateUpdate] ҵ����Ӧ�����
	int OnSpotInstState(CBroadcastPacket& pkt);

	// [onRecvRtnForwardInstStateUpdate] ҵ����Ӧ�����
	int OnForwardInstState(CBroadcastPacket& pkt);

	// [onRecvRtnDeferInstStateUpdate] ҵ����Ӧ�����
	int OnDeferInstState(CBroadcastPacket& pkt);

	// [onRecvRtnSpotMarketStateUpdate] ҵ����Ӧ�����
	int OnSpotMarketState(CBroadcastPacket& pkt);

	// [onRecvRtnForwardMarketStateUpdate] ҵ����Ӧ�����
	int OnForwardMarketState(CBroadcastPacket& pkt);

	// [onRecvRtnDeferMarketStateUpdate] ҵ����Ӧ�����
	int OnDeferMarketState(CBroadcastPacket& pkt);

	// K�ӿ�[onRecvQuit] ҵ����Ӧ�����
	int OnRecvQuit(CIpcPacket& pkt);
	//�ڲ��㲥
	int OnHostStatus(CBroadcastPacket& pkt);
};
#endif