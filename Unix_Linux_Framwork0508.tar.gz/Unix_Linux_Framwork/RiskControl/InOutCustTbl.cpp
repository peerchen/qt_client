#include "InOutCustTbl.h"
CInOutCustTbl::CInOutCustTbl()
{

}
CInOutCustTbl::~CInOutCustTbl()
{
	Finish();
}
void CInOutCustTbl::InsertByDb(string acctNo,double inCap,double outCap)
{
	CGessGuard guard(m_mutexTbl);
	map<string,CInOutCust>::iterator it;
	CInOutCust tempCust;
	tempCust.m_sAcctNo=acctNo;
	tempCust.m_sSerialNo="";
	if (inCap>=outCap)
	{
		tempCust.m_iAccessWay=RiskConst::gc_cCapitalIn;
		tempCust.m_dAmount=inCap-outCap;
	}
	else
	{
		tempCust.m_iAccessWay=RiskConst::gc_cCapitalOut;
		tempCust.m_dAmount=outCap-inCap;
	}
	m_mapInOutCust[acctNo]=tempCust;
}
void CInOutCustTbl::InitSerialNo(string acctNo,string sSerialNo)
{
	if (""==m_mapInOutCust[acctNo].m_sSerialNo)
	{
		m_mapInOutCust[acctNo].m_sSerialNo=sSerialNo;
	}else
	{
		m_mapInOutCust[acctNo].m_sSerialNo+=","+sSerialNo;
	}
}
int CInOutCustTbl::InsertToInOutCustList(CInOutCust &ioCust,double inCap,double outCap)
{
	CGessGuard guard(m_mutexTbl);
	map<string,CInOutCust>::iterator it;
	it=m_mapInOutCust.find(ioCust.m_sAcctNo);
	if (it==m_mapInOutCust.end())
	{
		m_mapInOutCust[ioCust.m_sAcctNo]=ioCust;
	}
	else
	{
		if (m_mapInOutCust[ioCust.m_sAcctNo].m_sSerialNo!="")
		{
			m_mapInOutCust[ioCust.m_sAcctNo].m_sSerialNo+=",";
			m_mapInOutCust[ioCust.m_sAcctNo].m_sSerialNo+=ioCust.m_sSerialNo;
		}
		else
		{
			m_mapInOutCust[ioCust.m_sAcctNo].m_sSerialNo=ioCust.m_sSerialNo;
		}
		if (inCap>=outCap)
		{
			m_mapInOutCust[ioCust.m_sAcctNo].m_iAccessWay=RiskConst::gc_cCapitalIn;
			m_mapInOutCust[ioCust.m_sAcctNo].m_dAmount=inCap-outCap;
		}
		else
		{
			m_mapInOutCust[ioCust.m_sAcctNo].m_iAccessWay=RiskConst::gc_cCapitalOut;
			m_mapInOutCust[ioCust.m_sAcctNo].m_dAmount=outCap-inCap;
		}
	}
	return 0;
}
int CInOutCustTbl::GetRecordSet(map<string,CInOutCust>& mapInOutCust)
{
	CGessGuard guard(m_mutexTbl);
	map<string,CInOutCust>::iterator it=m_mapInOutCust.begin();
	for (;it!=m_mapInOutCust.end();++it)
	{
		mapInOutCust[it->second.m_sAcctNo]=it->second;
	}
	return 0;
}
void CInOutCustTbl::Finish()
{
	CGessGuard guard(m_mutexTbl);
	m_mapInOutCust.clear();
}