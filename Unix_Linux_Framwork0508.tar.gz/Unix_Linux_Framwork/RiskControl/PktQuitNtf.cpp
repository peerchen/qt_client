#include "RiskCpMgr.h"

// K�ӿ�[onRecvQuit] ҵ����Ӧ�����
int CRiskCpMgr::OnRecvQuit(CIpcPacket& pkt)
{
	//
	QuitNotify stBody;
	CPacketStructIpcNm::Packet2Struct(stBody,pkt);
	
	CRLog(E_APPINFO,"%s","Recv Ipc Packet Quit!");
	m_oNetLogThread.EndThread();
	m_oBroadcastPktThread.EndThread();
	m_bStop = true;
	m_deqCondMutex.Signal();

	return 0;
}

