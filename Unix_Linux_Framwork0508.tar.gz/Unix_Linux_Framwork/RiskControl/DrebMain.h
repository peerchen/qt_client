//#pragma once
#ifndef _DREB_MAIN_H
#define _DREB_MAIN_H
#include "VersionMacro.h"
#ifdef _VER_DREB
#include "ArbMain.h"

class CDrebMain
{
public:
	CDrebMain(void);
	~CDrebMain(void);

	// ִ�к���
	int Run( int argc, char* argv[] );

private:
	CArbMain frun;
	char *g_pExitFlag;
	//int   g_pRunFlag;
};

#endif
#endif