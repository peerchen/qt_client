#include "RiskHandler.h"

// A1 �ӿ� [onAcctCapitalAccess]AcctCapitalAccess ��ҵ��ʵ��
int CRiskHandler::OnAcctCapitalAccess(CBroadcastPacket& pkt)
{
	AcctCapitalAccess stBody;
	CPacketStructBroadcastRisk::Packet2Struct(stBody, pkt);
	
	SendAck(pkt);

	//ҵ��ʵ��......
	CCustomer* p = FindCustomer(stBody.acct_no);
	if (!p)
		return -1;

	std::string sKey = stBody.fund_src_type + stBody.serial_no;
	CCapitalTbl& tblCapital = m_pMemDb->GetCapitalTbl();
	if (tblCapital.IsHandled(sKey,stBody.acct_no))
		return -1;

	CRLog(E_APPINFO,"OnAcctCapitalAccess %s %d %f %s %s %s\n",	stBody.acct_no.c_str(), stBody.access_way,stBody.amount,stBody.fund_src_type.c_str(),stBody.serial_no.c_str(),sKey.c_str());

	CustRiskInfo oCustRiskInfo;
	int nRtn = p->OnCapitalInOut(stBody.amount,stBody.access_way,oCustRiskInfo);
    //������������  add by zengweiwei 2013-11-18 begin
	CInOutCust cust;
	cust.m_sAcctNo=stBody.acct_no;
	cust.m_sSerialNo=stBody.serial_no;
	cust.m_dAmount=stBody.amount;
	cust.m_iAccessWay=stBody.access_way;
	CInOutCustTbl & tblInoutCust=m_pMemDb->GetInOutCustTbl();
	tblInoutCust.InsertToInOutCustList(cust,p->InCapitalTdy(),p->OutCapitalTdy());
	//������������  add by zengweiwei 2013-11-18 end
	if (nRtn == gc_cStateNormal)
	{
	}
	if (nRtn == gc_cStateValueChange)
	{
		//����� 
		m_pRiskNotify->Enque(oCustRiskInfo);
	}
	if (nRtn == gc_cStateRiskTransfer)
	{
		//����� 
		m_pRiskNotify->Enque(oCustRiskInfo);
	}

	p->UpdateAgentBalanceStat();
	p->UpdateAgentDebtStat();

	// �����ɹ������¼��㱬����Ϣ  add by liuwei 2012-3-28
	CQuotationTbl& tblQuotation = m_pMemDb->GetQuotationTbl();
	double dlup,dldown,dlup1,dldown1;
	tblQuotation.UpLimitPrice("Ag(T+D)", dlup);
	tblQuotation.DownLimitPrice("Ag(T+D)", dldown);
	tblQuotation.UpLimitPrice1("Ag(T+D)", dlup1);
	tblQuotation.UpLimitPrice1("Ag(T+D)", dldown1);

	double dlup2,dldown2,dlup21,dldown21;
	tblQuotation.UpLimitPrice("Au(T+D)", dlup2);
	tblQuotation.DownLimitPrice("Au(T+D)", dldown2);
	tblQuotation.UpLimitPrice1("Au(T+D)", dlup21);
	tblQuotation.UpLimitPrice1("Au(T+D)", dldown21);

	p->CalculateOutStockInfo(dlup, dldown, dlup1, dldown1, dlup2, dldown2, dlup21, dldown21);

	return 0;
};
