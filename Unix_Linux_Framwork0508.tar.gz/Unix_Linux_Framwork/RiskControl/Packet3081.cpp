#include "MainServiceHandler.h"
#include "Logger.h"
#include <sstream>
#include "strutils.h"

using namespace strutils;

#ifdef _VER_25_DB2
// F1 �ӿ� [3081]�������ñ��� ��ҵ��ʵ��
int CMainServiceHandler::OnRiskStateParaReq(CTradePacket& pkt)
{
	HEADER_REQ stHeaderReq;
	RiskStateParaReq stBodyReq;

	HEADER_RSP stHeaderRsp;
	RiskStateParaRsp stBodyRsp;

	pkt.GetHeader(stHeaderReq);
	CPacketStructTradeRisk::Packet2Struct(stBodyReq, pkt);

	//ҵ��ʵ��......
	CTradePacket pktRsp;
	CPacketStructTradeRisk::HeadReq2Rsp(stHeaderReq,stHeaderRsp);

	char cAcctNo[16];		//�ͻ���
	char cGradeId[9];		//�ͻ�����
	char cBranchId[13];	//��������ID
	char cAcctType[16];	//�˻�����
	char cGradeName[21];	//��������
	short sRiskType;
	string sSql = "";
	ArrayListMsg alm_resutl;					//��������(ArrayListMsg, �ֶΣ����յȼ����, ������Сֵ���������ֵ)

	memset(cAcctNo, 0, sizeof(cAcctNo));
	memset(cGradeId, 0, sizeof(cGradeId));
	memset(cBranchId, 0, sizeof(cBranchId));
	memset(cAcctType, 0, sizeof(cAcctType));
	memset(cGradeName, 0, sizeof(cGradeName));

	//��ʼ����������Ϣ	1���ͻ�		2���ͻ�����		3����������		4���˻�����
	if (stBodyReq.obj_type == "1")
	{
		strcpy(cAcctNo, stBodyReq.obj_id.c_str());
		strcpy(cGradeId, "XXXXXX");
		strcpy(cBranchId, "XXXXXX");
		strcpy(cAcctType, "XX");
	}
	else if (stBodyReq.obj_type == "2")
	{
		strcpy(cAcctNo, "XXXXXXXX");
		strcpy(cGradeId, stBodyReq.obj_id.c_str());
		strcpy(cBranchId, "XXXXXX");
		strcpy(cAcctType, "XX");
	}
	else if (stBodyReq.obj_type == "3")
	{
		strcpy(cAcctNo, "XXXXXXXX");
		strcpy(cGradeId, "XXXXXX");
		strcpy(cBranchId, stBodyReq.obj_id.c_str());
		strcpy(cAcctType, "XX");
	}
	else if (stBodyReq.obj_type == "4")
	{
		strcpy(cAcctNo, "XXXXXXXX");
		strcpy(cGradeId, "XXXXXX");
		strcpy(cBranchId, "XXXXXX");
		strcpy(cAcctType, stBodyReq.obj_id.c_str());
	}
	else
	{
		strcpy(cAcctNo, "XXXXXXXX");
		strcpy(cGradeId, "XXXXXX");
		strcpy(cBranchId, "XXXXXX");
		strcpy(cAcctType, "XX");
	}

	try
	{
		//���Ĵ���	0����ѯ		1���޸�		2������		3��ɾ��
		if (stBodyReq.oper_flag == 0)
		{
			double dDebtExchValue = 0.0;				//ǿƽ��
			double dDebtCallValue = 0.0;				//׷��������
			double dGradeValueDown = 0.0;				//���շֶ�ֵ�±߽�
			double dGradeValueUp = 0.0;					//���շֶ�ֵ�ϱ߽�
			int iGradeId = 0;							//���ռ���

			//��ѯ���ͷ�������
			sSql = "select debt_exch_value, debt_call_value from cust_debt_line where acct_no = :f1<char[16]> and acct_grade_id = :f2<char[9]> and branch_id = :f3<char[16]> and acct_type = :f4<char[3]>";
			otl_stream o(1, sSql.c_str(), GetOtlConn());
			o << cAcctNo << cGradeId << cBranchId << cAcctType;
			if (!o.eof())
			{
				o >> dDebtExchValue >> dDebtCallValue;
				stBodyRsp.obj_type = stBodyReq.obj_type;
				stBodyRsp.obj_id = stBodyReq.obj_id;
			}
			else
			{
				stBodyRsp.obj_type = "";
				stBodyRsp.obj_id = "";
			}

			//����ת��
			stBodyRsp.debt_exch_value = ToString<double>(dDebtExchValue);
			stBodyRsp.debt_call_value = ToString<double>(dDebtCallValue);

			//��ѯ���ռ�������
			sSql = "select a.grade_id, b.grade_name, b.risk_type, a.grade_vale_down, a.grade_vale_up from risk_grade_cust a left join risk_grade b on a.grade_id = b.grade_id where a.acct_no = :f1<char[16]> and a.acct_grade_id = :f2<char[9]> and a.branch_id = :f3<char[13]> and a.acct_type = :f4<char[3]>";
			otl_stream i(1, sSql.c_str(), GetOtlConn());
			i << cAcctNo << cGradeId << cBranchId << cAcctType;

			while (!i.eof())
			{
				i >> iGradeId >> cGradeName >> sRiskType >> dGradeValueDown >> dGradeValueUp;

				alm_resutl.clear();
				alm_resutl.AddValue(iGradeId);
				alm_resutl.AddValue(cGradeName);				
				alm_resutl.AddValue(dGradeValueDown);
				alm_resutl.AddValue(dGradeValueUp);
				alm_resutl.AddValue(sRiskType);

				stBodyRsp.obj_content.AddValue(alm_resutl);
			}
			
		}
		else if (stBodyReq.oper_flag == 1)
		{
			//�޸ķ����������ñ���Ӧ��¼
			sSql = "update cust_debt_line set debt_exch_value = :f2<double>, debt_call_value = :f3<double> where acct_no = :f4<char[16]> and acct_grade_id = :f5<char[9]> and branch_id = :f6<char[13]> and acct_type = :f7<char[3]>";
			otl_stream o(1, sSql.c_str(), GetOtlConn());
			o << atof(stBodyReq.debt_exch_value.c_str()) << atof(stBodyReq.debt_call_value.c_str()) << cAcctNo << cGradeId << cBranchId << cAcctType;

			//�޸ķ��ռ������ñ���Ӧ��¼	��ɾ��ԭ��¼���ٲ����¼�¼
			sSql = "delete from risk_grade_cust where acct_no = :f1<char[16]> and acct_grade_id = :f2<char[9]> and branch_id = :f3<char[13]> and acct_type = :f4<char[3]>";
			otl_stream i(1, sSql.c_str(), GetOtlConn());
			i << cAcctNo << cGradeId << cBranchId << cAcctType;

			sSql = "insert into risk_grade_cust values(:f1<char[16]>, :f2<char[13]>, :f3<char[3]>, :f4<char[9]>, :f5<char[3]>, :f6<double>, :f7<double>)";
			otl_stream p(1, sSql.c_str(), GetOtlConn());
			for (unsigned int i=0; i<stBodyReq.obj_content.size(); i++)
			{
				alm_resutl.clear();
				stBodyReq.obj_content.GetValue(i, alm_resutl);

				p << cAcctNo << cBranchId << cAcctType << cGradeId << alm_resutl.GetValue<string>(0).c_str() << alm_resutl.GetValue<double>(1) << alm_resutl.GetValue<double>(2);
			}

			//ͬ���ڴ����ݿ�
// 			setCustRiskInfo(stBodyReq.obj_type, stBodyReq.obj_id, atof(stBodyReq.debt_exch_value.c_str()), atof(stBodyReq.debt_call_value.c_str()), stBodyReq.obj_content, GetOtlConn());

		}
		else if (stBodyReq.oper_flag == 2)
		{
			//����ǰ�Ƚ��м����û�д���
			sSql = "select debt_exch_value, debt_call_value from cust_debt_line where acct_no = :f1<char[16]> and acct_grade_id = :f2<char[9]> and branch_id = :f3<char[16]> and acct_type = :f4<char[3]>";
			otl_stream check(1, sSql.c_str(), GetOtlConn());
			check<< cAcctNo << cGradeId << cBranchId << cAcctType;
			if(!check.eof())
			{
				strcpy(stHeaderRsp.rsp_code, "00000001");
				pktRsp.AddParameter("rsp_msg", "�÷��յȼ������Ѿ����ù�");
			}
			else
			{
				//��������������ñ�
				sSql = "insert into cust_debt_line values(:f1<char[16]>, :f2<char[13]>, :f3<char[3]>, :f4<char[9]>, :f6<double>, :f7<double>)" ;
				otl_stream o(1, sSql.c_str(), GetOtlConn());
				o << cAcctNo << cBranchId << cAcctType << cGradeId << atof(stBodyReq.debt_exch_value.c_str()) << atof(stBodyReq.debt_call_value.c_str());

				//������ռ������ñ�
				sSql = "insert into risk_grade_cust values(:f1<char[16]>, :f2<char[13]>, :f3<char[3]>, :f4<char[9]>, :f5<double>, :f6<double>, :f7<double>)";
				otl_stream p(1, sSql.c_str(), GetOtlConn());
				for (unsigned int i=0; i<stBodyReq.obj_content.size(); i++)
				{
					alm_resutl.clear();
					stBodyReq.obj_content.GetValue(i, alm_resutl);

					p << cAcctNo << cBranchId << cAcctType << cGradeId << alm_resutl.GetValue<double>(0)<< alm_resutl.GetValue<double>(1) << alm_resutl.GetValue<double>(2);
				}

				//ͬ�����ڴ����ݿ�
// 				setCustRiskInfo(stBodyReq.obj_type, stBodyReq.obj_id, atof(stBodyReq.debt_exch_value.c_str()), atof(stBodyReq.debt_call_value.c_str()), stBodyReq.obj_content, GetOtlConn());
			}
			
		}
		else if (stBodyReq.oper_flag == 3)
		{
			//ɾ�������������ñ���Ӧ��¼
			sSql = "delete from cust_debt_line where acct_no = :f1<char[16]> and acct_grade_id = :f2<char[9]> and branch_id = :f3<char[13]> and acct_type = :f4<char[3]>";
			otl_stream o(1, sSql.c_str(), GetOtlConn());
			o << cAcctNo << cGradeId << cBranchId << cAcctType;
			CRLog(E_PROINFO, "sSql: %s", sSql.c_str());
			CRLog(E_PROINFO, "cAcctNo=%s,cGradeId=%s,cBranchId=%s,cAcctType=%s",  cAcctNo, cGradeId, cBranchId, cAcctType);

			//ɾ�����ռ������ñ���Ӧ��¼
			sSql = "delete from risk_grade_cust where acct_no = :f1<char[16]> and acct_grade_id = :f2<char[9]> and branch_id = :f3<char[13]> and acct_type = :f4<char[3]>";
			otl_stream i(1, sSql.c_str(), GetOtlConn());
			i << cAcctNo << cGradeId << cBranchId << cAcctType;
			CRLog(E_PROINFO, "sSql: %s", sSql.c_str());
			CRLog(E_PROINFO, "cAcctNo=%s,cGradeId=%s,cBranchId=%s,cAcctType=%s",  cAcctNo, cGradeId, cBranchId, cAcctType);

			//ͬ�����ڴ����ݿ�
// 			setCustRiskInfo(stBodyReq.obj_type, stBodyReq.obj_id, GetOtlConn());
		}

	}
	catch(otl_exception& p)
	{
		CRLog(E_ERROR, "DB:MSG:%s\nTEXT:%s\nVARINFO:%s", p.msg, p.stm_text, p.var_info); 
		Rollback();
		strcpy(stHeaderRsp.rsp_code, "00000001");
		pktRsp.AddParameter("rsp_msg", (const char *)p.msg);
	}

	//������Ӧ����
	stBodyRsp.oper_flag = stBodyReq.oper_flag;

	pktRsp.SetHeader(stHeaderRsp);
	CPacketStructTradeRisk::Struct2Packet(stBodyRsp,pktRsp);

	//ת������
	m_pRiskCpMgr->ToInterfaceF1(pktRsp,m_ulKey);

	return 0;
};

/*
�������������ղ������ø���ʱͬ���ڴ�ͻ�������Ϣ
���������const string & �������
			  const string & ���ֵ
		  double ���ǿƽ��
		  double ׷����
		  ArrayListMsg ���յȼ���Ϣ
		  otl_connect & ���ݿ�����
�����������
����ֵ	��void
*/
void CMainServiceHandler::setCustRiskInfo(const string &sObjType, const string &sValue, double dExchValue, double dCallValue, ArrayListMsg almGradeCust, otl_connect& dbConnection)
{
	char cAcctNo[16];	
	char cGradeName[21];
	short sRiskType;
	ArrayListMsg almRiskGrade;
	ArrayListMsg alm_resutl;
	string sSql = "";

	memset(cAcctNo, 0, sizeof(cAcctNo));
	memset(cGradeName, 0, sizeof(cGradeName));

	if (sObjType == "1")
	{
		//�ͻ���
		sSql = "select acct_no from cust_info where acct_no = '" + sValue + "'";
	}
	else if (sObjType == "2")
	{
		//�ͻ�����
		sSql = "select acct_no "
				"from cust_info "
				"where grade_id = '" + sValue + "' "
				"and acct_no not in (select distinct acct_no from cust_debt_line)";
	}
	else if (sObjType == "3")
	{
		//��������
		sSql = "select acct_no "
				"from cust_info "
				"where branch_id = '" + sValue + "' "
				"and acct_no not in (select distinct acct_no from cust_debt_line) "
				"and grade_id not in (select distinct acct_grade_id from cust_debt_line)";
	}
	else if (sObjType == "4")
	{
		//�˻�����
		sSql = "select acct_no "
				"from cust_info "
				"where acct_type = '" + sValue + "' "
				"and acct_no not in (select distinct acct_no from cust_debt_line) "
				"and grade_id not in (select distinct acct_grade_id from cust_debt_line) "
				"and branch_id not in (select distinct branch_id from cust_debt_line)";
	}
	else if(sObjType == "0")
	{
		//���пͻ�
		sSql ="select a.acct_no "
				"from cust_info a "
				"where a.acct_no not in (select distinct acct_no from cust_debt_line) "
				"and a.grade_id not in (select distinct acct_grade_id from cust_debt_line) "
				"and a.branch_id not in (select distinct branch_id from cust_debt_line) "
				"and a.acct_type not in (select distinct acct_type from cust_debt_line)";
	}

	//������յȼ���Ϣ
	string sRiskGradeSql = "select grade_name, risk_type from risk_grade where grade_id = :f1<int>";
	otl_stream oGrade(1, sRiskGradeSql.c_str(), dbConnection);
	for (unsigned int i=0; i<almGradeCust.size(); i++)
	{
		ArrayListMsg aMsg = almGradeCust.GetValue(i);
		oGrade << aMsg.GetValue<int>(0);
		oGrade >> cGradeName >> sRiskType;

		alm_resutl.clear();
		alm_resutl.AddValue(aMsg.GetValue<int>(0));
		alm_resutl.AddValue(cGradeName);				
		alm_resutl.AddValue(aMsg.GetValue<double>(1));
		alm_resutl.AddValue(aMsg.GetValue<double>(2));
		alm_resutl.AddValue(sRiskType);

		almRiskGrade.AddValue(alm_resutl);

	}

	//��ȡ��Ҫͬ���ڴ���Ŀͻ�
	otl_stream oCust(1, sSql.c_str(), dbConnection);
	while (!oCust.eof())
	{
		oCust >> cAcctNo;

		//ͬ���ڴ���Ϣ
		m_pMemDb->GetCustTble().UpdateCustRisk(cAcctNo, dExchValue, dCallValue, almRiskGrade);
	}
}

/*
�������������ղ�������ɾ��ʱͬ���ڴ�ͻ�������Ϣ
���������const string & �������
		  const string & ���ֵ
		  otl_connect & ���ݿ�����
�����������
����ֵ	��void
*/
void CMainServiceHandler::setCustRiskInfo(const string &sObjType, const string &sValue, otl_connect& dbConnection)
{
	char cAcctNo[16];		//�ͻ���
	char cGradeId[9];		//�ͻ�����
	char cBranchId[16];		//��������
	char cAcctType[3];		//�˻�����
	char cGradeName[21];	//��������
	short sRiskType;
	int iGradeId;
	double dDebtExchValue = 0.0;
	double dDebtCallValue = 0.0;
	double dGradeValueDown = 0.0;
	double dGradeValueUp = 0.0;
	ArrayListMsg almRiskGrade;
	ArrayListMsg alm_resutl;
	string sSql = "";

	memset(cAcctNo, 0, sizeof(cAcctNo));
	memset(cGradeId, 0, sizeof(cGradeId));
	memset(cBranchId, 0, sizeof(cBranchId));
	memset(cAcctType, 0, sizeof(cAcctType));
	memset(cGradeName, 0, sizeof(cGradeName));
	
	string sAcctNo = "XXXXXXXX";

	if (sObjType == "1")
	{
		//�ͻ���
		sSql = "select "
					"z.acct_no, "
					"FG_CovNull((select acct_grade_id from cust_debt_line where acct_grade_id = z.grade_id), 'XXXXXX') grade_id, "
					"z.branch_id, "
					"FG_CovNull((select acct_type from cust_debt_line where acct_type = z.acct_type), 'XX') acct_type "
				"from cust_info z "
				"where z.acct_no = '" + sValue + "'";
	}
	else if (sObjType == "2")
	{
		//�ͻ�����
		sSql = "select "
					"z.acct_no, "
					"'XXXXXX' grade_id, "
					"z.branch_id, "
					"FG_CovNull((select acct_type from cust_debt_line where acct_type = z.acct_type), 'XX') acct_type "
				"from cust_info z "
				"where z.grade_id = '" + sValue + "' "
				"and z.acct_no not in (select distinct acct_no from cust_debt_line)";
	}
	else if (sObjType == "3")
	{
		//��������
		sSql = "select "
					"z.acct_no, "
					"'XXXXXX' grade_id, "
					"z.branch_id, "
					"FG_CovNull((select acct_type from cust_debt_line where acct_type = z.acct_type), 'XX') acct_type "
				"from cust_info z "
				"where z.branch_id = '" + sValue + "' "
				"and z.acct_no not in (select distinct acct_no from cust_debt_line) "
				"and z.grade_id not in (select distinct acct_grade_id from cust_debt_line)";
	}
	else if (sObjType == "4")
	{
		//�˻�����
		sSql = "select "
					"z.acct_no, "
					"'XXXXXX' grade_id, "
					"'XXXXXX' branch_id, "
					"'XX' acct_type "
				"from cust_info z "
				"where z.acct_type = '" + sValue + "' "
				"and z.acct_no not in (select distinct acct_no from cust_debt_line) "
				"and z.grade_id not in (select distinct acct_grade_id from cust_debt_line) "
				"and z.branch_id not in (select distinct branch_id from cust_debt_line)";
	}

	//��ȡ��Ҫͬ���ڴ���Ŀͻ�
	otl_stream oCust(1, sSql.c_str(), dbConnection);
	while (!oCust.eof())
	{
		oCust >> cAcctNo >> cGradeId >> cBranchId >> cAcctType;

		//���ڷ�ɾ���˻����͵ģ�����Ҫ���Ҵ�����������
		if (sObjType != "4" && (strcmp(cGradeId, "XXXXXX") == 0))
		{
			//otl_stream oGetBranch(1, "select x.branch_id from (select level lv, branch_id from branch_info start with branch_id = :f1<char[13]> connect by prior parent_branch_id = branch_id order by lv) y, cust_debt_line x  where x.branch_id = y.branch_id and rownum = 1", dbConnection);
			otl_stream oGetBranch(1, "select x.branch_id from (select parent_branch_id from  v_rte_branch_info where branch_id=:f1<char[13]> ) y ,cust_debt_line x where y.parent_branch_id=x.branch_id", dbConnection);
			oGetBranch << cBranchId;
			if (!oGetBranch.eof())
			{
				oGetBranch >> cBranchId;
			}
			else
			{
				strcpy(cBranchId, "XXXXXX");
			}
		}

		//��ѯ������Ϣ����
		sSql = "select debt_exch_value, debt_call_value from cust_debt_line where acct_no = 'XXXXXXXX' and acct_grade_id = :f1<char[9]> and branch_id = :f2<char[16]> and acct_type = :f3<char[3]>";
		otl_stream oGetDebtLine(1, sSql.c_str(), dbConnection);
		oGetDebtLine << cGradeId << cBranchId << cAcctType;
		if (!oGetDebtLine.eof())
		{
			oGetDebtLine >> dDebtExchValue >> dDebtCallValue;
		}

		//��ѯ���ռ�������
		sSql = "select a.grade_id, b.grade_name, b.risk_type, a.grade_vale_down, a.grade_vale_up from risk_grade_cust a left join risk_grade b on a.grade_id = b.grade_id where a.acct_no = 'XXXXXXXX' and a.acct_grade_id = :f1<char[9]> and a.branch_id = :f2<char[16]> and a.acct_type = :f3<char[3]>";
		otl_stream oGetRiskGrade(1, sSql.c_str(), GetOtlConn());
		oGetRiskGrade << cGradeId << cBranchId << cAcctType;

		almRiskGrade.clear();
		while (!oGetRiskGrade.eof())
		{
			oGetRiskGrade >> iGradeId >> cGradeName >> sRiskType >> dGradeValueDown >> dGradeValueUp;

			alm_resutl.clear();
			alm_resutl.AddValue(iGradeId);
			alm_resutl.AddValue(cGradeName);				
			alm_resutl.AddValue(dGradeValueDown);
			alm_resutl.AddValue(dGradeValueUp);
			alm_resutl.AddValue(sRiskType);

			almRiskGrade.AddValue(alm_resutl);
		}

		//ͬ���ڴ���Ϣ
		m_pMemDb->GetCustTble().UpdateCustRisk(cAcctNo, dDebtExchValue, dDebtCallValue, almRiskGrade);
	}
}
#else
// F1 �ӿ� [3081]�������ñ��� ��ҵ��ʵ��
int CMainServiceHandler::OnRiskStateParaReq(CTradePacket& pkt)
{
	HEADER_REQ stHeaderReq;
	RiskStateParaReq stBodyReq;

	HEADER_RSP stHeaderRsp;
	RiskStateParaRsp stBodyRsp;

	pkt.GetHeader(stHeaderReq);
	CPacketStructTradeRisk::Packet2Struct(stBodyReq, pkt);

	//ҵ��ʵ��......
	CTradePacket pktRsp;
	CPacketStructTradeRisk::HeadReq2Rsp(stHeaderReq,stHeaderRsp);

	char cAcctNo[16];		//�ͻ���
	char cGradeId[8+1];		//�ͻ�����
	char cBranchId[12+1];	//��������ID
	char cAcctType[16];	//�˻�����
	char cGradeName[21];	//��������
	short sRiskType;
	string sSql = "";
	ArrayListMsg obj_ListMsg;
	ArrayListMsg alm_resutl;					//��������(ArrayListMsg, �ֶΣ����յȼ����, ������Сֵ���������ֵ)
	ArrayListMsg rec_ListMsg;                   //�洢��¼��Ϣ

	memset(cAcctNo, 0, sizeof(cAcctNo));
	memset(cGradeId, 0, sizeof(cGradeId));
	memset(cBranchId, 0, sizeof(cBranchId));
	memset(cAcctType, 0, sizeof(cAcctType));
	memset(cGradeName, 0, sizeof(cGradeName));

	//��ʼ����������Ϣ	1���ͻ�		2���ͻ�����		3����������		4���˻�����
	if (stBodyReq.obj_type == "1")
	{
		strcpy(cAcctNo, stBodyReq.obj_id =="" ? "XXXXXXXX":stBodyReq.obj_id.c_str());
		strcpy(cGradeId, "XXXXXX");
		strcpy(cBranchId, "XXXXXX");
		strcpy(cAcctType, "XX");
	}
	else if (stBodyReq.obj_type == "2")
	{
		strcpy(cAcctNo, "XXXXXXXX");
		strcpy(cGradeId, stBodyReq.obj_id =="" ? "XXXXXX":stBodyReq.obj_id.c_str());
		strcpy(cBranchId, "XXXXXX");
		strcpy(cAcctType, "XX");
	}
	else if (stBodyReq.obj_type == "3")
	{
		strcpy(cAcctNo, "XXXXXXXX");
		strcpy(cGradeId, "XXXXXX");
		strcpy(cBranchId, stBodyReq.obj_id =="" ? "XXXXXX":stBodyReq.obj_id.c_str());
		strcpy(cAcctType, "XX");
	}
	else if (stBodyReq.obj_type == "4")
	{
		strcpy(cAcctNo, "XXXXXXXX");
		strcpy(cGradeId, "XXXXXX");
		strcpy(cBranchId, "XXXXXX");
		strcpy(cAcctType, stBodyReq.obj_id =="" ? "XX":stBodyReq.obj_id.c_str());
	}
	else
	{
		strcpy(cAcctNo, "XXXXXXXX");
		strcpy(cGradeId, "XXXXXX");
		strcpy(cBranchId, "XXXXXX");
		strcpy(cAcctType, "XX");
	}

	try
	{
		//���Ĵ���	0����ѯ		1���޸�		2������		3��ɾ��
		if (stBodyReq.oper_flag == 0)
		{
			double dDebtExchValue = 0.0;				//ǿƽ��
			double dDebtCallValue = 0.0;				//׷��������
			double dGradeValueDown = 0.0;				//���շֶ�ֵ�±߽�
			double dGradeValueUp = 0.0;					//���շֶ�ֵ�ϱ߽�
			int iGradeId = 0;							//���ռ���
			//��ѯ���ͷ�������
			string sTempParas ="";
			string obj_type; //�������� 0��Ĭ������ 1���ͻ�		2���ͻ�����		3����������		4���˻�����
			
	
			sSql = "select acct_no,acct_grade_id,branch_id,acct_type,debt_exch_value,debt_call_value from cust_debt_line where 1=1 ";
			if(stBodyReq.obj_type == "1")
				sSql += strcmp(cAcctNo ,"XXXXXXXX") == 0 ? " and acct_no !='XXXXXXXX'" : " and acct_no='" + sTempParas.assign(cAcctNo) +"'";
			else if(stBodyReq.obj_type == "2")
				sSql += strcmp(cGradeId , "XXXXXX") == 0 ? " and acct_grade_id !='XXXXXX'" : " and acct_grade_id='" + sTempParas.assign(cGradeId) +"'";
			else if(stBodyReq.obj_type == "3")
				sSql += strcmp(cBranchId, "XXXXXX") == 0 ? " and branch_id  !='XXXXXX'" : " and branch_id='" + sTempParas.assign(cBranchId) +"'";
			else if(stBodyReq.obj_type == "4")
				sSql += strcmp(cAcctType,"XX")  == 0 ?  " and acct_type !='XX'" : " and acct_type='" + sTempParas.assign(cAcctType) +"'";
			CRLog(E_DEBUG, "sSql:%s", sSql.c_str()); 
			otl_stream o(1, sSql.c_str(), GetOtlConn());
			
			rec_ListMsg.clear();
		
			while(!o.eof())
			{
				alm_resutl.clear();
				o >> cAcctNo >> cGradeId >> cBranchId >> cAcctType >> dDebtExchValue >> dDebtCallValue;


				if (strncmp(cAcctNo,"XXXXXXXX",8) != 0
					&& strncmp(cGradeId,"XXXXXX",6) ==0
					&& strncmp(cBranchId,"XXXXXX",6) ==0
					&& strncmp(cAcctType,"XX",2) ==0)
				{
					obj_type ="1";
					sTempParas.assign(cAcctNo);
				}
				else if (strncmp(cAcctNo,"XXXXXXXX",8) == 0
					&& strncmp(cGradeId,"XXXXXX",6) !=0
					&& strncmp(cBranchId,"XXXXXX",6) ==0
					&& strncmp(cAcctType,"XX",2) ==0)
				{
					obj_type ="2";
					sTempParas.assign(cGradeId);
				}
				else if(strncmp(cAcctNo,"XXXXXXXX",8) == 0
					&& strncmp(cGradeId,"XXXXXX",6) ==0
					&& strncmp(cBranchId,"XXXXXX",6) !=0
					&& strncmp(cAcctType,"XX",2) ==0)
				{
					obj_type ="3";
					sTempParas.assign(cBranchId);
				}
				else if (strncmp(cAcctNo,"XXXXXXXX",8) == 0
					&& strncmp(cGradeId,"XXXXXX",6) ==0
					&& strncmp(cBranchId,"XXXXXX",6) ==0
					&& strncmp(cAcctType,"XX",2) !=0)
				{
					obj_type ="4";
					sTempParas.assign(cAcctType);
				}
				else
				{
					obj_type = "0";
					sTempParas= "0";
				}
				alm_resutl.AddValue(obj_type);
				alm_resutl.AddValue(sTempParas);
				alm_resutl.AddValue(ToString<double>(dDebtExchValue));
				alm_resutl.AddValue(ToString<double>(dDebtCallValue));

				//��ѯ���ռ�������
				sSql = "select a.grade_id, b.grade_name, b.risk_type, a.grade_vale_down, a.grade_vale_up from risk_grade_cust a left join risk_grade b ";
					sSql += "on a.grade_id = b.grade_id where a.acct_no = :f1<char[16]> and a.acct_grade_id = :f2<char[9]> and a.branch_id = :f3<char[13]> and a.acct_type = :f4<char[3]>";
				otl_stream i(1, sSql.c_str(), GetOtlConn());
				i << cAcctNo << cGradeId << cBranchId << cAcctType;

				while (!i.eof())
				{
					i >> iGradeId >> cGradeName >> sRiskType >> dGradeValueDown >> dGradeValueUp;
					obj_ListMsg.clear();
					obj_ListMsg.AddValue(iGradeId);
					obj_ListMsg.AddValue(cGradeName);				
					obj_ListMsg.AddValue(dGradeValueDown);
					obj_ListMsg.AddValue(dGradeValueUp);
					obj_ListMsg.AddValue(sRiskType);

					alm_resutl.AddValue(obj_ListMsg);				
				}
				rec_ListMsg.AddValue(alm_resutl);				
			}
			if(rec_ListMsg.size() <=0 )
			{
				strcpy(stHeaderRsp.rsp_code, RSP_NO_RECORD.c_str());
				pktRsp.AddParameter("alm_result", "δ�ҵ��������ļ�¼");
			}
		}
		else if (stBodyReq.oper_flag == 1)
		{
			
			if(1 == CheckAcctNoIsExists(stBodyReq.obj_type, stBodyReq.obj_id))
			{
				//�޸ķ����������ñ���Ӧ��¼
				sSql = "update cust_debt_line set debt_exch_value = :f2<double>, debt_call_value = :f3<double> where acct_no = :f4<char[16]> and acct_grade_id = :f5<char[9]> and branch_id = :f6<char[13]> and acct_type = :f7<char[3]>";
				otl_stream o(1, sSql.c_str(), GetOtlConn());
				o << atof(stBodyReq.debt_exch_value.c_str()) << atof(stBodyReq.debt_call_value.c_str()) << cAcctNo << cGradeId << cBranchId << cAcctType;

				//�޸ķ��ռ������ñ���Ӧ��¼	��ɾ��ԭ��¼���ٲ����¼�¼
				sSql = "delete from risk_grade_cust where acct_no = :f1<char[16]> and acct_grade_id = :f2<char[9]> and branch_id = :f3<char[13]> and acct_type = :f4<char[3]>";
				otl_stream i(1, sSql.c_str(), GetOtlConn());
				i << cAcctNo << cGradeId << cBranchId << cAcctType;

				sSql = "insert into risk_grade_cust values(:f1<char[16]>, :f2<char[13]>, :f3<char[3]>, :f4<char[9]>, :f5<char[3]>, :f6<double>, :f7<double>)";
				otl_stream p(1, sSql.c_str(), GetOtlConn());
				for (unsigned int i=0; i<stBodyReq.obj_content.size(); i++)
				{
					alm_resutl.clear();
					stBodyReq.obj_content.GetValue(i, alm_resutl);

					p << cAcctNo << cBranchId << cAcctType << cGradeId << alm_resutl.GetValue<string>(0).c_str() << alm_resutl.GetValue<double>(1) << alm_resutl.GetValue<double>(2);
				}

				//ͬ���ڴ����ݿ�
				setCustRiskInfo(stBodyReq.obj_type, stBodyReq.obj_id, atof(stBodyReq.debt_exch_value.c_str()), atof(stBodyReq.debt_call_value.c_str()), stBodyReq.obj_content, GetOtlConn());
			}
			else
			{
				strcpy(stHeaderRsp.rsp_code,RSP_NO_CUST.c_str());
				pktRsp.AddParameter("rsp_msg", "�ͻ�"+stBodyReq.obj_id+"������,�����!");
			}			
		}
		else if (stBodyReq.oper_flag == 2)
		{

			if(1 == CheckAcctNoIsExists(stBodyReq.obj_type, stBodyReq.obj_id))
			{	
				//����ǰ�Ƚ��м����û�д���
				sSql = "select debt_exch_value, debt_call_value from cust_debt_line where acct_no = :f1<char[16]> and acct_grade_id = :f2<char[9]> and branch_id = :f3<char[16]> and acct_type = :f4<char[3]>";
				otl_stream check(1, sSql.c_str(), GetOtlConn());
				check<< cAcctNo << cGradeId << cBranchId << cAcctType;
				if(!check.eof())
				{
					strcpy(stHeaderRsp.rsp_code,RSP_RISK_PARA.c_str());
					pktRsp.AddParameter("rsp_msg", "�ò����Ѿ����ù�");
				}
				else
				{
					//��������������ñ�
					sSql = "insert into cust_debt_line values(:f1<char[16]>, :f2<char[13]>, :f3<char[3]>, :f4<char[9]>, :f6<double>, :f7<double>)" ;
					otl_stream o(1, sSql.c_str(), GetOtlConn());
					o << cAcctNo << cBranchId << cAcctType << cGradeId << atof(stBodyReq.debt_exch_value.c_str()) << atof(stBodyReq.debt_call_value.c_str());

					//������ռ������ñ�
					sSql = "insert into risk_grade_cust values(:f1<char[16]>, :f2<char[13]>, :f3<char[3]>, :f4<char[9]>, :f5<double>, :f6<double>, :f7<double>)";
					otl_stream p(1, sSql.c_str(), GetOtlConn());
					for (unsigned int i=0; i<stBodyReq.obj_content.size(); i++)
					{
						alm_resutl.clear();
						stBodyReq.obj_content.GetValue(i, alm_resutl);

						p << cAcctNo << cBranchId << cAcctType << cGradeId << alm_resutl.GetValue<double>(0)<< alm_resutl.GetValue<double>(1) << alm_resutl.GetValue<double>(2);
					}

					//ͬ�����ڴ����ݿ�
					setCustRiskInfo(stBodyReq.obj_type, stBodyReq.obj_id, atof(stBodyReq.debt_exch_value.c_str()), atof(stBodyReq.debt_call_value.c_str()), stBodyReq.obj_content, GetOtlConn());
				}
			}
			else
			{
				strcpy(stHeaderRsp.rsp_code, RSP_NO_CUST.c_str());
				pktRsp.AddParameter("rsp_msg", "�ͻ�"+stBodyReq.obj_id+"������,�����!");
			}			
		}
		else if (stBodyReq.oper_flag == 3)
		{
			//ɾ�������������ñ���Ӧ��¼
			sSql = "delete from cust_debt_line where acct_no = :f1<char[16]> and acct_grade_id = :f2<char[9]> and branch_id = :f3<char[13]> and acct_type = :f4<char[3]>";
			otl_stream o(1, sSql.c_str(), GetOtlConn());
			o << cAcctNo << cGradeId << cBranchId << cAcctType;
			CRLog(E_PROINFO, "sSql: %s", sSql.c_str());
			CRLog(E_PROINFO, "cAcctNo=%s,cGradeId=%s,cBranchId=%s,cAcctType=%s",  cAcctNo, cGradeId, cBranchId, cAcctType);

			//ɾ�����ռ������ñ���Ӧ��¼
			sSql = "delete from risk_grade_cust where acct_no = :f1<char[16]> and acct_grade_id = :f2<char[9]> and branch_id = :f3<char[13]> and acct_type = :f4<char[3]>";
			otl_stream i(1, sSql.c_str(), GetOtlConn());
			i << cAcctNo << cGradeId << cBranchId << cAcctType;
			CRLog(E_PROINFO, "sSql: %s", sSql.c_str());
			CRLog(E_PROINFO, "cAcctNo=%s,cGradeId=%s,cBranchId=%s,cAcctType=%s",  cAcctNo, cGradeId, cBranchId, cAcctType);

			//ͬ�����ڴ����ݿ�
			setCustRiskInfo(stBodyReq.obj_type, stBodyReq.obj_id, GetOtlConn());
		}

	}
	catch(otl_exception& p)
	{
		CRLog(E_ERROR, "DB:MSG:%s\nTEXT:%s\nVARINFO:%s", p.msg, p.stm_text, p.var_info); 
		Rollback();
		strcpy(stHeaderRsp.rsp_code, RSP_EXCEPTION.c_str());
		pktRsp.AddParameter("rsp_msg", (const char *)p.msg);
	}

	//������Ӧ����
	stBodyRsp.oper_flag = stBodyReq.oper_flag;
	stBodyRsp.alm_result = rec_ListMsg;
	

	pktRsp.SetHeader(stHeaderRsp);
	CPacketStructTradeRisk::Struct2Packet(stBodyRsp,pktRsp);

	//ת������
	m_pRiskCpMgr->ToInterfaceF1(pktRsp,m_ulKey);

	return 0;
};

/*
������������֤����ͻ��Ƿ���ϵͳ�д���
���������const string & �������
			  const string & ���ֵ
�����������
����ֵ	��1--��ʾ���ڣ�0--������
*/

int CMainServiceHandler::CheckAcctNoIsExists(const string &sObjType, const string &sValue)
{
	int flag=0;
	//����������Ϣ	1���ͻ�		2���ͻ�����		3����������		4���˻�����

	if("1" == sObjType)
	{
		CCustomer* p=m_pMemDb->GetCustTble().GetCustomer(sValue);
		if(p != 0)
			flag = 1;
		else
			flag = 0;
	}
	else
		flag = 1;
	CRLog(E_DEBUG, "sObjType:%s sValue:%s flag =%d ", sObjType.c_str(),sValue.c_str(),flag); 
	return flag;



}

/*
�������������ղ������ø���ʱͬ���ڴ�ͻ�������Ϣ
���������const string & �������
			  const string & ���ֵ
		  double ���ǿƽ��
		  double ׷����
		  ArrayListMsg ���յȼ���Ϣ
		  otl_connect & ���ݿ�����
�����������
����ֵ	��void
*/
void CMainServiceHandler::setCustRiskInfo(const string &sObjType, const string &sValue, double dExchValue, double dCallValue, ArrayListMsg almGradeCust, otl_connect& dbConnection)
{
	char cAcctNo[16];	
	char cGradeName[21];
	short sRiskType;
	ArrayListMsg almRiskGrade;
	ArrayListMsg alm_resutl;
	string sSql = "";

	memset(cAcctNo, 0, sizeof(cAcctNo));
	memset(cGradeName, 0, sizeof(cGradeName));

	if (sObjType == "1")
	{
		//�ͻ���
		sSql = "select acct_no from cust_info where acct_no = '" + sValue + "'";
	}
	else if (sObjType == "2")
	{
		//�ͻ�����
		sSql = "select acct_no "
				"from cust_info "
				"where grade_id = '" + sValue + "' "
				"and acct_no not in (select distinct acct_no from cust_debt_line)";
	}
	else if (sObjType == "3")
	{
		//��������
		sSql = "select acct_no "
				"from cust_info "
				"where branch_id = '" + sValue + "' "
				"and acct_no not in (select distinct acct_no from cust_debt_line) "
				"and grade_id not in (select distinct acct_grade_id from cust_debt_line)";
	}
	else if (sObjType == "4")
	{
		//�˻�����
		sSql = "select acct_no "
				"from cust_info "
				"where acct_type = '" + sValue + "' "
				"and acct_no not in (select distinct acct_no from cust_debt_line) "
				"and grade_id not in (select distinct acct_grade_id from cust_debt_line) "
				"and branch_id not in (select distinct branch_id from cust_debt_line)";
	}
	else if(sObjType == "0")
	{
		//���пͻ�
		sSql ="select a.acct_no "
				"from cust_info a "
				"where a.acct_no not in (select distinct acct_no from cust_debt_line) "
				"and a.grade_id not in (select distinct acct_grade_id from cust_debt_line) "
				"and a.branch_id not in (select distinct branch_id from cust_debt_line) "
				"and a.acct_type not in (select distinct acct_type from cust_debt_line)";
	}

	//������յȼ���Ϣ
	string sRiskGradeSql = "select grade_name, risk_type from risk_grade where grade_id = :f1<int>";
	otl_stream oGrade(1, sRiskGradeSql.c_str(), dbConnection);
	for (unsigned int i=0; i<almGradeCust.size(); i++)
	{
		ArrayListMsg aMsg = almGradeCust.GetValue(i);
		oGrade << aMsg.GetValue<int>(0);
		oGrade >> cGradeName >> sRiskType;

		alm_resutl.clear();
		alm_resutl.AddValue(aMsg.GetValue<int>(0));
		alm_resutl.AddValue(cGradeName);				
		alm_resutl.AddValue(aMsg.GetValue<double>(1));
		alm_resutl.AddValue(aMsg.GetValue<double>(2));
		alm_resutl.AddValue(sRiskType);

		almRiskGrade.AddValue(alm_resutl);

	}

	//��ȡ��Ҫͬ���ڴ���Ŀͻ�
	otl_stream oCust(1, sSql.c_str(), dbConnection);
	while (!oCust.eof())
	{
		oCust >> cAcctNo;

		//ͬ���ڴ���Ϣ
		m_pMemDb->GetCustTble().UpdateCustRisk(cAcctNo, dExchValue, dCallValue, almRiskGrade);
	}
}

/*
�������������ղ�������ɾ��ʱͬ���ڴ�ͻ�������Ϣ
���������const string & �������
		  const string & ���ֵ
		  otl_connect & ���ݿ�����
�����������
����ֵ	��void
*/
void CMainServiceHandler::setCustRiskInfo(const string &sObjType, const string &sValue, otl_connect& dbConnection)
{
	char cAcctNo[16];		//�ͻ���
	char cGradeId[9];		//�ͻ�����
	char cBranchId[16];		//��������
	char cAcctType[3];		//�˻�����
	char cGradeName[21];	//��������
	short sRiskType;
	int iGradeId;
	double dDebtExchValue = 0.0;
	double dDebtCallValue = 0.0;
	double dGradeValueDown = 0.0;
	double dGradeValueUp = 0.0;
	ArrayListMsg almRiskGrade;
	ArrayListMsg alm_resutl;
	string sSql = "";

	memset(cAcctNo, 0, sizeof(cAcctNo));
	memset(cGradeId, 0, sizeof(cGradeId));
	memset(cBranchId, 0, sizeof(cBranchId));
	memset(cAcctType, 0, sizeof(cAcctType));
	memset(cGradeName, 0, sizeof(cGradeName));
	
	string sAcctNo = "XXXXXXXX";

	if (sObjType == "1")
	{
		//�ͻ���
		sSql = "select "
					"z.acct_no, "
					"nvl((select acct_grade_id from cust_debt_line where acct_grade_id = z.grade_id), 'XXXXXX') grade_id, "
					"z.branch_id, "
					"nvl((select acct_type from cust_debt_line where acct_type = z.acct_type), 'XX') acct_type "
				"from cust_info z "
				"where z.acct_no = '" + sValue + "'";
	}
	else if (sObjType == "2")
	{
		//�ͻ�����
		sSql = "select "
					"z.acct_no, "
					"'XXXXXX' grade_id, "
					"z.branch_id, "
					"nvl((select acct_type from cust_debt_line where acct_type = z.acct_type), 'XX') acct_type "
				"from cust_info z "
				"where z.grade_id = '" + sValue + "' "
				"and z.acct_no not in (select distinct acct_no from cust_debt_line)";
	}
	else if (sObjType == "3")
	{
		//��������
		sSql = "select "
					"z.acct_no, "
					"'XXXXXX' grade_id, "
					"z.branch_id, "
					"nvl((select acct_type from cust_debt_line where acct_type = z.acct_type), 'XX') acct_type "
				"from cust_info z "
				"where z.branch_id = '" + sValue + "' "
				"and z.acct_no not in (select distinct acct_no from cust_debt_line) "
				"and z.grade_id not in (select distinct acct_grade_id from cust_debt_line)";
	}
	else if (sObjType == "4")
	{
		//�˻�����
		sSql = "select "
					"z.acct_no, "
					"'XXXXXX' grade_id, "
					"'XXXXXX' branch_id, "
					"'XX' acct_type "
				"from cust_info z "
				"where z.acct_type = '" + sValue + "' "
				"and z.acct_no not in (select distinct acct_no from cust_debt_line) "
				"and z.grade_id not in (select distinct acct_grade_id from cust_debt_line) "
				"and z.branch_id not in (select distinct branch_id from cust_debt_line)";
	}

	//��ȡ��Ҫͬ���ڴ���Ŀͻ�
	otl_stream oCust(1, sSql.c_str(), dbConnection);
	while (!oCust.eof())
	{
		oCust >> cAcctNo >> cGradeId >> cBranchId >> cAcctType;

		//���ڷ�ɾ���˻����͵ģ�����Ҫ���Ҵ�����������
		if (sObjType != "4" && (strcmp(cGradeId, "XXXXXX") == 0))
		{
	        //otl_stream oGetBranch(1, "select x.branch_id from (select level lv, branch_id from branch_info start with branch_id = :f1<char[13]> connect by prior parent_branch_id = branch_id order by lv) y, cust_debt_line x  where x.branch_id = y.branch_id and rownum = 1", dbConnection);		
			otl_stream oGetBranch(1, "select x.branch_id from (select level lv, branch_id from branch_info start with branch_id = :f1<char[13]> connect by prior parent_branch_id = branch_id order by lv) y, cust_debt_line x  where x.branch_id = y.branch_id and rownum = 1", dbConnection);
			oGetBranch << cBranchId;
			if (!oGetBranch.eof())
			{
				oGetBranch >> cBranchId;
			}
			else
			{
				strcpy(cBranchId, "XXXXXX");
			}
		}

		//��ѯ������Ϣ����
		sSql = "select debt_exch_value, debt_call_value from cust_debt_line where acct_no = 'XXXXXXXX' and acct_grade_id = :f1<char[9]> and branch_id = :f2<char[16]> and acct_type = :f3<char[3]>";
		otl_stream oGetDebtLine(1, sSql.c_str(), dbConnection);
		oGetDebtLine << cGradeId << cBranchId << cAcctType;
		if (!oGetDebtLine.eof())
		{
			oGetDebtLine >> dDebtExchValue >> dDebtCallValue;
		}

		//��ѯ���ռ�������
		sSql = "select a.grade_id, b.grade_name, b.risk_type, a.grade_vale_down, a.grade_vale_up from risk_grade_cust a left join risk_grade b on a.grade_id = b.grade_id where a.acct_no = 'XXXXXXXX' and a.acct_grade_id = :f1<char[9]> and a.branch_id = :f2<char[16]> and a.acct_type = :f3<char[3]>";
		otl_stream oGetRiskGrade(1, sSql.c_str(), GetOtlConn());
		oGetRiskGrade << cGradeId << cBranchId << cAcctType;

		almRiskGrade.clear();
		while (!oGetRiskGrade.eof())
		{
			oGetRiskGrade >> iGradeId >> cGradeName >> sRiskType >> dGradeValueDown >> dGradeValueUp;

			alm_resutl.clear();
			alm_resutl.AddValue(iGradeId);
			alm_resutl.AddValue(cGradeName);				
			alm_resutl.AddValue(dGradeValueDown);
			alm_resutl.AddValue(dGradeValueUp);
			alm_resutl.AddValue(sRiskType);

			almRiskGrade.AddValue(alm_resutl);
		}

		//ͬ���ڴ���Ϣ
		m_pMemDb->GetCustTble().UpdateCustRisk(cAcctNo, dDebtExchValue, dDebtCallValue, almRiskGrade);
	}
}
#endif