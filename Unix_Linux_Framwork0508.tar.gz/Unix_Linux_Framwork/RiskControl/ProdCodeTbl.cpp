#include "ProdCodeTbl.h"
#include "Logger.h"
#include "DB_Version.h" 
//#include "VersionMacro.h"

CProdCodeTbl::CProdCodeTbl()
{

}

CProdCodeTbl::~CProdCodeTbl()
{
	Finish();
}

//##ModelId=49169696031C
int CProdCodeTbl::Index(const string& sProdCode)
{
	CGessGuard guard(m_mutexTbl);

	map<string,PROD_CODE>::iterator it = m_mapProdCode.find(sProdCode);
	if (it != m_mapProdCode.end())
	{
		return it->second.nIndex;
	}
	else
	{
		return -1;
	}
}

int CProdCodeTbl::GetMeasureUnit(const string& sProdCode, double& dlUnit)
{
	CGessGuard guard(m_mutexTbl);

	map<string,PROD_CODE>::iterator it = m_mapProdCode.find(sProdCode);
	if (it != m_mapProdCode.end())
	{
		dlUnit = it->second.dlMeasureUnit;
		return 0;
	}
	return -1;
}

int CProdCodeTbl::GetVarietyType(const string& sProdCode, int& nType)
{
	CGessGuard guard(m_mutexTbl);

	map<string,PROD_CODE>::iterator it = m_mapProdCode.find(sProdCode);
	if (it != m_mapProdCode.end())
	{
		nType = it->second.nVarietyType;
		return 0;
	}
	return -1;
}

int CProdCodeTbl::GetRecordSet(map<string,PROD_CODE>& mapProd)
{
	CGessGuard guard(m_mutexTbl);

	map<string,PROD_CODE>::iterator it;
	for (it = m_mapProdCode.begin(); it != m_mapProdCode.end(); ++it)
	{
		mapProd.insert(map<string,PROD_CODE>::value_type((*it).first,(*it).second));
	}
	return 0;
}

int CProdCodeTbl::Init(otl_connect& dbConnection)
{
	char cProdCode[11];			//��Լ����
	char cProdName[32];			//��Լ����
	char cVarietyType[3];		//Ʒ������
	char cExchUnit[3];			//���׵�λ
	char cMeasureUnit[25];		//������λ
	char cPriceTick[25];		//��С������λ
	int iIndex = 0;				//��Լ������
	char cUpLimitRatio[30];     //��ͣ�����  add by liuwei 2012-3-21
	char cDownLimitRatio[30];   //��ͣ�����  add by liuwei 2012-3-21

	PROD_CODE stProdCode;		//��Լ������ṹ
	string sSql = "";

	memset(cProdCode, 0, sizeof(cProdCode));
	memset(cProdName, 0, sizeof(cProdName));
	memset(cExchUnit, 0, sizeof(cExchUnit));
	memset(cMeasureUnit, 0, sizeof(cMeasureUnit));

	try
	{
		CGessGuard guard(m_mutexTbl);

#ifdef _VER_25_DB2
		sSql = "select prod_code, prod_name, variety_type,exch_unit, FG_CovToChar(Measure_unit),FG_CovToChar(tick) FG_CovToChar(upper_limit_value), FG_CovToChar(lower_limit_value) from Prod_code_def order by market_id desc";
#else
		sSql = "select prod_code, prod_name, variety_type,exch_unit, to_char(Measure_unit),to_char(tick), to_char(upper_limit_value), to_char(lower_limit_value) from Prod_code_def order by market_id desc";
#endif

		otl_stream o(1, sSql.c_str(), dbConnection);

		while (!o.eof())
		{
			o >> cProdCode >> cProdName >> cVarietyType >> cExchUnit >> cMeasureUnit >> cPriceTick >> cUpLimitRatio >> cDownLimitRatio;

			stProdCode.nIndex = iIndex;
			stProdCode.sProdCode = cProdCode;
			stProdCode.sProdName = cProdName;
			stProdCode.sExchUnit = cExchUnit;
			stProdCode.nVarietyType = atoi(cVarietyType);
			stProdCode.dlMeasureUnit = atof(cMeasureUnit);
			stProdCode.dlMinPriceTick = atof(cPriceTick);
			stProdCode.dlUpLimitRatio = atof(cUpLimitRatio);
			stProdCode.dlDownLimitRatio = atof(cDownLimitRatio);

			//����Լ�����¼����map
			m_mapProdCode[stProdCode.sProdCode] = stProdCode;

			//��Լ�����ŵ���
			iIndex++;
		}
	}
	catch(otl_exception& p)
	{
		CRLog(E_ERROR, "otl exception:%s,%s,%s,%s", p.msg, p.stm_text, p.sqlstate, p.var_info);
	}

	return 0;
}

//��������
void CProdCodeTbl::Finish()
{
	CGessGuard guard(m_mutexTbl);
	m_mapProdCode.clear();
}

//��ȡĳһ��Լ��Ϣ add by liuwei 2012-3-21
int CProdCodeTbl::GetProdInfo(const string& sProdCode, PROD_CODE& ProdCode)
{
	CGessGuard guard(m_mutexTbl);

	map<string,PROD_CODE>::iterator it = m_mapProdCode.find(sProdCode);
	if (it != m_mapProdCode.end())
	{
		ProdCode = it->second;
	}
	else
	{
		return -1;
	}

	return 0;
}

//����ĳһ��Լ��Ϣ add by liuwei 2012-3-23
int CProdCodeTbl::SetProdInfo(const string& sProdCode, PROD_CODE& ProdCode)
{
	CGessGuard guard(m_mutexTbl);

	map<string, PROD_CODE>::iterator it = m_mapProdCode.find(sProdCode);
	if (it != m_mapProdCode.end())
	{
		it->second = ProdCode;
	}
	else
	{
		return -1;
	}

	return 0;
}