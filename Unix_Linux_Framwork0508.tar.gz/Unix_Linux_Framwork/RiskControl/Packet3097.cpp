#include "MainServiceHandler.h"

// F1 �ӿ� [3097]ƽ��������������� ��ҵ��ʵ��
int CMainServiceHandler::OnTryCloseReq(CTradePacket& pkt)
{
	HEADER_REQ stHeaderReq;
	TryCloseReq stBodyReq;

	HEADER_RSP stHeaderRsp;
	TryCloseRsp stBodyRsp;

	pkt.GetHeader(stHeaderReq);
	CPacketStructTradeRisk::Packet2Struct(stBodyReq, pkt);

	CPacketStructTradeRisk::HeadReq2Rsp(stHeaderReq,stHeaderRsp);

	CTradePacket pktRsp;

	//ҵ��ʵ��......
	FORCE_ORDER stFC;
	vector<FORCE_ORDER> vecFC;

#ifndef _VER_25_DB2
	//���ύ����ǿƽ��
	vector <CEntrFlow> vecdelegateFoceOrder;

	//��ȡ�Ѿ����ɵ�ǿƽί�е���Ϣ
	vecFC.clear();

	m_pMemDb->GetEntrFlowTbl().GetForceEntrFlowOrder(stBodyReq.acct_no,vecdelegateFoceOrder);
	vector <CEntrFlow>::iterator itFcoreOrder= vecdelegateFoceOrder.begin();
	for(;itFcoreOrder != vecdelegateFoceOrder.end();++itFcoreOrder )
	{

		stFC.sProdCode = itFcoreOrder->GetProdCode();
		stFC.uiNum = itFcoreOrder->GetRemainAmount();
		stFC.dlClosePrice = itFcoreOrder->GetEntrPrice();
		stFC.ucDir = itFcoreOrder->GetEntrDir();
		vecFC.push_back(stFC);
	}
	CRLog(E_DEBUG,"������ǿ����:%d ",vecFC.size());
#endif

	for(size_t i=0; i<stBodyReq.close_para.size(); i++)
	{  
		ArrayListMsg aMsg = stBodyReq.close_para.GetValue(i);
		stFC.sProdCode = aMsg.GetValue<string>(0);
		unsigned char ucDir = aMsg.GetValue<string>(1).c_str()[0];
		if (gc_cProdBuy == ucDir)
		{
			stFC.ucDir = gc_cShort;
		}
		else if(gc_cProdSell == ucDir)
		{
			stFC.ucDir = gc_cLong;
		}
		else
		{
			strcpy(stHeaderRsp.rsp_code,RSP_PARAM_ERROR.c_str());
			pktRsp.AddParameter("rsp_msg", "�����������");	
			stBodyRsp.oper_flag = stBodyReq.oper_flag;
			pktRsp.SetHeader(stHeaderRsp);
			CPacketStructTradeRisk::Struct2Packet(stBodyRsp,pktRsp);
			//ת������
			m_pRiskCpMgr->ToInterfaceF1(pktRsp,m_ulKey);
			return 0;
		}
		
		stFC.dlClosePrice = aMsg.GetValue<double>(2);
		stFC.uiNum = aMsg.GetValue<unsigned int>(3);
		vecFC.push_back(stFC);
	}



	CQuotationTbl& tblQuotation = m_pMemDb->GetQuotationTbl();

	//double dlPrice[gc_nProdNum];
	//tblQuotation.GetPriceArray(dlPrice,gc_nProdNum);

	vector<double> dlPrice=tblQuotation.GetPriceArray();


	RISK_DATA stRsk;
	CCustomer* pCustomer = m_pMemDb->GetCustTble().GetCustomer(stBodyReq.acct_no);
	if (0 == pCustomer)
	{
		stBodyRsp.oper_flag = 0;
		strcpy(stHeaderRsp.rsp_code, RSP_NO_CUST_DATA.c_str());
		pktRsp.AddParameter("rsp_msg", "û�д˿ͻ�����");
	}
	else if(pCustomer->RiskGrade()==gc_cRiskGradeNormal||pCustomer->RiskGrade()==gc_cRiskGradeCall)
	{
		stBodyRsp.oper_flag = 0;
		strcpy(stHeaderRsp.rsp_code, RSP_CUST_SAFE.c_str());
		pktRsp.AddParameter("rsp_msg", pCustomer->CustAbbr()+"���Ѿ�����ǿƽ�ͻ�");
	}
	else
	{
		pCustomer->TryCloseCalculate(dlPrice,vecFC,stRsk);
		stBodyRsp.oper_flag = 0;
		stBodyRsp.cust_id = stBodyReq.acct_no;	//�ͻ���
		stBodyRsp.margin_exch = ToString(-stRsk.dlMarginExch);//Ԥ�ƽ�������֤��
		stBodyRsp.margin_mem= ToString(-stRsk.dlMarginMem);//Ԥ�ƻ�Ա��֤��
		stBodyRsp.curr_bal = ToString(stRsk.dlCapital);	//Ԥ�ƿ����ʽ�	
		stBodyRsp.margin_total = ToString(-stRsk.dlMargin);//Ԥ���ܱ�֤��
		stBodyRsp.float_surplus = ToString(stRsk.dlBalance);//Ԥ�Ƹ���ӯ��
		stBodyRsp.call_debt = ToString(stRsk.dlDebtCall);//Ԥ��׷�����
		stBodyRsp.risk_degree1 = ToString(stRsk.dlRiskDegree1);//Ԥ�Ʒ��ն�1
		stBodyRsp.risk_degree2 = ToString(stRsk.dlRiskDegree2);//Ԥ�Ʒ��ն�2
		stBodyRsp.risk_grade = ToString(stRsk.usRiskGrade);//Ԥ�Ʒ��յȼ�
		stBodyRsp.risk_type = ToString(stRsk.usRiskType);//Ԥ�Ʒ�������
	}

	//������Ӧ����	
	pktRsp.SetHeader(stHeaderRsp);
	CPacketStructTradeRisk::Struct2Packet(stBodyRsp,pktRsp);

	//ת������
	m_pRiskCpMgr->ToInterfaceF1(pktRsp,m_ulKey);

	return 0;
};
