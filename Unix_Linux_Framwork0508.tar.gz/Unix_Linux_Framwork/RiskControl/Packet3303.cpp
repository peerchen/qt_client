#include "MainServiceHandler.h"

int CMainServiceHandler::OnHandlSmsMessageReq(CTradePacket& pkt)
{

	HEADER_REQ stHeaderReq;
	HandleSmsReq stBodyReq;


	HEADER_REQ stHeaderReqA2;
	CTradePacket pktReqA2;
	CTradePacket pktRsp;


	//3303���׷���

	HEADER_RSP stHeaderRsp;
	HandleSmsRsp stBodyRsp;

	pkt.GetHeader(stHeaderReq);
	CPacketStructTradeRisk::Packet2Struct(stBodyReq, pkt);

	CustRiskInfo CustRinfo;
	std::string content="";
	std::string sCustNo; //�ͻ���
	std::string sAcctType; //�˻�����
	std::string sRiskType; //���յȼ�

	//������Ӧ����
	CPacketStructTradeRisk::HeadReq2Rsp(stHeaderReq,stHeaderRsp);
   try
	{ 
        if(stBodyReq.oper_flag == 1)
		{	

			for(size_t i=0; i<stBodyReq.alm_result.size(); i++)
			{
				try
				{
					content.clear();			

					sCustNo=stBodyReq.alm_result.GetValue<string>(i);
					m_pMemDb->GetCustTble().GetCustomer(sCustNo)->GetRiskInfo(CustRinfo);
					sAcctType=m_pMemDb->GetCustTble().GetCustomer(sCustNo)->AcctType();
					sRiskType=m_pMemDb->GetCustTble().GetCustomer(sCustNo)->RiskType()+'0';
					memset(&stHeaderReqA2,0x00,sizeof(stHeaderReqA2));
					sprintf(stHeaderReqA2.seq_no,"%s","000000000");
					sprintf(stHeaderReqA2.msg_type,"%s","1");
					sprintf(stHeaderReqA2.exch_code,"%s","3056");
					sprintf(stHeaderReqA2.msg_flag,"%s",gc_sPktTypeTrade.c_str());
					sprintf(stHeaderReqA2.term_type,"%s",gc_sTermTypeRsk.c_str());
					sprintf(stHeaderReqA2.user_type,"%s",gc_sUserTypeOper.c_str());
					sprintf(stHeaderReqA2.user_id,"%s",CustRinfo.sAcctNo.c_str());

					char szTmp[128];
					memset(szTmp,0x00,128);
					sprintf(szTmp,"%c%ds",'%',BRANCHID);
					sprintf(stHeaderReqA2.branch_id,szTmp,CustRinfo.sAgentID.c_str());

					sprintf(stHeaderReqA2.c_teller_id1,"%s","");
					sprintf(stHeaderReqA2.c_teller_id2,"%s","");

					pktReqA2.SetHeader(stHeaderReqA2);
							
					pktReqA2.AddParameter("oper_flag",1);
					pktReqA2.AddParameter("source_type",3);   //1-���ж���,	2-��������,	3-�ֹ�����
					pktReqA2.AddParameter("cust_abbr",CustRinfo.sCustAbbr);

					pktReqA2.AddParameter("acct_no",CustRinfo.sAcctNo);
					pktReqA2.AddParameter("branch_id",CustRinfo.sAgentID);
					pktReqA2.AddParameter("agent_name",CustRinfo.sAgentName);
					pktReqA2.AddParameter("bk_acct_no",CustRinfo.sBankAcctNo);  //�˺�
					pktReqA2.AddParameter("mobile",CustRinfo.sCustMoblie);  //�ֻ�����

					if( 0 != GetSmsCotent(CustRinfo,content))
					{
						CRLog(E_ERROR, "CustNo=[%s],mobile=[%s]�������Ÿ�ʽʧ��!",CustRinfo.sAcctNo.c_str(),CustRinfo.sCustMoblie.c_str()); 
						continue;
					}
					pktReqA2.AddParameter("content",content); //��������
					pktReqA2.AddParameter("risk_from_type",CustRinfo.stRiskDataFrom.usRiskType); //ת��ǰ��������
					pktReqA2.AddParameter("risk_to_type",CustRinfo.stRiskDataTo.usRiskType);   //ת�ƺ��������
					pktReqA2.AddParameter("risk_from_grade",CustRinfo.stRiskDataFrom.usRiskGrade);
					pktReqA2.AddParameter("risk_to_grade",CustRinfo.stRiskDataTo.usRiskGrade);

					pktReqA2.AddParameter("risk_yday_type",CustRinfo.usRiskTypeYda);
					pktReqA2.AddParameter("risk_yday_grade",CustRinfo.usRiskGradeYda);
					pktReqA2.AddParameter("debt_call",CustRinfo.dlDebtLineCall);

					pktReqA2.AddParameter("surplus",CustRinfo.stRiskDataTo.dlBalance);
					pktReqA2.AddParameter("risk_deg1",CustRinfo.stRiskDataTo.dlRiskDegree1);
					pktReqA2.AddParameter("risk_deg2",CustRinfo.stRiskDataTo.dlRiskDegree2);
					pktReqA2.AddParameter("margin_mem",CustRinfo.stRiskDataTo.dlMarginMem);
					pktReqA2.AddParameter("margin_exch",CustRinfo.stRiskDataTo.dlMarginExch);
					pktReqA2.AddParameter("margin",CustRinfo.stRiskDataTo.dlMargin);
					pktReqA2.AddParameter("curr_can_use",CustRinfo.stRiskDataTo.dlCapital);
					pktReqA2.AddParameter("req_type",0);
					pktReqA2.AddParameter("try_times",0);
					m_pRiskCpMgr->ToInterfaceSms(pktReqA2,m_ulKey);
				}
				catch(std::exception e)
				{
					CRLog(E_ERROR,"exception:%s!",e.what());
					continue;
				}
				catch(...)
				{
					CRLog(E_ERROR,"%s","Unknown exception!");
					continue;
				}
			}   
			  strcpy(stHeaderRsp.rsp_code, "00000000"); 
		}
		else
		{
			strcpy(stHeaderRsp.rsp_code, RSP_PARAM_ERROR.c_str());
			content="������ʶ��������!";
			pktRsp.AddParameter("rsp_msg", content);
		}
			  
    }
   catch(std::exception e)
   {
	   strcpy(stHeaderRsp.rsp_code, RSP_EXCEPTION.c_str());
	   content="���ŷ��ʹ����쳣,"+ToString(e.what());
		   
	   pktRsp.AddParameter("rsp_msg",content);
   }
   catch(...)
   {
	   strcpy(stHeaderRsp.rsp_code, RSP_UNKNOWN_EXCEPTION.c_str());
	   content="���ŷ��ʹ���ʧ��,δ֪����!";
	   pktRsp.AddParameter("rsp_msg", content);
   }
   pktRsp.SetHeader(stHeaderRsp);
   stBodyRsp.oper_flag=stBodyReq.oper_flag;
   CPacketStructTradeRisk::Struct2Packet(stBodyRsp,pktRsp);

   //ת������
   m_pRiskCpMgr->ToInterfaceF1(pktRsp,m_ulKey);
  	return 0;

}

int CMainServiceHandler::GetSmsCotent(CustRiskInfo CustRinfo ,std::string& content)
{	
	std::string sRisk_Type="";
	try
	{
		//sRisk_Type=std::string(CustRinfo.stRiskDataTo.usRiskType);
		//sprintf(sRisk_Type,"%d",
		sRisk_Type=ToString<unsigned short>(CustRinfo.stRiskDataTo.usRiskType);

		//��ȡָ���ȼ��Ķ���֪ͨ��ʽ
		if( 0!=m_pMemDb->GetSmsFormatTbl().GetSmsFormatMap(CustRinfo.sAcctType,sRisk_Type,content))
		{
			CRLog(E_ERROR, "δ�ҵ�Acc_Type=[%s],Risk_Type[%s] ���͵Ķ��Ÿ�ʽ",CustRinfo.sAcctType.c_str(),sRisk_Type.c_str()); 
			return -1;
		}
		//	NOTIFY_CONTENT={"��acctno��", "��cust��","��branch��",
		//			 "��degree��","��capi��","��margin��",
		//			 "��bal��","��debt��","��exdate��"};

		string aCustRinfo[CONTENT_NUM];
		aCustRinfo[0]=CustRinfo.sAcctNo; 
		aCustRinfo[1]=CustRinfo.sCustAbbr;
		aCustRinfo[2]=CustRinfo.sAgentName;
		aCustRinfo[3]=ToString(CustRinfo.stRiskDataTo.dlRiskDegree2);
		aCustRinfo[4]=ToString(CustRinfo.stRiskDataTo.dlCapital);
		aCustRinfo[5]=ToString(abs(CustRinfo.stRiskDataTo.dlMargin));
		aCustRinfo[6]=ToString(CustRinfo.stRiskDataTo.dlBalance);
		aCustRinfo[7]=ToString(CustRinfo.stRiskDataTo.dlDebtCall);

		// ��ȡϵͳ��ǰ����ʱ��
		//time_t tmNow;
		//time(&tmNow);
		//struct tm stTime;
		//localtime_r(&tmNow,&stTime);

		//int nMonth = stTime.tm_mon + 1;
		//int nDay = stTime.tm_mday;
		//int nYear = stTime.tm_year + 1900;

		//aCustRinfo[8]=ToString<int>(nYear)+"��"+ToString<int>(nMonth)+"��"+ToString<int>(nDay)+"��";

		aCustRinfo[8]=m_pMemDb->GetBasicParaTbl().GetExchDate();
		//�滻ָ���ַ�������
		for(int i=0;i<CONTENT_NUM;i++)
		{
			for(string::size_type pos(0);pos!=string::npos;pos+=aCustRinfo[i].length()) 
			{   
				if((pos=content.find(NOTIFY_CONTENT[i],pos))!=string::npos)  
				{
					content.replace(pos,NOTIFY_CONTENT[i].length(),aCustRinfo[i]);   
				}
				else  
				{
					break;   
				}
			}   
		}

	}
	catch(std::exception e)
	{
		CRLog(E_ERROR,"exception:%s!",e.what());
		return -1;
	}
	catch(...)
	{
		CRLog(E_ERROR,"%s","Unknown exception!");
		return -1;
	}
	return 0;
}