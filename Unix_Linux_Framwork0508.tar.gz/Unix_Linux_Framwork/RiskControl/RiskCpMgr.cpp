#include "osdepend.h"
//#include "Gess.h"
#include "VersionMacro.h"
#include "ConfigImpl.h"
#include "RiskCpMgr.h"
#include "ProtocolConnectPoint.h"
#include "TradePacket.h"
#include "BroadcastPacket.h"
#include "ProcessInterfaceKC.h"
#include "ProcessInterfaceA2C.h"
#include "ProcessInterfaceF1S.h"
#include "ProcessInterfaceF2S.h"
#include "ProcessInterfaceCmd.h"
#include "ProcessInterfaceA1C.h"
#include "ProcessInterfaceH1C.h"
#include "ProcessInterfaceH2C.h"
#include "ProcessInterfaceH2C.h"
#include "ProcessInterfaceSmscService.h"
#include "RiskHandler.h"
#include "DbSync.h"
#include "RiskNotify.h"
#include "MemDb.h"
#include "MainServiceHandler.h"
#include "LinePacket.h"
#include "GessDate.h"
#include "GessTimerMgrPosix.h"
#include "NetMgrModule.h"
#include "Encode.h"
#include "BF_DesEncrypt.h"
#include "ArbMain.h"
#include "Global.h"

//Դ�ӿ�+������ ����·�����ñ�
CRiskCpMgr::IfRouterCfg CRiskCpMgr::m_tblIfRouterCfg[] = 
{
	//from A1	
	//A1 To RiskHandler
	///////////////////////////////////////////////////////////////////////////
	//Obj      To						From             CmdID			  	///
	///////////////////////////////////////////////////////////////////////////
	{0,    EnumKeyRiskHandler,		EnumKeyIfA1,     "OnNotifyFeeInfo"},
	{0,    EnumKeyRiskHandler,		EnumKeyIfA1,     "onRecvRtnSpotMatch"},
	{0,    EnumKeyRiskHandler,		EnumKeyIfA1,     "onRecvRtnForwardMatch"},
	{0,    EnumKeyRiskHandler,		EnumKeyIfA1,     "onRecvRtnDeferMatch"},
	{0,    EnumKeyRiskHandler,		EnumKeyIfA1,     "onRecvRtnDeferDeliveryAppMatch"},
	{0,    EnumKeyRiskHandler,		EnumKeyIfA1,     "onRecvRtnEtfMatch"},			//add by luobaolin 2013-3-18
	{0,    EnumKeyRiskHandler,		EnumKeyIfA1,     "onAcctCapitalAccess"},
	{0,    EnumKeyRiskHandler,		EnumKeyIfA1,     "onCustInfoChange"},
	{0,    EnumKeyRiskHandler,		EnumKeyIfA1,     "onRecvSpotQuotation"},
	{0,    EnumKeyRiskHandler,		EnumKeyIfA1,     "onRecvForwardQuotation"},
	{0,    EnumKeyRiskHandler,		EnumKeyIfA1,     "onRecvDeferQuotation"},
	{0,    EnumKeyRiskHandler,		EnumKeyIfA1,     "onRecvDeferDeliveryQuotation"},
	{0,    EnumKeyRiskHandler,		EnumKeyDREB,     "OnNotifyFeeInfo"},
	{0,    EnumKeyRiskHandler,		EnumKeyDREB,     "onRecvRtnSpotMatch"},
	{0,    EnumKeyRiskHandler,		EnumKeyDREB,     "onRecvRtnForwardMatch"},
	{0,    EnumKeyRiskHandler,		EnumKeyDREB,     "onRecvRtnDeferMatch"},
	{0,    EnumKeyRiskHandler,		EnumKeyDREB,     "onRecvRtnDeferDeliveryAppMatch"},
	{0,    EnumKeyRiskHandler,		EnumKeyDREB,     "onRecvRtnEtfMatch"},			
	{0,    EnumKeyRiskHandler,		EnumKeyDREB,     "onAcctCapitalAccess"},
	{0,    EnumKeyRiskHandler,		EnumKeyDREB,     "onCustInfoChange"},
	{0,    EnumKeyRiskHandler,		EnumKeyDREB,     "onRecvForwardQuotation"},
	{0,    EnumKeyRiskHandler,		EnumKeyDREB,     "onRecvDeferQuotation"},
	{0,    EnumKeyRiskHandler,		EnumKeyDREB,     "onRecvDeferDeliveryQuotation"},
	{0,    EnumKeyMainService,		EnumKeyIfA1,     "onRecvDeferQuotation"}, 	
	{0,    EnumKeyMainService,		EnumKeyIfA1,     "onRecvRtnDeferOrder"}, 
	{0,    EnumKeyMainService,		EnumKeyIfA1,     "onRecvRtnDeferOrderCancel"}, 	
	{0,    EnumKeyMainService,		EnumKeyIfA1,     "onRecvRspDeferOrder"}, 	
	{0,    EnumKeyRiskHandler,		EnumKeyIfA1,     "onRecvRtnFpMatch"},	//add by wct 2016-03-25
	{0,    EnumKeyRiskHandler,		EnumKeyIfA1,     "onRecvRtnFpRoundQuotation"}, 
	{0,    EnumKeyMainService,		EnumKeyIfA1,     "onRecvRtnFpOrder"}, 	
	{0,    EnumKeyMainService,		EnumKeyIfA1,     "onRecvRtnFpOrderCancel"}, 	
	{0,    EnumKeyMainService,		EnumKeyIfA1,     "onRecvRspFpOrderFullCancel"}, 
	{0,    EnumKeyMainService,		EnumKeyIfA1,     "onRecvRspFpFrCancel"}, 	

	{0,    EnumKeyMainService,		EnumKeyDREB,     gc_sDefaultCmdID}, 
		
	//IFA1 To RiskNotify
	///////////////////////////////////////////////////////////////////////////
	//Obj      To						From             CmdID			  	///
	///////////////////////////////////////////////////////////////////////////
	{0,    EnumKeyDbSync,			EnumKeyIfA1,     "onBaseTableUpdate"},
	{0,    EnumKeyDbSync,			EnumKeyDREB,     "onBaseTableUpdate"},
	
	//IFA1 To Self
	///////////////////////////////////////////////////////////////////////////
	//Obj      To						From             CmdID			  	///
	///////////////////////////////////////////////////////////////////////////
	{0,    EnumKeySelfBroadcast,			    EnumKeyIfA1,     "onSysInit"},
	{0,    EnumKeySelfBroadcast,			    EnumKeyIfA1,     "onSysStatChange"},
	{0,    EnumKeySelfBroadcast,				EnumKeyIfA1,     "onRecvRtnSpotInstStateUpdate"},
	{0,    EnumKeySelfBroadcast,				EnumKeyIfA1,     "onRecvRtnForwardInstStateUpdate"}, 	
	{0,    EnumKeySelfBroadcast,				EnumKeyIfA1,     "onRecvRtnDeferInstStateUpdate"},
	{0,    EnumKeySelfBroadcast,				EnumKeyIfA1,     "onRecvRtnSpotMarketStateUpdate"},
	{0,    EnumKeySelfBroadcast,				EnumKeyIfA1,     "onRecvRtnForwardMarketStateUpdate"},
	{0,    EnumKeySelfBroadcast,				EnumKeyIfA1,     "onRecvRtnDeferMarketStateUpdate"},
	{0,    EnumKeySelfBroadcast,			    EnumKeyDREB,     "onSysInit"},
	{0,    EnumKeySelfBroadcast,			    EnumKeyDREB,     "onSysStatChange"},
	{0,    EnumKeySelfBroadcast,				EnumKeyDREB,     "HostStatus"},//add lqh
	

	//from A2	
	//IFA2 To RiskNotify
	///////////////////////////////////////////////////////////////////////////
	//Obj      To						From             CmdID			  	///
	///////////////////////////////////////////////////////////////////////////
	{0,    EnumKeyRiskNotify,		EnumKeyIfA2,     "3051"},
	
	//IFA2 To MainServiceHandler		
	///////////////////////////////////////////////////////////////////////////
	//Obj      To						From             CmdID			  	///
	///////////////////////////////////////////////////////////////////////////
	{0,    EnumKeyMainService,		EnumKeyIfA2,	 "4043"},    
	{0,    EnumKeyMainService,		EnumKeyIfA2,	 "4044"},    
	{0,    EnumKeyMainService,		EnumKeyIfA2,	 "4061"},



	//from F1	
	//IFF1 To RiskNotify		
	///////////////////////////////////////////////////////////////////////////
	//Obj      To						From             CmdID			  	///
	///////////////////////////////////////////////////////////////////////////
	{0,    EnumKeyRiskNotify,		EnumKeyIfF1,     "3061"},               
	{0,    EnumKeyRiskNotify,		EnumKeyIfF1,     "3062"},
	{0,    EnumKeyRiskNotify,		EnumKeyIfF1,     "3305"},
	{0,    EnumKeyRiskNotify,		EnumKeyDREB,     "3061"},
	{0,    EnumKeyRiskNotify,		EnumKeyDREB,     "3062"},
	{0,    EnumKeyRiskNotify,		EnumKeyDREB,     "3305"},

		
		
	//IFF1 To MainServiceHandler
	///////////////////////////////////////////////////////////////////////////
	//Obj      To						From             CmdID			  	///
	///////////////////////////////////////////////////////////////////////////
	{0,    EnumKeyMainService,		EnumKeyIfF1,			"3063"},    
	{0,    EnumKeyMainService,		EnumKeyIfF1,			"3064"},    
	{0,    EnumKeyMainService,		EnumKeyIfF1,			"3065"},                          
	{0,    EnumKeyMainService,		EnumKeyIfF1,			"3066"},                          
	{0,    EnumKeyMainService,		EnumKeyIfF1,			"3067"},                          
	{0,    EnumKeyMainService,		EnumKeyIfF1,			"3069"},                          
	{0,    EnumKeyMainService,		EnumKeyIfF1,			"3070"},                          
	{0,    EnumKeyMainService,		EnumKeyIfF1,			"3081"},                          
	{0,    EnumKeyMainService,		EnumKeyIfF1,			"3082"},                          
	{0,    EnumKeyMainService,		EnumKeyIfF1,			"3084"},                          
	{0,    EnumKeyMainService,		EnumKeyIfF1,			"3085"},                          
	{0,    EnumKeyMainService,		EnumKeyIfF1,			"3086"},                          
	{0,    EnumKeyMainService,		EnumKeyIfF1,			"3088"},                          
	{0,    EnumKeyMainService,		EnumKeyIfF1,			"3091"},                          
	{0,    EnumKeyMainService,		EnumKeyIfF1,			"3093"},                          
	{0,    EnumKeyMainService,		EnumKeyIfF1,			"3094"},                          
	{0,    EnumKeyMainService,		EnumKeyIfF1,			"3095"},                          
	{0,    EnumKeyMainService,		EnumKeyIfF1,			"3096"},    
	{0,    EnumKeyMainService,		EnumKeyIfF1,			"3097"},    
	{0,    EnumKeyMainService,		EnumKeyIfF1,			"3098"},
	{0,    EnumKeyMainService,		EnumKeyIfF1,			"3099"},    
	{0,    EnumKeyMainService,		EnumKeyIfF1,			"3100"},
    {0,    EnumKeyMainService,		EnumKeyIfF1,			"3301"},
	{0,    EnumKeyMainService,		EnumKeyIfF1,			"3302"},
	{0,    EnumKeyMainService,		EnumKeyIfF1,			"3303"},
	{0,    EnumKeyMainService,		EnumKeyIfF1,			"3304"},
	{0,    EnumKeyMainService,		EnumKeyIfF1,			"3306"},
	{0,    EnumKeyMainService,		EnumKeyIfF1,			"3307"}, //add by liuwei 2012-8-16
	{0,    EnumKeyMainService,		EnumKeyIfF1,			"3308"}, //add by liuwei 2012-8-16
	{0,    EnumKeyMainService,		EnumKeyIfF1,			"3309"}, //add by liuwei 2012-9-14
	{0,    EnumKeyMainService,		EnumKeyIfF1,			"3310"}, //add by liuwei 2012-9-14
	{0,    EnumKeyMainService,		EnumKeyIfF1,			"3311"}, //add by liuwei 2012-10-23
	{0,    EnumKeyMainService,		EnumKeyIfF1,			"3312"}, //add by zengweiwei 2013-11-18
	{0,    EnumKeyMainService,		EnumKeyIfF1,			"3321"}, //20140916 add by zww ������������������տͻ���ѯ�ӿڡ��ⲿϵͳ���׷��������󣬽��׷���������������
	//from RiskHandler
	//RiskHandler To A1
	///////////////////////////////////////////////////////////////////////////
	//Obj      To						From             CmdID			  	///
	///////////////////////////////////////////////////////////////////////////
	{0,    EnumKeyIfA1,				EnumKeyRiskHandler,   "Ack"},
	{0,    EnumKeyDREB,				EnumKeyRiskHandler,   "Ack"},
		
	//from RiskNotify
	//RiskNotify To IFA1  
	///////////////////////////////////////////////////////////////////////////
	//Obj      To						From             CmdID			  	///
	///////////////////////////////////////////////////////////////////////////
	{0,    EnumKeyIfA1,				EnumKeyDbSync,    	"Ack"},
	{0,    EnumKeyDREB,				EnumKeyDbSync,    	"Ack"},

	//RiskNotify To IFA2 
	///////////////////////////////////////////////////////////////////////////
	//Obj      To						From             CmdID			  	///
	///////////////////////////////////////////////////////////////////////////
	{0,    EnumKeyIfA2,				EnumKeyRiskNotify,    "3051"},

	//RiskNotify To IFF1
	///////////////////////////////////////////////////////////////////////////
	//Obj      To						From             CmdID			  	///
	///////////////////////////////////////////////////////////////////////////
	{0,    EnumKeyIfF1,				EnumKeyRiskNotify,    "3061"},               
	{0,    EnumKeyIfF1,				EnumKeyRiskNotify,    "3062"},
	{0,    EnumKeyIfF1,				EnumKeyRiskNotify,    "3305"},
	{0,    EnumKeyDREB,				EnumKeyRiskNotify,    "3061"},               
	{0,    EnumKeyDREB,				EnumKeyRiskNotify,    "3062"},
	{0,    EnumKeyDREB,				EnumKeyRiskNotify,    "3305"},


	//RiskNotify To IFF2 
	///////////////////////////////////////////////////////////////////////////
	//Obj      To						From             CmdID			  	///
	///////////////////////////////////////////////////////////////////////////
	{0,    EnumKeyIfF2,				EnumKeyRiskNotify,    "onBranchRiskStat"},   
	{0,    EnumKeyIfF2,				EnumKeyRiskNotify,    "onCustRiskChangeNtf"},


	//RiskNotify To IFF2 
	///////////////////////////////////////////////////////////////////////////
	//Obj      To						From             CmdID			  	///
	///////////////////////////////////////////////////////////////////////////
	{0,    EnumKeySmsService,		EnumKeyRiskNotify,    "3056"},   
	{0,    EnumKeySmsService,		EnumKeyRiskNotify,    "3057"},

	//from MainServiceHandler
	//MainServiceHandler To IFA2
	///////////////////////////////////////////////////////////////////////////
	//Obj      To						From             CmdID			  	///
	///////////////////////////////////////////////////////////////////////////
	{0,    EnumKeyIfA2,				EnumKeyMainService,					"4043"},  
	{0,    EnumKeyIfA2,				EnumKeyMainService,					"4044"},  
	{0,    EnumKeyIfA2,				EnumKeyMainService,					"4061"},

	//MainServiceHandler To IFF1  
	///////////////////////////////////////////////////////////////////////////
	//Obj      To						From             CmdID			  	///
	///////////////////////////////////////////////////////////////////////////
	{0,    EnumKeyIfF1,				EnumKeyMainService,					"3063"},  
	{0,    EnumKeyIfF1,				EnumKeyMainService,					"3064"},  
	{0,    EnumKeyIfF1,				EnumKeyMainService,					"3065"},  
	{0,    EnumKeyIfF1,				EnumKeyMainService,					"3066"},  
	{0,    EnumKeyIfF1,				EnumKeyMainService,					"3067"},  
	{0,    EnumKeyIfF1,				EnumKeyMainService,					"3069"},  
	{0,    EnumKeyIfF1,				EnumKeyMainService,					"3070"},  
	{0,    EnumKeyIfF1,				EnumKeyMainService,					"3081"},  
	{0,    EnumKeyIfF1,				EnumKeyMainService,					"3082"},  
	{0,    EnumKeyIfF1,				EnumKeyMainService,					"3084"},  
	{0,    EnumKeyIfF1,				EnumKeyMainService,					"3085"},  
	{0,    EnumKeyIfF1,				EnumKeyMainService,					"3086"},  
	{0,    EnumKeyIfF1,				EnumKeyMainService,					"3088"},  
	{0,    EnumKeyIfF1,				EnumKeyMainService,					"3091"},  
	{0,    EnumKeyIfF1,				EnumKeyMainService,					"3093"},  
	{0,    EnumKeyIfF1,				EnumKeyMainService,					"3094"},  
	{0,    EnumKeyIfF1,				EnumKeyMainService,					"3095"},  
	{0,    EnumKeyIfF1,				EnumKeyMainService,					"3096"},  
	{0,    EnumKeyIfF1,				EnumKeyMainService,					"3097"},  
	{0,    EnumKeyIfF1,				EnumKeyMainService,					"3098"},
	{0,    EnumKeyIfF1,				EnumKeyMainService,					"3099"},  
	{0,    EnumKeyIfF1,				EnumKeyMainService,					"3100"},
    {0,    EnumKeyIfF1,		        EnumKeyMainService,			         "3301"},
	{0,    EnumKeyIfF1,		        EnumKeyMainService,			         "3302"},
	{0,    EnumKeyIfF1,		        EnumKeyMainService,			         "3303"},
	{0,    EnumKeyIfF1,				EnumKeyMainService,					"3321"},//20140916 add by zww ������������������տͻ���ѯ�ӿڡ�
	{0,    EnumKeyIfF1,		        EnumKeyMainService,			        "3304"},
	{0,    EnumKeyIfF1,		        EnumKeyMainService,			        "3306"},
	//from H1	
	//H1 To NetMgrModule
	///////////////////////////////////////////////////////////////////////////
	//Obj      To						From                    CmdID		///
	///////////////////////////////////////////////////////////////////////////
	{0,    EnumNetMagModule,			EnumKeyIfH1,            "1921"},
	{0,    EnumNetMagModule,			EnumKeyIfH1,			"1922"},
	{0,    EnumNetMagModule,			EnumKeyIfH1,			"1923"},
	{0,    EnumNetMagModule,			EnumKeyIfH1,			"1924"},
	{0,    EnumNetMagModule,			EnumKeyIfH1,		    "1925"}, 

	{0,    EnumNetMagModule,			EnumKeyIfH1,            "1911"},
	{0,    EnumNetMagModule,			EnumKeyIfH1,			"1912"},
	{0,    EnumNetMagModule,			EnumKeyIfH1,			"1913"},
	{0,    EnumNetMagModule,			EnumKeyIfH1,			"1914"},
	{0,    EnumNetMagModule,			EnumKeyIfH1,		    "1915"},
	{0,    EnumNetMagModule,			EnumKeyIfH1,		    "1916"}, 
	//from H1	
	//NetMgrModule To H1 
	///////////////////////////////////////////////////////////////////////////
	//Obj      To						From                    CmdID		//
	{0,    EnumKeyIfH1,			EnumNetMagModule,           "1921"},
	{0,    EnumKeyIfH1,			EnumNetMagModule,			"1922"},
	{0,    EnumKeyIfH1,			EnumNetMagModule,			"1923"},
	{0,    EnumKeyIfH1,			EnumNetMagModule,			"1924"},
	{0,    EnumKeyIfH1,			EnumNetMagModule,		    "1925"}, 
	
	{0,    EnumKeyIfH1,			EnumNetMagModule,            "1911"},
	{0,    EnumKeyIfH1,			EnumNetMagModule,			"1912"},
	{0,    EnumKeyIfH1,			EnumNetMagModule,			"1913"},
	{0,    EnumKeyIfH1,			EnumNetMagModule,			"1914"},
	{0,    EnumKeyIfH1,			EnumNetMagModule,		    "1915"},
	{0,    EnumKeyIfH1,			EnumNetMagModule,		    "1916"}, 

	//from K
	//K To WatchDog
	///////////////////////////////////////////////////////////////////////////
	//Obj      To						From					CmdID		///
	///////////////////////////////////////////////////////////////////////////
	//{0,    EnumKeyIfK,				EnumKeySelfBroadcast,		    "Hello"},

	//from K
	//K To EnumKeySelfBroadcast
	///////////////////////////////////////////////////////////////////////////
	//Obj      To						From             CmdID			  	///
	///////////////////////////////////////////////////////////////////////////
	{0,    EnumKeySelfIpc,			EnumKeyIfK,    			"QuitNotify"},

	//from EnumKeySelfIpc
	//EnumKeySelfIpc To K
	///////////////////////////////////////////////////////////////////////////
	//Obj      To						From             CmdID			  	///
	///////////////////////////////////////////////////////////////////////////
	{0,    EnumKeyIfK,			    EnumKeySelfIpc,    			"Hello"},

	
	//from NetMgrModule
	//NetMgrModule To H2
	///////////////////////////////////////////////////////////////////////////
	//Obj      To						From					CmdID		///
	///////////////////////////////////////////////////////////////////////////
	{0,    EnumKeyIfH2,				EnumNetMagModule,		"onEventNotify"},   //�¼��㲥�౨��
	{0,    EnumKeyIfH2,				EnumNetMagModule,		"onAlarmNotify"},   //�澯�㲥�౨��
	{0,    EnumKeyIfH2,				EnumNetMagModule,		"onNodeMibTblChg"}, //��¼�仯�㲥����


	//from IFCMD
	//IFCMD To default ȱʡ·��
	///////////////////////////////////////////////////////////////////////////
	//Obj      To						From             CmdID			  	///
	///////////////////////////////////////////////////////////////////////////
	{0,    EnumKeyCmdHandler,		EnumKeyIfCmd,    			 "#"}
	
};

//�㲥�౨�Ķ�Ӧ�Ĵ�����Ա�������ñ�
CRiskCpMgr::Cmd2Api CRiskCpMgr::m_Cmd2Api[] =
{
	//����ApiName					����������ָ��
	{"HostStatus",					&CRiskCpMgr::OnHostStatus},
	{"onSysInit",					&CRiskCpMgr::OnSysInit},
	{"onSysStatChange",				&CRiskCpMgr::OnSysStat},
	{"onRecvRtnSpotInstStateUpdate", &CRiskCpMgr::OnSpotInstState},
	{"onRecvRtnForwardInstStateUpdate", &CRiskCpMgr::OnForwardInstState},
	{"onRecvRtnDeferInstStateUpdate", &CRiskCpMgr::OnDeferInstState},
	{"onRecvRtnSpotMarketStateUpdate", &CRiskCpMgr::OnSpotMarketState},
	{"onRecvRtnForwardMarketStateUpdate", &CRiskCpMgr::OnForwardMarketState},
	{"onRecvRtnDeferMarketStateUpdate", &CRiskCpMgr::OnDeferMarketState}
};

//Ipc���Ķ�Ӧ�Ĵ�����Ա�������ñ�
CRiskCpMgr::IpcCmd2Api CRiskCpMgr::m_IpcCmd2Api[] =
{
	//����ApiName					����������ָ��
	{"QuitNotify",					&CRiskCpMgr::OnRecvQuit}
};

//Telnet or Console CommandLine ��Ӧ�����������ñ�
CRiskCpMgr::CmdLine2Api CRiskCpMgr::m_CmdLine2Api[] = 
{
	//������			��д			���������ָ��					˵��
	{"quit",			"q",			&CRiskCpMgr::OnCmdLineQuit,			"quit the system"},
	{"test",			"t",			&CRiskCpMgr::OnCmdLineSimQuotation, "simulate quotation"},
	{"sysinit",			"",				&CRiskCpMgr::OnCmdLineSimInit,		"simulate sysinit"},
	{"sysstate",		"",				&CRiskCpMgr::OnCmdLineSimSysState,	"simulate sysstate"},
	{"stat",			"s",			&CRiskCpMgr::OnCmdLineState,		"output the statics"},
	{"cust",			"c",			&CRiskCpMgr::OnCmdLineCustInfo,		"show cust info,'cust acct_no',example: cust 010029701"},
	{"agent",			"a",			&CRiskCpMgr::OnCmdLineBranchInfo,	"show agent info,'agent agent_id',example: agent B00001"},
	{"quotation",		"",				&CRiskCpMgr::OnCmdLineQotationInfo, "show quotation info"},
	{"?",				"",				&CRiskCpMgr::OnCmdLineHelp,			"for help"},
	{"help",			"h",			&CRiskCpMgr::OnCmdLineHelp,			"for help"},
	{"match",			"m",			&CRiskCpMgr::OnCmdLineMatchInfo,	"show match key tbl"},
	{"info",			"i",			&CRiskCpMgr::OnCmdLineSysInfo,		"show SysInfo"},
	{"3des",			"des",			&CRiskCpMgr::OnCmdLine3DesEnc,		"Password 3Des/Base64 Encode"}
};

CRiskCpMgr::CRiskCpMgr(void)
:m_pMemDb(0)
,m_pMainService(0)
,m_pRiskHandler(0)
,m_pDbSync(0)
,m_pRiskNotify(0)
,m_pCpInterfaceA1(0)
,m_pCpInterfaceA2(0)
,m_pCpInterfaceSmscService(0)
,m_pCpInterfaceF1(0)
,m_pCpInterfaceF2(0)
,m_pCpInterfaceH1(0)
,m_pCpInterfaceH2(0)
,m_pCpInterfaceCmd(0)
,m_pCpInterfaceK(0)
,m_pNetMagModule(0)
,m_pGessTimerMgr(0)
//,m_pSmsSender(0)
,m_nSysState(gc_nSysStateReady)
,m_bStop(false)
,m_nReadyQuit(0)
,m_nIsMaster(0)
#ifdef _VER_DREB
,m_arbMain(NULL)
#endif
,m_bUseDreb(true)

{
	m_bsCps.reset();
	m_pConfig = new CConfigImpl();
#ifdef _VER_DREB
	m_bUseDreb = true;
#endif
}

CRiskCpMgr::~CRiskCpMgr(void)
{	
	for (int i = 0; i < EnumKeyUnknown; i++)
	{
		m_tblIfRouter[i].mmapCmds.clear();
	}


	if (0 != m_pConfig)
		delete m_pConfig;

	if (0 != m_pCpInterfaceA1)
		delete m_pCpInterfaceA1;

	if (0 != m_pCpInterfaceA2)
		delete m_pCpInterfaceA2;

	if (0 !=m_pCpInterfaceSmscService)
		delete m_pCpInterfaceSmscService;

	if (0 != m_pCpInterfaceF1)
		delete m_pCpInterfaceF1;

	if (0 != m_pCpInterfaceF2)
		delete m_pCpInterfaceF2;

	if (0 != m_pCpInterfaceH1)
		delete m_pCpInterfaceH1;

	if (0 != m_pCpInterfaceH2)
		delete m_pCpInterfaceH2;

	if (0 != m_pCpInterfaceCmd)
		delete m_pCpInterfaceCmd;

	if (0 != m_pCpInterfaceK)
		delete m_pCpInterfaceK;

		if (0 != m_pMainService)
		delete m_pMainService;

	if (0 != m_pRiskNotify)
		delete m_pRiskNotify;

	if (0 != m_pRiskHandler)
		delete m_pRiskHandler;

	if (0 != m_pDbSync)
		delete m_pDbSync;

	m_deqIpcPacket.clear();
	m_deqTelnets.clear();
}

//ƥ�䱨�Ĵ�����Ա���������е��ô��� �����Ż�Ϊ��ϣ������
int CRiskCpMgr::RunBroadcastPacketHandleApi(CBroadcastPacket& pkt)
{
	try
	{
		std::string sCmdID = pkt.GetCmdID();
	
		int nSize = sizeof(m_Cmd2Api)/sizeof(Cmd2Api);
		for ( int i = 0 ; i < nSize ; i++ )
		{
			if ( m_Cmd2Api[i].sApiName == sCmdID )
			{
				if (m_Cmd2Api[i].pMemberFunc == 0)
					break;

				return (this->*(m_Cmd2Api[i].pMemberFunc))(pkt);				
			}
		}

		//CRLog(E_ERROR,"%s","Unknown packet!");
		return -1;
	}
	catch(std::exception e)
	{
		CRLog(E_CRITICAL,"exception:%s", e.what());
		return -1;
	}
	catch(...)
	{
		CRLog(E_CRITICAL,"%s","Unknown exception");
		return -1;
	}
}

//ƥ�䱨�Ĵ�����Ա���������е��ô��� �����Ż�Ϊ��ϣ������
int CRiskCpMgr::RunIpcPacketHandleApi(CIpcPacket& pkt)
{
	try
	{
		std::string sCmdID = pkt.GetCmdID();
	
		int nSize = sizeof(m_IpcCmd2Api)/sizeof(IpcCmd2Api);
		for ( int i = 0 ; i < nSize ; i++ )
		{
			if ( m_IpcCmd2Api[i].sApiName == sCmdID )
			{
				if (m_IpcCmd2Api[i].pMemberFunc == 0)
					break;

				return (this->*(m_IpcCmd2Api[i].pMemberFunc))(pkt);				
			}
		}

		//CRLog(E_ERROR,"%s","Unknown packet!");
		return -1;
	}
	catch(std::exception e)
	{
		CRLog(E_CRITICAL,"exception:%s", e.what());
		return -1;
	}
	catch(...)
	{
		CRLog(E_CRITICAL,"%s","Unknown exception");
		return -1;
	}
}

//�ͻ���Э�����ӵ����ӳɹ���ص�
int CRiskCpMgr::OnConnect(const unsigned long& ulKey, const string& sLocalIp, int nLocalPort, const string& sPeerIp, int nPeerPort,int nFlag)
{
	assert(ulKey < EnumKeyUnknown);
	if (ulKey >= EnumKeyUnknown || nFlag != 0)
		return -1;

	/*Ψ��ֻ��A2��A1���ӳɹ���������ģ������	   */
	if(EnumKeyIfA2 != ulKey || EnumKeyIfA1 != ulKey )
		 return -1;

	m_csBitsetCps.Lock();
	m_bsCps.set(ulKey);
	if (m_bsCps.test(EnumKeyIfA2) &&  m_bsCps.test(EnumKeyIfA1))
	{
		CRLog(E_APPINFO,"%s","IFA2 and IFA1 OnConnect,simulate quotation!");

		//ģ�����鴥��һ�η��նȱ�������
		vector<string> v;
		//OnCmd("test", v);
		CBroadcastPacket pkt("onRecvDeferQuotation");
		m_pRiskHandler->Enque(pkt);
	}
	m_csBitsetCps.Unlock();
	return 0;
}

//�����Э�����ӵ���յ����Ӻ�ص�
int CRiskCpMgr::OnAccept(const unsigned long& ulKey, const string& sLocalIp, int nLocalPort, const string& sPeerIp, int nPeerPort)
{
	if (EnumKeyIfF2 == ulKey)
	{
		NotifyClientInit();
	}

	return 0;
}

int CRiskCpMgr::OnLogin( const unsigned long& ulKey,const string& sLocalIp, int nLocalPort, const string& sPeerIp, int nPeerPort,int nFlag)
{
	return 0;
}

int CRiskCpMgr::OnClose(const unsigned long& ulKey, const string& sLocalIp, int nLocalPort, const string& sPeerIp, int nPeerPort)
{
	return 0;
}

//���ӵ��������ʼ��
int CRiskCpMgr::Init()
{
	if (0 != BasicCfgInit())
		return -1;

	//��ʼ����Ӧ��ģ��
	if (0 != RiskModuleInit())
		return -1;

	//��ʼ����Э�����ӵ�
	IfCpsInit();

	//��ʼ������·�ɱ�
	InitRouterTbl();
	return 0;
}

//��ʼ��·�ɱ�
int CRiskCpMgr::InitRouterTbl()
{
	//���ñ�
	int nSize = sizeof(m_tblIfRouterCfg)/sizeof(IfRouterCfg);
	//����·�����ñ���ʼ���ڴ�·�ɱ�
	for ( int m = 0; m < nSize; m++ )
	{
		unsigned long ulRow = m_tblIfRouterCfg[m].ulIfFrom;
		m_tblIfRouter[ulRow].ulIfFrom = m_tblIfRouterCfg[m].ulIfFrom;
		string sCmdID = m_tblIfRouterCfg[m].sCmdID;

		switch(m_tblIfRouterCfg[m].ulIfTo)
		{
		case EnumKeyIfA1:
			m_tblIfRouter[ulRow].mmapCmds.insert(MMAP_CP::value_type(m_tblIfRouterCfg[m].sCmdID, m_pCpInterfaceA1));
			break;
		case EnumKeyIfA2:
			m_tblIfRouter[ulRow].mmapCmds.insert(MMAP_CP::value_type(m_tblIfRouterCfg[m].sCmdID, m_pCpInterfaceA2));
			break;
		case EnumKeySmsService:
			m_tblIfRouter[ulRow].mmapCmds.insert(MMAP_CP::value_type(m_tblIfRouterCfg[m].sCmdID,m_pCpInterfaceSmscService));
			break;
		case EnumKeyIfF1:
			m_tblIfRouter[ulRow].mmapCmds.insert(MMAP_CP::value_type(m_tblIfRouterCfg[m].sCmdID, m_pCpInterfaceF1));
			break;
		case EnumKeyIfF2:
			m_tblIfRouter[ulRow].mmapCmds.insert(MMAP_CP::value_type(m_tblIfRouterCfg[m].sCmdID, m_pCpInterfaceF2));
			break;
		case EnumKeyIfK:
			m_tblIfRouter[ulRow].mmapCmds.insert(MMAP_CP::value_type(m_tblIfRouterCfg[m].sCmdID, m_pCpInterfaceK));
			break;
		case EnumKeyIfH1:
			m_tblIfRouter[ulRow].mmapCmds.insert(MMAP_CP::value_type(m_tblIfRouterCfg[m].sCmdID, m_pCpInterfaceH1));
			break;
		case EnumKeyIfH2:
			m_tblIfRouter[ulRow].mmapCmds.insert(MMAP_CP::value_type(m_tblIfRouterCfg[m].sCmdID, m_pCpInterfaceH2));
			break;
		case EnumNetMagModule:
			m_tblIfRouter[ulRow].mmapCmds.insert(MMAP_CP::value_type(m_tblIfRouterCfg[m].sCmdID, m_pNetMagModule));
			break;
		case EnumKeyIfCmd:
			m_tblIfRouter[ulRow].mmapCmds.insert(MMAP_CP::value_type(m_tblIfRouterCfg[m].sCmdID, m_pCpInterfaceCmd));
			break;
		case EnumKeyRiskHandler:
			m_tblIfRouter[ulRow].mmapCmds.insert(MMAP_CP::value_type(m_tblIfRouterCfg[m].sCmdID, m_pRiskHandler));
			break;
		case EnumKeyRiskNotify:
			m_tblIfRouter[ulRow].mmapCmds.insert(MMAP_CP::value_type(m_tblIfRouterCfg[m].sCmdID, m_pRiskNotify));
			break;
		case EnumKeyMainService:
			m_tblIfRouter[ulRow].mmapCmds.insert(MMAP_CP::value_type(m_tblIfRouterCfg[m].sCmdID, m_pMainService));
			break;
		case EnumKeyDbSync:
			m_tblIfRouter[ulRow].mmapCmds.insert(MMAP_CP::value_type(m_tblIfRouterCfg[m].sCmdID, m_pDbSync));
			break;
		case EnumKeySelfBroadcast:
			m_tblIfRouter[ulRow].mmapCmds.insert(MMAP_CP::value_type(m_tblIfRouterCfg[m].sCmdID, &m_oCpSelfBroadcast));
			break;
		case EnumKeySelfIpc:
			m_tblIfRouter[ulRow].mmapCmds.insert(MMAP_CP::value_type(m_tblIfRouterCfg[m].sCmdID, &m_oCpSelfIpc));
			break;
		case EnumKeyCmdHandler:
			m_tblIfRouter[ulRow].mmapCmds.insert(MMAP_CP::value_type(m_tblIfRouterCfg[m].sCmdID, &m_oCpCmdHandler));
			break;
#ifdef _VER_DREB
		case EnumKeyDREB:
			m_tblIfRouter[ulRow].mmapCmds.insert(MMAP_CP::value_type(m_tblIfRouterCfg[m].sCmdID, m_arbMain));
			break;
#endif
		//default:
		//	m_tblIfRouter[ulRow].mmapCmds.insert(MMAP_CP::value_type(m_tblIfRouterCfg[m].sCmdID, NULL));
		//	break;
		}
	}

	return 0;
}

//�������ó�ʼ��
int  CRiskCpMgr::BasicCfgInit()
{
	cout << "���������ļ�..." << endl;

	std::string sCfgFilename;
	sCfgFilename = DEFUALT_CONF_PATH PATH_SLASH;
	sCfgFilename = sCfgFilename + "Risk.cfg";
	if (m_pConfig->Load(sCfgFilename) != 0)
	{
		cout << "Log Config File failure!" << endl;
		msleep(3);
		return -1;
	}

	cout << "��ʼ����־..." << endl;

	// ��ʼ����־
	if (CLogger::Instance()->Initial(m_pConfig->GetProperties("logger")) != 0)
	{
		cout << "Log Init failure!" << endl;
		msleep(3);
		return -1;
	}

	cout << "������־..." << endl;

	// ������־
	if (CLogger::Instance()->Start() != 0)
	{
		cout << "Log start failure!" << endl;
		msleep(3);
		return -1;
	}

	CRLog(E_APPINFO,"%s","��ط�������ʼ����v20161118!");

	cout << "��ʼ����������..." << endl;
	string sTblPrefix = "risk";
	CConfig *pCfgNetMagModule = m_pConfig->GetProperties(gc_sCfgNetMagModule);
	if (0 != pCfgNetMagModule)
	{
		string sTmp;
		if (0 == pCfgNetMagModule->GetProperty("tbl_prefix",sTmp))
			sTblPrefix = sTmp;
	}
	m_pNetMagModule = new CNetMgrModule();
	CNetMgr::Instance()->NmInit(m_pNetMagModule,sTblPrefix);

	//��ʼ����ʱ��������/������ʱ��
	m_pGessTimerMgr = CGessTimerMgrImp::Instance();
	m_pGessTimerMgr->Init(2);
	m_pGessTimerMgr->Start();

	//telnet ���Ĵ������ӵ�
	m_oCpCmdHandler.Bind(this,EnumKeyCmdHandler);

	//�������������Ĵ������ӵ�
	m_oCpSelfBroadcast.Bind(this,EnumKeySelfBroadcast);
	m_oCpSelfIpc.Bind(this,EnumKeySelfIpc);

	//������־�ص�����
	m_oNetLogHost.Bind(this);

	m_oNetLogThread.Bind(this);
#ifdef _WINDOWS
	m_oCmdLineThread.Bind(this);
#endif
	m_oBroadcastPktThread.Bind(this);
	if (m_bUseDreb)
	{
		m_oIpcThread.Bind(this);
	}
	return 0;
}

//ҵ��ģ���ʼ��
int CRiskCpMgr::RiskModuleInit(const string& sDate)
{
	//��ʼ���ڴ����ݿ�
	CRLog(E_APPINFO,"%s","Init MemDb");
	CConfig *pCfgMemDb = m_pConfig->GetProperties(gc_sCfgMemDb);
	if (0 == pCfgMemDb)
		pCfgMemDb = m_pConfig;

	m_pMemDb = new CMemDb();
	if (0 != m_pMemDb->Init(pCfgMemDb,sDate))
	{
		cout << "Init MemDb failure!" << endl;
		msleep(3);
		delete m_pMemDb;
		return -1;
	}
	
	//��ʼ������֪ͨ����ģ��
	CRLog(E_APPINFO,"%s","Init RiskNotify");
	CConfig *pCfgRiskNotify = m_pConfig->GetProperties(gc_sCfgRiskNotify);
	if (0 == pCfgRiskNotify)
		pCfgRiskNotify = m_pConfig;

	m_pRiskNotify = new CRiskNotify(m_pMemDb);
	m_pRiskNotify->Bind(this,EnumKeyRiskNotify);
	m_pRiskNotify->Init(pCfgRiskNotify);


	//��ʼ�����ռ���ģ��
	CRLog(E_APPINFO,"%s","Init RiskHandler");
	CConfig *pCfgRiskHandler = m_pConfig->GetProperties(gc_sCfgRiskHandler);
	if (0 == pCfgRiskHandler)
		pCfgRiskHandler = m_pConfig;

	m_pRiskHandler = new CRiskHandler(m_pRiskNotify,m_pMemDb);
	m_pRiskHandler->Bind(this,EnumKeyRiskHandler);
	m_pRiskHandler->Init(pCfgRiskHandler);

	//��ʼ������ͬ��ģ��
	CRLog(E_APPINFO,"%s","Init DbSync");
	CConfig *pCfgDbSync = m_pConfig->GetProperties(gc_sCfgDbSync);
	if (0 == pCfgDbSync)
		pCfgDbSync = m_pConfig;

	m_pDbSync = new CDbSync(m_pRiskHandler,m_pMemDb);
	m_pDbSync->Bind(this,EnumKeyDbSync);
	m_pDbSync->Init(pCfgDbSync);

	//��ʼ����ض���ҵ����ģ��
	CRLog(E_APPINFO,"%s","Init MainService");
	CConfig *pCfgMainService = m_pConfig->GetProperties(gc_sCfgMainService);
	if (0 == pCfgMainService)
		pCfgMainService = m_pConfig;

	m_pMainService = new CMainServiceHandler(m_pRiskNotify, m_pMemDb);
	m_pMainService->Bind(this,EnumKeyMainService);
	m_pMainService->Init(pCfgMainService);
	//NetMagModule
	CConfig * pCfgNetMagModule = m_pConfig->GetProperties(gc_sCfgNetMagModule);
	m_pNetMagModule->Init(pCfgNetMagModule);
	m_pNetMagModule->Bind(this,EnumNetMagModule);

	//����֪ͨ
	//m_pSmsSender = new CSmsSender(m_pMemDb);
	//CConfig * pCfgSms = m_pConfig->GetProperties(gc_sCfgSMS);
	//m_pSmsSender->Init(pCfgSms);
	return 0;
	
}

//�����ӵ��ʼ��
int CRiskCpMgr::IfCpsInit()
{
	m_csBitsetCps.Lock();
	m_bsCps.reset();
	m_csBitsetCps.Unlock();

	CConfig *pCfgA1, *pCfgA2,*pCfgF1,*pCfgF2,*pCfgK,*pCfgH1,*pCfgH2,*pCfgSmsIf;
	pCfgA1 = m_pConfig->GetProperties(gc_sCfgIfA1);
	if (0 != pCfgA1 && !pCfgA1->IsEmpty())
	{
		CRLog(E_APPINFO,"%s","��ʼ�����ӵ�A1");
		m_pCpInterfaceA1 = new CProtocolCpCli<CProcessInterfaceA1C>();
		m_pCpInterfaceA1->Init(pCfgA1);
		m_pCpInterfaceA1->Bind(this,EnumKeyIfA1);
	}
#ifdef _VER_DREB
	if (m_bUseDreb)
	{
		// ��ʼ�����������ӵ��Ѿ����ⲿ���������������ﴴ��
		if( m_arbMain != NULL )
		{
			m_arbMain->Init("risk.xml");
			m_arbMain->Bind(this, EnumKeyDREB);
			m_arbMain->SetSvrTxList(m_pMainService->GetSvrTxList());
		}
		return 0;//����ֻ��Ҫ���׷������Ĺ㲥�˿�
	}
#endif
	pCfgA2 = m_pConfig->GetProperties(gc_sCfgIfA2);
	pCfgF1 = m_pConfig->GetProperties(gc_sCfgIfF1);
	pCfgF2 = m_pConfig->GetProperties(gc_sCfgIfF2);
	pCfgK = m_pConfig->GetProperties(gc_sCfgIfK);
	pCfgH1 = m_pConfig->GetProperties(gc_sCfgIfH1);
	pCfgH2 = m_pConfig->GetProperties(gc_sCfgIfH2);

	pCfgSmsIf= m_pConfig->GetProperties(gc_sCfgIfSmscService);
	
	

	CRLog(E_APPINFO,"%s","��ʼ�����ӵ�...");

	if (0 != pCfgF2 && !pCfgF2->IsEmpty())
	{
		CRLog(E_APPINFO,"%s","��ʼ�����ӵ�F2");
		m_pCpInterfaceF2 = new CProtocolCpSvr<CProcessInterfaceF2S>();	
		m_pCpInterfaceF2->Init(pCfgF2);
		m_pCpInterfaceF2->Bind(this,EnumKeyIfF2);
	}

	if (0 != pCfgA2 && !pCfgA2->IsEmpty())
	{
		CRLog(E_APPINFO,"%s","��ʼ�����ӵ�A2");

		m_pCpInterfaceA2 = new CProtocolCpCli<CProcessInterfaceA2C>();
		m_pCpInterfaceA2->Init(pCfgA2);
		m_pCpInterfaceA2->Bind(this,EnumKeyIfA2);
	}

	if (0 != pCfgSmsIf && !pCfgSmsIf->IsEmpty())
	{
		CRLog(E_APPINFO,"%s","��ʼ�����ӵ�Sms");

		m_pCpInterfaceSmscService = new CProtocolCpCli<CProcessInterfaceSmscService>();
		m_pCpInterfaceSmscService->Init(pCfgSmsIf);
		m_pCpInterfaceSmscService->Bind(this,EnumKeySmsService);
	}


	if (0 != pCfgF1 && !pCfgF1->IsEmpty())
	{
		CRLog(E_APPINFO,"%s","��ʼ�����ӵ�F1");
		m_pCpInterfaceF1 = new CProtocolCpSvr<CProcessInterfaceF1S>();	
		m_pCpInterfaceF1->Init(pCfgF1);
		m_pCpInterfaceF1->Bind(this,EnumKeyIfF1);
	}

	if (0 != pCfgH1 && !pCfgH1->IsEmpty())
	{
		CRLog(E_APPINFO,"%s","��ʼ�����ӵ�H1");
		m_pCpInterfaceH1 = new CProtocolCpCli<CProcessInterfaceH1C>();	
		m_pCpInterfaceH1->Init(pCfgH1);
		m_pCpInterfaceH1->Bind(this,EnumKeyIfH1);
	}

	if (0 != pCfgH2 && !pCfgH2->IsEmpty())
	{
		CRLog(E_APPINFO,"%s","��ʼ�����ӵ�H2");
		m_pCpInterfaceH2 = new CProtocolCpCli<CProcessInterfaceH2C>();
		m_pCpInterfaceH2->Init(pCfgH2);
		m_pCpInterfaceH2->Bind(this,EnumKeyIfH2);
	}

	if (0 != pCfgK && !pCfgK->IsEmpty())
	{
		CRLog(E_APPINFO,"%s","��ʼ�����ӵ�K");
		m_pCpInterfaceK = new CProtocolCpCli<CProcessInterfaceKC>();
		m_pCpInterfaceK->Init(pCfgK);
		m_pCpInterfaceK->Bind(this,EnumKeyIfK);
		m_oIfkTimer.Bind(this);
	}
	return 0;
}

//�������������߳�
int CRiskCpMgr::Start()
{
	//��������������ģ��
	CRLog(E_APPINFO,"%s","Start NetMagModule");
	m_pNetMagModule->Start();

	RiskModuleStart();

	int nRtn = IfCpsStart();
	//ģ�����鴥��һ�η��նȱ�������
	vector<string> v;
	OnCmd("test", v);
	return nRtn;
}

//�����ӵ�����
int CRiskCpMgr::IfCpsStart()
{
	CRLog(E_APPINFO,"%s","�������ӵ�...");

	if (0 != m_pCpInterfaceF2)
	{
		CRLog(E_APPINFO,"%s","�������ӵ�F2");
		if (0 != m_pCpInterfaceF2->Start())
		{
			CRLog(E_APPINFO,"%s","�������ӵ�F2ʧ��");
			return -1;
		}
	}

	if (0 != m_pCpInterfaceF1)
	{
		CRLog(E_APPINFO,"%s","�������ӵ�F1");
		if (0 != m_pCpInterfaceF1->Start())
		{
			CRLog(E_APPINFO,"%s","�������ӵ�F1ʧ��");
			return -1;
		}
	}

	if (0 != m_pCpInterfaceA2)
	{
		CRLog(E_APPINFO,"%s","�������ӵ�A2");
		m_pCpInterfaceA2->Start();
	}
	if (0 != m_pCpInterfaceSmscService)
	{
		CRLog(E_APPINFO,"%s","�������ӵ�Sms");
		m_pCpInterfaceSmscService->Start();
	}

	if (0 != m_pCpInterfaceH1)
	{
		CRLog(E_APPINFO,"%s","�������ӵ�H1");
		m_pCpInterfaceH1->Start();
	}

	if (0 != m_pCpInterfaceH2)
	{
		CRLog(E_APPINFO,"%s","�������ӵ�H2");
		m_pCpInterfaceH2->Start();
	}

	if (0 != m_pCpInterfaceA1)
	{
		CRLog(E_APPINFO,"%s","�������ӵ�A1");
		m_pCpInterfaceA1->Start();
	}

	if (0 != m_pCpInterfaceK)
	{
		CRLog(E_APPINFO,"%s","�������ӵ�K");
		m_pCpInterfaceK->Start();
		m_pGessTimerMgr->CreateTimer(&m_oIfkTimer,8,"Hello");
	}
#ifdef _VER_DREB
	if( m_arbMain != NULL )
	{
		CRLog(E_APPINFO,"%s","�����������ӵ�");
		if (!m_arbMain->Start())
		{
			CRLog(E_ERROR,"m_arbMain.Start() fail \n");
			return -1;
		}
	}
#endif
	return 0;
}

//����ҵ��ģ��
int CRiskCpMgr::RiskModuleStart()
{
	//����������֪ͨ����ģ��
	CRLog(E_APPINFO,"%s","Start RiskNotify");
	m_pRiskNotify->Start();

	//���������ռ���ģ��
	CRLog(E_APPINFO,"%s","Start RiskHandler");
	m_pRiskHandler->Start();
	//ע�ᶨʱ��

	//����������ͬ��ģ��
	CRLog(E_APPINFO,"%s","Start DbSync");
	m_pDbSync->Start();

	//��������ض���ҵ����ģ��
	CRLog(E_APPINFO,"%s","Start MainService");
	m_pMainService->Start();

	/*CRLog(E_APPINFO,"%s","Start SmsSender");
	m_pSmsSender->Start();*/
	

	return 0;
}

//�������� 
void CRiskCpMgr::Finish()
{
	RouterTblFinish();

	IfCpsFinish();

	RiskModuleFinish();

	//
	m_oCpCmdHandler.Finish();
	m_oCpSelfBroadcast.Finish();
	m_oCpSelfIpc.Finish();

	CRLog(E_APPINFO,"%s","Finish NetMagModule");
	m_pNetMagModule->Finish();
	
	m_pGessTimerMgr->Finish();
	CNetMgr::Instance()->NmFinish();

	delete m_pNetMagModule;
	m_pNetMagModule=0;
	
	m_pGessTimerMgr=0;
}

//·�ɱ�����
void CRiskCpMgr::RouterTblFinish()
{
	for (int i = 0; i < EnumKeyUnknown; i++)
	{
		m_tblIfRouter[i].mmapCmds.clear();
	}
}

//ֹͣ����ҵ��
void CRiskCpMgr::Stop()
{
	//��������������ģ��
	CRLog(E_APPINFO,"%s","Stop NetMagModule");
	m_pNetMagModule->Stop();

	//������ʱ��
	CRLog(E_APPINFO,"%s","Stop GessTimerMgr");
	m_pGessTimerMgr->Stop();

	RiskModuleStop();
	
	IfCpsStop();
}

//ֹͣҵ��ģ��
void CRiskCpMgr::RiskModuleStop()
{
	try
	{
		CRLog(E_APPINFO,"%s","Stop����ģ��...");
		CRLog(E_APPINFO,"%s","Stop RiskHandler");
		m_pRiskHandler->Stop();
		CRLog(E_APPINFO,"%s","Stop MainService");
		m_pMainService->Stop();
		CRLog(E_APPINFO,"%s","Stop RiskNotify");
		m_pRiskNotify->Stop();
		CRLog(E_APPINFO,"%s","Stop DbSync");
		m_pDbSync->Stop();
		/*CRLog(E_APPINFO,"%s","Stop SmsSender");
		m_pSmsSender->Stop();*/

	}
	catch(...)
	{
		CRLog(E_ERROR,"%s","Unknown exception!");
	}
}

//ֹͣ�����ӵ�
void CRiskCpMgr::IfCpsStop()
{
	try
	{
		CRLog(E_APPINFO,"%s","Stop���ӵ�...");
		if (0 != m_pCpInterfaceK)
		{
			CRLog(E_APPINFO,"%s","Stop InterfaceK");	
			m_pCpInterfaceK->Stop();
			m_pGessTimerMgr->DestroyTimer(&m_oIfkTimer,"Hello");		
		}

		if (0 != m_pCpInterfaceA1)
		{
			CRLog(E_APPINFO,"%s","Stop InterfaceA1");
			m_pCpInterfaceA1->Stop();
		}

		if (0 != m_pCpInterfaceF1)
		{
			CRLog(E_APPINFO,"%s","Stop InterfaceF1");
			m_pCpInterfaceF1->Stop();
		}

		if (0 != m_pCpInterfaceA2)
		{
			CRLog(E_APPINFO,"%s","Stop InterfaceA2");
			m_pCpInterfaceA2->Stop();
		}

		if (0 != m_pCpInterfaceSmscService)
		{
			CRLog(E_APPINFO,"%s","Stop Interface SmscService");
			m_pCpInterfaceSmscService->Stop();
		}

		if (0 != m_pCpInterfaceF2)
		{
			CRLog(E_APPINFO,"%s","Stop InterfaceF2");
			m_pCpInterfaceF2->Stop();
		}

		if (0 != m_pCpInterfaceH1)
		{
			CRLog(E_APPINFO,"%s","Stop InterfaceH1");
			m_pCpInterfaceH1->Stop();
		}

		if (0 != m_pCpInterfaceH2)
		{
			CRLog(E_APPINFO,"%s","Stop InterfaceH2");
			m_pCpInterfaceH2->Stop();
		}
	}
	catch(...)
	{
		CRLog(E_ERROR,"%s","Unknown exception!");
	}
}

//������ҵ��ģ��
void CRiskCpMgr::RiskModuleFinish()
{
	CRLog(E_APPINFO,"%s","Finish����ģ��...");
	CRLog(E_APPINFO,"%s","Finish RiskHandler");
	m_pRiskHandler->Finish();
	CRLog(E_APPINFO,"%s","Finish MainService");
	m_pMainService->Finish();
	CRLog(E_APPINFO,"%s","Finish RiskNotify");
	m_pRiskNotify->Finish();	
	CRLog(E_APPINFO,"%s","Finish DbSync");
	m_pDbSync->Finish();
	CRLog(E_APPINFO,"%s","Finish MemDb");
	m_pMemDb->Finish();

	delete m_pMainService;
	m_pMainService = 0;

	delete m_pRiskNotify;
	m_pRiskNotify = 0;

	delete m_pRiskHandler;
	m_pRiskHandler = 0;

	delete m_pDbSync;
	m_pDbSync = 0;

	delete m_pMemDb;
	m_pMemDb = 0;
	
}

//���������ӵ�
void CRiskCpMgr::IfCpsFinish()
{
	CRLog(E_APPINFO,"%s","Finish���ӵ�...");
	
	if (0 != m_pCpInterfaceK)
	{
		CRLog(E_APPINFO,"%s","Finish InterfaceK");
		m_pCpInterfaceK->Finish();
		delete m_pCpInterfaceK;	
		m_pCpInterfaceK = 0;
	}

	if (0 != m_pCpInterfaceA1)
	{
		CRLog(E_APPINFO,"%s","Finish InterfaceA1");
		m_pCpInterfaceA1->Finish();
		delete m_pCpInterfaceA1;
		m_pCpInterfaceA1 = 0;	
	}

	if (0 != m_pCpInterfaceA2)
	{
		CRLog(E_APPINFO,"%s","Finish InterfaceA2");
		m_pCpInterfaceA2->Finish();
		delete m_pCpInterfaceA2;
		m_pCpInterfaceA2 = 0;	
	}
	if (0 != m_pCpInterfaceSmscService)
	{
		CRLog(E_APPINFO,"%s","Finish  Interface Sms");
		m_pCpInterfaceSmscService->Finish();
		delete m_pCpInterfaceSmscService;
		m_pCpInterfaceSmscService = 0;	
	}

	if (0 != m_pCpInterfaceF1)
	{
		CRLog(E_APPINFO,"%s","Finish InterfaceF1");
		m_pCpInterfaceF1->Finish();
		delete m_pCpInterfaceF1;
		m_pCpInterfaceF1 = 0;	
	}
	
	if (0 != m_pCpInterfaceF2)
	{
		CRLog(E_APPINFO,"%s","Finish InterfaceF2");
		m_pCpInterfaceF2->Finish();
		delete m_pCpInterfaceF2;
		m_pCpInterfaceF2 = 0;	
	}
	
	if (0 != m_pCpInterfaceH1)
	{
		CRLog(E_APPINFO,"%s","Finish InterfaceH1");
		m_pCpInterfaceH1->Finish();
		delete m_pCpInterfaceH1;
		m_pCpInterfaceH1 = 0;
	}
	
	if (0 != m_pCpInterfaceH2)
	{
		CRLog(E_APPINFO,"%s","Finish InterfaceH2");
		m_pCpInterfaceH2->Finish();
		delete m_pCpInterfaceH2;
		m_pCpInterfaceH2 = 0;
	}

}

//�����߳�
int CRiskCpMgr::StartMe()
{
	//telnet ���������ӵ��ʼ������
	CConfig *pCfgCmd = m_pConfig->GetProperties(gc_sCfgIfCmd);
	m_pCpInterfaceCmd = new CProtocolCpSvr<CProcessInterfaceCmd>();
	CRLog(E_APPINFO,"%s","��ʼ�����ӵ�Cmd");
	m_pCpInterfaceCmd->Init(pCfgCmd);
	m_pCpInterfaceCmd->Bind(this,EnumKeyIfCmd);

	CRLog(E_APPINFO,"%s","�������ӵ�Cmd");
	m_pCpInterfaceCmd->Start();

	m_oNetLogThread.BeginThread();
#ifdef _WINDOWS
	string sCmdFlag("0");
	int nCmdFlag = 0;
	if (0 == m_pConfig->GetProperty("cmdline",sCmdFlag))
	{
		nCmdFlag = FromString<int>(sCmdFlag);
	}
	if (1 == nCmdFlag)
	{
		m_oCmdLineThread.BeginThread();
	}
#endif
	m_oBroadcastPktThread.BeginThread();
	if (m_bUseDreb)
	{
		m_oIpcThread.BeginThread();
	}
	return 0;
}

//ֹͣ�߳�
void CRiskCpMgr::StopMe()
{
	//if (true == m_bStop)
	//	return;
	if (m_bUseDreb)
	{
		m_oIpcThread.EndThread();
	}
	m_oNetLogThread.EndThread();
#ifdef _WINDOWS
	m_oCmdLineThread.EndThread();
	CRLog(E_APPINFO,"%s","Stop InterfaceCmd");
	m_pCpInterfaceCmd->Stop();

	CRLog(E_APPINFO,"%s","Finish InterfaceCmd");
	m_pCpInterfaceCmd->Finish();

	delete m_pCpInterfaceCmd;
	m_pCpInterfaceCmd = 0;
#endif
	m_oBroadcastPktThread.EndThread();
}

//���б��Ĵ�������Ҫ���³�ʼ��
void CRiskCpMgr::SysInit(const string& sDate)
{
	m_csBitsetCps.Lock();
	m_bsCps.reset();
	m_csBitsetCps.Unlock();

	m_bStop=true;
	m_deqCondMutex.Signal();

	/*
	string sTmp = sDate;
	if (sDate == "")
		sTmp = "now";

	CRLog(E_APPINFO,"SysInit To %s...",sTmp.c_str());
	CRLog(E_APPINFO,"%s","Now Stop RiskModules...");
	RiskModuleStop();


	CRLog(E_APPINFO,"%s","Now Finish RouterTbl...");
	RouterTblFinish();

	CRLog(E_APPINFO,"%s","Now Finish Module...");
	RiskModuleFinish();
	
	*/


	/*
		CRLog(E_APPINFO,"%s","Now ReInit MemDb...");
		m_pMemDb->ReInit();
	*/


	//CRLog(E_APPINFO,"%s","Now ReInit Module...");
	//RiskModuleInit(sDate);
	//CRLog(E_APPINFO,"%s","Now Reinit router tbl...");
	//InitRouterTbl();

	
	//CRLog(E_APPINFO,"%s","Now Start RiskModules...");
	//RiskModuleStart();



}

//����ת������
int CRiskCpMgr::Forward(CPacket& pkt,const unsigned long& ulKey)
{
	try
	{	
		int nRtn = -2;
		assert(EnumKeyUnknown > ulKey);
		if (EnumKeyUnknown <= ulKey)
			return -1;

		std::string sCmdID = pkt.GetCmdID();
		if (ulKey == EnumKeyIfA1 && m_nSysState != gc_nSysStateReady && sCmdID != "onSysStatChange" && sCmdID != "onSysInit")
			return 0;
		if (ulKey == EnumKeyDREB && m_nSysState != gc_nSysStateReady && sCmdID != "onSysStatChange" && sCmdID != "onSysInit" && sCmdID.length() > 4)
			return 0;
		bool blFound = false;
		MMAP_IT it;
		RANGE_CP range = m_tblIfRouter[ulKey].mmapCmds.equal_range(sCmdID);
		for (it = range.first; it != range.second; ++it)
		{
			if (0 != (*it).second)
			{
				(*it).second->SendPacket(pkt);
				nRtn = 0;
			}
			blFound = true;
		}

		if (!blFound)
		{
			it = m_tblIfRouter[ulKey].mmapCmds.find(gc_sDefaultCmdID);
			if (it != m_tblIfRouter[ulKey].mmapCmds.end())
			{
				if (0 != (*it).second)
				{
					(*it).second->SendPacket(pkt);
					nRtn = 0;
				}
			}
		}
		return nRtn;
	}
	catch(std::exception e)
	{
		CRLog(E_CRITICAL,"exception:%s", e.what());
		return -1;
	}
	catch(...)
	{
		CRLog(E_CRITICAL,"%s","Unknown exception");
		return -1;
	}
}


//������ͨ��A1�ӿ�ת����ȥ
int CRiskCpMgr::ToInterfaceA1(CPacket& pkt,const unsigned long& ulKey)
{
	return m_pCpInterfaceA1->SendPacket(pkt);
}

//������ͨ��A2�ӿ�ת����ȥ
int CRiskCpMgr::ToInterfaceA2(CPacket& pkt,const unsigned long& ulKey)
{
	return m_pCpInterfaceA2->SendPacket(pkt);
}
int CRiskCpMgr::ToInterfaceSms(CPacket& pkt,const unsigned long& ulKey)
{
	if (0 == m_pCpInterfaceSmscService)
		return -1;

	return m_pCpInterfaceSmscService->SendPacket(pkt);
}

//������ͨ��F1�ӿ�ת����ȥ
int CRiskCpMgr::ToInterfaceF1(CPacket& pkt,const unsigned long& ulKey)
{
	return m_pCpInterfaceF1->SendPacket(pkt);
}

//������ͨ��F2�ӿ�ת����ȥ
int CRiskCpMgr::ToInterfaceF2(CPacket& pkt,const unsigned long& ulKey)
{
	return m_pCpInterfaceF2->SendPacket(pkt);
}

int CRiskCpMgr::ToInterfaceK(CPacket& pkt,const unsigned long& ulKey)
{
	return m_pCpInterfaceK->SendPacket(pkt);
}

//�������̺߳��� ����������
int CRiskCpMgr::Run()
{
	try
	{
		while ( !m_bStop )
		{
			m_deqCondMutex.Lock();
			while(m_deqIpcPacket.empty()&& !m_bStop)
				m_deqCondMutex.Wait();
			
			if (m_bStop)
			{
				m_deqIpcPacket.clear();
				m_deqCondMutex.Unlock();
				break;
			}
		
			if ( !m_deqIpcPacket.empty())
			{
				CIpcPacket pkt = m_deqIpcPacket.front();
				m_deqIpcPacket.pop_front();
				m_deqCondMutex.Unlock();
				RunIpcPacketHandleApi(pkt);
			}
		}

		//�첽�����˳�
		AsynQuit();

		//���ȴ�10��,�������߳�ֱ���˳�
		int nCount = 0;
		do
		{
			if (IsReadyToQuit())
			{
				break;
			}

			msleep(1);
			nCount++;
		} while (nCount < 10);

		return 0;
	}
	catch(std::exception e)
	{
		CRLog(E_CRITICAL,"exception:%s", e.what());
		return -1;
	}
	catch(...)
	{
		CRLog(E_CRITICAL,"%s","Unknown exception");
		return -1;
	}
}

//CmdLine����ƥ�䴦��
string CRiskCpMgr::OnCmd(const string& sCmdLine, const vector<string>& vecPara)
{
	try
	{
		std::string sCmdID = trim(sCmdLine);
	
		int nSize = sizeof(m_CmdLine2Api)/sizeof(CmdLine2Api);
		for ( int i = 0 ; i < nSize ; i++ )
		{
			if ( m_CmdLine2Api[i].sCmdName == sCmdID || (sCmdID != "" && m_CmdLine2Api[i].sCmdAbbr == sCmdID) )
			{
				if (m_CmdLine2Api[i].pMemberFunc == 0)
					break;

				return (this->*(m_CmdLine2Api[i].pMemberFunc))(sCmdLine, vecPara);				
			}
		}
		
		string sRtn("");
		if (sCmdID != "")
		{
			sRtn += "err command!\r\n";
		}
		sRtn += "RiskMgr->";
		return sRtn;
	}
	catch(std::exception e)
	{
		CRLog(E_CRITICAL,"exception:%s", e.what());
		string sRtn = "\r\nRiskMgr->";
		return sRtn;
	}
	catch(...)
	{
		CRLog(E_CRITICAL,"%s","Unknown exception");
		string sRtn = "\r\nRiskMgr->";
		return sRtn;
	}
}

//ͳһA1�ӿڱ���Ӧ��
int CRiskCpMgr::SendAck(CBroadcastPacket& pkt)
{
	//CRLog(E_APPINFO, "%s", m_bsCps.to_string().c_str());

	//CBroadcastPacket pktAck("Ack");
	return 0;//ToInterfaceA1(pktAck);
}

//A1�ӿ�ϵͳ�౨�Ĵ���
int CRiskCpMgr::OnPacketSelfBroadcast(CPacket& pkt)
{
	try
	{
		string sCmdID("");
		
		sCmdID = pkt.GetCmdID();
		CBroadcastPacket pktBroadcast = dynamic_cast<CBroadcastPacket&>(pkt);
		if(sCmdID == "onSysInit" || sCmdID == "onSysStatChange" || sCmdID == "HostStatus")
		{
			m_oBroadcastPktThread.Enque(pktBroadcast);
		}
		else
		{
			SendAck(pktBroadcast);
		}
		
		return 0;
	}
	catch(std::exception e)
	{
		CRLog(E_CRITICAL,"exception:%s", e.what());
		return -1;
	}
	catch(...)
	{
		CRLog(E_CRITICAL,"%s","Unknown exception");
		return -1;
	}
}

int CRiskCpMgr::OnPacketSelfIpc(CPacket& pkt)
{
	try
	{
		CIpcPacket pktIpc = dynamic_cast<CIpcPacket&>(pkt);
		
		m_deqCondMutex.Lock();
		m_deqIpcPacket.push_back(pktIpc);
		m_deqCondMutex.Signal();
		m_deqCondMutex.Unlock();
		return 0;
	}
	catch(std::bad_cast)
	{
		CRLog(E_ERROR,"%s","packet error!");
		return -1;
	}
	catch(std::exception e)
	{
		CRLog(E_CRITICAL,"exception:%s", e.what());
		return -1;
	}
	catch(...)
	{
		CRLog(E_CRITICAL,"%s","Unknown exception");
		return -1;
	}
}

//telnet�ն������
int CRiskCpMgr::OnPacketCmd(CPacket& pkt)
{
	try
	{
		CPacketLineReq & pktLine = dynamic_cast<CPacketLineReq&>(pkt);
		string sRouteKey = pktLine.RouteKey();
		string sCmd = pktLine.GetCmdID();

		vector<string> vecPara;
		vecPara.clear();
		pktLine.GetPara(vecPara);
		
		string sRsp("");
		if ("q" == trim(sCmd) || "quit" == trim(sCmd))
		{
			sRsp += "RiskMgr->";
		}
		else if (sCmd == "debug")
		{
			string sPara("");
			if (vecPara.size() > 0)
				sPara = vecPara[0];
			
			if (trim(sPara) == "on")
			{
				m_csTelnets.Lock();
				m_deqTelnets[sRouteKey] = sRouteKey;
				if (m_deqTelnets.size() == 1)
					CLogger::Instance()->RegisterNetLog(&m_oNetLogHost);
				m_csTelnets.Unlock();

				sRsp += "RiskMgr->";
			}
			else if (trim(sPara) == "off")
			{
				map<string,string>::iterator itTel;	
				m_csTelnets.Lock();
				itTel = m_deqTelnets.find(sRouteKey);
				if (itTel != m_deqTelnets.end())
					m_deqTelnets.erase( itTel);

				if (m_deqTelnets.size() == 0)
					CLogger::Instance()->UnRegisterNetLog(&m_oNetLogHost);
				m_csTelnets.Unlock();

				sRsp += "RiskMgr->";
			}
			else
			{
				sRsp = "Parameter err!";
				sRsp += "\r\n";
				sRsp += "RiskMgr->";
			}
		}
		else
		{
			sRsp = OnCmd(sCmd, vecPara);
		}

		CPacketLineRsp pktRsp(sRsp);
		pktRsp.AddRouteKey(sRouteKey);
		return m_pCpInterfaceCmd->SendPacket(pktRsp);
	}
	catch(std::bad_cast)
	{
		CRLog(E_ERROR,"%s","packet error!");
		return -1;
	}
	catch(std::exception e)
	{
		CRLog(E_ERROR,"exception:%s!",e.what());
		return -1;
	}
	catch(...)
	{
		CRLog(E_ERROR,"%s","Unknown exception!");
		return -1;
	}
}

//��־��Ϣ���̶߳���
void CRiskCpMgr::OnNetLogMsg(const string& sMsg)
{
	m_oNetLogThread.Enque(sMsg);
}

//��־����
int CRiskCpMgr::HandleNetLogMsg(const string & sNetLogMsg)
{
	string sMsg = sNetLogMsg;
	sMsg += "\r\n";
	map<string,string>::iterator itTel;				
	m_csTelnets.Lock();
	for (itTel = m_deqTelnets.begin(); itTel != m_deqTelnets.end(); ++itTel)
	{
		CPacketLineRsp pktRsp(sMsg);
		pktRsp.AddRouteKey((*itTel).first);
		if (0 > m_pCpInterfaceCmd->SendPacket(pktRsp))
		{
			string sKey = (*itTel).first;
			m_deqTelnets.erase(itTel);
			if (0 == m_deqTelnets.size())
			{
				cout << "UnRegisterNetLog! " << sKey << endl;
				CLogger::Instance()->UnRegisterNetLog(&m_oNetLogHost);
			}

			break;
		}
	}
	m_csTelnets.Unlock();

	return 0;
}

//�������̴߳������� ������,(linux�²����ø����á������һֱ���쳣��־lqh)
int CRiskCpMgr::HandleCmdLine(string& sIn)
{
	try
	{
		char cIn = 0;
		cin.get(cIn);
		if (cIn == '\n')
		{				
			string sCmd("");

			sIn = trim(sIn);
			vector<string> vPara;
			vPara = explodeQuoted(" ", sIn);
			if (vPara.size() > 1)
			{
				sCmd = vPara[0];
				vPara.erase(vPara.begin());
			}
			else
			{
				sCmd = sIn;
			}

			string sOut = OnCmd(sCmd, vPara);
			cout << sOut;
			sIn.clear();
		}
		else
		{
			sIn.append(1,cIn);
		}

		return 0;
	}
	catch(std::exception e)
	{
		CRLog(E_CRITICAL,"exception:%s", e.what());
		return -1;
	}
	catch(...)
	{
		CRLog(E_CRITICAL,"%s","Unknown exception");
		return -1;
	}
}

//K�ӿ�������ʱ���ص��ӿ�
int CRiskCpMgr::OnIfkTimeout()
{
	CIpcPacket ipcPkt("KHello");
	string sNodeID = "1002";
	string sTmp = "";
	if (0 == m_pConfig->GetProperty("node_id",sTmp))
		sNodeID = sTmp;

	ipcPkt.AddParameter("node_id",sNodeID);
	ToInterfaceK(ipcPkt);

	return 0;
}

//quit�����
string CRiskCpMgr::OnCmdLineQuit(const string& sCmd, const vector<string>& vecPara)
{
	m_oNetLogThread.EndThread();
	m_oBroadcastPktThread.EndThread();
	m_bStop = true;
	m_deqCondMutex.Signal();

	string sRtn = "RiskMgr->";
	return sRtn;
}

// ģ��quotation�仯
string CRiskCpMgr::OnCmdLineSimQuotation(const string& sCmdLine, const vector<string>& vecPara)
{
	CQuotationTbl& tblQuotation = m_pMemDb->GetQuotationTbl();
	PROD_QUOTATION stQuotation;
	PROD_QUOTATION stSpotQuotation;
	tblQuotation.GetQuotation("Au(T+D)",stQuotation);
	tblQuotation.GetQuotation("Au99.95",stSpotQuotation);

	double RANGE_MIN = stQuotation.dlDownLimit;
	double RANGE_MAX = stQuotation.dlUpLimit;
	double dlSpotMax = stSpotQuotation.dlUpLimit;
	double dlSpotMix = stSpotQuotation.dlDownLimit;


	unsigned int  nLen = 0;
	

	if (RANGE_MIN == 0 || RANGE_MAX == 0)
	{
		RANGE_MIN = 160.00;
		RANGE_MAX = 210.00;
	}
	if (dlSpotMax == 0 || dlSpotMix == 0)
	{
		dlSpotMix = 100.00;
		dlSpotMax = 160.00;
	}

	string sRtn("");
	string sPara("");
	string sCmd = trim(sCmdLine);

	int nCount = 1;
	int nIntervel = 1;
	if (vecPara.size() >= 1)
	{
		nCount = FromString<int>(vecPara[0]);
		if (nCount <= 0 || nCount > 1000)
			nCount = 1;
	}
	if (vecPara.size() >= 2)
	{
		nIntervel = FromString<int>(vecPara[1]);
		if (nIntervel <= 1 || nIntervel > 30)
			nIntervel = 1;
	}
	if (vecPara.size() >= 3)
	{
		double dlMin = FromString<double>(vecPara[2]);
		if (dlMin > 0 && dlMin <= 10000)
			RANGE_MIN = dlMin;
	}
	if (vecPara.size() >= 4)
	{
		double dlMax = FromString<double>(vecPara[3]);
		if (dlMax <= RANGE_MIN)
		{
			RANGE_MAX = RANGE_MIN + 200;
		}
		else
		{
			RANGE_MAX = dlMax;
		}
	}
	CRLog(E_APPINFO,"Sim %d %d",nCount,nIntervel);

	srand(static_cast<unsigned int>(time(0)));

	int nLeft = nCount;	
	for (int s = 0; s < nIntervel; s++)
	{
		int nSim = nLeft / (nIntervel - s);
		nLeft -= nSim;
		for (int i = 0; i < nSim; i++)
		{
			CBroadcastPacket pkt("onRecvDeferQuotation");

			DeferQuotation stBody;
// 			memset(&stBody,0x00,sizeof(DeferQuotation));

			double dlNowPrice = stQuotation.dlNowPrice;
			if( i!= 0 )
				dlNowPrice = rand() % (static_cast<int>(RANGE_MAX - RANGE_MIN)) + RANGE_MIN;

			CRLog(E_APPINFO,"Sim............... Au(T+D) dlNowPrice= %lf ",dlNowPrice);

			stBody.instID = "Au(T+D)";
			stBody.ask5 = stQuotation.dlAsk5;
			stBody.bid1 = stQuotation.dlBid1;
			stBody.lowLimit = stQuotation.dlDownLimit;	
			stBody.highLimit = stQuotation.dlUpLimit;
			stBody.last = dlNowPrice;
			stBody.quoteDate= m_pMemDb->GetBasicParaTbl().GetExchDate();

			CRLog(E_APPINFO,"Sim............... Au(T+D) ExchDate= %s ",stBody.quoteDate.c_str());
			CPacketStructBroadcastRisk::Struct2Packet(stBody, pkt);
			const char* pcBuf = pkt.Encode(nLen);
			CRLog(E_APPINFO,"Sim............... Au(T+D) nLen=%d,BroadcastBuff= %s ",nLen,pcBuf);
			if (0 != m_pRiskHandler)
			{
				m_pRiskHandler->HandleQuotation(pkt);
				sRtn += "Defer Run Quotation! ";
			}
			else
			{
				sRtn += "Defer m_pRiskHandler is not created";
			}	
			CRLog(E_APPINFO,"Sim............... Au(T+D) stat= %s ",sRtn.c_str());

		
			CBroadcastPacket pktSpot("onRecvSpotQuotation");
		
			CRLog(E_APPINFO,"Sim............... Au99.95 Mix= %lf, Max=%lf",dlSpotMix, dlSpotMax );
			if (dlSpotMax - dlSpotMix < numeric_limits<double>::epsilon())
			{
				dlNowPrice = dlSpotMix;
			}
			else
			{
				dlNowPrice = rand() % (static_cast<int>(dlSpotMax - dlSpotMix))  + dlSpotMix;
			}

			stBody.instID = "Au99.95";
			stBody.ask5 = stSpotQuotation.dlAsk5;
			stBody.bid1 = stSpotQuotation.dlBid1;
			stBody.lowLimit = stSpotQuotation.dlDownLimit;	
			stBody.highLimit = stSpotQuotation.dlUpLimit;
			stBody.last = dlNowPrice;
			stBody.quoteDate= m_pMemDb->GetBasicParaTbl().GetExchDate();
			CPacketStructBroadcastRisk::Struct2Packet(stBody, pktSpot);

			if (0 != m_pRiskHandler)
			{
				m_pRiskHandler->HandleQuotation(pktSpot);
			}
			else
			{
				sRtn += "Spot m_pRiskHandler is not created";
			}	
		}
		msleep(1);
	}
	
	sRtn += "RiskMgr->";
	return sRtn;
}

//ģ�����б���
string CRiskCpMgr::OnCmdLineSimInit(const string& sCmd, const vector<string>& vecPara)
{
	string sRtn("");

	CBroadcastPacket pktInit("onSysInit");
	m_oBroadcastPktThread.Enque(pktInit);

	sRtn = "RiskMgr->";
	return sRtn;
}

//ģ�������������
string CRiskCpMgr::OnCmdLineSimSysState(const string& sCmd, const vector<string>& vecPara)
{
	string sRtn("");

	
	CBroadcastPacket pktState("onSysStatChange");
	SysStat stBody;
	stBody.m_sys_stat = ToString(gc_nSysStateAcctFinish);

	CGessDate oDate(m_pMemDb->GetBasicParaTbl().GetExchDate());
	stBody.exch_date = oDate.ToString();

	CPacketStructBroadcastRisk::Struct2Packet(stBody, pktState);
	m_oBroadcastPktThread.Enque(pktState);
	

	sRtn = "RiskMgr->";
	return sRtn;

}

//ͳ������
string CRiskCpMgr::OnCmdLineState(const string& sCmd, const vector<string>& vecPara)  
{
	string sRtn("");

	sRtn +=  "Ave:";
	sRtn += ToString(m_pRiskHandler->GetStatAve());
	sRtn += " Min:" ;
	sRtn += ToString(m_pRiskHandler->GetStatMin());
	sRtn += " Max:";
	sRtn += ToString(m_pRiskHandler->GetStatMax());
	sRtn += " Count:";
	sRtn += ToString(m_pRiskHandler->GetStatCount());
	sRtn += "\r\n";
	sRtn += "RiskMgr->";

	return sRtn;

}

//�ͻ���Ϣ��ѯ����
string CRiskCpMgr::OnCmdLineCustInfo(const string& sCmdLine, const vector<string>& vecPara)   
{
	string sRtn("");
	string sPara("");
	string sCmd = trim(sCmdLine);

	if (vecPara.size() > 0)
	{
		sPara = vecPara[0];
	}

	CCustomer* p = m_pMemDb->GetCustTble().GetCustomer(sPara);
	if (0 != p)
	{
		sRtn = p->ToString();
	}
	else
	{
		sRtn = "Parameter err!";
		sRtn += "\r\n";
		sRtn += "RiskMgr->";
	}

	return sRtn;
}

//��������Ϣ��ѯ����
string CRiskCpMgr::OnCmdLineBranchInfo(const string& sCmdLine, const vector<string>& vecPara)
{
	string sRtn("");
	string sPara("");
	string sCmd = trim(sCmdLine);

	if (vecPara.size() > 0)
	{
		sPara = vecPara[0];
	}

	CAgent* p = m_pMemDb->GetAgentTble().GetAgent(sPara);
	if (0 != p)
	{
		sRtn =  p->ToString();
	}
	else
	{
		sRtn = "Parameter err!";
		sRtn += "\r\n";
		sRtn += "RiskMgr->";
	}

	return sRtn;
}

//Ŀǰ������Ϣ��ѯ
string CRiskCpMgr::OnCmdLineQotationInfo(const string& sCmdLine, const vector<string>& vecPara)
{
	string sRtn("");
	
	sRtn = m_pMemDb->GetQuotationTbl().ToString();
	sRtn += "RiskMgr->";
	return sRtn;
}

//������Ϣ
string CRiskCpMgr::OnCmdLineHelp(const string& sCmdLine, const vector<string>& vecPara)
{
	string sRtn("");
	int nSize = sizeof(m_CmdLine2Api)/sizeof(CmdLine2Api);
	for ( int i = 0 ; i < nSize ; i++ )
	{
		sRtn += m_CmdLine2Api[i].sCmdName;
		if (m_CmdLine2Api[i].sCmdAbbr != "")
		{
			sRtn += "/";
			sRtn += m_CmdLine2Api[i].sCmdAbbr;
		}
		sRtn += ":";
		sRtn += m_CmdLine2Api[i].sHelp;
		sRtn += "\r\n";
	}
	sRtn += "RiskMgr->";

	return sRtn;
}

string CRiskCpMgr::OnCmdLineMatchInfo(const string& sCmdLine, const vector<string>& vecPara)
{
	string sRtn("");
	
	sRtn = m_pMemDb->GetMatchDetailTbl().ToString();
	sRtn += "\r\n";
	sRtn += m_pMemDb->GetCapitalTbl().ToString();
	sRtn += "RiskMgr->";
	return sRtn;
}

string CRiskCpMgr::OnCmdLineSysInfo(const string& sCmdLine, const vector<string>& vecPara)
{
	string sRtn = CSelectorIo::Instance()->ToString();
	sRtn += "\r\n";
	sRtn += CSelectorListen::Instance()->ToString();
	sRtn += "\r\n";
	sRtn += CGessTimerMgrImp::Instance()->ToString();
	sRtn += "RiskMgr->";
	return sRtn;
}

string CRiskCpMgr::OnCmdLine3DesEnc(const string& sCmdLine, const vector<string>& vecPara)
{
	string sRtn = "";
	if (vecPara.size() == 0)
	{
		sRtn = "Parameter error!";
		sRtn += "\r\n";
		sRtn += "RiskMgr->";
		return sRtn;
	}
		
	// ��ȡԭʼ����
	char szPwd[512];
	strcpy(szPwd,vecPara[0].c_str());

	// ��ԭʼ������м���
	string sErrorMsg;
	if( CGlobal::Get3DesEnc(szPwd,strlen(szPwd),sErrorMsg) == 0 )
	{
		sRtn = "3DES/BASE64���ܺ�ĵ����봮:";
		sRtn += szPwd;
	}
	else
	{
		sRtn = sErrorMsg;
	}

	sRtn += "\r\n";
	sRtn += "RiskMgr->";
	return sRtn;
}

int CRiskCpMgr::NotifyClientInit()
{
	CRLog(E_APPINFO,"%s","֪ͨ�ͻ���ϵͳ��ʼ��...");

	CBroadcastPacket pktSysInit("RiskSystemInit");
	
	//�鱨��ͷ...
	pktSysInit.AddParameter("MsgType",gc_sPktTypeBroadcast);
	pktSysInit.AddParameter("CheckFlag","0");
	
	return ToInterfaceF2(pktSysInit);
}

int CRiskCpMgr::NotifySmsDayend(std::string curDate)
{
	HEADER_REQ stHeaderReqA2;

	CTradePacket pktReqA2;
	unsigned long	m_ulKey=123;
	std::string content="";
	try
	{
		memset(&stHeaderReqA2,0x00,sizeof(stHeaderReqA2));
		sprintf(stHeaderReqA2.seq_no,"%s","000000000");
		sprintf(stHeaderReqA2.msg_type,"%s",gc_sPktTypeBroadcast.c_str());
		sprintf(stHeaderReqA2.exch_code,"%s","3057");
		sprintf(stHeaderReqA2.msg_flag,"%s",gc_sPktTypeTrade.c_str());
		sprintf(stHeaderReqA2.term_type,"%s",gc_sTermTypeRsk.c_str());
		sprintf(stHeaderReqA2.user_type,"%s",gc_sUserTypeOper.c_str());
		sprintf(stHeaderReqA2.user_id,"%s", "  ");


		char szTmp[128];
		memset(szTmp,0x00,128);
		sprintf(szTmp,"%c%ds",'%',BRANCHID);
		sprintf(stHeaderReqA2.branch_id,"   ");

		sprintf(stHeaderReqA2.c_teller_id1,"%s","");
		sprintf(stHeaderReqA2.c_teller_id2,"%s","");

		pktReqA2.SetHeader(stHeaderReqA2);

		pktReqA2.AddParameter("oper_flag",1);
		pktReqA2.AddParameter("exch_date",curDate);		
	
		ToInterfaceSms(pktReqA2,m_ulKey);
		return 0;
	}
	catch(std::exception e)
	{
		CRLog(E_ERROR,"exception:%s!",e.what());
		return -1;
	}
	catch(...)
	{
		CRLog(E_ERROR,"%s","Unknown exception!");
		return -1;
	}
}

int CRiskCpMgr::OnHostStatus( CBroadcastPacket& pkt )
{
	pkt.GetParameterVal("IsMaster", m_nIsMaster);
	if (1 == m_nIsMaster)
	{
		CRLog(E_APPINFO, "��ǰ����Ϊ��������Ȩִ���Զ�ǿƽ ");
	}
	else
	{
		CRLog(E_APPINFO, "��ǰ����Ϊ����������ִ���Զ�ǿƽ ");
	}
	return 0;
}
