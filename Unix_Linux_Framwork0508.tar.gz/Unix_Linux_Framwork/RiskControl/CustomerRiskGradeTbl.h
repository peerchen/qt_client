#ifndef CCUSTOMERRISKGRADETBL_H_HEADER_INCLUDED_B6E390DA
#define CCUSTOMERRISKGRADETBL_H_HEADER_INCLUDED_B6E390DA
#include <string>
#include <map>
#include <vector>
#include "Gess.h"
using namespace std;

//���ռ���
class CRiskGrade
{
public:
	CRiskGrade(unsigned short usGradeID,string sGradeName, double dlGradeValueDown,double dlGradeValueUp, unsigned short usTypeID):
	m_usGradeID(usGradeID)
	,m_sGradeName(sGradeName)
	,m_dlGradeValueDown(dlGradeValueDown)
	,m_dlGradeValueUp(dlGradeValueUp)
	,m_usTypeID(usTypeID)
	{}
	~CRiskGrade(){}
	inline unsigned short GradeID() const {return m_usGradeID;}
	inline string Name() const {return m_sGradeName;}
	inline double DownValue() const {return m_dlGradeValueDown;}
	inline double UpValue() const {return m_dlGradeValueUp;}
	inline bool IsInclude(const double& dlVal) const {return dlVal > m_dlGradeValueDown && dlVal <= m_dlGradeValueUp;}
	inline unsigned short TypeID() const {return m_usTypeID;}
private:
	unsigned short m_usGradeID;	//���ռ���ID
	string m_sGradeName;		//���ռ�������
	double m_dlGradeValueDown;  //�÷��ռ�����ն�ֵ
	double m_dlGradeValueUp;   	//�÷��ռ�����ն�ֵ

	unsigned short m_usTypeID;  //������������ID
};

//�ͻ����ռ���
class CustomerRiskGrade
{
public:
	CustomerRiskGrade(const string& sCustID,const string& sAgentID,const string& sAcctType,unsigned short usGradeID,string sGradeName, double dlGradeValueDow,double dlGradeValueUp):
	m_sCustID(sCustID)
	,m_sAgentID(sAgentID)
	,m_sAcctType(sAcctType)
	,m_RiskGrade(usGradeID,sGradeName,dlGradeValueDow,dlGradeValueUp,usGradeID/10)
	{}
	~CustomerRiskGrade(){}
	unsigned short GradeID() const {return m_RiskGrade.GradeID();}
	double DownValue() const {return m_RiskGrade.DownValue();}
	double UpValue() const {return m_RiskGrade.UpValue();}
	bool IsInclude(double dlVal) const {return dlVal >= m_RiskGrade.DownValue() && dlVal < m_RiskGrade.UpValue();}
private:
	string m_sCustID;
	string m_sAgentID;
	string m_sAcctType;
	CRiskGrade m_RiskGrade;
};

class otl_connect;
class CCustomerRiskGradeTbl
{
public:
	CCustomerRiskGradeTbl();
	~CCustomerRiskGradeTbl();

    //���ݿͻ�ID������������ID���˻����Ͳ�����ȡ��Ӧ�ķ��ռ�����Ϣ
    //int GetRiskGrade(const string& sCustID, const string& sAgentID, const string& sAcctType, unsigned short usGradeID, RISK_GRADE& stRiskGrade);
	int GetRiskGrade(const string& sCustID, const string& sAgentID, const string& sAcctType, unsigned short usGradeID, CRiskGrade& RiskGrade);

    //���Ӽ�¼
    int AddCustomerGrade(const string& sCustID,const string& sAgentID, const string& sAcctType,unsigned short usGradeID, double dlGradeValueDown,double dlGradeValueUp);

    //�޸ļ�¼
    int UpdateCustomerGrade(const string& sCustID,const string& sAgentID, const string& sAcctType,unsigned short usGradeID, double dlGradeValueDown,double dlGradeValueUp);

    //���������ݿ��ʼ��
    int Init(otl_connect& dbConnection);
	//��������
	void Finish();
  private:
    //��¼����
    vector<CustomerRiskGrade> m_vecRiskGrade;
    //����
    CGessMutex m_mutexTbl;
};

#endif /* CCUSTOMERRISKGRADETBL_H_HEADER_INCLUDED_B6E390DA */
