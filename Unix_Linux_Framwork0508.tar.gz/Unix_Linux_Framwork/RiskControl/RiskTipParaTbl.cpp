#include "RiskTipParaTbl.h"
#include "DB_Version.h" 
#include "Logger.h"
#include "strutils.h"
//#include "VersionMacro.h"

using namespace strutils;

CRiskTipParaTbl::CRiskTipParaTbl()
{

}

CRiskTipParaTbl::~CRiskTipParaTbl()
{
	Finish();
}

//##ModelId=491A48DE0119
int CRiskTipParaTbl::GetRiskTip(unsigned short usTipType,string& sTip)
{
	int nRtn = -1;
	CGessGuard guard(m_mutexTbl);
	map<unsigned short,string>::iterator it = m_mapTips.find(usTipType);
	if (it != m_mapTips.end())
	{
		sTip = it->second; 
		nRtn = 0;
	}
	return nRtn;
}

int CRiskTipParaTbl::GetRiskTip(unsigned short usSrcGrade, unsigned short usDesGrade, std::string &sTip)
{
	int nRtn = -1;
	string sKey = ToString<unsigned short>(usSrcGrade) + ToString<unsigned short>(usDesGrade);

	CGessGuard guard(m_mutexTbl);
	map<string, string>::iterator it = m_mapNotifyPara.find(sKey);
	if (it != m_mapNotifyPara.end())
	{
		sTip = it->second; 
		nRtn = 0;
	}
	return nRtn;
}

//##ModelId=491A48FC0167
void CRiskTipParaTbl::SetRiskTip(unsigned short usTipType,const string& sTip)
{
	CGessGuard guard(m_mutexTbl);
	map<unsigned short,string>::iterator it = m_mapTips.find(usTipType);
	if (it != m_mapTips.end())
	{
		it->second = sTip; 
	}
	else
	{
		m_mapTips[usTipType] = sTip;
	}
}

void CRiskTipParaTbl::SetRiskTip(unsigned short usSrcGrade, unsigned short usDesGrade, std::string &sTip)
{
	string sKey = ToString<unsigned short>(usSrcGrade) + ToString<unsigned short>(usDesGrade);
	CGessGuard guard(m_mutexTbl);
	map<string, string>::iterator it = m_mapNotifyPara.find(sKey);
	if (it != m_mapNotifyPara.end())
	{
		it->second = sTip; 
	}
	else
	{
		m_mapNotifyPara[sKey] = sTip;
	}
}

//##ModelId=491A4DD2002E
int CRiskTipParaTbl::Init(otl_connect& dbConnection)
{
	char cTipType[5];
	char cTipContent[2001];
	char cSrcGrade[5];
	char cDesGrade[5];
	string sSql = "";

	memset(cTipType, 0, sizeof(cTipType));
	memset(cTipContent, 0, sizeof(cTipContent));
	memset(cSrcGrade, 0, sizeof(cSrcGrade));
	memset(cDesGrade, 0, sizeof(cDesGrade));
	
	try
	{
		
#ifdef _VER_25_DB2
		sSql = "select FG_CovToChar(tip_type), tip_content, FG_CovToChar(src_grade_id), FG_CovToChar(des_grade_id) from risk_notify_para";
#else
		sSql = "select to_char(tip_type), tip_content, to_char(src_grade_id), to_char(des_grade_id) from risk_notify_para";
#endif

		otl_stream oTip(1, sSql.c_str(), dbConnection);

		while (!oTip.eof())
		{
			oTip >> cTipType >> cTipContent >> cSrcGrade >>cDesGrade;
			string sKey = cSrcGrade;
			sKey = sKey + cDesGrade;
			m_mapTips[atoi(cTipType)] = cTipContent;
			m_mapNotifyPara[sKey] = cTipContent;
		}
	}
	catch(otl_exception &p)
	{
		CRLog(E_ERROR, "otl exception:%s,%s,%s,%s", p.msg, p.stm_text, p.sqlstate, p.var_info);
	}

	return 0;
}

//��������
void CRiskTipParaTbl::Finish()
{
	CGessGuard guard(m_mutexTbl);
	m_mapTips.clear();
	m_mapNotifyPara.clear();
}