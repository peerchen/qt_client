#ifndef CTRIGGERTBL_H_HEADER_INCLUDED_B6E3ACAA
#define CTRIGGERTBL_H_HEADER_INCLUDED_B6E3ACAA
#include <string>
#include <map>
#include <vector>
#include "Gess.h"

using namespace std;

typedef struct tagTriggerPrice
{
	string  sProdCode;					// ��Լ����  
	int 		nIndex;							//������
	double  dlTriggerPrice;            // �����۸�
} TRIGGER_PRICE,*PTRIGGER_PRICE;

class CProdCodeTbl;
class CTriggerTbl
{//�����ʴ����۸���ʷ��
public:
	CTriggerTbl();
	~CTriggerTbl();

    //##ModelId=4913F5B20290
    int GetTriggerPrice(int nIndex,double& dlPrice);

    //##ModelId=4913F5D4036B
    int  GetTriggerPrice(const string& sProdID,double& dlPrice);

    //##ModelId=4913F61D00DA
    int SetTriggerPrice(int nIndex,double dlPrice);

    //##ModelId=4913F63901A5
    int SetTriggerPrice(string sProdID,double dlPrice);

	//##ModelId=491529F900EA
    int GetPriceArray(vector <double> & dlPrice);

	 int Init(CProdCodeTbl& ProdCodeTbl);
	 //��������
	void Finish();
private:
    //##ModelId=4913F5790261
    vector<TRIGGER_PRICE> vecTrigger;
	//##ModelId=4916E108033C
    CGessMutex  m_mutexTbl;
};
#endif /* CTRIGGERTBL_H_HEADER_INCLUDED_B6E3ACAA */
