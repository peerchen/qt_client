#include "RiskCpMgr.h"

// A1 �ӿ� [onRecvRtnSpotMarketStateUpdate]SpotMarketState ��ҵ��ʵ��
int CRiskCpMgr::OnSpotMarketState(CBroadcastPacket& pkt)
{
	SpotMarketState stBody;
	CPacketStructBroadcastRisk::Packet2Struct(stBody, pkt);

	//ҵ��ʵ��......
	SendAck(pkt);

	return 0;
};
