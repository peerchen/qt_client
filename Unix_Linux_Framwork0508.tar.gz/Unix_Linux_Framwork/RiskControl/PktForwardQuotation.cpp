#include "RiskHandler.h"

// A1 �ӿ� [onRecvForwardQuotation]ForwardQuotation ��ҵ��ʵ��
int CRiskHandler::OnForwardQuotation(CBroadcastPacket& pkt)
{
	ForwardQuotation stBody;
	CPacketStructBroadcastRisk::Packet2Struct(stBody, pkt);

	//ҵ��ʵ��......
	SendAck(pkt);

	return 0;
};
