#ifndef CRISKALGORITHMDEF_H_HEADER_INCLUDED_B6E3F77F
#define CRISKALGORITHMDEF_H_HEADER_INCLUDED_B6E3F77F
#include <cmath>
#include <limits>
#include "RiskAlgorithm.h"
#include "strutils.h"
#include "Constant.h"

using namespace strutils;
using namespace Const;

class CRiskAlgorithmDef : public CRiskAlgorithm
{
public:
	CRiskAlgorithmDef(){}
	~CRiskAlgorithmDef(){}

	//##ModelId=49153E74029F
	inline double Risk(double dlCapital, double dlMarginMem, double dlBalance,double dlMarginExch)
	{
		double dlRiskDegree = 0.00;
		double dlMargin=dlMarginMem+dlMarginExch;
		if (dlMargin <= numeric_limits<double>::epsilon())
		{
			dlRiskDegree = 0.00;
		}
		else
		{
			double dlVal = dlCapital + dlMargin + dlBalance;
			if	(dlVal <= numeric_limits<double>::epsilon())
			{
				dlRiskDegree = 100.00;
			}
			else
			{
				dlRiskDegree = dlMargin / dlVal;
				if (dlRiskDegree > 100)
					dlRiskDegree = 100;
			}
		}

		//����ת��,�Ա�֤���㾫�Ⱥ���ʾ����һ��,��ֹ��ʾ���ն�ֵһ������������ķ������͵Ȳ�һ��
		//return FRound(dlRiskDegree);
		return dlRiskDegree;
	}
};

#endif /* CRISKALGORITHMDEF_H_HEADER_INCLUDED_B6E3F77F */
