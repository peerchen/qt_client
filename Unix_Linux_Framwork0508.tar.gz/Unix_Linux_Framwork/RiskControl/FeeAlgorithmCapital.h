#ifndef CFEEALGORITHMCAPITAL_H_HEADER_INCLUDED_B6E394E7
#define CFEEALGORITHMCAPITAL_H_HEADER_INCLUDED_B6E394E7
#include "FeeAlgorithm.h"

class CFeeAlgorithmCapital : public CFeeAlgorithm
{
  public:
    //##ModelId=4916D62D035B
	  CFeeAlgorithmCapital(double dlRatio):m_dlRatio(dlRatio){}

    //##ModelId=4915BAC10280
	double Fee(double dlMatchCapital, double dlWeight, int nVolume){return dlMatchCapital*m_dlRatio;}

  private:
    //##ModelId=4915BA4A0138
    double m_dlRatio;
};

#endif /* CFEEALGORITHMCAPITAL_H_HEADER_INCLUDED_B6E394E7 */
