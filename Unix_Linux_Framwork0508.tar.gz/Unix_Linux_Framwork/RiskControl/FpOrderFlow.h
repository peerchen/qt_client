#ifndef FPORDERFLOW_H_
#define FPORDERFLOW_H_

#include <string>
#include "Gess.h"

using namespace std;
class CFpOrderFlowStatistics
{
public:
	CFpOrderFlowStatistics(){}
	CFpOrderFlowStatistics( string sGameId, string sRoundId, string sAcctNo,string sMemberId,string sProdCode,double dlPrice,int nNumBuy=0,int nNumSell=0,double dlMarignBuy=0.0,double dlMarginSell=0.0,double dlFareBuy=0.0,double dlFareSell=0.0)
	:m_sGameId(sGameId)
	,m_sRoundId(sRoundId)
	,m_sAcctNo(sAcctNo)
	,m_sMemberId(sMemberId)
	,m_sProdCode(sProdCode)
	,m_dlPrice(dlPrice)
	,m_nNumBuy(nNumBuy)
	,m_nNumSell(nNumSell)
	,m_dlMarginBuy(dlMarignBuy)
	,m_dlMarginSell(dlMarginSell)
	,m_dlFareBuy(dlFareBuy)
	,m_dlFareSell(dlFareSell){}
	~CFpOrderFlowStatistics(){}
	void SetNumBuy(int nNum);
	void SetNumSell(int nNum);
	void SetMarginBuy(double dlMargin);
	void SetMarginSell(double dlMargin);
	void SetFareBuy(double dlFare);
	void SetFareSell(double dlFare);

	void UpdateNumBuy(int nNum);
	void UpdateNumSell(int nNum);
	void UpdateMarginBuy(double dlMargin);
	void UpdateMarginSell(double dlMargin);
	void UpdateFareBuy(double dlFare);
	void UpdateFareSell(double dlFare);
	void UpdateEntrPrice(double dlPrice);

	string GetGameId() const {return m_sGameId;}
	string GetRoundId() const {return m_sRoundId;}
	string GetAcctNo() const {return m_sAcctNo;}
	string GetProdCode() const {return m_sProdCode;}
	string GetMemberId() const {return m_sMemberId;}
	int GetNumBuy() const {return m_nNumBuy;}
	int GetNumSell() const {return m_nNumSell;}
	double GetMarginBuy() const {return m_dlMarginBuy;}
	double GetMarginSell() const {return m_dlMarginSell;}
	double GetFareBuy() const {return m_dlFareBuy;}
	double GetFareSell() const {return m_dlFareSell;}
	double GetFpEntrPrice() const {return m_dlPrice;}

private:
	//add by wct ͳ�����ӳ��κ��ִΣ�ԭ��
	string m_sGameId;       //����
	string m_sRoundId;      //�ִ�
	//add end

	string m_sAcctNo;			
	string m_sMemberId;
	string m_sProdCode;
	int	   m_nNumBuy;		//�걨������
	int    m_nNumSell;		//�걨������
	double m_dlMarginBuy;	//�걨�򶳽ᱣ֤��
	double m_dlMarginSell;	//�걨�����ᱣ֤��
	double m_dlFareBuy;		//�걨�򶳽�������
	double m_dlFareSell;	//�걨�򶳽�������
	double m_dlPrice;		//�����걨�۸�

};

class CFpOrderFlow
{
public:
	CFpOrderFlow(){}
	CFpOrderFlow(string sOrderNo,string sAcctNo,string sMemberId,string sProdCode,char cBs,int nNum,double dlPrice,double dlMargin,double dlFare,string sPhase,string sOrderType,string sStat,string sGameId,string sRoundId)
		:m_sOrderNo(sOrderNo)
		,m_sAcctNo(sAcctNo)
		,m_sMemberId(sMemberId)
		,m_sProdCode(sProdCode)
		,m_cBs(cBs)
		,m_nNum(nNum)
		,m_dlPrice(dlPrice)
		,m_dlFrozMargin(dlMargin)
		,m_dlFroFare(dlFare)
		,m_sEntrPhase(sPhase)
		,m_sOrderType(sOrderType)
		,m_sStat(sStat)
		,m_sGameId(sGameId)
		,m_sRoundId(sRoundId){}
	~CFpOrderFlow(){}

	string GetOrderNo() const {return m_sOrderNo;}
	string GetAcctNo() const {return m_sAcctNo;}
	string GetProdCode() const {return m_sProdCode;}
	string GetMemberId() const {return m_sMemberId;}
	
	char GetBuyorSell() const {return m_cBs;}
	int  GetNum() const {return m_nNum;}
	double GetPrice() const {return m_dlPrice;}
	double GetFrozMargin() const {return m_dlFrozMargin;}
	double GetFrozFare() const {return m_dlFroFare;}

	string GetEntrPhase() const {return m_sEntrPhase;}
	string GetOrderType() const {return m_sOrderType;}
	string GetStat() const {return m_sStat;}
	string GetGameId() const {return m_sGameId;}
	string GetRoundId() const {return m_sRoundId;}
private:
	string m_sOrderNo;
	string m_sAcctNo;			
	string m_sMemberId;
	string m_sProdCode;
	char   m_cBs;			//�걨����
	int    m_nNum;			//�걨����
	double m_dlPrice;		//�����걨�۸�
	double m_dlFrozMargin;	//���ᱣ֤��
	double m_dlFroFare;		//����������
	string m_sEntrPhase;    //�걨�׶�
	string m_sOrderType;	//��������
	string m_sStat;			//״̬
	string m_sGameId;		//����
	string m_sRoundId;		//�ִ�
};
#endif