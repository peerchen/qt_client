#include "MainServiceHandler.h"
#include "Logger.h"
#include "ForceCloseParaTbl.h"

// F1 �ӿ� [3085]�������ñ��� ��ҵ��ʵ��
int CMainServiceHandler::OnForceCoverParaReq(CTradePacket& pkt)
{
	HEADER_REQ stHeaderReq;
	ForceCoverParaReq stBodyReq;

	HEADER_RSP stHeaderRsp;
	ForceCoverParaRsp stBodyRsp;

	pkt.GetHeader(stHeaderReq);
	CPacketStructTradeRisk::Packet2Struct(stBodyReq, pkt);

	//ҵ��ʵ��......
	CTradePacket pktRsp;
	CPacketStructTradeRisk::HeadReq2Rsp(stHeaderReq,stHeaderRsp);
	
	char cProdCode[11];		//��Լ����
	char cBs[3];			//��������
	char cPriority[11];		//��Լ˳��
	string sSql = "";
	ArrayListMsg almResultTemp;
	vector<PROD_PRIORITY> vecProd;
	PROD_PRIORITY stProdPriority;

	strcpy(stHeaderRsp.rsp_code,RSP_SUCCESS.c_str());

	memset(cProdCode, 0, sizeof(cProdCode));
	memset(cBs, 0, sizeof(cBs));
	memset(cPriority, 0, sizeof(cPriority));

	try
	{
		//���Ĵ���		0����ѯ		1���޸�
		if (stBodyReq.oper_flag == 0)
		{
			/*
			sSql = "select prod_code, bs, to_char(priority) from force_cover_priority order by priority";

			otl_stream o(1, sSql.c_str(), m_OtlConn);
			while (!o.eof())
			{
				o >> cProdCode >> cBs >> cPriority;

				almResultTemp.clear();
				almResultTemp.AddValue(cProdCode);
				almResultTemp.AddValue(cBs);
				almResultTemp.AddValue(cPriority);

				stBodyRsp.prod_set.AddValue(almResultTemp);
			}
			*/
			//���ڴ����ȡ
			m_pMemDb->GetForceCloseParaTbl().GetRecordSet(vecProd);

			for (vector<PROD_PRIORITY>::iterator it = vecProd.begin(); it != vecProd.end(); it++)
			{
				almResultTemp.clear();
				almResultTemp.AddValue(it->sProdCode);
				if (it->ucDir == gc_cShort)
				{
					almResultTemp.AddValue(gc_sProdBuy);
				}
				else
				{
					almResultTemp.AddValue(gc_sProdSell);
				}
				almResultTemp.AddValue(it->nPriority);

				stBodyRsp.prod_set.AddValue(almResultTemp);
			}
		}
		else if (stBodyReq.oper_flag == 1)
		{
			otl_cursor::direct_exec(GetOtlConn(), "delete from force_cover_priority");

			sSql = "insert into force_cover_priority values(:f1<char[10]>, :f2<char[2]>, :f3<int>)";
			otl_stream o(1, sSql.c_str(), GetOtlConn());
			
			bool blSuccessFlag = true;
			for (unsigned int i=0; i<stBodyReq.prod_set.size(); i++)
			{
				almResultTemp.clear();
				stBodyReq.prod_set.GetValue(i, almResultTemp);
				if (almResultTemp.GetValue<string>(1) == gc_sProdBuy)
				{
					stProdPriority.ucDir = gc_cShort;
				}
				else if(almResultTemp.GetValue<string>(1) == gc_sProdSell)
				{
					stProdPriority.ucDir = gc_cLong;
				}
				else
				{
					blSuccessFlag =  false;
					strcpy(stHeaderRsp.rsp_code, RSP_PARAM_ERROR.c_str());
					pktRsp.AddParameter("rsp_msg", "�����������");
					break;
				}

				//�������ݿ��
				o << almResultTemp.GetValue<string>(0).c_str() << stProdPriority.ucDir << almResultTemp.GetValue<int>(2);

				//�����ڴ��
				stProdPriority.sProdCode = almResultTemp.GetValue<string>(0).c_str();
				
				stProdPriority.nPriority = almResultTemp.GetValue<int>(2);

				vecProd.push_back(stProdPriority);
			}
			if(blSuccessFlag == true)
			{
				Commit();
				m_pMemDb->GetForceCloseParaTbl().UpdateRecord(vecProd);
			}   
			else
			{
				Rollback();
			}
		}
		else
		{
			strcpy(stHeaderRsp.rsp_code, RSP_PARAM_ERROR.c_str());
			pktRsp.AddParameter("rsp_msg", "�����������");
		}
	}
	catch(otl_exception& p)
	{
		CRLog(E_ERROR, "DB:MSG:%s\nTEXT:%s\nVARINFO:%s", p.msg, p.stm_text, p.var_info); 
		Rollback();
		strcpy(stHeaderRsp.rsp_code, RSP_EXCEPTION.c_str());
		pktRsp.AddParameter("rsp_msg", (const char *)p.msg);
	}

	//������Ӧ����
	stBodyRsp.oper_flag = stBodyReq.oper_flag;

	pktRsp.SetHeader(stHeaderRsp);
	CPacketStructTradeRisk::Struct2Packet(stBodyRsp,pktRsp);

	//ת������
	m_pRiskCpMgr->ToInterfaceF1(pktRsp,m_ulKey);

	return 0;
};
