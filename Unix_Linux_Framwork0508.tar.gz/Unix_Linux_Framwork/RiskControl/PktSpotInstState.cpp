#include "RiskCpMgr.h"

// A1 �ӿ� [onRecvRtnSpotInstStateUpdate]SpotInstState ��ҵ��ʵ��
int CRiskCpMgr::OnSpotInstState(CBroadcastPacket& pkt)
{
	SpotInstState stBody;
	CPacketStructBroadcastRisk::Packet2Struct(stBody, pkt);

	//ҵ��ʵ��......
	SendAck(pkt);

	return 0;
};
