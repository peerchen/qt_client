#include "EtfFeeDetailTbl.h"
#include "RiskConstant.h"
#include "Logger.h"
#include "FeeAlgorithmCapital.h"
#include "FeeAlgorithmVolume.h"
#include "FeeAlgorithmWeight.h"
using namespace RiskConst ;

CEtfFeeDetailTbl::CEtfFeeDetailTbl()
{

}

CEtfFeeDetailTbl::~CEtfFeeDetailTbl()
{
	Finish();
}



//������Ӧ������ȡ��Ӧ���շ�ģʽ����
int CEtfFeeDetailTbl::GetFeeVal(const string& sEtfCollectType,const string& sCustID, const string& sProdID,const string& sFeeType,double& dlFeeVal)
{
	int nRtn = -1;
	CGessGuard guard(m_mutexTbl);
	map<string, ETF_FEE_DETAIL>::iterator it = m_mapEtfFeeDetail.find(sEtfCollectType + sCustID + sProdID);
	if (it != m_mapEtfFeeDetail.end())
	{
		if(sFeeType.compare(gc_sETFSubscribe) == 0)
		{
			dlFeeVal =  it->second.dlETFSubscribe_Value;
			nRtn = 0;
		}
		else if(sFeeType.compare(gc_sETFPurchase) == 0)
		{
			dlFeeVal =  it->second.dlETFPurchase_Value;
			nRtn = 0;
		}
		else if(sFeeType.compare(gc_sETFRedemption) == 0)
		{		
			dlFeeVal =  it->second.dlETFRedemption_Value;
			nRtn = 0;
		}
		else 
		{}
		
	}
	return nRtn;
}


//���´��������ݿ��ʼ��
int CEtfFeeDetailTbl::ReInit(otl_connect& dbConnection)
{
	CGessGuard guard(m_mutexTbl);
	//��ռ���
	Finish();

	//��ʼ��
	Init(dbConnection);

	return 0;
}


//���������ݿ��ʼ��
int CEtfFeeDetailTbl::Init(otl_connect& dbConnection)
{
	char cCollectType[3];					//�շѷ�
	char cAcctNo[16];						//�ͻ���
	char cEtfID[11];						//��Լ����
	double dlETFSubscribe_Value;			//�Ϲ���������
	double dlETFPurchase_Value;				//�깺��������
	double dlETFRedemption_Value;			//�����������

	ETF_FEE_DETAIL stEtfFeeDetail;
	string sSql = "";

	memset(cAcctNo, 0, sizeof(cAcctNo));
	memset(cEtfID, 0, sizeof(cEtfID));
	

	try
	{
		sSql = "select etf_collect_type, acct_no, etf_id, subscribe_fare_value, subscription_fare_value, redemption_fare_value from etf_fare_detail";
		otl_stream o(1, sSql.c_str(), dbConnection);

		CGessGuard guard(m_mutexTbl);
		while (!o.eof())
		{
			o >> cCollectType >> cAcctNo >> cEtfID >> dlETFSubscribe_Value >> dlETFPurchase_Value >> dlETFRedemption_Value;

			stEtfFeeDetail.sEtfCollectType = cCollectType;
			stEtfFeeDetail.sCustID = cAcctNo;
			stEtfFeeDetail.sEtfID = cEtfID;
			stEtfFeeDetail.dlETFSubscribe_Value  = dlETFSubscribe_Value;
			stEtfFeeDetail.dlETFPurchase_Value   = dlETFPurchase_Value;
			stEtfFeeDetail.dlETFRedemption_Value = dlETFRedemption_Value;

			m_mapEtfFeeDetail[stEtfFeeDetail.sEtfCollectType + stEtfFeeDetail.sCustID + stEtfFeeDetail.sEtfID] = stEtfFeeDetail;			
		}
	}
	catch(otl_exception& p)
	{
		CRLog(E_ERROR,"otl exception:%s,%s,%s,%s",p.msg,p.stm_text,p.sqlstate,p.var_info);
	}

	return 0;
}

//��������
void CEtfFeeDetailTbl::Finish()
{
	try
	{
		CGessGuard guard(m_mutexTbl);
		m_mapEtfFeeDetail.clear();
	}
	catch(...)
	{
		CRLog(E_ERROR,"%s","CEtfFeeDetailTbl Error!");
	}
}

