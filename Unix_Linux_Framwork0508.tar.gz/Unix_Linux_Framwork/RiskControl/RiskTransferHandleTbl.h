#ifndef CRISKTRANSFERHANDLETBL_H_HEADER_INCLUDED_B6E3FF78
#define CRISKTRANSFERHANDLETBL_H_HEADER_INCLUDED_B6E3FF78
#include <string>
#include <map>
#include <vector>
#include "Gess.h"
using namespace std;

typedef struct tagRiskTransferHandle
{
	unsigned short usGradeFrom;
	unsigned short usGradeTo;
	unsigned short usHandleID;
	unsigned short usPrioty;
} RISK_TRANSFER_HANDLE,*PRISK_TRANSFER_HANDLE;

class otl_connect;
class CRiskTransferHandleTbl
{
public:
	CRiskTransferHandleTbl();
	~CRiskTransferHandleTbl();

    //##ModelId=491AF46200BB
    int GetHandle(unsigned short usGradeFrom, unsigned short usGradeTo, vector<RISK_TRANSFER_HANDLE>& vec);

    //##ModelId=491B044E007D
    int Init(otl_connect& dbConnection);
	//��������
	void Finish();
  private:
    //##ModelId=491AF42D006D
    vector<RISK_TRANSFER_HANDLE> m_vecRiskTransferHandle;
};


#endif /* CRISKTRANSFERHANDLETBL_H_HEADER_INCLUDED_B6E3FF78 */
