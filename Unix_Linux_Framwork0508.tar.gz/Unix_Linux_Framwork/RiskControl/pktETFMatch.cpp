#include "RiskHandler.h"

// A1 �ӿ� [onRecvRtnETFMatch]ETFMatch ��ҵ��ʵ��
int CRiskHandler::OnETFMatch(CBroadcastPacket& pkt)
{
	ETFMatch stBody;
	
	try
	{
		CPacketStructBroadcastRisk::Packet2Struct(stBody, pkt);	

		//ҵ��ʵ��......
		SendAck(pkt);

		//ͨ���ͻ��Ų��ҿͻ�����
		CCustomer* p = FindCustomer(stBody.acct_no);		
		if (!p)
			return -1;

		std::string sKey = stBody.local_order_no;
		CEtfMatchDetailTbl& tblMatch = m_pMemDb->GetETFMatchDetailTbl();	
		if (tblMatch.IsHandled(sKey,stBody.acct_no))
			return -1;
		

		CRLog(E_APPINFO,"OnETFMatch %s %s %s %s %s %s %f %f %s %f %f %s %f %f %s %f %f %s %f %f %f %f %f",
			stBody.orderNo.c_str(), stBody.local_order_no.c_str(), stBody.acct_no.c_str(), stBody.b_etf_trade_type.c_str(), stBody.etf_id.c_str(),
			stBody.prod_code1.c_str(), stBody.day_cash_balance1, stBody.weight1,
			stBody.prod_code2.c_str(), stBody.day_cash_balance2, stBody.weight2,
			stBody.prod_code3.c_str(), stBody.day_cash_balance3, stBody.weight3,
			stBody.prod_code4.c_str(), stBody.day_cash_balance4, stBody.weight4,
			stBody.prod_code5.c_str(), stBody.day_cash_balance5, stBody.weight5,
			stBody.froz_trans_fee, stBody.froz_diff_fee/*, stBody.froz_cash_balance*/
			);

		//����ת����Ϣ
		CustRiskInfo oCustRiskInfo;		
		
		int nRtn = gc_cStateNormal;		
		
		CETFMatch pETFMatch = CETFMatch(stBody.orderNo,stBody.b_etf_trade_type,stBody.acct_no,stBody.etf_id,
			stBody.prod_code1,stBody.day_cash_balance1,stBody.weight1,
			stBody.prod_code2,stBody.day_cash_balance2,stBody.weight2,
			stBody.prod_code3,stBody.day_cash_balance3,stBody.weight3,
			stBody.prod_code4,stBody.day_cash_balance4,stBody.weight4,
			stBody.prod_code5,stBody.day_cash_balance5,stBody.weight5,
			stBody.froz_trans_fee, stBody.froz_diff_fee,/* stBody.froz_cash_balance,*/
			stBody.local_order_no);
			
		nRtn = p->OnRtnMatchETF(pETFMatch,oCustRiskInfo);


		if (nRtn == gc_cStateNormal)
		{
		}
		if (nRtn == gc_cStateValueChange)
		{
			//����� 
			m_pRiskNotify->Enque(oCustRiskInfo);
		}
		if (nRtn == gc_cStateRiskTransfer)
		{
			//����� 
			m_pRiskNotify->Enque(oCustRiskInfo);
		}

		p->UpdateAgentBalanceStat();
		p->UpdateAgentDebtStat();
	}
	catch(...)
	{
		CRLog(E_ERROR,"%s","OnETFMatch exception");
	}

	return 0;
}