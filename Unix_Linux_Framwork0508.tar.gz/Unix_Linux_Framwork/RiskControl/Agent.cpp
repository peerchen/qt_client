#include "Agent.h"
#include "Customer.h"
#include "Logger.h"
#include "RiskConstant.h"

using namespace RiskConst;
using namespace std;

CAgent::CAgent()
:m_sName("")
,m_sID("")
,m_sType("")
,m_sLevel("")
,m_pParent(0)
,m_dlCapitalStat(0.0)
,m_dlMarginMemOther(0.0)
,m_dlMarginExchOther(0.0)
,m_dlMarginStat(0.0)
,m_dlMarginMem(0.0)
,m_dlMarginExch(0.0)
,m_dlBalanceStat(0.0)
,m_dlLossStat(0.0)
,m_dlInCapitalTdyStat(0.0)
,m_dlOutCapitalTdyStat(0.0)
,m_dlCapitalStatOther(0.0)
,m_dlMarginStatOther(0.0)
,m_dlBalanceStatOther(0.0)
,m_dlLossStatOther(0.0)
,m_dlInCapitalTdyStatOther(0.0)
,m_dlOutCapitalTdyStatOther(0.0)
,m_dlBalanceStatOld(0.0)
,m_dlLossStatOld(0.0)
,m_dlBalanceStatOtherOld(0.0)
,m_dlLossStatOtherOld(0.0)
,m_blBalanceUpdate(false)
,m_dlDebtStat(0.0)
,m_dlDebtStatOther(0.0)
,m_dlDebtStatOld(0.0)
,m_dlDebtStatOtherOld(0.0)
,m_blDebtUpdate(false)
,m_dlMarginStatLastDay(0.0)
,m_dlMarginMemLastDay(0.0)
,m_dlMarginExchLastday(0.0)
,m_dlMarginStatOtherLastDay(0.0)
,m_dlMarginMemOtherLastDay(0.0)
,m_dlMarginExchOtherLastday(0.0)
{}	
 
CAgent::CAgent(string sAgentName,string sAgentId, string sAgentType, string sAgentLevel)
:m_sName(sAgentName)
,m_sID(sAgentId)
,m_sType(sAgentType)
,m_sLevel(sAgentLevel)
,m_pParent(0)
,m_dlCapitalStat(0.0)
,m_dlMarginMemOther(0.0)
,m_dlMarginExchOther(0.0)
,m_dlMarginMem(0.0)
,m_dlMarginExch(0.0)
,m_dlMarginStat(0.0)
,m_dlBalanceStat(0.0)
,m_dlLossStat(0.0)
,m_dlInCapitalTdyStat(0.0)
,m_dlOutCapitalTdyStat(0.0)
,m_dlCapitalStatOther(0.0)
,m_dlMarginStatOther(0.0)
,m_dlBalanceStatOther(0.0)
,m_dlLossStatOther(0.0)
,m_dlInCapitalTdyStatOther(0.0)
,m_dlOutCapitalTdyStatOther(0.0)
,m_dlBalanceStatOld(0.0)
,m_dlLossStatOld(0.0)
,m_dlBalanceStatOtherOld(0.0)
,m_dlLossStatOtherOld(0.0)
,m_blBalanceUpdate(false)
,m_dlDebtStat(0.0)
,m_dlDebtStatOther(0.0)
,m_dlDebtStatOld(0.0)
,m_dlDebtStatOtherOld(0.0)
,m_blDebtUpdate(false)
,m_dlMarginStatLastDay(0.0)
,m_dlMarginMemLastDay(0.0)
,m_dlMarginExchLastday(0.0)
,m_dlMarginStatOtherLastDay(0.0)
,m_dlMarginMemOtherLastDay(0.0)
,m_dlMarginExchOtherLastday(0.0)
{}

CAgent::~CAgent()
{
	m_mapRiskGradeStat.clear();	
	m_mapRiskTypeStat.clear();

	m_mapRiskGradeStatOther.clear();	
	m_mapRiskTypeStatOther.clear();

	m_mapCust.clear();
	m_mapChildAgent.clear();
}

//����ֱ������������
void CAgent::AddChildAgent(const string& sChildAgentID, CAgent* pChildAgent)
{
	m_csAgent.Lock();
	m_mapChildAgent[sChildAgentID] = pChildAgent;
	m_csAgent.Unlock();
}

//����ֱ�������ͻ�
void CAgent::AddCustomer(const string& sCustID, CCustomer* pCust)
{
	unsigned short usRiskGrade = pCust->RiskGrade();
	unsigned short usRiskType = pCust->RiskType();

	m_csAgent.Lock();
	map<unsigned short,RISK_GRADE_STAT>::iterator iterGrade = m_mapRiskGradeStat.find(usRiskGrade);
	if (iterGrade != m_mapRiskGradeStat.end())
	{
		(*iterGrade).second.nNum += 1;
// 		CRLog(E_DEBUG, "1.���ӿͻ� usRiskGrade=%d,usRiskType=%d,num=%d", usRiskGrade, usRiskType, (*iterGrade).second.nNum);
	}
	else
	{
		RISK_GRADE_STAT stStat;
		stStat.usGrade = usRiskGrade;
		stStat.nNum = 1;
		m_mapRiskGradeStat[usRiskGrade] = stStat;
// 		CRLog(E_DEBUG, "2.���ӿͻ�usRiskGrade=%d,usRiskType=%d,num=%d", usRiskGrade, usRiskType, stStat.nNum);
	}

	map<unsigned short,RISK_GRADE_STAT>::iterator iterType = m_mapRiskTypeStat.find(usRiskType);
	if (iterType != m_mapRiskTypeStat.end())
	{
		(*iterType).second.nNum += 1;
// 		CRLog(E_DEBUG, "3.���ӿͻ� usRiskGrade=%d,usRiskType=%d,num=%d", usRiskGrade, usRiskType, (*iterType).second.nNum);
	}
	else
	{
		RISK_GRADE_STAT stStat;
		stStat.usGrade = usRiskType;
		stStat.nNum = 1;
		m_mapRiskTypeStat[usRiskType] = stStat;
// 		CRLog(E_DEBUG, "4.���ӿͻ� usRiskGrade=%d,usRiskType=%d,num=%d", usRiskGrade, usRiskType, stStat.nNum);
	}

	m_mapCust[sCustID] = pCust;
	m_csAgent.Unlock();

	if (0 != m_pParent)
		m_pParent->AddRiskStateOther(usRiskGrade,usRiskType);
}

//���ӷ��յȼ�ͳ��
void CAgent::AddRiskStateOther(unsigned short usRiskGrade,unsigned short usRiskType)
{
	m_csAgent.Lock();
	map<unsigned short,RISK_GRADE_STAT>::iterator iterGrade = m_mapRiskGradeStatOther.find(usRiskGrade);
	if (iterGrade != m_mapRiskGradeStatOther.end())
	{
		(*iterGrade).second.nNum += 1;
	}
	else
	{
		RISK_GRADE_STAT stStat;
		stStat.usGrade = usRiskGrade;
		stStat.nNum = 1;
		m_mapRiskGradeStatOther[usRiskGrade] = stStat;
	}

	map<unsigned short,RISK_GRADE_STAT>::iterator iterType = m_mapRiskTypeStatOther.find(usRiskType);
	if (iterType != m_mapRiskTypeStatOther.end())
	{
		(*iterType).second.nNum += 1;
// 		CRLog(E_DEBUG, "8.���ӿͻ� usRiskGrade=%d,usRiskType=%d,num=%d", usRiskGrade, usRiskType, (*iterType).second.nNum);
	}
	else
	{
		RISK_GRADE_STAT stStat;
		stStat.usGrade = usRiskType;
		stStat.nNum = 1;
		m_mapRiskTypeStatOther[usRiskType] = stStat;
// 		CRLog(E_DEBUG, "9.���ӿͻ� usRiskGrade=%d,usRiskType=%d,num=%d", usRiskGrade, usRiskType, stStat.nNum);
	}
	m_csAgent.Unlock();

	if (0 != m_pParent)
		m_pParent->AddRiskStateOther(usRiskGrade,usRiskType);
}

string CAgent::GetName() const
{
	return m_sName;
}

//����ֱ�ӿͻ��ܳ����
void CAgent::UpdateInOut(double dlCapital,int nDir)
{
	m_csAgent.Lock();
	if(nDir == gc_cCapitalIn)
	{
		m_dlInCapitalTdyStat+=dlCapital;
	}
	else
	{
		 m_dlOutCapitalTdyStat+=dlCapital;
	}
	m_csAgent.Unlock();

	if (0 != m_pParent)
		m_pParent->UpdateInOutOther(dlCapital,nDir);
}

//������ӿͻ��ܳ����
void CAgent::UpdateInOutOther(double dlCapital,int nDir)
{
	m_csAgent.Lock();
	if(nDir == gc_cCapitalIn)
	{
		m_dlInCapitalTdyStatOther += dlCapital;
	}
	else
	{
		 m_dlOutCapitalTdyStatOther += dlCapital;
	}
	m_csAgent.Unlock();

	if (0 != m_pParent)
		m_pParent->UpdateInOutOther(dlCapital,nDir);
}


//����ֱ�ӿͻ�����
void CAgent::UpdateRiskState(unsigned short usGradeTo, unsigned short usGradeFrom,unsigned short usTypeTo, unsigned short usTypeFrom)
{
	m_csAgent.Lock();
	if(usGradeTo != usGradeFrom)
	{
		map<unsigned short,RISK_GRADE_STAT>::iterator iterGrade = m_mapRiskGradeStat.find(usGradeFrom);
		if (iterGrade != m_mapRiskGradeStat.end())
		{
			(*iterGrade).second.nNum -= 1;
		}

		iterGrade = m_mapRiskGradeStat.find(usGradeTo);
		if (iterGrade != m_mapRiskGradeStat.end())
		{
			(*iterGrade).second.nNum += 1;
		}
		else
		{
			RISK_GRADE_STAT stStat;
			stStat.usGrade = usGradeTo;
			stStat.nNum = 1;
			m_mapRiskGradeStat[usGradeTo] = stStat;
		}
	}

	if(usTypeTo != usTypeFrom)
	{
		map<unsigned short,RISK_GRADE_STAT>::iterator iterType = m_mapRiskTypeStat.find(usTypeFrom);
		if (iterType != m_mapRiskTypeStat.end())
		{
			(*iterType).second.nNum -= 1;
//  			CRLog(E_DEBUG, "5.���¿ͻ� usGradeFrom=%d, num=%d", usTypeFrom, (*iterType).second.nNum);
		}

		iterType = m_mapRiskTypeStat.find(usTypeTo);
		if (iterType != m_mapRiskTypeStat.end())
		{
			(*iterType).second.nNum += 1;
// 			CRLog(E_DEBUG, "6.���¿ͻ� usTypeTo=%d, num=%d", usTypeTo, (*iterType).second.nNum);
		}
		else
		{
			RISK_GRADE_STAT stStat;
			stStat.usGrade = usTypeTo;
			stStat.nNum = 1;
			m_mapRiskTypeStat[usTypeTo] = stStat;
// 			CRLog(E_DEBUG, "7.���¿ͻ� usTypeTo=%d, num=%d", usTypeTo, stStat.nNum);
		}
	}
	m_csAgent.Unlock();

	if (0 != m_pParent)
		m_pParent->UpdateRiskStateOther(usGradeTo,usGradeFrom,usTypeTo,usTypeFrom);
}

//������ӿͻ�����
void CAgent::UpdateRiskStateOther(unsigned short usGradeTo, unsigned short usGradeFrom,unsigned short usTypeTo, unsigned short usTypeFrom)
{
	m_csAgent.Lock();
	if(usGradeTo != usGradeFrom)
	{
		map<unsigned short,RISK_GRADE_STAT>::iterator iterGrade = m_mapRiskGradeStatOther.find(usGradeFrom);
		if (iterGrade != m_mapRiskGradeStatOther.end())
		{
			(*iterGrade).second.nNum -= 1;
		}

		iterGrade = m_mapRiskGradeStatOther.find(usGradeTo);
		if (iterGrade != m_mapRiskGradeStatOther.end())
		{
			(*iterGrade).second.nNum += 1;
		}
		else
		{
			RISK_GRADE_STAT stStat;
			stStat.usGrade = usGradeTo;
			stStat.nNum = 1;
			m_mapRiskGradeStatOther[usGradeTo] = stStat;
		}
	}

	if(usTypeTo != usTypeFrom)
	{
		map<unsigned short,RISK_GRADE_STAT>::iterator iterType = m_mapRiskTypeStatOther.find(usTypeFrom);
		if (iterType != m_mapRiskTypeStatOther.end())
		{
			(*iterType).second.nNum -= 1;
// 			CRLog(E_DEBUG, "10.���¿ͻ� usGradeFrom=%d, num=%d", usTypeFrom, (*iterType).second.nNum);
		}

		iterType = m_mapRiskTypeStatOther.find(usTypeTo);
		if (iterType != m_mapRiskTypeStatOther.end())
		{
			(*iterType).second.nNum += 1;
// 			CRLog(E_DEBUG, "11.���¿ͻ� usTypeTo=%d, num=%d", usTypeTo, (*iterType).second.nNum);
		}
		else
		{
			RISK_GRADE_STAT stStat;
			stStat.usGrade = usTypeTo;
			stStat.nNum = 1;
			m_mapRiskTypeStatOther[usTypeTo] = stStat;
// 			CRLog(E_DEBUG, "12.���¿ͻ� usTypeTo=%d, num=%d", usTypeTo, stStat.nNum);
		}
	}
	m_csAgent.Unlock();

	if (0 != m_pParent)
		m_pParent->UpdateRiskStateOther(usGradeTo,usGradeFrom,usTypeTo,usTypeFrom);
}

//����ֱ�ӿͻ��ܿ����ʽ�
void CAgent::UpdateCapital(double dlCapital)
{
	m_csAgent.Lock();
	m_dlCapitalStat += dlCapital;
	m_csAgent.Unlock();

	if (0 != m_pParent)
		m_pParent->UpdateCapitalOther(dlCapital);
}

//������ӿͻ��ܿ����ʽ�
void CAgent::UpdateCapitalOther(double dlCapital)
{
	m_csAgent.Lock();
	m_dlCapitalStatOther += dlCapital;
	m_csAgent.Unlock();

	if (0 != m_pParent)
		m_pParent->UpdateCapitalOther(dlCapital);
}

//����ֱ�ӿͻ��ܱ�֤��
void CAgent::UpdateMargin(double dlMarginMen,double dlMarginExch)
{
	m_csAgent.Lock();
	m_dlMarginStat+=(dlMarginMen+dlMarginExch);
	m_dlMarginMem+=dlMarginMen;
	m_dlMarginExch+=dlMarginExch;
	m_csAgent.Unlock();

	if (0 != m_pParent)
		m_pParent->UpdateMarginOther(dlMarginMen,dlMarginExch);
}

//������ӿͻ��ܱ�֤��
void CAgent::UpdateMarginOther(double dlMarginMen,double dlMarginExch)
{
	m_csAgent.Lock();
	m_dlMarginStatOther += (dlMarginMen+dlMarginExch);
	m_dlMarginMemOther+=dlMarginMen;
	m_dlMarginExchOther+=dlMarginExch;
	m_csAgent.Unlock();

	if (0 != m_pParent)
		m_pParent->UpdateMarginOther(dlMarginMen,dlMarginExch);
}

//������ӿͻ������ܱ�֤��
void CAgent::UpdateMarginOtherLastDay(double dlMarginMen,double dlMarginExch)
{
	m_csAgent.Lock();
	m_dlMarginStatOtherLastDay += (dlMarginMen + dlMarginExch);
	m_dlMarginMemOtherLastDay += dlMarginMen;
	m_dlMarginExchOtherLastday += dlMarginExch;
	m_csAgent.Unlock();

	if (0 != m_pParent)
	{
		m_pParent->UpdateMarginOtherLastDay(dlMarginMen, dlMarginExch);
	}

}

//���������ܱ�֤��
void CAgent::UpdateMarginLastDay(double dlMarginMen,double dlMarginExch)
{
	m_csAgent.Lock();
	m_dlMarginStatLastDay += (dlMarginMen+dlMarginExch);
	m_dlMarginMemLastDay += dlMarginMen;
	m_dlMarginExchLastday += dlMarginExch;
	m_csAgent.Unlock();

	if (0 != m_pParent)
	{
		m_pParent->UpdateMarginOtherLastDay(dlMarginMen, dlMarginExch);
	}

}

//ȡ�����̿����ʽ�
//nType 0ֱ�������ܼ� 1���м�������ܼ�
double CAgent::GetCapitalStat(int nType) const
{
	m_csAgent.Lock();
	double dlCapitalStat = nType == 0 ? m_dlCapitalStat : m_dlCapitalStat + m_dlCapitalStatOther;
	m_csAgent.Unlock();
	return dlCapitalStat;
}

//���������ܱ�֤��
//nType 0ֱ�������ܼ� 1���м�������ܼ�
double CAgent::GetMarginStat(int nType) const
{
	m_csAgent.Lock();
	double dlMarginStat = nType == 0 ? m_dlMarginStat : m_dlMarginStat + m_dlMarginStatOther;
	m_csAgent.Unlock();
	return dlMarginStat;
}

//�������������ܱ�֤��
double CAgent::GetMarginStatLastDay(int nType /* = 1 */) const
{
	m_csAgent.Lock();
	double dlMarginStatLastDay = (nType == 0) ? m_dlMarginStatLastDay : m_dlMarginStatLastDay + m_dlMarginStatOtherLastDay;
	m_csAgent.Unlock();

	return dlMarginStatLastDay;
}

//�������������ܻ�Ա��֤��
double CAgent::GetMarginMemLastDay(int nType /* = 1 */) const
{
	m_csAgent.Lock();
	double dlMarginMemLastDay = (nType == 0) ? m_dlMarginMemLastDay : m_dlMarginMemLastDay + m_dlMarginMemOtherLastDay;
	m_csAgent.Unlock();

	return dlMarginMemLastDay;
}

//�������������ܽ�������֤��
double CAgent::GetMarginExchLastDay(int nType /* = 1 */) const
{
	m_csAgent.Lock();
	double dlMarginExchLastDay = (nType == 0) ? m_dlMarginExchLastday : m_dlMarginExchLastday + m_dlMarginExchOtherLastday;
	m_csAgent.Unlock();

	return dlMarginExchLastDay;
}

//���������ܻ�Ա��֤��
//nType 0ֱ�������ܼ� 1���м�������ܼ�
double CAgent::GetMarginMem(int nType) const
{
	double dlMarginMem = 0.00;
	m_csAgent.Lock();
	dlMarginMem = nType == 0 ? m_dlMarginMem: m_dlMarginMem + m_dlMarginMemOther;
	m_csAgent.Unlock();
	return dlMarginMem;
}
//���������ܽ�������֤��
//nType 0ֱ�������ܼ� 1���м�������ܼ�
double CAgent::GetMarginExch(int nType) const
{
	m_csAgent.Lock();
	double dlMarginExch = nType == 0 ? m_dlMarginExch : m_dlMarginExch + m_dlMarginExchOther;
	m_csAgent.Unlock();
	return dlMarginExch;
}

//���������ܸ���ӯ��
//nType 0ֱ�������ܼ� 1���м�������ܼ�
double CAgent::GetBalanceStat(int nType) const
{
	m_csAgent.Lock();
	double dlBalanceStat = nType == 0 ? m_dlBalanceStat : m_dlBalanceStat + m_dlBalanceStatOther;
	m_csAgent.Unlock();
	return dlBalanceStat;
}

//��������׷�����
//nType 0ֱ�������ܼ� 1���м�������ܼ�
double CAgent::GetDebtStat(int nType) const
{
	m_csAgent.Lock();
	double dlDebtStat = 0.000;
	if (nType == 0)
	{
		if (fabs(m_dlCapitalStat + m_dlBalanceStat) >= numeric_limits<double>::epsilon())
		{
			dlDebtStat = 0.000;
		
		}
		else
		{
			dlDebtStat = m_dlCapitalStat + m_dlBalanceStat;
		    
		}
	}
	else
	{
		if (fabs(m_dlCapitalStat + m_dlCapitalStatOther + m_dlBalanceStat + m_dlBalanceStatOther) >= numeric_limits<double>::epsilon())
		{
			dlDebtStat = 0.000;
		
		}
		else
		{
			dlDebtStat = m_dlCapitalStat + m_dlCapitalStatOther + m_dlBalanceStat + m_dlBalanceStatOther;
		}
	}
	m_csAgent.Unlock();
	return dlDebtStat;
}

//���������ܿ���
//nType 0ֱ�������ܼ� 1���м�������ܼ�
double CAgent::GetLossStat(int nType) const
{
	m_csAgent.Lock();
	double dlLossStat = nType == 0 ? m_dlLossStat : m_dlLossStat + m_dlLossStatOther;
	m_csAgent.Unlock();
	return dlLossStat;
	
}

//�������̽������
//nType 0ֱ�������ܼ� 1���м�������ܼ�
double CAgent::GetInCapitalTdyStat(int nType) const
{
	m_csAgent.Lock();
	double dlInCapitalTdyStat = nType == 0 ? m_dlInCapitalTdyStat : m_dlInCapitalTdyStat + m_dlInCapitalTdyStatOther;
	m_csAgent.Unlock();
	return dlInCapitalTdyStat;
}

//�������̽��ճ���
//nType 0ֱ�������ܼ� 1���м�������ܼ�
double CAgent::GetOutCapitalTdyStat(int nType) const
{
	m_csAgent.Lock();
	double dlOutCapitalTdyStat = nType == 0 ? m_dlOutCapitalTdyStat : m_dlOutCapitalTdyStat + m_dlOutCapitalTdyStatOther;
	m_csAgent.Unlock();
	return dlOutCapitalTdyStat;
}

//�жϱ��������Ƿ�����sAgentID�������Ĵ����̵��¼�
//sAgentID,������ID
//����ֵ:0ֱ���¼�,1����¼� 2���� -1���¼�
int CAgent::IsBelongTo(const string& sAgentID) const
{
	if (m_sID == sAgentID)
		return 2;

	if (m_pParent == 0)
		return -1;

	if (sAgentID == m_pParent->ID())
		return 0;

	if (-1 != m_pParent->IsBelongTo(sAgentID))
		return 1;

	return -1;

}

//��ȡ���տͻ�����ͳ������ 
//���������nType 0ֱ�ӿͻ�ͳ�� 1���к���ӿͻ�ͳ��
//���������nNormalNum,�����ͻ���
//          nCallNum,׷���ͻ���
//          nForceNum,ǿƽ�ͻ���
void CAgent::GetRiskTypeStat(int& nNormalNum,int& nCallNum,int& nForceNum,int& nForceNumAbs ,int& nOutStock ,int &nNeg ,int nType) const
{
	nNormalNum = nCallNum = nForceNum = nForceNumAbs = 0;
	map<unsigned short,RISK_GRADE_STAT>::const_iterator iterType;
	try
	{
		m_csAgent.Lock();
		for (iterType = m_mapRiskTypeStat.begin(); iterType!=m_mapRiskTypeStat.end(); ++iterType)   
		{
			if((*iterType).first==gc_cRiskTypeNormal)
			{
				nNormalNum = (*iterType).second.nNum;
			}
			else if((*iterType).first==gc_cRiskTypeCall)
			{
				nCallNum = (*iterType).second.nNum;
			}
			else if((*iterType).first==gc_cRiskTypeForce)
			{
				nForceNum = (*iterType).second.nNum;
			}
			else if ((*iterType).first==gc_cRiskTypeForceAbs)
			{
				nForceNumAbs= (*iterType).second.nNum;
			}
			else if ((*iterType).first==gc_cRiskTypeOutStock)
			{
				nOutStock = (*iterType).second.nNum;
			}
			else if ((*iterType).first==gc_cRiskTypeNeg)
			{
				nNeg= (*iterType).second.nNum;
			}
			
		}

		if (1 == nType)
		{
			for (iterType = m_mapRiskTypeStatOther.begin(); iterType!=m_mapRiskTypeStatOther.end(); ++iterType)   
			{
				if((*iterType).first==gc_cRiskTypeNormal)
				{
					nNormalNum += (*iterType).second.nNum;
				}
				else if((*iterType).first==gc_cRiskTypeCall)
				{
					nCallNum += (*iterType).second.nNum;
				}
				else  if((*iterType).first==gc_cRiskTypeForce)
				{
					nForceNum += (*iterType).second.nNum;
				}
				else if ((*iterType).first==gc_cRiskTypeForceAbs)
				{
					nForceNumAbs += (*iterType).second.nNum;
				}
				else if ((*iterType).first==gc_cRiskTypeOutStock)
				{
					nOutStock += (*iterType).second.nNum;
				}
				else if ((*iterType).first==gc_cRiskTypeNeg)
				{
					nNeg += (*iterType).second.nNum;
				}
			}
		}
		m_csAgent.Unlock();
	}
	catch(std::exception e)
	{
		m_csAgent.Unlock();
		CRLog(E_ERROR,"exception:%s!",e.what());			
	}
	catch(...)
	{
		m_csAgent.Unlock();
		CRLog(E_ERROR,"%s","Unknown exception!");			
	}
}

//��ȡ�������������ͻ�����
//���������nType 0������ֱ�ӡ�1���������к����
//���������m �������������ͻ�������
void CAgent::GetCustomers(int nType,map<std::string,CCustomer*>& m) const
{
	map<std::string,CCustomer*>::const_iterator itCust;
	try
	{	
		m_csAgent.Lock();
		for(itCust=m_mapCust.begin();itCust!=m_mapCust.end();++itCust)
		{
			m.insert(map<std::string,CCustomer*>::value_type((*itCust).first, (*itCust).second));
		}
		
		if (nType!=0)
		{
			if(!m_mapChildAgent.empty())
			{
				map<std::string,CAgent*> ::const_iterator itAgent;
				for(itAgent=m_mapChildAgent.begin();itAgent!=m_mapChildAgent.end();++itAgent)
				{
					CAgent* p = (*itAgent).second;
					if (0 != p)
						p->GetCustomers(nType,m);
				}
			}
		}
		m_csAgent.Unlock();
	}
	catch(std::exception e)
	{
		m_csAgent.Unlock();
		CRLog(E_ERROR,"exception:%s!",e.what());			
	}
	catch(...)
	{
		m_csAgent.Unlock();
		CRLog(E_ERROR,"%s","Unknown exception!");			
	}
}


//��ȡ�������������ͻ�����
//���������nType 0������ֱ�ӡ�1���������к����
//���������m �������������ͻ�������
void CAgent::GetCustomers(int nType,vector<CCustomer*>& m) const
{
	map<std::string,CCustomer*>::const_iterator itCust;
	try
	{	
		m_csAgent.Lock();
		for(itCust=m_mapCust.begin();itCust!=m_mapCust.end();++itCust)
		{
			m.push_back((*itCust).second);
		}
		
		if (nType!=0)
		{
			if(!m_mapChildAgent.empty())
			{
				map<std::string,CAgent*> ::const_iterator itAgent;
				for(itAgent=m_mapChildAgent.begin();itAgent!=m_mapChildAgent.end();++itAgent)
				{
					CAgent* p = (*itAgent).second;
					if (0 != p)
						p->GetCustomers(nType,m);
				}
			}
		}
		m_csAgent.Unlock();
	}
	catch(std::exception e)
	{
		m_csAgent.Unlock();
		CRLog(E_ERROR,"%s","exception:%s!",e.what());			
	}
	catch(...)
	{
		m_csAgent.Unlock();
		CRLog(E_ERROR,"%s","Unknown exception!");			
	}
}


//��ȡ�����������������̼���
//���������nType 0������ֱ�ӡ�1���������к����
//���������m �����������������̵�����
void CAgent::GetAgents(int nType,map<std::string,CAgent*>& m) const
{
	map<std::string,CAgent*>::const_iterator itAgent;
	try
	{	
		m_csAgent.Lock();
		for(itAgent=m_mapChildAgent.begin();itAgent!=m_mapChildAgent.end();++itAgent)
		{
			CAgent* p = (*itAgent).second;
			if (0 != p)
			{
				m.insert(map<std::string,CAgent*>::value_type((*itAgent).first, p));
				
				if (nType!=0)
				{//��ֱ��
					p->GetAgents(nType,m);
				}
			}
		}
		m_csAgent.Unlock();
	}
	catch(std::exception e)
	{
		m_csAgent.Unlock();
		CRLog(E_ERROR,"exception:%s!",e.what());			
	}
	catch(...)
	{
		m_csAgent.Unlock();
		CRLog(E_ERROR,"%s","Unknown exception!");			
	}
}

//��ȡ�����������Լ����и����������б�
void CAgent::GetAgents(vector<CAgent*>& m)
{
	m.push_back(this);
	if(!this->IsTopPraent())
	{
		this->m_pParent->GetAgents(m);
	}

}

//����ֱ�ӿͻ��ܸ���ӯ��ͳ��
void CAgent::UpdateBalance(double dlBalanceOld, double dlBalanceNew)
{
	if (fabs(dlBalanceOld - dlBalanceNew) < 0.01)
		return;

	m_csAgent.Lock();
	m_blBalanceUpdate = true;

	m_dlBalanceStat += (dlBalanceNew - dlBalanceOld);

	if (dlBalanceOld < 0)
	{
		m_dlLossStat -= dlBalanceOld;
	}
		
	if (dlBalanceNew < 0)
	{
		m_dlLossStat += dlBalanceNew;
	}
	m_csAgent.Unlock();

	if (0 != m_pParent)
		m_pParent->UpdateBalanceOther(dlBalanceOld, dlBalanceNew);
}

//������ӿͻ��ܸ���ӯ��ͳ��
void CAgent::UpdateBalanceOther(double dlBalanceOld, double dlBalanceNew)
{
	m_csAgent.Lock();
	m_blBalanceUpdate = true;

	m_dlBalanceStatOther += (dlBalanceNew - dlBalanceOld);
	if (dlBalanceOld < 0)
	{
		m_dlLossStatOther -= dlBalanceOld;
	}
		
	if (dlBalanceNew < 0)
	{
		m_dlLossStatOther += dlBalanceNew;
	}
	m_csAgent.Unlock();

	if (0 != m_pParent)
		m_pParent->UpdateBalanceOther(dlBalanceOld, dlBalanceNew);
}

//�ж��Ƿ��ܸ���ӯ��ͳ�Ƴ����仯��ֵ
bool CAgent::NotifyBalanceChanged(double dlRatio,int nType)
{
	bool blRtn = false;
	double dlRatioUsed = dlRatio;

	if (dlRatio <= 0)
		dlRatioUsed = 0.1;

	m_csAgent.Lock();
	if (m_blBalanceUpdate)
	{
		if (0 == nType)
		{
			if(fabs(m_dlBalanceStatOld) <= numeric_limits<double>::epsilon() && fabs(m_dlBalanceStat) > numeric_limits<double>::epsilon())
			{
				blRtn = true;
			}
			else if (dlRatio < fabs((m_dlBalanceStat - m_dlBalanceStatOld) / m_dlBalanceStatOld))
			{
				blRtn = true;
			}
		}
		else
		{
			if(fabs(m_dlBalanceStatOld + m_dlBalanceStatOtherOld) <= numeric_limits<double>::epsilon() && fabs(m_dlBalanceStat + m_dlBalanceStatOther) > numeric_limits<double>::epsilon())
			{
				blRtn = true;
			}
			else if (dlRatio < fabs((m_dlBalanceStat + m_dlBalanceStatOther - (m_dlBalanceStatOld + m_dlBalanceStatOtherOld)) / (m_dlBalanceStatOld + m_dlBalanceStatOtherOld)))
			{
				blRtn = true;
			}
		}
	
		if (blRtn)
		{
			m_dlBalanceStatOtherOld = m_dlBalanceStatOther;
			m_dlLossStatOtherOld = m_dlLossStatOther;
			m_dlBalanceStatOld = m_dlBalanceStat;
			m_dlLossStatOld = m_dlLossStat;

			m_blBalanceUpdate = false;
		}
	}
	m_csAgent.Unlock();

	return blRtn;
}

//����ֱ�ӿͻ���׷�����ͳ��
void CAgent::UpdateDebt(double dlDebtOld, double dlDebtNew)
{
	if (fabs(dlDebtOld - dlDebtNew) < 0.01)
		return;

	m_csAgent.Lock();	
	m_blDebtUpdate = true;
	m_dlDebtStat += (dlDebtNew - dlDebtOld);
	m_csAgent.Unlock();

	if (0 != m_pParent)
		m_pParent->UpdateDebtOther(dlDebtOld, dlDebtNew);
}

//������ӿͻ���׷�����ͳ��
void CAgent::UpdateDebtOther(double dlDebtOld, double dlDebtNew)
{
	m_csAgent.Lock();
	m_blDebtUpdate = true;
	m_dlDebtStatOther += (dlDebtNew - dlDebtOld);
	m_csAgent.Unlock();

	if (0 != m_pParent)
		m_pParent->UpdateDebtOther(dlDebtOld, dlDebtNew);
}

//�ж��Ƿ���׷�����ͳ�Ƴ����仯��ֵ
bool CAgent::NotifyDebtChanged(double dlRatio,int nType)
{
	bool blRtn = false;
	double dlRatioUsed = dlRatio;

	if (dlRatio <= 0)
		dlRatioUsed = 0.1;

	m_csAgent.Lock();
	if (m_blDebtUpdate)
	{
		if (0 == nType)
		{
			if(fabs(m_dlDebtStatOld) <= numeric_limits<double>::epsilon() && fabs(m_dlDebtStat) > numeric_limits<double>::epsilon())
			{
				blRtn = true;
			}
			else if (dlRatio < fabs((m_dlDebtStat - m_dlDebtStatOld) / m_dlDebtStatOld))
			{
				blRtn = true;
			}
		}
		else
		{
			if(fabs(m_dlDebtStatOld + m_dlDebtStatOtherOld) <= numeric_limits<double>::epsilon() && fabs(m_dlDebtStat + m_dlDebtStatOther) > numeric_limits<double>::epsilon())
			{
				blRtn = true;
			}
			else if (dlRatio < fabs((m_dlDebtStat + m_dlDebtStatOther - (m_dlDebtStatOld + m_dlDebtStatOtherOld)) / (m_dlDebtStatOld + m_dlDebtStatOtherOld)))
			{
				blRtn = true;
			}
		}
	
		if (blRtn)
		{
			m_dlDebtStatOld = m_dlDebtStat;
			m_dlDebtStatOtherOld = m_dlDebtStatOther;

			m_blDebtUpdate = false;
		}
	}
	m_csAgent.Unlock();

	return blRtn;
}

//���������Ϣ
string CAgent::ToString() 
{
	std::stringstream ss;
	ss << "ID=" << m_sID << "\r\n";;
	ss << fixed << setprecision(2);
	ss << "CapitalStat=" << m_dlCapitalStat << "\r\n";;
	ss << "MarginStat=" << m_dlMarginStat << "\r\n";;
	ss << "BalanceStat=" << m_dlBalanceStat << "\r\n";;
	ss << "LossStat=" << m_dlLossStat << "\r\n";;
	ss << "InCapitalTdyStat=" << m_dlInCapitalTdyStat << "\r\n";;
	ss << "OutCapitalTdyStat=" << m_dlOutCapitalTdyStat << "\r\n";;
	ss << "CapitalStatOther=" << m_dlCapitalStatOther << "\r\n";;
	ss << "MarginStatOther=" << m_dlMarginStatOther << "\r\n";;
	ss << "BalanceStatOther=" << m_dlBalanceStatOther << "\r\n";;
	ss << "LossStatOther=" << m_dlLossStatOther << "\r\n";;
	ss << "InCapitalTdyStatOther=" << m_dlInCapitalTdyStatOther << "\r\n";;
	ss << "OutCapitalTdyStatOther=" << m_dlOutCapitalTdyStatOther << "\r\n";;	
	
	
	map<unsigned short,RISK_GRADE_STAT>::iterator it;
	for (it = m_mapRiskGradeStat.begin(); it != m_mapRiskGradeStat.end(); ++it)
	{
		ss << "RiskGradeStat:" << (*it).second.usGrade << " " << (*it).second.nNum << "\r\n";;
	}
 
	for (it = m_mapRiskTypeStat.begin(); it != m_mapRiskTypeStat.end(); ++it)
	{
		ss << "RiskTypeStat:" << (*it).second.usGrade << " " <<  (*it).second.nNum << "\r\n";;
	}


	for (it = m_mapRiskGradeStatOther.begin(); it != m_mapRiskGradeStatOther.end(); ++it)
	{
		ss << "RiskGradeStatOther:" << (*it).second.usGrade << " " <<  (*it).second.nNum << "\r\n";;
	}

	for (it = m_mapRiskTypeStatOther.begin(); it != m_mapRiskTypeStatOther.end(); ++it)
	{
		ss << "RiskTypeStatOther:" << (*it).second.usGrade << " " <<  (*it).second.nNum << "\r\n";;
	}

	map<std::string,CCustomer*>::iterator it2;
	for (it2 = m_mapCust.begin(); it2 != m_mapCust.end(); ++it2)
	{
		ss << "inc customer:" << (*it2).second->CustAcctNo() << " " << (*it2).second->CustAbbr() << "\r\n";;
	}
	
	map<std::string,CAgent*>::const_iterator it3;
	for (it3 = m_mapChildAgent.begin(); it3 != m_mapChildAgent.end(); ++it3)
	{
		ss << "child agent:" << (*it3).second->ID() << " " << (*it3).second->GetName() << "\r\n";;
	}
	
	return ss.str();
}

string CAgent::GetAgentID()
{
	return m_sID;
}

string CAgent::GetAgenType()
{
	return m_sType;
}

string CAgent::GetAgentLevel()
{
	return m_sLevel;
}

double CAgent::GetSubAgentCapital(int nType/* = 1*/) const
{
	vector<CCustomer *> mapCustomers;
	vector<CCustomer *>::iterator it;
	double dlCapital = 0.0;

	GetCustomers(nType, mapCustomers);
	for(it = mapCustomers.begin(); it != mapCustomers.end(); ++it)
	{
		if ((*it)->RiskDegree2() > 1.0)
		{
			dlCapital += (*it)->Capital();
		}
	}

	return dlCapital;
}

double CAgent::GetSubAgentMarginMem(int nType /* = 1 */) const
{
	vector<CCustomer *> mapCustomers;
	vector<CCustomer *>::iterator it;
	double dlMarginMem = 0.0;

	GetCustomers(nType, mapCustomers);
	for (it = mapCustomers.begin(); it != mapCustomers.end(); ++it)
	{
		if ((*it)->RiskDegree2() > 1.0)
		{
			dlMarginMem += (*it)->MarginMem();
		}
	}

	return dlMarginMem;
}