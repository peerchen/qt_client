#include "FeeModelDetailTbl.h"
#include "Logger.h"
#include "FeeAlgorithmCapital.h"
#include "FeeAlgorithmVolume.h"
#include "FeeAlgorithmWeight.h"
#include "VersionMacro.h"

CFeeModelDetailTbl::CFeeModelDetailTbl()
{

}

CFeeModelDetailTbl::~CFeeModelDetailTbl()
{
	Finish();
}

//##ModelId=4913CC5B01D4
CFeeAlgorithm* CFeeModelDetailTbl::GetFeeAlgorithm(const string& sModelID, const string& sProdID, const string& sFeeType)
{
	CFeeAlgorithm* p = 0;
	CGessGuard guard(m_mutexTbl);
	map<string, FEE_MODEL_DETAIL >::iterator it = m_mapCustFeeDetail.find(sModelID + sProdID + sFeeType);
	if (it != m_mapCustFeeDetail.end())
	{
		p = it->second.pFeeAlgorithm;
	}
	return p;
}

int CFeeModelDetailTbl::GetFeeVal(const string& sModelID, const string& sProdID, const string& sFeeType,double& dlFeeVal)
{
	int nRtn = -1;
	CGessGuard guard(m_mutexTbl);
	map<string, FEE_MODEL_DETAIL >::iterator it = m_mapCustFeeDetail.find(sModelID + sProdID + sFeeType);
	if (it != m_mapCustFeeDetail.end())
	{
		dlFeeVal = it->second.dlValue;
		nRtn = 0;
	}
	return nRtn;
}

//##ModelId=4913CFA10167
int CFeeModelDetailTbl::ReInit(otl_connect& dbConnection)
{
	CGessGuard guard(m_mutexTbl);
	//��ռ���
	Finish();

	//��ʼ��
	Init(dbConnection);

	return 0;
}

//##ModelId=4916CB7A0000
int CFeeModelDetailTbl::Init(otl_connect& dbConnection)
{
	char cFareModel[21];			//����ģ��
	char cProdCode[11];			//��Լ����
	char cFareType[4];			//��������
	char cFareMode[3];			//�շ�ģʽ
	char cFareValue[25];		//����ֵ
	FEE_MODEL_DETAIL stFeeModelDetail;
	string sSql = "";

	memset(cFareModel, 0, sizeof(cFareModel));
	memset(cProdCode, 0, sizeof(cProdCode));
	memset(cFareType, 0, sizeof(cFareType));
	memset(cFareMode, 0, sizeof(cFareMode));
	memset(cFareValue, 0, sizeof(cFareValue));

	try
	{
		CGessGuard guard(m_mutexTbl);

#ifdef _VER_25_DB2
		sSql = "select fare_model_id, prod_code, fare_type_id, fare_mode, FG_CovToChar(fare_value) from fare_model_detail";
#else
		sSql = "select fare_model_id, prod_code, fare_type_id, fare_mode, to_char(fare_value) from fare_model_detail";
#endif

		otl_stream o(1, sSql.c_str(), dbConnection);

		while (!o.eof())
		{
			o >> cFareModel >> cProdCode >> cFareType >> cFareMode >> cFareValue;

			stFeeModelDetail.sFeeModelID = cFareModel;
			stFeeModelDetail.sProdCode = cProdCode;
			stFeeModelDetail.sFeeTypeID = cFareType;
			stFeeModelDetail.dlValue = atof(cFareValue);

			if (strcmp(cFareMode, "1") == 0)
			{
				stFeeModelDetail.pFeeAlgorithm = new CFeeAlgorithmCapital(atof(cFareValue));
			}
			else if (strcmp(cFareMode, "2") == 0)
			{
				stFeeModelDetail.pFeeAlgorithm = new CFeeAlgorithmWeight(atof(cFareValue));
			}
			else if (strcmp(cFareMode, "3") == 0)
			{
				stFeeModelDetail.pFeeAlgorithm = new CFeeAlgorithmVolume(atof(cFareValue));
			}			

			m_mapCustFeeDetail[stFeeModelDetail.sFeeModelID + stFeeModelDetail.sProdCode + stFeeModelDetail.sFeeTypeID] = stFeeModelDetail;			
		}
	}
	catch(otl_exception& p)
	{
		CRLog(E_ERROR,"otl exception:%s,%s,%s,%s",p.msg,p.stm_text,p.sqlstate,p.var_info);
	}

	return 0;
}

//��������
void CFeeModelDetailTbl::Finish()
{
	try
	{
		CGessGuard guard(m_mutexTbl);
		map<string, FEE_MODEL_DETAIL >::iterator it = m_mapCustFeeDetail.begin();
		for ( ; it != m_mapCustFeeDetail.end(); it++)
		{
			delete it->second.pFeeAlgorithm;
			it->second.pFeeAlgorithm = 0;
		}
		m_mapCustFeeDetail.clear();
	}
	catch(...)
	{
		CRLog(E_ERROR,"%s","CFeeModelDetailTbl error!");
		
	}
}

